import { base44 } from './base44Client';


export const ServiceCall = base44.entities.ServiceCall;

export const Part = base44.entities.Part;

export const UsedPart = base44.entities.UsedPart;

export const BowlingAlley = base44.entities.BowlingAlley;

export const ScheduledMaintenance = base44.entities.ScheduledMaintenance;

export const UserSchedule = base44.entities.UserSchedule;

export const PreventativeMaintenanceTask = base44.entities.PreventativeMaintenanceTask;

export const PreventativeMaintenanceLog = base44.entities.PreventativeMaintenanceLog;

export const Permission = base44.entities.Permission;

export const Role = base44.entities.Role;

export const ScheduleTemplate = base44.entities.ScheduleTemplate;

export const RoleAuditLog = base44.entities.RoleAuditLog;

export const Notification = base44.entities.Notification;

export const MachineRepairLog = base44.entities.MachineRepairLog;

export const RecurringMaintenanceSchedule = base44.entities.RecurringMaintenanceSchedule;

export const MaintenanceTaskCatalog = base44.entities.MaintenanceTaskCatalog;

export const TimeOffRequest = base44.entities.TimeOffRequest;

export const ShiftTradeRequest = base44.entities.ShiftTradeRequest;

export const PerformanceReview = base44.entities.PerformanceReview;

export const EmployeeAvailability = base44.entities.EmployeeAvailability;

export const RecurringSchedule = base44.entities.RecurringSchedule;

export const TimeEntry = base44.entities.TimeEntry;

export const DevelopmentPlan = base44.entities.DevelopmentPlan;

export const SkillGoal = base44.entities.SkillGoal;

export const TrainingModule = base44.entities.TrainingModule;

export const TrainingAssignment = base44.entities.TrainingAssignment;

export const OnboardingTemplate = base44.entities.OnboardingTemplate;

export const OnboardingChecklist = base44.entities.OnboardingChecklist;

export const OnboardingTask = base44.entities.OnboardingTask;

export const OnboardingResource = base44.entities.OnboardingResource;

export const Message = base44.entities.Message;

export const SkillCertification = base44.entities.SkillCertification;

export const Machine = base44.entities.Machine;

export const CustomerFeedback = base44.entities.CustomerFeedback;

export const LoyaltyProgram = base44.entities.LoyaltyProgram;

export const CustomerLoyalty = base44.entities.CustomerLoyalty;

export const Channel = base44.entities.Channel;

export const RepairLogPart = base44.entities.RepairLogPart;

export const TaskTemplate = base44.entities.TaskTemplate;

export const ScheduledTask = base44.entities.ScheduledTask;



// auth sdk:
export const User = base44.auth;