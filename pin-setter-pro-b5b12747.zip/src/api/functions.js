import { base44 } from './base44Client';


export const exportServiceHistory = base44.functions.exportServiceHistory;

export const exportMachineRepairLog = base44.functions.exportMachineRepairLog;

export const exportData = base44.functions.exportData;

export const generateWeeklyReport = base44.functions.generateWeeklyReport;

export const sendScheduleNotifications = base44.functions.sendScheduleNotifications;

