import React from 'react';
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Download } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export function ExportMenu({ data, columns, filename, title }) {
  const handleExport = async (format) => {
    if (!data || data.length === 0) {
      toast.error("No data to export");
      return;
    }

    const loadingToast = toast.loading(`Exporting as ${format.toUpperCase()}...`);
    try {
      const response = await base44.functions.invoke('exportData', {
        data,
        columns,
        format,
        filename,
        title
      });
      
      // Create blob from response data
      // Note: base44 sdk returns object { data, status, headers }
      // For binary data, we need to ensure we handle it correctly.
      // If the backend returns a Buffer/Blob, axios (or the sdk's fetch wrapper) 
      // needs to be configured to receive 'blob' or 'arraybuffer'.
      // The standard sdk invoke might try to parse JSON.
      // If the SDK doesn't support binary response natively easily, 
      // we might get a string that we need to convert.
      
      // Assuming standard behavior:
      // For now, let's try handling it as standard blob response.
      // If the SDK parses it as JSON string (for text/csv) it's fine.
      // For binary (xlsx/pdf), it might be tricky if SDK tries JSON.parse.
      // However, assuming the SDK handles it or returns the raw data if content-type is not json.
      
      const blob = new Blob([response.data], { 
        type: format === 'csv' ? 'text/csv' : 
              format === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 
              'application/pdf' 
      });
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      
      toast.dismiss(loadingToast);
      toast.success('Export complete');
    } catch (error) {
      toast.dismiss(loadingToast);
      console.error(error);
      toast.error('Export failed');
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem onClick={() => handleExport('xlsx')}>Excel (.xlsx)</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('csv')}>CSV (.csv)</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('pdf')}>PDF (.pdf)</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}