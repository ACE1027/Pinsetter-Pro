import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Search, Wrench, Package, User, Building2, Loader2 } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";
import { Badge } from "@/components/ui/badge";

export default function GlobalSearch({ open, onOpenChange }) {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ serviceCalls: [], parts: [], users: [], locations: [] });
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setResults({ serviceCalls: [], parts: [], users: [], locations: [] });
      return;
    }

    const searchTimer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const [serviceCalls, parts, users, locations] = await Promise.all([
          base44.entities.ServiceCall.list().catch(() => []),
          base44.entities.Part.list().catch(() => []),
          base44.entities.User.list().catch(() => []),
          base44.entities.BowlingAlley.list().catch(() => []),
        ]);

        const q = query.toLowerCase();
        
        setResults({
          serviceCalls: serviceCalls.filter(sc => 
            sc.title?.toLowerCase().includes(q) ||
            sc.lane_number?.toLowerCase().includes(q) ||
            sc.description?.toLowerCase().includes(q)
          ).slice(0, 5),
          parts: parts.filter(p => 
            p.name?.toLowerCase().includes(q) ||
            p.part_number?.toLowerCase().includes(q) ||
            p.description?.toLowerCase().includes(q)
          ).slice(0, 5),
          users: users.filter(u => 
            u.display_name?.toLowerCase().includes(q) ||
            u.full_name?.toLowerCase().includes(q) ||
            u.email?.toLowerCase().includes(q) ||
            u.position?.toLowerCase().includes(q)
          ).slice(0, 5),
          locations: locations.filter(l => 
            l.name?.toLowerCase().includes(q) ||
            l.city?.toLowerCase().includes(q) ||
            l.address?.toLowerCase().includes(q)
          ).slice(0, 5),
        });
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(searchTimer);
  }, [query]);

  const handleNavigate = (type, id, email) => {
    onOpenChange(false);
    setQuery("");
    
    switch(type) {
      case 'serviceCall':
        navigate(createPageUrl("ServiceCallDetail") + `?id=${id}`);
        break;
      case 'part':
        navigate(createPageUrl("PartsInventory") + `?highlight=${id}`);
        break;
      case 'user':
        navigate(createPageUrl("EmployeeProfile") + `?email=${email}`);
        break;
      case 'location':
        navigate(createPageUrl("Locations") + `?id=${id}`);
        break;
    }
  };

  const totalResults = results.serviceCalls.length + results.parts.length + results.users.length + results.locations.length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`max-w-2xl ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
        <DialogHeader>
          <DialogTitle className={isDarkMode ? 'text-slate-100' : ''}>Search</DialogTitle>
        </DialogHeader>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search service calls, parts, users, locations..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
            autoFocus
          />
          {isSearching && (
            <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400 animate-spin" />
          )}
        </div>

        <div className="max-h-96 overflow-y-auto space-y-4">
          {!query.trim() ? (
            <p className={`text-center py-8 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Start typing to search...
            </p>
          ) : totalResults === 0 && !isSearching ? (
            <p className={`text-center py-8 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              No results found
            </p>
          ) : (
            <>
              {results.serviceCalls.length > 0 && (
                <div>
                  <h3 className={`text-sm font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    Service Calls
                  </h3>
                  <div className="space-y-1">
                    {results.serviceCalls.map((sc) => (
                      <button
                        key={sc.id}
                        onClick={() => handleNavigate('serviceCall', sc.id)}
                        className={`w-full text-left p-3 rounded-lg hover:bg-blue-50 ${isDarkMode ? 'hover:bg-slate-800' : ''} transition-colors flex items-center gap-3`}
                      >
                        <Wrench className="w-4 h-4 text-blue-600 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className={`font-medium truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{sc.title}</p>
                          <p className={`text-sm truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Lane {sc.lane_number}</p>
                        </div>
                        <Badge variant="outline" className="text-xs">{sc.status}</Badge>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {results.parts.length > 0 && (
                <div>
                  <h3 className={`text-sm font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    Parts
                  </h3>
                  <div className="space-y-1">
                    {results.parts.map((part) => (
                      <button
                        key={part.id}
                        onClick={() => handleNavigate('part', part.id)}
                        className={`w-full text-left p-3 rounded-lg hover:bg-blue-50 ${isDarkMode ? 'hover:bg-slate-800' : ''} transition-colors flex items-center gap-3`}
                      >
                        <Package className="w-4 h-4 text-green-600 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className={`font-medium truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{part.name}</p>
                          <p className={`text-sm truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{part.part_number}</p>
                        </div>
                        <Badge variant="outline" className="text-xs">Stock: {part.quantity_in_stock}</Badge>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {results.users.length > 0 && (
                <div>
                  <h3 className={`text-sm font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    Users
                  </h3>
                  <div className="space-y-1">
                    {results.users.map((user) => (
                      <button
                        key={user.id}
                        onClick={() => handleNavigate('user', null, user.email)}
                        className={`w-full text-left p-3 rounded-lg hover:bg-blue-50 ${isDarkMode ? 'hover:bg-slate-800' : ''} transition-colors flex items-center gap-3`}
                      >
                        <User className="w-4 h-4 text-purple-600 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className={`font-medium truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            {user.display_name || user.full_name || user.email}
                          </p>
                          <p className={`text-sm truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                            {user.position?.replace(/_/g, ' ') || user.department}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {results.locations.length > 0 && (
                <div>
                  <h3 className={`text-sm font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    Locations
                  </h3>
                  <div className="space-y-1">
                    {results.locations.map((location) => (
                      <button
                        key={location.id}
                        onClick={() => handleNavigate('location', location.id)}
                        className={`w-full text-left p-3 rounded-lg hover:bg-blue-50 ${isDarkMode ? 'hover:bg-slate-800' : ''} transition-colors flex items-center gap-3`}
                      >
                        <Building2 className="w-4 h-4 text-orange-600 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className={`font-medium truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{location.name}</p>
                          <p className={`text-sm truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{location.city}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}