import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";

const LocationContext = createContext();

export function LocationProvider({ children }) {
  const [selectedLocationId, setSelectedLocationId] = useState(() => {
    // Load from localStorage on initial mount
    if (typeof window !== 'undefined') {
      return localStorage.getItem('selectedLocationId') || null;
    }
    return null;
  });
  const [userDefaultSet, setUserDefaultSet] = useState(false);

  // Auto-set to user's assigned location on mount
  useEffect(() => {
    if (!userDefaultSet) {
      base44.auth.me().then(user => {
        if (user?.bowling_alley_id && !selectedLocationId) {
          setSelectedLocationId(user.bowling_alley_id);
          localStorage.setItem('selectedLocationId', user.bowling_alley_id);
        }
        setUserDefaultSet(true);
      }).catch(() => {
        setUserDefaultSet(true);
      });
    }
  }, [userDefaultSet, selectedLocationId]);

  useEffect(() => {
    // Save to localStorage whenever it changes
    if (selectedLocationId) {
      localStorage.setItem('selectedLocationId', selectedLocationId);
    } else {
      localStorage.removeItem('selectedLocationId');
    }
  }, [selectedLocationId]);

  const value = {
    selectedLocationId,
    setSelectedLocationId,
  };

  return (
    <LocationContext.Provider value={value}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation() {
  const context = useContext(LocationContext);
  if (!context) {
    throw new Error('useLocation must be used within LocationProvider');
  }
  return context;
}