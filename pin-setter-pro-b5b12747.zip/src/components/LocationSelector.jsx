import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, MapPin } from 'lucide-react';
import { useLocation } from './LocationContext';

export default function LocationSelector() {
  const [user, setUser] = useState(null);
  const { selectedLocationId, setSelectedLocationId } = useLocation();

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      // If user has a default location and nothing is selected, use their location
      if (u.bowling_alley_id && !selectedLocationId) {
        setSelectedLocationId(u.bowling_alley_id);
      }
    }).catch(() => {});
  }, []);

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const isAdmin = user && user.role === 'admin';

  // Only admins can switch locations
  if (!isAdmin) {
    return null;
  }

  // Filter active locations
  const visibleLocations = locations.filter(l => l.active !== false);
  const selectedLocation = locations.find(l => l.id === selectedLocationId);

  // Don't show selector if only one location exists
  if (visibleLocations.length <= 1) {
    return null;
  }

  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-2">
        <MapPin className="w-4 h-4 text-slate-500" />
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          View Location
        </span>
      </div>
      <Select value={selectedLocationId || ""} onValueChange={setSelectedLocationId}>
        <SelectTrigger className="w-full bg-white hover:bg-slate-50 transition-colors">
          <SelectValue>
            {selectedLocation ? (
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span className="font-medium">{selectedLocation.name}</span>
              </div>
            ) : (
              <span className="text-slate-500">Select a location...</span>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-400" />
              <span className="font-medium">All Locations</span>
            </div>
          </SelectItem>
          {visibleLocations.map(location => (
            <SelectItem key={location.id} value={location.id}>
              <div className="flex flex-col">
                <span className="font-medium">{location.name}</span>
                {location.city && (
                  <span className="text-xs text-slate-500">{location.city}, {location.state}</span>
                )}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}