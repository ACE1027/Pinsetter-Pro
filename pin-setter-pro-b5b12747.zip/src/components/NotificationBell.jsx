import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger } from
'@/components/ui/popover';
import NotificationPanel from './notifications/NotificationPanel';
import { useTheme } from '@/components/ThemeContext';
import { playSound, SOUND_TYPES } from './sounds/SoundManager';

export default function NotificationBell() {
  const { isDarkMode } = useTheme();
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const [previousUnreadCount, setPreviousUnreadCount] = React.useState(0);

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const all = await base44.entities.Notification.list('-created_date');
      return all.filter((n) => n.user_email === user.email);
    },
    enabled: !!user?.email,
    refetchInterval: 5000
  });

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  // Play sound when new notifications arrive
  React.useEffect(() => {
    if (unreadCount > previousUnreadCount && previousUnreadCount > 0) {
      playSound(SOUND_TYPES.NOTIFICATION, user?.sound_preferences);
    }
    setPreviousUnreadCount(unreadCount);
  }, [unreadCount, user?.sound_preferences]);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="text-slate-400 text-sm font-medium rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover:bg-accent hover:text-accent-foreground h-9 w-9 relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 &&
          <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-600 text-white text-xs">
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          }
        </Button>
      </PopoverTrigger>
      <PopoverContent className={`w-96 p-4 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`} align="end">
        <NotificationPanel user={user} compact />
      </PopoverContent>
    </Popover>);

}