import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export function useNotifications() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }
  }, []);

  const requestPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      try {
        const permission = await Notification.requestPermission();
        setNotificationsEnabled(permission === 'granted');
        if (permission === 'granted') {
          toast.success('Push notifications enabled for mobile and desktop');
        } else {
          toast.error('Notification permission denied');
        }
      } catch (error) {
        console.error('Permission request error:', error);
      }
    }
  };

  const sendNotification = (title, options = {}) => {
    if (!notificationsEnabled || typeof Notification === 'undefined') return;

    const defaultOptions = {
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      requireInteraction: true,
      vibrate: [200, 100, 200],
      ...options,
    };

    try {
      if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window) {
        // Try service worker notification (better for mobile)
        navigator.serviceWorker.ready.then((registration) => {
          registration.showNotification(title, defaultOptions).catch(() => {
            // Fallback to regular notification
            new Notification(title, defaultOptions);
          });
        }).catch(() => {
          // Fallback to regular notification
          new Notification(title, defaultOptions);
        });
      } else {
        // Regular notification
        new Notification(title, defaultOptions);
      }
    } catch (error) {
      console.error('Notification error:', error);
    }
  };

  return {
    notificationsEnabled,
    requestPermission,
    sendNotification,
    user,
  };
}

export function NotificationPrompt({ onEnable }) {
  const { notificationsEnabled, requestPermission } = useNotifications();

  if (notificationsEnabled || typeof window === 'undefined' || !('Notification' in window)) return null;

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0">
          <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-semibold text-blue-900 mb-1">Enable Push Notifications</h3>
          <p className="text-xs text-blue-700 mb-2">
            Get instant alerts for urgent service calls, schedule changes, and low inventory on your mobile device.
          </p>
          <button
            onClick={() => {
              requestPermission();
              if (onEnable) onEnable();
            }}
            className="text-xs font-medium text-blue-600 hover:text-blue-800 underline"
          >
            Enable Notifications
          </button>
        </div>
      </div>
    </div>
  );
}