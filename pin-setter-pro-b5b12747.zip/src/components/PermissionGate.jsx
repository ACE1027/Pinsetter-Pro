import React from 'react';
import { hasPermission, hasAnyPermission, hasAllPermissions } from './permissions/permissions';

/**
 * Component that conditionally renders children based on user permissions
 * 
 * Usage:
 * <PermissionGate user={user} permission="service_calls.create">
 *   <Button>Create Service Call</Button>
 * </PermissionGate>
 * 
 * <PermissionGate user={user} anyOf={["users.view", "users.create"]}>
 *   <UserManagementButton />
 * </PermissionGate>
 */
export default function PermissionGate({ 
  user, 
  permission, 
  anyOf, 
  allOf, 
  children, 
  fallback = null 
}) {
  let hasAccess = false;

  if (permission) {
    hasAccess = hasPermission(user, permission);
  } else if (anyOf) {
    hasAccess = hasAnyPermission(user, anyOf);
  } else if (allOf) {
    hasAccess = hasAllPermissions(user, allOf);
  }

  return hasAccess ? <>{children}</> : fallback;
}