import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";

const ThemeContext = createContext();

export const THEMES = {
  default: {
    id: 'default',
    name: 'Default',
    light: {
      bg: 'bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100',
      cardBg: 'bg-white/80 backdrop-blur-sm',
      cardBorder: 'border-slate-200',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-blue-100',
      navActive: 'bg-blue-600',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950',
      cardBg: 'bg-slate-800/90 backdrop-blur-sm',
      cardBorder: 'border-slate-700',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-slate-700',
      navActive: 'bg-slate-700',
    }
  },
  ocean: {
    id: 'ocean',
    name: 'Ocean',
    light: {
      bg: 'bg-gradient-to-br from-cyan-50 via-blue-100 to-indigo-100',
      cardBg: 'bg-white/70 backdrop-blur-md',
      cardBorder: 'border-blue-200/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-blue-200',
      navActive: 'bg-blue-500',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950',
      cardBg: 'bg-slate-800/80 backdrop-blur-md',
      cardBorder: 'border-blue-800/50',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-blue-900/50',
      navActive: 'bg-blue-800',
    }
  },
  sunset: {
    id: 'sunset',
    name: 'Sunset',
    light: {
      bg: 'bg-gradient-to-br from-orange-50 via-rose-50 to-purple-100',
      cardBg: 'bg-white/70 backdrop-blur-md',
      cardBorder: 'border-rose-200/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-rose-200',
      navActive: 'bg-rose-500',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-900 via-rose-950 to-purple-950',
      cardBg: 'bg-slate-800/80 backdrop-blur-md',
      cardBorder: 'border-rose-800/50',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-rose-900/50',
      navActive: 'bg-rose-700',
    }
  },
  forest: {
    id: 'forest',
    name: 'Forest',
    light: {
      bg: 'bg-gradient-to-br from-emerald-50 via-green-100 to-teal-100',
      cardBg: 'bg-white/70 backdrop-blur-md',
      cardBorder: 'border-emerald-200/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-emerald-200',
      navActive: 'bg-emerald-600',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-950',
      cardBg: 'bg-slate-800/80 backdrop-blur-md',
      cardBorder: 'border-emerald-800/50',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-emerald-900/50',
      navActive: 'bg-emerald-700',
    }
  },
  purple: {
    id: 'purple',
    name: 'Purple',
    light: {
      bg: 'bg-gradient-to-br from-purple-50 via-violet-100 to-indigo-100',
      cardBg: 'bg-white/70 backdrop-blur-md',
      cardBorder: 'border-purple-200/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-purple-200',
      navActive: 'bg-purple-600',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-900 via-purple-950 to-indigo-950',
      cardBg: 'bg-slate-800/80 backdrop-blur-md',
      cardBorder: 'border-purple-800/50',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-purple-900/50',
      navActive: 'bg-purple-700',
    }
  },
  amber: {
    id: 'amber',
    name: 'Amber',
    light: {
      bg: 'bg-gradient-to-br from-amber-50 via-yellow-100 to-orange-100',
      cardBg: 'bg-white/70 backdrop-blur-md',
      cardBorder: 'border-amber-200/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-amber-200',
      navActive: 'bg-amber-500',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-900 via-amber-950 to-orange-950',
      cardBg: 'bg-slate-800/80 backdrop-blur-md',
      cardBorder: 'border-amber-800/50',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-amber-900/50',
      navActive: 'bg-amber-700',
    }
  },
  rose: {
    id: 'rose',
    name: 'Rose',
    light: {
      bg: 'bg-gradient-to-br from-rose-50 via-pink-100 to-red-100',
      cardBg: 'bg-white/70 backdrop-blur-md',
      cardBorder: 'border-rose-200/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-rose-200',
      navActive: 'bg-rose-500',
    },
    dark: {
      bg: 'bg-gradient-to-br from-slate-900 via-rose-950 to-red-950',
      cardBg: 'bg-slate-800/80 backdrop-blur-md',
      cardBorder: 'border-rose-800/50',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-rose-900/50',
      navActive: 'bg-rose-700',
    }
  },
  slate: {
    id: 'slate',
    name: 'Slate',
    light: {
      bg: 'bg-gradient-to-br from-slate-100 via-slate-200 to-slate-300',
      cardBg: 'bg-white/60 backdrop-blur-md',
      cardBorder: 'border-slate-300/50',
      text: 'text-slate-900',
      textSecondary: 'text-slate-700',
      textTertiary: 'text-slate-600',
      navHover: 'hover:bg-slate-300',
      navActive: 'bg-slate-500',
    },
    dark: {
      bg: 'bg-gradient-to-br from-gray-900 via-gray-800 to-slate-900',
      cardBg: 'bg-gray-800/90 backdrop-blur-sm',
      cardBorder: 'border-gray-700',
      text: 'text-slate-50',
      textSecondary: 'text-slate-200',
      textTertiary: 'text-slate-300',
      navHover: 'hover:bg-gray-700',
      navActive: 'bg-gray-600',
    }
  },
};

export function ThemeProvider({ children }) {
  const [user, setUser] = useState(null);
  const [currentThemeName, setCurrentThemeName] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('themeName');
      return saved || 'default';
    }
    return 'default';
  });

  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('darkMode');
      return saved === 'true';
    }
    return true;
  });

  // Load user and their theme preferences
  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u.theme_name) {
        setCurrentThemeName(u.theme_name);
        localStorage.setItem('themeName', u.theme_name);
      }
      if (typeof u.dark_mode === 'boolean') {
        setIsDarkMode(u.dark_mode);
        localStorage.setItem('darkMode', u.dark_mode.toString());
      }
    }).catch(() => {});
  }, []);

  // Save to user profile when theme changes
  useEffect(() => {
    if (user) {
      base44.auth.updateMe({ theme_name: currentThemeName }).catch(() => {});
    }
    localStorage.setItem('themeName', currentThemeName);
  }, [currentThemeName, user]);

  // Save to user profile when dark mode changes
  useEffect(() => {
    if (user) {
      base44.auth.updateMe({ dark_mode: isDarkMode }).catch(() => {});
    }
    localStorage.setItem('darkMode', isDarkMode.toString());
  }, [isDarkMode, user]);

  const themeConfig = THEMES[currentThemeName];
  const theme = isDarkMode ? themeConfig?.dark : themeConfig?.light;

  const changeTheme = (themeId) => {
    setCurrentThemeName(themeId);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  return (
    <ThemeContext.Provider value={{ theme, isDarkMode, currentTheme: currentThemeName, changeTheme, toggleDarkMode }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}