import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, CheckCircle2, Wrench, Calendar, Package, User, Clock } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { useTheme } from "@/components/ThemeContext";

export default function LiveActivityFeed({ locationId }) {
  const { theme, isDarkMode } = useTheme();

  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-updated_date', 20),
    refetchInterval: 10000,
  });

  const { data: maintenanceLogs = [] } = useQuery({
    queryKey: ['maintenanceLogs'],
    queryFn: () => base44.entities.PreventativeMaintenanceLog.list('-completed_date', 20),
    refetchInterval: 10000,
  });

  const { data: timeEntries = [] } = useQuery({
    queryKey: ['timeEntries'],
    queryFn: () => base44.entities.TimeEntry.list('-clock_in', 20),
    refetchInterval: 10000,
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const getUserName = (email) => {
    const user = users.find(u => u.email === email);
    return user?.display_name || user?.full_name || email;
  };

  // Filter by location if specified
  const filterByLocation = (item) => {
    if (locationId === 'all') return true;
    return item.bowling_alley_id === locationId;
  };

  // Build activity feed
  const activities = [];

  // Recent service calls
  serviceCalls.filter(filterByLocation).forEach(call => {
    activities.push({
      id: `service-${call.id}`,
      type: 'service_call',
      timestamp: call.updated_date || call.created_date,
      user: call.assigned_to || call.created_by,
      action: call.status === 'completed' ? 'completed' : call.status === 'in_progress' ? 'started work on' : 'created',
      details: `${call.title} - Lane ${call.lane_number}`,
      priority: call.priority,
      status: call.status,
      icon: Wrench,
      color: call.status === 'completed' ? 'text-green-600' : call.priority === 'urgent' ? 'text-red-600' : 'text-blue-600'
    });
  });

  // Recent maintenance completions
  maintenanceLogs.filter(filterByLocation).forEach(log => {
    activities.push({
      id: `maintenance-${log.id}`,
      type: 'maintenance',
      timestamp: log.completed_date,
      user: log.created_by,
      action: 'completed',
      details: `${log.period} maintenance: ${log.task_text}`,
      icon: CheckCircle2,
      color: 'text-green-600'
    });
  });

  // Active time entries
  const activeEntries = timeEntries.filter(filterByLocation).filter(e => !e.clock_out);
  activeEntries.forEach(entry => {
    activities.push({
      id: `time-${entry.id}`,
      type: 'clock_in',
      timestamp: entry.clock_in,
      user: entry.user_email,
      action: 'clocked in',
      details: 'Currently on shift',
      icon: Clock,
      color: 'text-blue-600',
      active: true
    });
  });

  // Sort by most recent
  activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  // Get unique active users (clocked in within last hour)
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const activeUsers = new Set();
  activities.forEach(activity => {
    if (new Date(activity.timestamp) > oneHourAgo && activity.user) {
      activeUsers.add(activity.user);
    }
  });

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            <Activity className="w-5 h-5 text-blue-600" />
            Live Activity Feed
          </CardTitle>
          <Badge className="bg-green-100 text-green-800">
            {activeUsers.size} active
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-[500px] overflow-y-auto">
          {activities.length > 0 ? (
            <div className="divide-y">
              {activities.slice(0, 15).map((activity) => {
                const Icon = activity.icon;
                return (
                  <div 
                    key={activity.id} 
                    className={`p-4 hover:bg-slate-50 transition-colors ${
                      activity.active ? 'bg-blue-50 border-l-4 border-blue-500' : ''
                    } ${isDarkMode && !activity.active ? 'hover:bg-slate-800' : ''}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${
                        activity.active ? 'bg-blue-100' : 
                        activity.status === 'completed' ? 'bg-green-100' : 
                        'bg-slate-100'
                      }`}>
                        <Icon className={`w-4 h-4 ${activity.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            {getUserName(activity.user)}
                            <span className={`font-normal ml-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              {activity.action}
                            </span>
                          </p>
                          {activity.active && (
                            <Badge className="bg-green-500 text-white text-xs">
                              Active
                            </Badge>
                          )}
                        </div>
                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'} mb-1`}>
                          {activity.details}
                        </p>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-slate-500">
                            {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                          </span>
                          {activity.priority && (
                            <Badge className={`text-xs ${
                              activity.priority === 'urgent' ? 'bg-red-100 text-red-800' :
                              activity.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {activity.priority}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center">
              <Activity className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
              <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No recent activity</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}