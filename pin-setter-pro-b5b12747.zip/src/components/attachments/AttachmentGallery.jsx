import React from "react";
import { Image as ImageIcon, Video, ExternalLink } from "lucide-react";

const TAG_COLORS = {
  before: "bg-yellow-100 text-yellow-800",
  during: "bg-blue-100 text-blue-800",
  after: "bg-green-100 text-green-800"
};

const TAG_LABELS = {
  before: "Before",
  during: "During",
  after: "After/Completion"
};

export default function AttachmentGallery({ attachments = [], isDarkMode = false }) {
  if (!attachments || attachments.length === 0) return null;

  // Group attachments by tag
  const groupedAttachments = {
    before: attachments.filter(a => a.tag === 'before'),
    during: attachments.filter(a => a.tag === 'during'),
    after: attachments.filter(a => a.tag === 'after')
  };

  const renderAttachment = (file, index) => (
    <a 
      key={index} 
      href={file.url} 
      target="_blank" 
      rel="noopener noreferrer"
      className="relative group block"
    >
      <div className="relative rounded-lg overflow-hidden border-2 border-slate-200 hover:border-blue-400 transition-colors">
        {file.type === 'image' ? (
          <img 
            src={file.url} 
            alt={file.name || `Attachment ${index + 1}`}
            className="w-full h-32 object-cover"
          />
        ) : file.type === 'video' ? (
          <div className="w-full h-32 bg-slate-800 flex items-center justify-center">
            <Video className="w-8 h-8 text-slate-300" />
          </div>
        ) : (
          <div className="w-full h-32 bg-slate-100 flex items-center justify-center">
            <span className="text-sm text-slate-600 truncate px-2">{file.name}</span>
          </div>
        )}
        
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity flex items-center justify-center">
          <ExternalLink className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
        
        <div className={`absolute top-2 left-2 px-2 py-1 rounded text-xs font-medium ${TAG_COLORS[file.tag]}`}>
          {file.type === 'image' && <ImageIcon className="w-3 h-3 inline mr-1" />}
          {file.type === 'video' && <Video className="w-3 h-3 inline mr-1" />}
          {TAG_LABELS[file.tag]}
        </div>
      </div>
    </a>
  );

  const hasGroupedItems = groupedAttachments.before.length > 0 || groupedAttachments.during.length > 0 || groupedAttachments.after.length > 0;

  return (
    <div className={`mt-6 pt-4 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
      <h4 className={`text-sm font-medium mb-4 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
        Attachments ({attachments.length})
      </h4>

      {hasGroupedItems ? (
        <div className="space-y-4">
          {groupedAttachments.before.length > 0 && (
            <div>
              <h5 className="text-xs font-semibold text-yellow-700 mb-2 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                Before ({groupedAttachments.before.length})
              </h5>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {groupedAttachments.before.map((file, idx) => renderAttachment(file, `before-${idx}`))}
              </div>
            </div>
          )}

          {groupedAttachments.during.length > 0 && (
            <div>
              <h5 className="text-xs font-semibold text-blue-700 mb-2 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                During ({groupedAttachments.during.length})
              </h5>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {groupedAttachments.during.map((file, idx) => renderAttachment(file, `during-${idx}`))}
              </div>
            </div>
          )}

          {groupedAttachments.after.length > 0 && (
            <div>
              <h5 className="text-xs font-semibold text-green-700 mb-2 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                After/Completion ({groupedAttachments.after.length})
              </h5>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {groupedAttachments.after.map((file, idx) => renderAttachment(file, `after-${idx}`))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {attachments.map((file, idx) => renderAttachment(file, idx))}
        </div>
      )}
    </div>
  );
}