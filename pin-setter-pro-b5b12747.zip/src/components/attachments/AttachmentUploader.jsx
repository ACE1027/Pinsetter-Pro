import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, X, Image as ImageIcon, Video, Loader2 } from "lucide-react";
import { toast } from "sonner";

const TAG_COLORS = {
  before: "bg-yellow-100 text-yellow-800 border-yellow-300",
  during: "bg-blue-100 text-blue-800 border-blue-300",
  after: "bg-green-100 text-green-800 border-green-300"
};

const TAG_LABELS = {
  before: "Before",
  during: "During",
  after: "After/Completion"
};

export default function AttachmentUploader({ attachments = [], onChange, disabled = false }) {
  const [uploading, setUploading] = useState(false);
  const [selectedTag, setSelectedTag] = useState("before");

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const uploadPromises = files.map(async (file) => {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return {
          url: file_url,
          name: file.name,
          type: file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'file',
          tag: selectedTag
        };
      });

      const uploadedFiles = await Promise.all(uploadPromises);
      onChange([...attachments, ...uploadedFiles]);
      toast.success(`${uploadedFiles.length} file(s) uploaded successfully`);
    } catch (error) {
      toast.error('Failed to upload files');
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const removeAttachment = (index) => {
    onChange(attachments.filter((_, i) => i !== index));
  };

  const updateAttachmentTag = (index, newTag) => {
    const updated = [...attachments];
    updated[index] = { ...updated[index], tag: newTag };
    onChange(updated);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <Label className="text-sm mb-2 block">Upload Tag</Label>
          <Select value={selectedTag} onValueChange={setSelectedTag} disabled={disabled}>
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="before">Before</SelectItem>
              <SelectItem value="during">During</SelectItem>
              <SelectItem value="after">After/Completion</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-end">
          <input
            type="file"
            id="attachment-upload"
            multiple
            accept="image/*,video/*"
            onChange={handleFileUpload}
            className="hidden"
            disabled={disabled || uploading}
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => document.getElementById('attachment-upload').click()}
            disabled={disabled || uploading}
            className="w-full sm:w-auto"
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Upload Files
              </>
            )}
          </Button>
        </div>
      </div>

      {attachments.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {attachments.map((file, index) => (
            <div key={index} className="relative group">
              <div className={`relative rounded-lg overflow-hidden border-2 ${TAG_COLORS[file.tag] || 'border-slate-200'}`}>
                {file.type === 'image' ? (
                  <img 
                    src={file.url} 
                    alt={file.name || `Attachment ${index + 1}`}
                    className="w-full h-32 object-cover"
                  />
                ) : file.type === 'video' ? (
                  <div className="w-full h-32 bg-slate-800 flex items-center justify-center">
                    <Video className="w-8 h-8 text-slate-300" />
                  </div>
                ) : (
                  <div className="w-full h-32 bg-slate-100 flex items-center justify-center">
                    <span className="text-sm text-slate-600 truncate px-2">{file.name}</span>
                  </div>
                )}
                
                {/* Tag Badge */}
                <div className={`absolute top-2 left-2 px-2 py-1 rounded text-xs font-medium ${TAG_COLORS[file.tag]}`}>
                  {file.type === 'image' && <ImageIcon className="w-3 h-3 inline mr-1" />}
                  {file.type === 'video' && <Video className="w-3 h-3 inline mr-1" />}
                  {TAG_LABELS[file.tag]}
                </div>

                {/* Remove Button */}
                {!disabled && (
                  <Button
                    type="button"
                    size="icon"
                    variant="destructive"
                    onClick={() => removeAttachment(index)}
                    className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                )}

                {/* Tag Selector on Hover */}
                {!disabled && (
                  <div className="absolute bottom-0 left-0 right-0 p-2 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Select 
                      value={file.tag} 
                      onValueChange={(value) => updateAttachmentTag(index, value)}
                    >
                      <SelectTrigger className="h-7 text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="before">Before</SelectItem>
                        <SelectItem value="during">During</SelectItem>
                        <SelectItem value="after">After</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}