import { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

export function CertificationMonitor({ user }) {
  const { data: certifications = [] } = useQuery({
    queryKey: ['expiringCertifications', user?.bowling_alley_id],
    queryFn: async () => {
      if (!user || (user.department !== 'manager' && user.role !== 'admin')) return [];
      const certs = await base44.entities.SkillCertification.list();
      return certs.filter(c => c.bowling_alley_id === user.bowling_alley_id);
    },
    enabled: !!user && (user.department === 'manager' || user.role === 'admin'),
    refetchInterval: 300000 // Check every 5 minutes
  });

  useEffect(() => {
    if (!certifications || certifications.length === 0) return;

    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    certifications.forEach(async (cert) => {
      if (!cert.expiry_date) return;

      const expiryDate = new Date(cert.expiry_date);
      const daysUntilExpiry = Math.floor((expiryDate - now) / (1000 * 60 * 60 * 24));

      // Send reminder if expiring in 30 days and reminder not sent yet
      if (daysUntilExpiry <= 30 && daysUntilExpiry >= 0 && !cert.renewal_reminder_sent) {
        try {
          // Create notification
          await base44.entities.Notification.create({
            user_email: cert.employee_email,
            type: 'certification_expiry',
            title: `Certification Expiring Soon`,
            message: `Your ${cert.name} certification expires in ${daysUntilExpiry} days on ${expiryDate.toLocaleDateString()}`,
            priority: 'high',
            bowling_alley_id: cert.bowling_alley_id
          });

          // Send email
          await base44.integrations.Core.SendEmail({
            to: cert.employee_email,
            subject: `Certification Renewal Reminder - ${cert.name}`,
            body: `
              <h2>Certification Renewal Reminder</h2>
              <p>Your certification is expiring soon:</p>
              <ul>
                <li><strong>Certification:</strong> ${cert.name}</li>
                <li><strong>Expires on:</strong> ${expiryDate.toLocaleDateString()}</li>
                <li><strong>Days remaining:</strong> ${daysUntilExpiry}</li>
              </ul>
              <p>Please arrange for renewal before the expiry date.</p>
            `
          });

          // Mark reminder as sent
          await base44.entities.SkillCertification.update(cert.id, {
            renewal_reminder_sent: true,
            status: 'pending_renewal'
          });
        } catch (error) {
          console.error('Failed to send certification reminder:', error);
        }
      }

      // Update status to expired if past expiry
      if (daysUntilExpiry < 0 && cert.status !== 'expired') {
        try {
          await base44.entities.SkillCertification.update(cert.id, {
            status: 'expired'
          });
        } catch (error) {
          console.error('Failed to update certification status:', error);
        }
      }
    });
  }, [certifications]);

  return null;
}