import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";

export default function StatsCard({ title, value, icon: Icon, trend, trendUp, bgColor = "bg-blue-600" }) {
  const { isDarkMode } = useTheme();
  
  return (
    <Card className={`relative overflow-hidden border-none shadow-sm hover:shadow-md transition-shadow ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
      <div className={`absolute top-0 right-0 w-20 h-20 sm:w-24 sm:h-24 ${bgColor} opacity-10 rounded-full transform translate-x-10 -translate-y-10`} />
      <CardContent className="p-3 sm:p-4">
        <div className="flex justify-between items-start mb-2">
          <div className={`p-1.5 sm:p-2 ${bgColor} bg-opacity-10 rounded-lg`}>
            <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${bgColor.replace('bg-', 'text-')}`} />
          </div>
          {trend && (
            <div className={`flex items-center gap-1 text-xs font-medium ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
              {trendUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {trend}
            </div>
          )}
        </div>
        <div>
          <p className={`text-xs font-medium mb-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{title}</p>
          <p className={`text-xl sm:text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}