import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Target, Calendar, TrendingUp, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";

export default function DevelopmentPlanCard({ plan, onView, isDarkMode }) {
  const statusConfig = {
    active: { color: "bg-blue-100 text-blue-800", label: "Active" },
    completed: { color: "bg-green-100 text-green-800", label: "Completed" },
    cancelled: { color: "bg-slate-100 text-slate-800", label: "Cancelled" }
  };

  const config = statusConfig[plan.status] || statusConfig.active;

  return (
    <Card className={`cursor-pointer transition-all hover:shadow-md ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`} onClick={onView}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Target className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-lg">{plan.title}</CardTitle>
              <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {plan.description}
              </p>
            </div>
          </div>
          <Badge className={config.color}>{config.label}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>
              {format(new Date(plan.start_date), 'MMM d, yyyy')} - {format(new Date(plan.target_completion_date), 'MMM d, yyyy')}
            </span>
          </div>
          {plan.focus_areas && plan.focus_areas.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {plan.focus_areas.map((area, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {area}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}