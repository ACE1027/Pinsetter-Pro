import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Target, Calendar, TrendingUp } from "lucide-react";
import { format } from "date-fns";

export default function SkillGoalTracker({ goal, isDarkMode }) {
  const progress = ((goal.current_level - 1) / (goal.target_level - 1)) * 100;
  
  const statusConfig = {
    not_started: { color: "bg-slate-100 text-slate-800", label: "Not Started" },
    in_progress: { color: "bg-blue-100 text-blue-800", label: "In Progress" },
    achieved: { color: "bg-green-100 text-green-800", label: "Achieved" },
    cancelled: { color: "bg-red-100 text-red-800", label: "Cancelled" }
  };

  const categoryColors = {
    technical: "bg-blue-100 text-blue-800",
    leadership: "bg-purple-100 text-purple-800",
    communication: "bg-green-100 text-green-800",
    customer_service: "bg-amber-100 text-amber-800",
    safety: "bg-red-100 text-red-800",
    other: "bg-slate-100 text-slate-800"
  };

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Target className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-base">{goal.skill_name}</CardTitle>
              <div className="flex gap-2 mt-1">
                <Badge className={categoryColors[goal.category]} variant="outline">
                  {goal.category.replace(/_/g, ' ')}
                </Badge>
                <Badge className={statusConfig[goal.status]?.color}>
                  {statusConfig[goal.status]?.label}
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <div className="flex items-center justify-between text-sm mb-2">
            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
              Level {goal.current_level} → {goal.target_level}
            </span>
            <span className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
              {Math.round(progress)}%
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Calendar className="w-4 h-4 text-slate-400" />
          <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
            Target: {format(new Date(goal.target_date), 'MMM d, yyyy')}
          </span>
        </div>
        {goal.progress_notes && (
          <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            {goal.progress_notes}
          </p>
        )}
      </CardContent>
    </Card>
  );
}