import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Calendar, Clock, ExternalLink, Play, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";

export default function TrainingAssignmentCard({ assignment, module, onStart, onComplete, onView, canEdit, isDarkMode }) {
  const statusConfig = {
    assigned: { color: "bg-yellow-100 text-yellow-800", label: "Assigned", icon: BookOpen },
    in_progress: { color: "bg-blue-100 text-blue-800", label: "In Progress", icon: Play },
    completed: { color: "bg-green-100 text-green-800", label: "Completed", icon: CheckCircle2 },
    overdue: { color: "bg-red-100 text-red-800", label: "Overdue", icon: Clock }
  };

  const contentTypeIcons = {
    video: "📹",
    document: "📄",
    online_course: "💻",
    external_link: "🔗",
    in_person: "👥"
  };

  const config = statusConfig[assignment.status] || statusConfig.assigned;
  const StatusIcon = config.icon;

  return (
    <Card className={`transition-all hover:shadow-md ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3 flex-1">
            <div className="text-2xl">{contentTypeIcons[module?.content_type] || "📚"}</div>
            <div className="flex-1">
              <CardTitle className="text-base">{module?.title || "Training Module"}</CardTitle>
              <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {module?.description}
              </p>
            </div>
          </div>
          <Badge className={config.color}>
            <StatusIcon className="w-3 h-3 mr-1" />
            {config.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-4 text-sm">
          {module?.estimated_duration_minutes && (
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-slate-400" />
              <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                {module.estimated_duration_minutes} min
              </span>
            </div>
          )}
          {assignment.due_date && (
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                Due: {format(new Date(assignment.due_date), 'MMM d')}
              </span>
            </div>
          )}
        </div>

        {module?.skill_tags && module.skill_tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {module.skill_tags.map((tag, idx) => (
              <Badge key={idx} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}

        <div className="flex gap-2 pt-2">
          {assignment.status === 'assigned' && (
            <Button size="sm" onClick={onStart} className="flex-1 bg-blue-600 hover:bg-blue-700">
              <Play className="w-3 h-3 mr-1" />
              Start Training
            </Button>
          )}
          {assignment.status === 'in_progress' && (
            <>
              {module?.content_url && (
                <Button size="sm" variant="outline" onClick={() => window.open(module.content_url, '_blank')} className="flex-1">
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Continue
                </Button>
              )}
              <Button size="sm" onClick={onComplete} className="flex-1 bg-green-600 hover:bg-green-700">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Mark Complete
              </Button>
            </>
          )}
          {assignment.status === 'completed' && module?.content_url && (
            <Button size="sm" variant="outline" onClick={() => window.open(module.content_url, '_blank')}>
              <ExternalLink className="w-3 h-3 mr-1" />
              Review
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}