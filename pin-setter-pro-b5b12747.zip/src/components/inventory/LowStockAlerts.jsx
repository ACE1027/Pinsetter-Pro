import React, { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function LowStockAlerts({ user }) {
  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
  });

  const lowStockParts = parts.filter((part) => {
    const isUserLocation = user?.role === 'admin' || part.bowling_alley_id === user?.bowling_alley_id;
    const threshold = part.reorder_point || part.min_quantity || 5;
    return isUserLocation && part.quantity_in_stock <= threshold && !part.discontinued;
  });

  useEffect(() => {
    if (lowStockParts.length > 0 && (user?.department === 'manager' || user?.role === 'admin')) {
      const criticalParts = lowStockParts.filter(p => p.quantity_in_stock === 0);
      
      if (criticalParts.length > 0) {
        toast.error(`${criticalParts.length} critical part(s) out of stock!`, {
          duration: 8000,
          icon: <AlertTriangle className="w-5 h-5" />,
        });
      }
    }
  }, [lowStockParts.length, user]);

  return null;
}