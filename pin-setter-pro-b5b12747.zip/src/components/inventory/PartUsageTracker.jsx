import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, AlertTriangle, Package } from "lucide-react";
import { toast } from "sonner";

export default function PartUsageTracker({ repairLogId, locationId, isDarkMode, onPartsUpdate }) {
  const queryClient = useQueryClient();
  const [selectedPartId, setSelectedPartId] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState("");

  const { data: allParts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
  });

  const { data: usedParts = [] } = useQuery({
    queryKey: ['repairLogParts', repairLogId],
    queryFn: async () => {
      if (!repairLogId) return [];
      const parts = await base44.entities.RepairLogPart.list();
      return parts.filter(p => p.repair_log_id === repairLogId);
    },
    enabled: !!repairLogId,
  });

  const locationParts = allParts.filter(p => 
    (p.bowling_alley_id === locationId || !p.bowling_alley_id) && 
    !p.discontinued &&
    p.quantity_in_stock > 0
  );

  const addPartMutation = useMutation({
    mutationFn: async (data) => {
      const part = allParts.find(p => p.id === data.part_id);
      if (!part) throw new Error("Part not found");
      
      if (part.quantity_in_stock < data.quantity_used) {
        throw new Error(`Insufficient stock. Only ${part.quantity_in_stock} available.`);
      }

      // Create usage record
      await base44.entities.RepairLogPart.create({
        ...data,
        cost_at_time: part.cost || 0,
      });

      // Deduct from inventory
      await base44.entities.Part.update(part.id, {
        quantity_in_stock: part.quantity_in_stock - data.quantity_used,
      });

      return { part, quantity: data.quantity_used };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['repairLogParts'] });
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      setSelectedPartId("");
      setQuantity(1);
      setNotes("");
      toast.success(`${result.quantity}x ${result.part.name} added and deducted from inventory`);
      if (onPartsUpdate) onPartsUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const removePartMutation = useMutation({
    mutationFn: async (usedPart) => {
      const part = allParts.find(p => p.id === usedPart.part_id);
      if (!part) throw new Error("Part not found");

      // Delete usage record
      await base44.entities.RepairLogPart.delete(usedPart.id);

      // Return to inventory
      await base44.entities.Part.update(part.id, {
        quantity_in_stock: part.quantity_in_stock + usedPart.quantity_used,
      });

      return { part, quantity: usedPart.quantity_used };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['repairLogParts'] });
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      toast.success(`${result.quantity}x ${result.part.name} returned to inventory`);
      if (onPartsUpdate) onPartsUpdate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleAddPart = () => {
    if (!selectedPartId) {
      toast.error("Please select a part");
      return;
    }

    addPartMutation.mutate({
      repair_log_id: repairLogId,
      part_id: selectedPartId,
      quantity_used: quantity,
      notes: notes,
    });
  };

  const getPartDetails = (partId) => allParts.find(p => p.id === partId);

  const selectedPart = allParts.find(p => p.id === selectedPartId);
  const isLowStock = selectedPart && selectedPart.quantity_in_stock <= (selectedPart.reorder_point || selectedPart.min_quantity || 5);

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        <Label>Add Part from Inventory</Label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <Select value={selectedPartId} onValueChange={setSelectedPartId}>
              <SelectTrigger>
                <SelectValue placeholder="Select part..." />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                {locationParts.map((part) => {
                  const isLow = part.quantity_in_stock <= (part.reorder_point || part.min_quantity || 5);
                  return (
                    <SelectItem key={part.id} value={part.id}>
                      <div className="flex items-center justify-between w-full">
                        <span>{part.name} ({part.part_number})</span>
                        <span className={`ml-2 text-xs ${isLow ? 'text-orange-600 font-bold' : 'text-slate-500'}`}>
                          Stock: {part.quantity_in_stock}
                        </span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            {isLowStock && (
              <p className="text-xs text-orange-600 mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Low stock warning: Only {selectedPart.quantity_in_stock} remaining
              </p>
            )}
          </div>
          <Input
            type="number"
            min="1"
            value={quantity}
            onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
            placeholder="Qty"
          />
        </div>
        <Textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Optional notes about part usage..."
          rows={2}
        />
        <Button 
          onClick={handleAddPart} 
          disabled={!selectedPartId || addPartMutation.isPending}
          className="w-full"
        >
          <Plus className="w-4 h-4 mr-2" />
          {addPartMutation.isPending ? "Adding..." : "Add Part"}
        </Button>
      </div>

      {usedParts.length > 0 && (
        <div className="space-y-2">
          <Label>Parts Used ({usedParts.length})</Label>
          {usedParts.map((usedPart) => {
            const part = getPartDetails(usedPart.part_id);
            return (
              <Card key={usedPart.id} className={`${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50'}`}>
                <CardContent className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-blue-600" />
                        <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          {part?.name || 'Unknown Part'}
                        </p>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Part #: {part?.part_number} | Qty: {usedPart.quantity_used}
                        {usedPart.cost_at_time && ` | Cost: $${(usedPart.cost_at_time * usedPart.quantity_used).toFixed(2)}`}
                      </p>
                      {usedPart.notes && (
                        <p className="text-xs text-slate-600 mt-1">{usedPart.notes}</p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removePartMutation.mutate(usedPart)}
                      disabled={removePartMutation.isPending}
                      className="h-8 w-8 text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}