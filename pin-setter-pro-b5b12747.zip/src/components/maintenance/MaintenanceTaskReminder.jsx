import { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { addDays, differenceInDays, parseISO, isAfter, isBefore, startOfDay } from 'date-fns';
import { playSound, SOUND_TYPES } from '@/components/sounds/SoundManager';

export function useMaintenanceTaskReminder(user) {
  const queryClient = useQueryClient();

  const { data: tasks = [] } = useQuery({
    queryKey: ['preventativeMaintenanceTasks'],
    queryFn: () => base44.entities.PreventativeMaintenanceTask.list(),
    enabled: !!user,
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PreventativeMaintenanceTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['preventativeMaintenanceTasks']);
    },
  });

  const createNotificationMutation = useMutation({
    mutationFn: (data) => base44.entities.Notification.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications']);
    },
  });

  useEffect(() => {
    if (!user || !tasks.length) return;

    const today = startOfDay(new Date());
    const sevenDaysFromNow = addDays(today, 7);

    tasks.forEach(task => {
      // Skip if no due date, already completed, or reminder already sent
      if (!task.due_date || task.status === 'completed' || task.reminder_sent) return;

      const dueDate = parseISO(task.due_date);
      const daysUntilDue = differenceInDays(dueDate, today);

      // Check if task is overdue
      if (isBefore(dueDate, today) && task.status !== 'overdue') {
        updateTaskMutation.mutate({
          id: task.id,
          data: { status: 'overdue' }
        });

        // Send overdue notification to assigned user
        if (task.assigned_to) {
          createNotificationMutation.mutate({
            user_email: task.assigned_to,
            type: 'maintenance_due',
            title: 'Maintenance Task Overdue',
            message: `Task "${task.task_text}" is overdue and needs attention.`,
            priority: 'high',
            related_entity_type: 'PreventativeMaintenanceTask',
            related_entity_id: task.id,
            bowling_alley_id: task.bowling_alley_id,
          });

          // Play sound if it's the current user's task
          if (user?.email === task.assigned_to) {
            playSound(SOUND_TYPES.MAINTENANCE_DUE, user?.sound_preferences);
          }
        }
      }

      // Send 7-day reminder
      if (daysUntilDue <= 7 && daysUntilDue > 0 && !task.reminder_sent && task.assigned_to) {
        // Send reminder notification
        createNotificationMutation.mutate({
          user_email: task.assigned_to,
          type: 'maintenance_due',
          title: 'Maintenance Task Due Soon',
          message: `Task "${task.task_text}" is due in ${daysUntilDue} day${daysUntilDue === 1 ? '' : 's'}.`,
          priority: 'medium',
          related_entity_type: 'PreventativeMaintenanceTask',
          related_entity_id: task.id,
          bowling_alley_id: task.bowling_alley_id,
        });

        // Play sound if it's the current user's task
        if (user?.email === task.assigned_to) {
          playSound(SOUND_TYPES.MAINTENANCE_DUE, user?.sound_preferences);
        }

        // Mark reminder as sent
        updateTaskMutation.mutate({
          id: task.id,
          data: { reminder_sent: true }
        });
      }
    });
  }, [user, tasks]);

  return null;
}