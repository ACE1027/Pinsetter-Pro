import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { addDays, addWeeks, addMonths, addYears, isAfter, isBefore, startOfDay } from 'date-fns';

export function useRecurringScheduleProcessor(locationId) {
  const queryClient = useQueryClient();

  const { data: recurringSchedules = [] } = useQuery({
    queryKey: ['recurringMaintenanceSchedules'],
    queryFn: () => base44.entities.RecurringMaintenanceSchedule.list(),
    initialData: []
  });

  const { data: scheduledMaintenance = [] } = useQuery({
    queryKey: ['scheduledMaintenance'],
    queryFn: () => base44.entities.ScheduledMaintenance.list(),
    initialData: []
  });

  const { data: preventativeTasks = [] } = useQuery({
    queryKey: ['preventativeMaintenanceTasks'],
    queryFn: () => base44.entities.PreventativeMaintenanceTask.list(),
    initialData: []
  });

  const createScheduledMutation = useMutation({
    mutationFn: (data) => base44.entities.ScheduledMaintenance.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledMaintenance'] });
    }
  });

  const createPreventativeMutation = useMutation({
    mutationFn: (data) => base44.entities.PreventativeMaintenanceTask.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['preventativeMaintenanceTasks'] });
    }
  });

  const updateRecurringMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RecurringMaintenanceSchedule.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringMaintenanceSchedules'] });
    }
  });

  const getNextScheduledDate = (lastDate, pattern) => {
    const baseDate = lastDate ? new Date(lastDate) : new Date();
    
    switch (pattern) {
      case 'daily':
        return addDays(baseDate, 1);
      case 'weekly':
        return addWeeks(baseDate, 1);
      case 'monthly':
        return addMonths(baseDate, 1);
      case 'quarterly':
        return addMonths(baseDate, 3);
      case 'yearly':
        return addYears(baseDate, 1);
      default:
        return addMonths(baseDate, 1);
    }
  };

  const processRecurringSchedules = async () => {
    const today = startOfDay(new Date());
    const activeSchedules = recurringSchedules.filter(s => 
      s.active && 
      (!locationId || s.bowling_alley_id === locationId)
    );

    for (const schedule of activeSchedules) {
      const nextScheduled = schedule.next_scheduled 
        ? new Date(schedule.next_scheduled) 
        : getNextScheduledDate(schedule.last_executed, schedule.recurrence_pattern);

      // Check if it's time to create a new task
      if (isBefore(nextScheduled, today) || nextScheduled.toDateString() === today.toDateString()) {
        // Check if task already exists for this schedule today
        const existingTask = scheduledMaintenance.find(m => 
          m.bowling_alley_id === schedule.bowling_alley_id &&
          m.maintenance_type === schedule.maintenance_type &&
          m.lane_number === schedule.lane_number &&
          startOfDay(new Date(m.scheduled_date)).getTime() === today.getTime()
        );

        if (!existingTask && schedule.auto_generate_logs !== false) {
          // Create scheduled maintenance task
          await createScheduledMutation.mutateAsync({
            bowling_alley_id: schedule.bowling_alley_id,
            lane_number: schedule.lane_number || '',
            machine_type: schedule.machine_type || '',
            maintenance_type: schedule.maintenance_type,
            scheduled_date: new Date().toISOString(),
            assigned_to: schedule.assigned_to || '',
            description: schedule.description || `Auto-generated from recurring schedule: ${schedule.name}`,
            status: 'scheduled',
            device_timestamp: new Date().toISOString()
          });

          // Also create preventative maintenance task if pattern matches
          const periodMap = {
            'daily': 'daily',
            'weekly': 'weekly',
            'monthly': 'monthly',
            'quarterly': 'quarterly',
            'yearly': 'yearly'
          };

          const period = periodMap[schedule.recurrence_pattern];
          if (period) {
            const existingPreventative = preventativeTasks.find(t =>
              t.bowling_alley_id === schedule.bowling_alley_id &&
              t.period === period &&
              t.task_text === schedule.name
            );

            if (!existingPreventative) {
              await createPreventativeMutation.mutateAsync({
                bowling_alley_id: schedule.bowling_alley_id,
                period: period,
                task_text: `${schedule.name}${schedule.lane_number ? ` - Lane ${schedule.lane_number}` : ''}${schedule.machine_type ? ` (${schedule.machine_type})` : ''}`
              });
            }
          }

          // Update the recurring schedule with last executed and next scheduled
          const newNextScheduled = getNextScheduledDate(new Date(), schedule.recurrence_pattern);
          await updateRecurringMutation.mutateAsync({
            id: schedule.id,
            data: {
              last_executed: new Date().toISOString(),
              next_scheduled: newNextScheduled.toISOString()
            }
          });
        }
      }
    }
  };

  useEffect(() => {
    if (recurringSchedules.length > 0) {
      processRecurringSchedules();
    }
  }, [recurringSchedules.length, locationId]);

  return { processRecurringSchedules };
}

export default useRecurringScheduleProcessor;