import React from "react";
import { Card } from "@/components/ui/card";
import { Plus, Wrench, Clock, Package, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useTheme } from "@/components/ThemeContext";

export default function MobileQuickActions({ user }) {
  const { isDarkMode } = useTheme();

  const actions = [
    {
      icon: Plus,
      label: "Report Issue",
      color: "bg-red-500",
      url: createPageUrl("CreateServiceCall"),
    },
    {
      icon: Wrench,
      label: "My Calls",
      color: "bg-blue-500",
      url: createPageUrl("ServiceCalls"),
    },
    {
      icon: CheckCircle2,
      label: "Maintenance",
      color: "bg-green-500",
      url: createPageUrl("PreventativeMaintenance"),
    },
    {
      icon: Package,
      label: "Parts",
      color: "bg-purple-500",
      url: createPageUrl("PartsInventory"),
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3">
      {actions.map((action) => (
        <Link key={action.label} to={action.url}>
          <Card className={`p-4 hover:shadow-lg transition-all active:scale-95 ${
            isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'
          }`}>
            <div className="flex flex-col items-center gap-2 text-center">
              <div className={`p-3 rounded-full ${action.color}`}>
                <action.icon className="w-6 h-6 text-white" />
              </div>
              <span className={`text-sm font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                {action.label}
              </span>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  );
}