import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ArrowLeft, Save, Calendar, Building2, User,
  Plus, Trash2, CheckCircle2, Clock, WifiOff, Tag } from
'lucide-react';
import { format } from 'date-fns';
import StatusBadge from '../service/StatusBadge';
import PriorityBadge from '../service/PriorityBadge';
import { useTheme } from '../ThemeContext';

export default function MobileServiceCallDetail({
  call,
  bowlingAlley,
  user,
  allUsers,
  mechanics,
  usedParts,
  allParts,
  canEdit,
  canDelete,
  isOffline,
  onStatusChange,
  onAssignmentChange,
  onAddNote,
  onAddPart,
  onDeletePart,
  onDeleteCall,
  onBack
}) {
  const { isDarkMode } = useTheme();
  const [activeTab, setActiveTab] = useState('details');
  const [notes, setNotes] = useState('');
  const [completionNotes, setCompletionNotes] = useState('');
  const [selectedPart, setSelectedPart] = useState('');
  const [partQuantity, setPartQuantity] = useState(1);

  const displayDate = call?.device_timestamp || call?.created_date;
  const locationName = bowlingAlley?.name || 'Loading...';

  const locationParts = call?.bowling_alley_id ?
  allParts.filter((p) => p.bowling_alley_id === call.bowling_alley_id) :
  allParts;

  const getPartDetails = (partId) => {
    return locationParts.find((p) => p.id === partId);
  };

  const handleAddNote = () => {
    if (notes.trim()) {
      onAddNote(notes);
      setNotes('');
    }
  };

  const handleAddPart = () => {
    if (selectedPart && partQuantity > 0) {
      onAddPart({
        part_id: selectedPart,
        quantity_used: partQuantity,
        service_call_id: call.id
      });
      setSelectedPart('');
      setPartQuantity(1);
    }
  };

  const handleStatusUpdate = (newStatus) => {
    onStatusChange(newStatus, completionNotes);
    setCompletionNotes('');
  };

  return (
    <div className={`min-h-screen pb-20 ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      {/* Offline Indicator */}
      {isOffline &&
      <div className="bg-orange-500 text-white px-4 py-2 text-center text-sm font-medium">
          <WifiOff className="w-4 h-4 inline mr-2" />
          Offline Mode - Changes will sync when reconnected
        </div>
      }

      {/* Header */}
      <div className={`sticky top-0 z-10 border-b px-4 py-3 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack} className="flex-shrink-0">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1 min-w-0">
            <h1 className={`text-lg font-bold truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              {call.title}
            </h1>
            {call.category && (
              <div className="flex items-center gap-2 mt-1">
                <Tag className="w-3 h-3 text-slate-400" />
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {call.category.replace(/_/g, ' ')}
                </p>
              </div>
            )}
            <p className={`text-sm truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Lane {call.lane_number}</p>
          </div>
        </div>
      </div>

      {/* Priority & Status Bar */}
      <div className={`px-4 py-3 border-b ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex items-center justify-between">
          <PriorityBadge priority={call.priority} />
          <StatusBadge status={call.status} />
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
        <TabsList className={`w-full grid grid-cols-3 rounded-none border-b ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <TabsTrigger value="details" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Details
          </TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Notes
          </TabsTrigger>
          <TabsTrigger value="parts" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Parts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="p-4 space-y-4 mt-0">
          {/* Location & Date Info */}
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardContent className="p-4 space-y-4">
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-slate-500">Location</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Building2 className="w-4 h-4 text-slate-400" />
                    <p className={`font-medium ${isDarkMode ? 'text-slate-100' : ''}`}>{locationName}</p>
                  </div>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Reported</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <p className={`text-sm ${isDarkMode ? 'text-slate-300' : ''}`}>
                      {format(new Date(displayDate), "MMM d, yyyy 'at' h:mm a")}
                    </p>
                  </div>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Reported By</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <User className="w-4 h-4 text-slate-400" />
                    <p className={`font-medium ${isDarkMode ? 'text-slate-100' : ''}`}>
                      {(allUsers?.find(u => u.email === call.created_by)?.full_name || call.created_by)}
                    </p>
                  </div>
                </div>
                {call.completed_date &&
                <div>
                    <Label className="text-xs text-slate-500">Completed</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-300' : ''}`}>
                        {format(new Date(call.completed_date), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                  </div>
                }
              </div>
            </CardContent>
          </Card>

          {/* Description */}
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base font-semibold tracking-tight`}>Description</CardTitle>
            </CardHeader>
            <CardContent>
              {call.description ?
              <div className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                  {call.description.split('\n').map((line, index) =>
                <p key={index} className="mb-1">{line}</p>
                )}
                </div> :

              <p className="text-sm text-slate-500">No description provided</p>
              }
            </CardContent>
          </Card>

          {/* Assignment */}
          {canEdit &&
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader className="text-slate-50 pb-3 p-6 flex flex-col space-y-1.5">
                <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base`}>Assigned To</CardTitle>
              </CardHeader>
              <CardContent>
                <Select
                value={call.assigned_to || ""}
                onValueChange={onAssignmentChange}>

                  <SelectTrigger className="bg-transparent text-slate-50 px-3 py-2 text-base rounded-md flex w-full max-w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 h-12">
                    <SelectValue placeholder="Unassigned" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Unassigned</SelectItem>
                    {mechanics.map((mechanic) =>
                  <SelectItem key={mechanic.id} value={mechanic.email}>
                        {mechanic.full_name || mechanic.email}
                      </SelectItem>
                  )}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          }

          {/* Status Management */}
          {canEdit &&
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader className="pb-3">
                <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base font-semibold tracking-tight`}>Update Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Select
                value={call.status}
                onValueChange={handleStatusUpdate}>

                  <SelectTrigger className="bg-transparent text-slate-50 px-3 py-2 text-base capitalize rounded-md flex w-full max-w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent position="popper" className="z-50">
                    <SelectItem value="open" className="text-base py-3">Open</SelectItem>
                    <SelectItem value="in_progress" className="text-base py-3">In Progress</SelectItem>
                    <SelectItem value="waiting_for_parts" className="text-base py-3">Waiting for Parts</SelectItem>
                    <SelectItem value="completed" className="text-base py-3">Completed</SelectItem>
                    <SelectItem value="cancelled" className="text-base py-3">Cancelled</SelectItem>
                  </SelectContent>
                </Select>

                {call.status !== 'completed' && call.status !== 'cancelled' &&
              <div className="space-y-2">
                    <Label className="text-sm">Completion Notes</Label>
                    <Textarea
                  placeholder="Add notes before completing..."
                  value={completionNotes}
                  onChange={(e) => setCompletionNotes(e.target.value)}
                  rows={3}
                  className="text-base" />

                  </div>
              }
              </CardContent>
            </Card>
          }

          {/* Delete Button */}
          {canDelete &&
          <Button
            onClick={onDeleteCall}
            variant="destructive"
            className="w-full h-12 text-base">

              <Trash2 className="w-4 h-4 mr-2" />
              Delete Service Call
            </Button>
          }
        </TabsContent>

        <TabsContent value="notes" className="p-4 space-y-4 mt-0">
          {/* Add Note */}
          {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader className="pb-3">
                <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base`}>Add Work Note</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Textarea
                placeholder="Describe the work performed..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                className="text-base" />

                <Button
                onClick={handleAddNote}
                disabled={!notes.trim()}
                className="w-full h-12 text-base bg-blue-600 hover:bg-blue-700">

                  <Save className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
              </CardContent>
            </Card>
          }

          {/* Existing Notes */}
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base font-semibold tracking-tight`}>Work History</CardTitle>
            </CardHeader>
            <CardContent>
              {call.notes ?
              <div className={`rounded-lg p-3 text-sm ${isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-50 text-slate-700'}`}>
                  <pre className="whitespace-pre-wrap font-sans">{call.notes}</pre>
                </div> :

              <p className="text-sm text-slate-500 text-center py-4">No work notes yet</p>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="parts" className="p-4 space-y-4 mt-0">
          {/* Add Part */}
          {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader className="pb-3">
                <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base`}>Add Part</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label className="text-sm mb-2 block">Select Part</Label>
                  <Select value={selectedPart} onValueChange={setSelectedPart}>
                    <SelectTrigger className="h-12 text-base">
                      <SelectValue placeholder="Choose a part" />
                    </SelectTrigger>
                    <SelectContent>
                      {locationParts.filter((p) => p.quantity_in_stock > 0).map((part) =>
                    <SelectItem key={part.id} value={part.id} className="text-base py-3">
                          {part.name} ({part.part_number}) - Stock: {part.quantity_in_stock}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm mb-2 block">Quantity</Label>
                  <input
                  type="number"
                  min="1"
                  value={partQuantity}
                  onChange={(e) => setPartQuantity(parseInt(e.target.value) || 1)}
                  className={`w-full h-12 px-3 rounded-lg border text-base ${
                  isDarkMode ?
                  'bg-slate-800 border-slate-700 text-slate-100' :
                  'bg-white border-slate-300'}`
                  } />

                </div>
                <Button
                onClick={handleAddPart}
                disabled={!selectedPart}
                className="w-full h-12 text-base bg-blue-600 hover:bg-blue-700">

                  <Plus className="w-4 h-4 mr-2" />
                  Add Part
                </Button>
              </CardContent>
            </Card>
          }

          {/* Parts List */}
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className={`${isDarkMode ? 'text-slate-300' : 'text-slate-900'} text-base font-semibold tracking-tight`}>Parts Used</CardTitle>
            </CardHeader>
            <CardContent>
              {usedParts.length > 0 ?
              <div className="space-y-3">
                  {usedParts.map((usedPart) => {
                  const part = getPartDetails(usedPart.part_id);
                  return (
                    <div
                      key={usedPart.id}
                      className={`flex items-center justify-between p-3 rounded-lg ${
                      isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`
                      }>

                        <div className="flex-1 min-w-0">
                          <p className={`font-medium text-sm truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            {part ? part.name : 'Unknown Part'}
                          </p>
                          <p className="text-xs text-slate-500">
                            {part?.part_number} × {usedPart.quantity_used}
                          </p>
                        </div>
                        {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDeletePart(usedPart)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 flex-shrink-0">

                            <Trash2 className="w-4 h-4" />
                          </Button>
                      }
                      </div>);

                })}
                </div> :

              <p className="text-sm text-slate-500 text-center py-4">No parts used yet</p>
              }
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

}