import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertCircle, Mic, ChevronRight, ChevronLeft } from 'lucide-react';

export default function MobileServiceCallForm({ 
  locations, 
  mechanics,
  formData, 
  onChange, 
  onSubmit, 
  isSubmitting 
}) {
  const selectedLocation = locations.find(l => l.id === formData.bowling_alley_id);
  const laneOptions = selectedLocation?.total_lanes > 0 
    ? Array.from({ length: selectedLocation.total_lanes }, (_, i) => (i + 1).toString())
    : [];
  const filteredMechanics = (mechanics || []).filter(m => 
    m.bowling_alley_id === formData.bowling_alley_id || m.role === 'admin'
  );

  const ISSUE_TYPES = [
    { value: "dead_wood", label: "Dead Wood" },
    { value: "ball_return", label: "Ball Return" },
    { value: "180_stop", label: "180 Stop" },
    { value: "rake_down", label: "Rake Down" },
    { value: "out_of_range", label: "Out Of Range" },
    { value: "re_spot", label: "Re Spot" },
    { value: "add", label: "Add" },
    { value: "failed_to_trigger", label: "Failed to Trigger" },
    { value: "full_rack", label: "Full Rack" },
    { value: "90_stop", label: "90 Stop" },
    { value: "270_stop", label: "270 Stop" },
    { value: "banana_tree", label: "Banana Tree" },
    { value: "continuous_cycle", label: "Continuous Cycle" },
    { value: "blackout", label: "Black out" },
    { value: "ball_damage", label: "Ball Damage" },
    { value: "other", label: "Other" },
  ];

  const BALL_CALL_LOCATIONS = [
    { value: "turret", label: "Turret" },
    { value: "curtain", label: "Curtain" },
    { value: "cross_conveyor", label: "Cross Conveyor" },
    { value: "cushion", label: "Cushion" },
    { value: "behind_cushion", label: "Behind Cushion" },
  ];

  const ONE_EIGHTY_ISSUES = [
    { value: "cycle_sweep_issue", label: "Cycle / Sweep Issue" },
    { value: "detector_issue", label: "Detector Issue" },
    { value: "table_issue", label: "Table Issue" },
  ];

  const DECK_JAMS_BLACKOUTS = [
    { value: "pins_on_deck", label: "Pins on Deck" },
    { value: "shaker_board_not_closing", label: "Shaker Board Not Closing" },
    { value: "pins_not_setting", label: "Pins Not Setting" },
    { value: "dead_wood_not_clearing", label: "Dead Wood Not Clearing" },
  ];

  const CON_CYCLES = [
    { value: "sweep_not_returning", label: "Sweep Not Returning" },
    { value: "table_not_lowering", label: "Table Not Lowering" },
    { value: "pins_not_distributing", label: "Pins Not Distributing" },
  ];

  const MISCELLANEOUS = [
    { value: "turret_not_closing", label: "Turret Not Closing" },
    { value: "gutter_door_malfunction", label: "Gutter Door Malfunction" },
    { value: "no_power", label: "No Power" },
    { value: "pin_jam_turret", label: "Pin Jam in Turret" },
    { value: "other", label: "Other" },
  ];

  const PIN_NUMBERS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];



  const handleVoiceInput = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const text = transcript.toLowerCase();
        const updates = {};
        let foundStructuredData = false;

        // Parse location
        const locationMatch = locations.find(l => 
          text.includes(l.name.toLowerCase()) || 
          (l.city && text.includes(l.city.toLowerCase()))
        );
        if (locationMatch) {
          updates.bowling_alley_id = locationMatch.id;
          foundStructuredData = true;
        }

        // Parse lane number - handle multiple formats including word numbers
        const numberWords = {
          'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
          'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10',
          'eleven': '11', 'twelve': '12', 'thirteen': '13', 'fourteen': '14', 'fifteen': '15',
          'sixteen': '16', 'seventeen': '17', 'eighteen': '18', 'nineteen': '19', 'twenty': '20',
          'thirty': '30', 'forty': '40', 'fifty': '50', 'sixty': '60'
        };
        
        let laneMatch = text.match(/lane[s]?\s*(\d+)/i) || text.match(/(\d+)\s*lane[s]?/i);
        if (laneMatch) {
          updates.lane_number = laneMatch[1];
          foundStructuredData = true;
        } else {
          // Try matching word numbers
          const wordPattern = /lane[s]?\s*(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty)/i;
          const wordMatch = text.match(wordPattern);
          if (wordMatch) {
            updates.lane_number = numberWords[wordMatch[1].toLowerCase()];
            foundStructuredData = true;
          }
        }

        // Parse priority
        if (text.includes('urgent') || text.includes('down')) {
          updates.priority = 'urgent';
          foundStructuredData = true;
        } else if (text.includes('high priority') || text.includes('high')) {
          updates.priority = 'high';
          foundStructuredData = true;
        } else if (text.includes('medium')) {
          updates.priority = 'medium';
          foundStructuredData = true;
        } else if (text.includes('low')) {
          updates.priority = 'low';
          foundStructuredData = true;
        }

        // Parse issue types
        if (text.includes('dead wood') || text.includes('deadwood')) {
          updates.issueType = 'dead_wood';
          foundStructuredData = true;
        } else if (text.includes('ball return')) {
          updates.issueType = 'ball_return';
          foundStructuredData = true;
        } else if (text.includes('180') || text.includes('one eighty') || text.includes('one-eighty')) {
          updates.issueType = '180_stop';
          foundStructuredData = true;
        } else if (text.includes('rake down') || text.includes('rake')) {
          updates.issueType = 'rake_down';
          foundStructuredData = true;
        } else if (text.includes('out of range')) {
          updates.issueType = 'out_of_range';
          foundStructuredData = true;
        } else if (text.includes('re spot') || text.includes('respot') || text.includes('re-spot')) {
          updates.issueType = 're_spot';
          foundStructuredData = true;
        } else if (text.includes('add pin') || text.includes('add pins')) {
          updates.issueType = 'add';
          foundStructuredData = true;
        } else if (text.includes('fail to trigger') || text.includes('failed to trigger')) {
          updates.issueType = 'failed_to_trigger';
          foundStructuredData = true;
        } else if (text.includes('full rack')) {
          updates.issueType = 'full_rack';
          foundStructuredData = true;
        } else if (text.includes('90 stop') || text.includes('ninety stop')) {
          updates.issueType = '90_stop';
          foundStructuredData = true;
        } else if (text.includes('270 stop')) {
          updates.issueType = '270_stop';
          foundStructuredData = true;
        } else if (text.includes('banana tree')) {
          updates.issueType = 'banana_tree';
          foundStructuredData = true;
        } else if (text.includes('continuous cycle') || text.includes('con cycle')) {
          updates.issueType = 'continuous_cycle';
          foundStructuredData = true;
        } else if (text.includes('blackout') || text.includes('black out')) {
          updates.issueType = 'blackout';
          foundStructuredData = true;
        } else if (text.includes('ball damage')) {
          updates.issueType = 'ball_damage';
          foundStructuredData = true;
        }

        // Parse pins for re-spot
        const pinMatches = text.match(/pin[s]?\s*(\d+(?:\s*(?:and|,)\s*\d+)*)/gi);
        if (pinMatches) {
          const pins = [];
          pinMatches.forEach(match => {
            const numbers = match.match(/\d+/g);
            if (numbers) {
              numbers.forEach(num => {
                if (num >= '1' && num <= '10' && !pins.includes(num)) {
                  pins.push(num);
                }
              });
            }
          });
          if (pins.length > 0) {
            updates.affectedPins = pins.sort((a, b) => parseInt(a) - parseInt(b));
            foundStructuredData = true;
          }
        }

        // Parse mechanic assignment
        const mechanicMatch = (mechanics || []).find(m => 
          text.includes(m.full_name?.toLowerCase()) || 
          text.includes(m.email?.toLowerCase())
        );
        if (mechanicMatch) {
          updates.assigned_to = mechanicMatch.email;
          foundStructuredData = true;
        }

        // Apply all updates at once
        Object.keys(updates).forEach(key => {
          onChange(key, updates[key]);
        });

        // Only add to description if no structured data was found
        if (!foundStructuredData) {
          onChange('description', (formData.description ? formData.description + ' ' : '') + transcript);
        }
      };
      
      recognition.start();
    }
  };

  const togglePin = (pin) => {
    const currentPins = formData.affectedPins || [];
    if (currentPins.includes(pin)) {
      onChange('affectedPins', currentPins.filter(p => p !== pin));
    } else {
      onChange('affectedPins', [...currentPins, pin]);
    }
  };

  const toggleLane = (lane) => {
    const currentLanes = formData.affectedLanes || [];
    if (currentLanes.includes(lane)) {
      onChange('affectedLanes', currentLanes.filter(l => l !== lane));
    } else {
      onChange('affectedLanes', [...currentLanes, lane]);
    }
  };

  const getSpecificIssueOptions = () => {
    switch (formData.issueType) {
      case '180':
        return ONE_EIGHTY_ISSUES;
      case 'deck_jam_blackout':
        return DECK_JAMS_BLACKOUTS;
      case 'con_cycle':
        return CON_CYCLES;
      case 'miscellaneous':
        return MISCELLANEOUS;
      default:
        return [];
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <Card className="p-6 space-y-6">
        <h2 className="text-2xl font-bold text-slate-900">New Service Call</h2>
        
        {/* Location & Lane */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="location" className="text-base font-semibold">Location *</Label>
            <Select 
              value={formData.bowling_alley_id} 
              onValueChange={(value) => onChange('bowling_alley_id', value)}
            >
              <SelectTrigger className="h-12 text-base">
                <SelectValue placeholder="Select location" />
              </SelectTrigger>
              <SelectContent>
                {locations.map(location => (
                  <SelectItem key={location.id} value={location.id} className="text-base py-3">
                    {location.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="lane" className="text-base font-semibold">Lane Number *</Label>
            {laneOptions.length > 0 ? (
              <Select 
                value={formData.lane_number} 
                onValueChange={(value) => onChange('lane_number', value)}
              >
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder="Select lane" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {laneOptions.map(lane => (
                    <SelectItem key={lane} value={lane} className="text-base py-3">
                      Lane {lane}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                id="lane"
                type="number"
                value={formData.lane_number}
                onChange={(e) => onChange('lane_number', e.target.value)}
                placeholder={formData.bowling_alley_id ? "Enter lane number" : "Select location first"}
                disabled={!formData.bowling_alley_id}
                className="h-12 text-base"
              />
            )}
          </div>
        </div>

        {/* Issue Type */}
        <div className="space-y-2">
          <Label htmlFor="issue-type" className="text-base font-semibold">Issue Type *</Label>
          <Select 
            value={formData.issueType} 
            onValueChange={(value) => {
              onChange('issueType', value);
              onChange('affectedLanes', []);
            }}
          >
            <SelectTrigger className="h-12 text-base">
              <SelectValue placeholder="Select issue type" />
            </SelectTrigger>
            <SelectContent>
              {ISSUE_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value} className="text-base py-3">
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Ball Return - Multiple Lane Selection */}
        {formData.issueType === 'ball_return' && (
          <div className="space-y-2">
            <Label className="text-base font-semibold">Affected Lanes *</Label>
            <p className="text-sm text-slate-600">Select all lanes with ball return issues</p>
            {laneOptions.length > 0 ? (
              <div className="grid grid-cols-4 gap-2 max-h-64 overflow-y-auto p-2 border rounded-lg bg-white">
                {laneOptions.map(lane => (
                  <button
                    key={lane}
                    type="button"
                    onClick={() => toggleLane(lane)}
                    className={`h-12 rounded-lg border-2 font-semibold text-base transition-colors ${
                      (formData.affectedLanes || []).includes(lane)
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'bg-white border-slate-300 text-slate-700'
                    }`}
                  >
                    {lane}
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-500 p-4 bg-slate-50 rounded-lg border">
                Please select a location first to see available lanes
              </p>
            )}
          </div>
        )}

        {/* Re-Spot - Pin Selection */}
        {formData.issueType === 're_spot' && (
          <div className="space-y-2">
            <Label className="text-base font-semibold">Select Pins *</Label>
            <p className="text-sm text-slate-600">Tap the pins that need to be re-spotted</p>
            <div className="grid grid-cols-5 gap-3 p-4 border rounded-lg bg-white">
              {PIN_NUMBERS.map(pin => (
                <button
                  key={pin}
                  type="button"
                  onClick={() => togglePin(pin)}
                  className={`h-14 rounded-lg border-2 font-bold text-lg transition-colors ${
                    (formData.affectedPins || []).includes(pin)
                      ? 'bg-blue-600 border-blue-600 text-white'
                      : 'bg-white border-slate-300 text-slate-700'
                  }`}
                >
                  {pin}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Add - Pin Selection */}
        {formData.issueType === 'add' && (
          <div className="space-y-2">
            <Label className="text-base font-semibold">Select Pins to Add *</Label>
            <p className="text-sm text-slate-600">Tap the pins that need to be added</p>
            <div className="grid grid-cols-5 gap-3 p-4 border-2 border-purple-300 rounded-lg bg-purple-50">
              {PIN_NUMBERS.map(pin => (
                <button
                  key={pin}
                  type="button"
                  onClick={() => togglePin(pin)}
                  className={`h-14 rounded-lg border-2 font-bold text-lg transition-colors ${
                    (formData.affectedPins || []).includes(pin)
                      ? 'bg-purple-600 border-purple-600 text-white'
                      : 'bg-white border-purple-300 text-slate-700'
                  }`}
                >
                  {pin}
                </button>
              ))}
            </div>
            {(formData.affectedPins || []).length > 0 && (
              <p className="text-sm text-purple-800 font-medium">
                Selected: Pins {formData.affectedPins.join(", ")}
              </p>
            )}
          </div>
        )}

        {/* Priority */}
        <div className="space-y-2">
          <Label htmlFor="priority" className="text-base font-semibold">Priority *</Label>
          <Select 
            value={formData.priority} 
            onValueChange={(value) => onChange('priority', value)}
          >
            <SelectTrigger className="h-12 text-base">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low" className="text-base py-3">Low</SelectItem>
              <SelectItem value="medium" className="text-base py-3">Medium</SelectItem>
              <SelectItem value="high" className="text-base py-3">High</SelectItem>
              <SelectItem value="urgent" className="text-base py-3">
                <span className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  Urgent
                </span>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Assign To */}
        <div className="space-y-2">
          <Label htmlFor="assigned-to" className="text-base font-semibold">Assign To</Label>
          <Select 
            value={formData.assigned_to || ''} 
            onValueChange={(value) => onChange('assigned_to', value)}
            disabled={!formData.bowling_alley_id}
          >
            <SelectTrigger className="h-12 text-base">
              <SelectValue placeholder={formData.bowling_alley_id ? "Unassigned" : "Select location first"} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null} className="text-base py-3">Unassigned</SelectItem>
              {filteredMechanics.map(mechanic => (
                <SelectItem key={mechanic.email} value={mechanic.email} className="text-base py-3">
                  {mechanic.full_name || mechanic.email}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Additional Details */}
        <div className="space-y-2">
          <Label htmlFor="description" className="text-base font-semibold">Additional Details</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => onChange('description', e.target.value)}
            placeholder="Describe the issue in more detail..."
            rows={5}
            className="text-base resize-none"
          />
          {('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) && (
            <Button 
              type="button" 
              variant="outline" 
              size="sm"
              onClick={handleVoiceInput}
              className="w-full"
            >
              <Mic className="w-4 h-4 mr-2" />
              Voice Input
            </Button>
          )}
        </div>

        {/* Submit Button */}
        <Button 
          onClick={onSubmit} 
          disabled={isSubmitting || !formData.bowling_alley_id || !formData.lane_number || !formData.issueType || (formData.issueType === 'ball_return' && (!formData.affectedLanes || formData.affectedLanes.length === 0)) || ((formData.issueType === 're_spot' || formData.issueType === 'add') && (!formData.affectedPins || formData.affectedPins.length === 0))}
          className="w-full h-12 text-base bg-green-600 hover:bg-green-700"
        >
          {isSubmitting ? 'Creating...' : 'Create Service Call'}
        </Button>
      </Card>
    </div>
  );
}