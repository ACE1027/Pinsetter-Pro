import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Download, Database, Clock } from "lucide-react";
import { useOfflineSync } from "@/components/offline/OfflineManager";
import { toast } from "sonner";
import { format } from "date-fns";
import { useTheme } from "@/components/ThemeContext";

export default function OfflineDataManager() {
  const { isDarkMode } = useTheme();
  const { isOnline, refreshCachedData, getPendingUpdatesCount, OFFLINE_KEYS } = useOfflineSync();
  const [cacheStats, setCacheStats] = useState({});
  const [lastSync, setLastSync] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    updateCacheStats();
    const lastSyncTime = localStorage.getItem('offline_last_sync');
    if (lastSyncTime) {
      setLastSync(new Date(lastSyncTime));
    }
  }, []);

  const updateCacheStats = () => {
    const stats = {};
    Object.entries(OFFLINE_KEYS).forEach(([key, value]) => {
      if (key !== 'PENDING_UPDATES') {
        try {
          const data = JSON.parse(localStorage.getItem(value) || '[]');
          stats[key] = Array.isArray(data) ? data.length : 0;
        } catch {
          stats[key] = 0;
        }
      }
    });
    setCacheStats(stats);
  };

  const handleRefresh = async () => {
    if (!isOnline) {
      toast.error("Cannot refresh while offline");
      return;
    }
    
    setIsRefreshing(true);
    try {
      await refreshCachedData();
      setLastSync(new Date());
      updateCacheStats();
      toast.success("Data cached for offline use");
    } catch (error) {
      toast.error("Failed to refresh cache");
    } finally {
      setIsRefreshing(false);
    }
  };

  const pendingCount = getPendingUpdatesCount();

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : ''}`}>
            <Database className="w-5 h-5" />
            Offline Data
          </CardTitle>
          <Badge className={isOnline ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
            {isOnline ? 'Online' : 'Offline'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Sync Status */}
        <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-sm font-medium ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
              Last Sync
            </span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            {lastSync ? format(lastSync, "MMM d, h:mm a") : "Never"}
          </p>
        </div>

        {/* Pending Updates */}
        {pendingCount > 0 && (
          <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-orange-900">
                Pending Changes
              </span>
              <Badge className="bg-orange-600 text-white">
                {pendingCount}
              </Badge>
            </div>
            <p className="text-xs text-orange-700 mt-1">
              Will sync when online
            </p>
          </div>
        )}

        {/* Cache Stats */}
        <div className="space-y-2">
          <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            Cached Records
          </p>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(cacheStats).map(([key, count]) => (
              <div key={key} className={`p-2 rounded ${isDarkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {key.replace(/_/g, ' ')}
                </p>
                <p className={`text-lg font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {count}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Refresh Button */}
        <Button
          onClick={handleRefresh}
          disabled={!isOnline || isRefreshing}
          className="w-full"
          variant="outline"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Refreshing...' : 'Refresh Offline Data'}
        </Button>
      </CardContent>
    </Card>
  );
}