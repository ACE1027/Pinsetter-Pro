import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";

export default function TouchOptimizedList({ items, onItemClick, renderItem }) {
  const { isDarkMode } = useTheme();
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);

  const handleTouchStart = (e, item) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isSwipe = Math.abs(distance) > 50;
    
    setTouchStart(null);
    setTouchEnd(null);
  };

  return (
    <div className="space-y-3">
      {items.map((item, index) => (
        <div
          key={item.id || index}
          onTouchStart={(e) => handleTouchStart(e, item)}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onClick={() => onItemClick(item)}
          className="cursor-pointer"
        >
          {renderItem ? (
            renderItem(item)
          ) : (
            <Card className={`hover:shadow-md transition-all active:scale-[0.98] ${
              isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'
            }`}>
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex-1">{item.title || item.name}</div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </CardContent>
            </Card>
          )}
        </div>
      ))}
    </div>
  );
}