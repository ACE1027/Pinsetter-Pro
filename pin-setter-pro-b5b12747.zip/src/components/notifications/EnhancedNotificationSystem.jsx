import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export function useEnhancedNotifications(user) {
  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list(),
    refetchInterval: 30000, // Check every 30 seconds
    enabled: !!user,
  });

  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    refetchInterval: 60000, // Check every minute
    enabled: !!user,
  });

  useEffect(() => {
    if (!user || typeof Notification === 'undefined' || Notification.permission !== 'granted') return;

    // Check for urgent service calls
    const urgentCalls = serviceCalls.filter(call => 
      call.priority === 'urgent' && 
      call.status !== 'completed' && 
      call.status !== 'cancelled' &&
      (call.bowling_alley_id === user.bowling_alley_id || user.role === 'admin')
    );

    urgentCalls.forEach(call => {
      const notificationKey = `urgent-call-${call.id}`;
      const lastNotified = localStorage.getItem(notificationKey);
      
      // Only notify once per call or after 4 hours
      if (!lastNotified || Date.now() - parseInt(lastNotified) > 4 * 60 * 60 * 1000) {
        try {
          new Notification('🚨 Urgent Service Call', {
            body: `Lane ${call.lane_number}: ${call.title}`,
            icon: '/favicon.ico',
            tag: `urgent-${call.id}`,
            requireInteraction: true,
            vibrate: [200, 100, 200],
          });
          localStorage.setItem(notificationKey, Date.now().toString());
        } catch (error) {
          console.error('Notification error:', error);
        }
      }
    });

    // Check for low/out of stock parts
    const lowStockParts = parts.filter(part => 
      part.quantity_in_stock <= part.min_quantity &&
      part.quantity_in_stock > 0 &&
      !part.discontinued &&
      (part.bowling_alley_id === user.bowling_alley_id || user.role === 'admin')
    );

    const outOfStockParts = parts.filter(part => 
      part.quantity_in_stock === 0 &&
      !part.discontinued &&
      (part.bowling_alley_id === user.bowling_alley_id || user.role === 'admin')
    );

    if (lowStockParts.length > 0) {
      const notificationKey = `low-stock-${Date.now()}`;
      const lastNotified = localStorage.getItem('last-low-stock-notification');
      
      // Only notify once per day
      if (!lastNotified || Date.now() - parseInt(lastNotified) > 24 * 60 * 60 * 1000) {
        try {
          new Notification('⚠️ Low Inventory Alert', {
            body: `${lowStockParts.length} part(s) running low on stock`,
            icon: '/favicon.ico',
            tag: 'low-stock',
          });
          localStorage.setItem('last-low-stock-notification', Date.now().toString());
        } catch (error) {
          console.error('Notification error:', error);
        }
      }
    }

    if (outOfStockParts.length > 0) {
      const notificationKey = `out-of-stock-${Date.now()}`;
      const lastNotified = localStorage.getItem('last-out-of-stock-notification');
      
      // Only notify once per day
      if (!lastNotified || Date.now() - parseInt(lastNotified) > 24 * 60 * 60 * 1000) {
        try {
          new Notification('🔴 Out of Stock Alert', {
            body: `${outOfStockParts.length} part(s) out of stock`,
            icon: '/favicon.ico',
            tag: 'out-of-stock',
            requireInteraction: true,
          });
          localStorage.setItem('last-out-of-stock-notification', Date.now().toString());
        } catch (error) {
          console.error('Notification error:', error);
        }
      }
    }
  }, [serviceCalls, parts, user]);
}