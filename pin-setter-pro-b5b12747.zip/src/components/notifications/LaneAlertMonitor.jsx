import { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

export function LaneAlertMonitor({ user }) {
  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    initialData: [],
    refetchInterval: 60000, // Check every minute
  });

  const { data: users = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  useEffect(() => {
    if (!user || serviceCalls.length === 0) return;

    const checkLaneAlerts = async () => {
      const now = new Date();
      const twelveHoursAgo = new Date(now - 12 * 60 * 60 * 1000);

      // Filter recent calls at user's location (last 12 hours)
      const recentCalls = serviceCalls.filter(call => {
        if (call.bowling_alley_id !== user.bowling_alley_id) return false;
        const callDate = new Date(call.created_date);
        return callDate >= twelveHoursAgo && call.status !== 'cancelled';
      });

      // Group by lane
      const callsByLane = {};
      recentCalls.forEach(call => {
        if (!call.lane_number) return;
        const lane = call.lane_number;
        if (!callsByLane[lane]) {
          callsByLane[lane] = [];
        }
        callsByLane[lane].push(call);
      });

      // Check for lanes with 5+ calls
      for (const [lane, calls] of Object.entries(callsByLane)) {
        if (calls.length >= 5) {
          const alertKey = `lane-alert-${user.bowling_alley_id}-${lane}-${new Date().toDateString()}`;
          const alreadyNotified = localStorage.getItem(alertKey);

          if (!alreadyNotified) {
            // Find Lead Mechanics at this location
            const leadMechanics = users.filter(u => 
              u.position === 'lead_mechanic' && 
              u.bowling_alley_id === user.bowling_alley_id &&
              u.active !== false
            );

            // Create urgent notification for each lead mechanic
            for (const mechanic of leadMechanics) {
              await base44.entities.Notification.create({
                user_email: mechanic.email,
                type: 'service_call_urgent',
                title: `🚨 URGENT: Lane ${lane} Critical Alert`,
                message: `Lane ${lane} has received ${calls.length} service calls in the last 12 hours. Immediate attention required!`,
                priority: 'critical',
                bowling_alley_id: user.bowling_alley_id,
                related_entity_type: 'ServiceCall',
                related_entity_id: calls[0].id
              });

              // Send browser notification if permitted
              if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(`🚨 URGENT: Lane ${lane} Critical Alert`, {
                  body: `${calls.length} service calls in 12 hours - Immediate action required!`,
                  icon: '/favicon.ico',
                  tag: alertKey,
                  requireInteraction: true
                });
              }
            }

            // Send notification to current user if they're a manager/admin
            if (user.department === 'manager' || user.role === 'admin') {
              await base44.entities.Notification.create({
                user_email: user.email,
                type: 'service_call_urgent',
                title: `🚨 URGENT: Lane ${lane} Critical Alert`,
                message: `Lane ${lane} has received ${calls.length} service calls in the last 12 hours. Lead Mechanic has been notified.`,
                priority: 'critical',
                bowling_alley_id: user.bowling_alley_id,
                related_entity_type: 'ServiceCall',
                related_entity_id: calls[0].id
              });
            }

            // Mark as notified (expires after 24 hours)
            localStorage.setItem(alertKey, new Date().toISOString());

            // Show toast
            toast.error(`🚨 URGENT: Lane ${lane} has ${calls.length} service calls in 12 hours!`, {
              duration: 10000,
              important: true
            });

            console.log(`Lane alert triggered for Lane ${lane}: ${calls.length} calls in 12 hours`);
          }
        }
      }
    };

    checkLaneAlerts();
  }, [serviceCalls, user, users]);

  return null;
}