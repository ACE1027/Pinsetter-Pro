import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Bell, Check, CheckCheck, Trash2, Wrench, Package, Calendar, AlertCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '@/components/ThemeContext';

const NOTIFICATION_ICONS = {
  service_call_created: Wrench,
  service_call_urgent: AlertCircle,
  service_call_assigned: Wrench,
  service_call_completed: Wrench,
  low_stock_alert: Package,
  maintenance_due: Calendar,
};

const PRIORITY_COLORS = {
  critical: 'bg-red-100 text-red-800 border-red-300',
  high: 'bg-orange-100 text-orange-800 border-orange-300',
  medium: 'bg-blue-100 text-blue-800 border-blue-300',
  low: 'bg-slate-100 text-slate-800 border-slate-300',
};

const PRIORITY_COLORS_DARK = {
  critical: 'bg-red-900/30 text-red-400 border-red-800',
  high: 'bg-orange-900/30 text-orange-400 border-orange-800',
  medium: 'bg-blue-900/30 text-blue-400 border-blue-800',
  low: 'bg-slate-800 text-slate-400 border-slate-700',
};

export default function NotificationPanel({ user, compact = false }) {
  const { isDarkMode } = useTheme();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState('unread');

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const all = await base44.entities.Notification.list('-created_date');
      return all.filter(n => n.user_email === user.email);
    },
    enabled: !!user?.email,
  });

  const markAsReadMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.update(notificationId, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications']);
    },
  });

  const acknowledgeMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.update(notificationId, { 
        is_acknowledged: true,
        acknowledged_at: new Date().toISOString(),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications']);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.delete(notificationId),
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications']);
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifications.map(n => 
          base44.entities.Notification.update(n.id, { is_read: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications']);
    },
  });

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'unread') return !n.is_read;
    if (filter === 'acknowledged') return n.is_acknowledged;
    if (filter === 'critical') return n.priority === 'critical' || n.priority === 'high';
    return true;
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate(notification.id);
    }

    if (notification.related_entity_type === 'ServiceCall' && notification.related_entity_id) {
      navigate(createPageUrl('ServiceCallDetail') + '?id=' + notification.related_entity_id);
    } else if (notification.related_entity_type === 'Part' && notification.related_entity_id) {
      navigate(createPageUrl('PartsInventory'));
    }
  };

  if (compact) {
    return (
      <div className="space-y-2">
        {unreadCount > 0 && (
          <div className="flex justify-end mb-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={markAllAsReadMutation.isPending}
              className={`text-xs ${isDarkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900'}`}
            >
              <CheckCheck className="w-4 h-4 mr-1" />
              {markAllAsReadMutation.isPending ? 'Marking...' : 'Read All'}
            </Button>
          </div>
        )}
        {filteredNotifications.slice(0, 5).map(notification => {
          const Icon = NOTIFICATION_ICONS[notification.type] || Bell;
          const colors = isDarkMode ? PRIORITY_COLORS_DARK : PRIORITY_COLORS;
          
          return (
            <div
              key={notification.id}
              onClick={() => handleNotificationClick(notification)}
              className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                isDarkMode 
                  ? `hover:bg-slate-800 ${notification.is_read ? 'bg-slate-900 border-slate-800' : 'bg-slate-800 border-slate-700'}` 
                  : `hover:bg-slate-50 ${notification.is_read ? 'bg-white border-slate-200' : 'bg-blue-50 border-blue-200'}`
              }`}
            >
              <div className="flex items-start gap-3">
                <Icon className={`w-5 h-5 flex-shrink-0 mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className={`font-semibold text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{notification.title}</p>
                    {!notification.is_read && (
                      <div className="w-2 h-2 rounded-full bg-blue-600 flex-shrink-0 mt-1" />
                    )}
                  </div>
                  <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{notification.message}</p>
                  <p className={`text-xs mt-1 ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                    {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className={`space-y-4 ${isDarkMode ? 'text-slate-100' : ''}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h2 className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Notifications</h2>
          {unreadCount > 0 && (
            <Badge className="bg-red-600 text-white">{unreadCount}</Badge>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            All
          </Button>
          <Button
            variant={filter === 'unread' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('unread')}
          >
            Unread
          </Button>
          <Button
            variant={filter === 'critical' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('critical')}
          >
            Critical
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {Array(3).fill(0).map((_, i) => (
            <div key={i} className={`h-24 rounded-lg animate-pulse ${isDarkMode ? 'bg-slate-900' : 'bg-slate-200'}`} />
          ))}
        </div>
      ) : filteredNotifications.length === 0 ? (
        <Card className={`p-12 text-center ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <Bell className={`w-12 h-12 mx-auto mb-3 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
          <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>No notifications</h3>
          <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>You're all caught up!</p>
        </Card>
      ) : (
        <ScrollArea className="h-[600px]">
          <div className="space-y-2">
            {filteredNotifications.map(notification => {
              const Icon = NOTIFICATION_ICONS[notification.type] || Bell;
              const colors = isDarkMode ? PRIORITY_COLORS_DARK : PRIORITY_COLORS;
              
              return (
                <Card
                  key={notification.id}
                  className={`p-4 transition-colors ${
                    isDarkMode 
                      ? `${notification.is_read ? 'bg-slate-900 border-slate-800' : 'bg-slate-800 border-slate-700'} hover:border-slate-600` 
                      : `${notification.is_read ? 'bg-white border-slate-200' : 'bg-blue-50 border-blue-200'} hover:border-slate-300`
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-2 rounded-lg ${colors[notification.priority]}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex items-center gap-2">
                          <p className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{notification.title}</p>
                          {!notification.is_read && (
                            <div className="w-2 h-2 rounded-full bg-blue-600" />
                          )}
                        </div>
                        <Badge variant="outline" className="text-xs capitalize">
                          {notification.priority}
                        </Badge>
                      </div>
                      <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{notification.message}</p>
                      <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                        {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                      </p>
                      <div className="flex gap-2 mt-3">
                        {notification.related_entity_id && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleNotificationClick(notification)}
                          >
                            View Details
                          </Button>
                        )}
                        {!notification.is_acknowledged && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => acknowledgeMutation.mutate(notification.id)}
                          >
                            <Check className="w-4 h-4 mr-1" />
                            Acknowledge
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(notification.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}