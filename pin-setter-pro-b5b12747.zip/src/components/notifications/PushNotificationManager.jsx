import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export function usePushNotifications(user) {
  useEffect(() => {
    if (!user || !('Notification' in window)) return;

    const requestPermission = async () => {
      if (Notification.permission === 'default') {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          toast.success('Notifications enabled');
        }
      }
    };

    requestPermission();

    // Monitor for urgent service calls
    const checkUrgentCalls = async () => {
      try {
        const calls = await base44.entities.ServiceCall.filter({
          priority: 'urgent',
          status: { $ne: 'completed' }
        });

        calls.forEach(call => {
          const notificationKey = `urgent-call-${call.id}`;
          const lastShown = localStorage.getItem(notificationKey);
          const shouldNotify = !lastShown || Date.now() - parseInt(lastShown) > 3600000; // 1 hour

          if (shouldNotify && Notification.permission === 'granted') {
            new Notification('🚨 Urgent Service Call', {
              body: `Lane ${call.lane_number}: ${call.title}`,
              icon: '/favicon.ico',
              tag: notificationKey,
              requireInteraction: true
            });
            localStorage.setItem(notificationKey, Date.now().toString());
          }
        });
      } catch (error) {
        console.error('Notification check error:', error);
      }
    };

    // Monitor for low stock (managers/admins only)
    const checkLowStock = async () => {
      if (user.department !== 'manager' && user.role !== 'admin') return;

      try {
        const parts = await base44.entities.Part.filter({
          bowling_alley_id: user.bowling_alley_id,
          quantity_in_stock: { $lte: 0 }
        });

        if (parts.length > 0 && Notification.permission === 'granted') {
          const notificationKey = 'low-stock-alert';
          const lastShown = localStorage.getItem(notificationKey);
          const shouldNotify = !lastShown || Date.now() - parseInt(lastShown) > 86400000; // 24 hours

          if (shouldNotify) {
            new Notification('📦 Low Stock Alert', {
              body: `${parts.length} part(s) out of stock`,
              icon: '/favicon.ico',
              tag: notificationKey
            });
            localStorage.setItem(notificationKey, Date.now().toString());
          }
        }
      } catch (error) {
        console.error('Low stock check error:', error);
      }
    };

    // Check every 5 minutes
    const interval = setInterval(() => {
      checkUrgentCalls();
      checkLowStock();
    }, 300000);

    // Initial check
    checkUrgentCalls();
    checkLowStock();

    return () => clearInterval(interval);
  }, [user]);
}