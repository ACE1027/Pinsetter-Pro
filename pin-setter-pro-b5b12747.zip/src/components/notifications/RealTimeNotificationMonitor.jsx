import { useEffect, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { Bell, AlertCircle, Wrench, Package, Calendar } from 'lucide-react';

const NOTIFICATION_ICONS = {
  service_call_created: Wrench,
  service_call_urgent: AlertCircle,
  service_call_assigned: Wrench,
  service_call_completed: Wrench,
  low_stock_alert: Package,
  maintenance_due: Calendar,
};

export function useRealTimeNotifications(user) {
  const queryClient = useQueryClient();
  const lastCheckRef = useRef(new Date());
  const notifiedIdsRef = useRef(new Set());

  // Fetch notifications for current user
  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const allNotifications = await base44.entities.Notification.list('-created_date');
      return allNotifications.filter(n => n.user_email === user.email);
    },
    enabled: !!user?.email,
    refetchInterval: 5000, // Poll every 5 seconds
  });

  // Fetch service calls to monitor
  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    refetchInterval: 5000,
  });

  // Fetch parts to monitor stock
  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    refetchInterval: 30000, // Check every 30 seconds
  });

  // Monitor for new unread notifications
  useEffect(() => {
    if (!user?.email || notifications.length === 0) return;

    const newNotifications = notifications.filter(n => {
      const isNew = !n.is_read && !notifiedIdsRef.current.has(n.id);
      const isRecent = new Date(n.created_date) > lastCheckRef.current;
      return isNew && isRecent;
    });

    newNotifications.forEach(notification => {
      notifiedIdsRef.current.add(notification.id);
      
      const Icon = NOTIFICATION_ICONS[notification.type] || Bell;
      const priorityColors = {
        critical: 'text-red-600',
        high: 'text-orange-600',
        medium: 'text-blue-600',
        low: 'text-slate-600',
      };

      toast(notification.title, {
        description: notification.message,
        icon: <Icon className={`w-5 h-5 ${priorityColors[notification.priority]}`} />,
        duration: notification.priority === 'critical' ? 10000 : 5000,
        action: notification.related_entity_id && notification.related_entity_type === 'ServiceCall' ? {
          label: 'View',
          onClick: () => {
            window.location.href = createPageUrl('ServiceCallDetail') + '?id=' + notification.related_entity_id;
          }
        } : undefined,
      });
    });

    lastCheckRef.current = new Date();
  }, [notifications, user?.email]);

  // Monitor for new urgent service calls
  useEffect(() => {
    if (!user?.email || !user?.bowling_alley_id) return;

    const urgentCalls = serviceCalls.filter(call => 
      call.priority === 'urgent' && 
      call.status === 'open' &&
      call.bowling_alley_id === user.bowling_alley_id &&
      new Date(call.created_date) > new Date(Date.now() - 60000) // Last minute
    );

    urgentCalls.forEach(call => {
      if (!notifiedIdsRef.current.has(`urgent-${call.id}`)) {
        notifiedIdsRef.current.add(`urgent-${call.id}`);
        
        // Create notification in database
        base44.entities.Notification.create({
          user_email: user.email,
          type: 'service_call_urgent',
          title: '🚨 Urgent Service Call',
          message: `Lane ${call.lane_number}: ${call.title}`,
          priority: 'critical',
          related_entity_type: 'ServiceCall',
          related_entity_id: call.id,
          bowling_alley_id: call.bowling_alley_id,
        }).then(() => {
          queryClient.invalidateQueries(['notifications']);
        });
      }
    });
  }, [serviceCalls, user, queryClient]);

  // Monitor for low stock alerts
  useEffect(() => {
    if (!user?.email || !user?.bowling_alley_id) return;

    const lowStockParts = parts.filter(part => 
      part.bowling_alley_id === user.bowling_alley_id &&
      part.quantity_in_stock <= part.min_quantity &&
      part.quantity_in_stock > 0
    );

    lowStockParts.forEach(part => {
      if (!notifiedIdsRef.current.has(`low-stock-${part.id}`)) {
        notifiedIdsRef.current.add(`low-stock-${part.id}`);
        
        base44.entities.Notification.create({
          user_email: user.email,
          type: 'low_stock_alert',
          title: '📦 Low Stock Alert',
          message: `${part.name} is running low (${part.quantity_in_stock} remaining)`,
          priority: 'medium',
          related_entity_type: 'Part',
          related_entity_id: part.id,
          bowling_alley_id: part.bowling_alley_id,
        }).then(() => {
          queryClient.invalidateQueries(['notifications']);
        });
      }
    });
  }, [parts, user, queryClient]);

  return { notifications };
}