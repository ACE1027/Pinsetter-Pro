import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Wifi, WifiOff } from 'lucide-react';
import React from 'react';

const OFFLINE_KEYS = {
  PARTS: 'offline_parts',
  SCHEDULES: 'offline_schedules',
  SERVICE_CALLS: 'offline_service_calls',
  MACHINES: 'offline_machines',
  USERS: 'offline_users',
  LOCATIONS: 'offline_locations',
  MAINTENANCE_TASKS: 'offline_maintenance_tasks',
  PENDING_UPDATES: 'offline_pending_updates',
};

export function useOfflineSync() {
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleOnline = async () => {
      setIsOnline(true);
      toast.success('Back online - syncing data...', { icon: <Wifi className="w-4 h-4" /> });
      await syncPendingUpdates();
      await refreshCachedData();
    };

    const handleOffline = () => {
      setIsOnline(false);
      toast.warning('You are offline - changes will sync when reconnected', { 
        icon: <WifiOff className="w-4 h-4" />,
        duration: 5000
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const syncPendingUpdates = async () => {
    const pending = JSON.parse(localStorage.getItem(OFFLINE_KEYS.PENDING_UPDATES) || '[]');
    
    if (pending.length === 0) return;
    
    let successCount = 0;
    let errorCount = 0;
    
    for (const update of pending) {
      try {
        if (update.type === 'create_service_call') {
          await base44.entities.ServiceCall.create(update.data);
        } else if (update.type === 'update_service_call') {
          await base44.entities.ServiceCall.update(update.id, update.data);
        } else if (update.type === 'add_part') {
          await base44.entities.UsedPart.create(update.data);
        } else if (update.type === 'update_part_stock') {
          await base44.entities.Part.update(update.id, update.data);
        } else if (update.type === 'create_maintenance_log') {
          await base44.entities.PreventativeMaintenanceLog.create(update.data);
        } else if (update.type === 'update_machine') {
          await base44.entities.Machine.update(update.id, update.data);
        } else if (update.type === 'clock_in') {
          await base44.entities.TimeEntry.create(update.data);
        } else if (update.type === 'clock_out') {
          await base44.entities.TimeEntry.update(update.id, update.data);
        }
        successCount++;
      } catch (error) {
        console.error('Sync error:', error);
        errorCount++;
      }
    }

    if (successCount > 0) {
      toast.success(`Synced ${successCount} change(s)`);
    }
    if (errorCount > 0) {
      toast.error(`Failed to sync ${errorCount} change(s)`);
    }

    localStorage.setItem(OFFLINE_KEYS.PENDING_UPDATES, '[]');
    queryClient.invalidateQueries();
  };

  const refreshCachedData = async () => {
    try {
      const [parts, schedules, serviceCalls, machines, users, locations, maintenanceTasks] = await Promise.all([
        base44.entities.Part.list(),
        base44.entities.UserSchedule.list(),
        base44.entities.ServiceCall.list(),
        base44.entities.Machine.list(),
        base44.entities.User.list(),
        base44.entities.BowlingAlley.list(),
        base44.entities.PreventativeMaintenanceTask.list(),
      ]);

      localStorage.setItem(OFFLINE_KEYS.PARTS, JSON.stringify(parts));
      localStorage.setItem(OFFLINE_KEYS.SCHEDULES, JSON.stringify(schedules));
      localStorage.setItem(OFFLINE_KEYS.SERVICE_CALLS, JSON.stringify(serviceCalls));
      localStorage.setItem(OFFLINE_KEYS.MACHINES, JSON.stringify(machines));
      localStorage.setItem(OFFLINE_KEYS.USERS, JSON.stringify(users));
      localStorage.setItem(OFFLINE_KEYS.LOCATIONS, JSON.stringify(locations));
      localStorage.setItem(OFFLINE_KEYS.MAINTENANCE_TASKS, JSON.stringify(maintenanceTasks));
      localStorage.setItem('offline_last_sync', new Date().toISOString());
    } catch (error) {
      console.error('Cache refresh error:', error);
    }
  };

  const getCachedData = (key) => {
    try {
      return JSON.parse(localStorage.getItem(key) || '[]');
    } catch {
      return [];
    }
  };

  const queueUpdate = (type, data, id = null) => {
    const pending = JSON.parse(localStorage.getItem(OFFLINE_KEYS.PENDING_UPDATES) || '[]');
    pending.push({ type, data, id, timestamp: new Date().toISOString() });
    localStorage.setItem(OFFLINE_KEYS.PENDING_UPDATES, JSON.stringify(pending));
    
    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent('offlineUpdateQueued', { 
      detail: { type, data, id } 
    }));
  };

  const getPendingUpdatesCount = () => {
    const pending = JSON.parse(localStorage.getItem(OFFLINE_KEYS.PENDING_UPDATES) || '[]');
    return pending.length;
  };

  return {
    isOnline,
    getCachedData,
    queueUpdate,
    refreshCachedData,
    getPendingUpdatesCount,
    OFFLINE_KEYS,
  };
}

export function OfflineIndicator() {
  const { isOnline, getPendingUpdatesCount } = useOfflineSync();
  const [pendingCount, setPendingCount] = React.useState(0);

  React.useEffect(() => {
    const updateCount = () => setPendingCount(getPendingUpdatesCount());
    
    updateCount();
    window.addEventListener('offlineUpdateQueued', updateCount);
    
    return () => window.removeEventListener('offlineUpdateQueued', updateCount);
  }, [getPendingUpdatesCount]);

  if (isOnline && pendingCount === 0) return null;

  return (
    <div className={`fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-80 px-4 py-3 rounded-lg shadow-lg z-50 flex items-center gap-3 ${
      isOnline ? 'bg-blue-500' : 'bg-orange-500'
    } text-white`}>
      {isOnline ? (
        <Wifi className="w-5 h-5 flex-shrink-0" />
      ) : (
        <WifiOff className="w-5 h-5 flex-shrink-0" />
      )}
      <div className="flex-1">
        <p className="font-semibold text-sm">
          {isOnline ? 'Syncing...' : 'Offline Mode'}
        </p>
        <p className="text-xs opacity-90">
          {pendingCount > 0 ? `${pendingCount} change(s) pending` : 'Changes will sync when reconnected'}
        </p>
      </div>
    </div>
  );
}