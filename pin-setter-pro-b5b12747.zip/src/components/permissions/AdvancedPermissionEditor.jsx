import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Search, Shield, Clock, MapPin, CheckCircle2, Circle } from "lucide-react";
import { PERMISSION_DEFINITIONS } from "./permissionDefinitions";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function AdvancedPermissionEditor({ permissions, onChange, userLocations = [] }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  // Group permissions by category
  const categories = [...new Set(PERMISSION_DEFINITIONS.map((p) => p.category))];

  const filteredPermissions = PERMISSION_DEFINITIONS.filter((permission) => {
    const matchesSearch =
    permission.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    permission.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    permission.key.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = activeCategory === "all" || permission.category === activeCategory;

    return matchesSearch && matchesCategory;
  });

  const groupedPermissions = filteredPermissions.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {});

  const handleToggle = (permissionKey) => {
    const newPermissions = permissions.includes(permissionKey) ?
    permissions.filter((p) => p !== permissionKey) :
    [...permissions, permissionKey];
    onChange(newPermissions);
  };

  const handleSelectAll = () => {
    const allKeys = PERMISSION_DEFINITIONS.map((p) => p.key);
    onChange(allKeys);
  };

  const handleDeselectAll = () => {
    onChange([]);
  };

  const handleSelectCategory = (category) => {
    const categoryPermissions = PERMISSION_DEFINITIONS.
    filter((p) => p.category === category).
    map((p) => p.key);

    const allSelected = categoryPermissions.every((key) => permissions.includes(key));

    if (allSelected) {
      // Deselect all in category
      onChange(permissions.filter((p) => !categoryPermissions.includes(p)));
    } else {
      // Select all in category
      const newPermissions = [...new Set([...permissions, ...categoryPermissions])];
      onChange(newPermissions);
    }
  };

  const getCategoryIcon = (category) => {
    const icons = {
      service_calls: "🔧",
      inventory: "📦",
      maintenance: "⚙️",
      scheduling: "📅",
      analytics: "📊",
      users: "👥",
      locations: "🏢",
      system: "⚡"
    };
    return icons[category] || "📋";
  };

  const getCategoryColor = (category) => {
    const colors = {
      service_calls: "bg-blue-100 text-blue-800 border-blue-300",
      inventory: "bg-purple-100 text-purple-800 border-purple-300",
      maintenance: "bg-orange-100 text-orange-800 border-orange-300",
      scheduling: "bg-green-100 text-green-800 border-green-300",
      analytics: "bg-cyan-100 text-cyan-800 border-cyan-300",
      users: "bg-pink-100 text-pink-800 border-pink-300",
      locations: "bg-indigo-100 text-indigo-800 border-indigo-300",
      system: "bg-red-100 text-red-800 border-red-300"
    };
    return colors[category] || "bg-slate-100 text-slate-800 border-slate-300";
  };

  const selectedCount = permissions.length;
  const totalCount = PERMISSION_DEFINITIONS.length;

  return (
    <div className="space-y-4">
      {/* Header with stats and actions */}
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div>
          <h3 className="text-slate-50 text-lg font-semibold flex items-center gap-2">Custom Permissions


          </h3>
          <p className="text-sm text-slate-600 mt-1">
            {selectedCount} of {totalCount} permissions granted
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSelectAll}>

            <CheckCircle2 className="w-4 h-4 mr-2" />
            Select All
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDeselectAll}>

            <Circle className="w-4 h-4 mr-2" />
            Clear All
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input
          placeholder="Search permissions..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9" />

      </div>

      {/* Category tabs */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto flex-wrap h-auto">
          <TabsTrigger value="all">
            All ({PERMISSION_DEFINITIONS.length})
          </TabsTrigger>
          {categories.map((category) => {
            const count = PERMISSION_DEFINITIONS.filter((p) => p.category === category).length;
            const selected = PERMISSION_DEFINITIONS.
            filter((p) => p.category === category).
            filter((p) => permissions.includes(p.key)).length;

            return (
              <TabsTrigger key={category} value={category} className="relative">
                {getCategoryIcon(category)} {category.replace(/_/g, ' ')} ({selected}/{count})
              </TabsTrigger>);

          })}
        </TabsList>

        {/* Permission list */}
        <TabsContent value={activeCategory} className="mt-4">
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {Object.entries(groupedPermissions).map(([category, perms]) => {
                const allSelected = perms.every((p) => permissions.includes(p.key));
                const someSelected = perms.some((p) => permissions.includes(p.key));

                return (
                  <Card key={category} className="border-2">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{getCategoryIcon(category)}</span>
                          <div>
                            <CardTitle className="text-base capitalize">
                              {category.replace(/_/g, ' ')}
                            </CardTitle>
                            <CardDescription className="text-xs">
                              {perms.filter((p) => permissions.includes(p.key)).length} of {perms.length} selected
                            </CardDescription>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleSelectCategory(category)}
                          className={someSelected ? "text-blue-600" : ""}>

                          {allSelected ?
                          <CheckCircle2 className="w-4 h-4" /> :
                          someSelected ?
                          <Circle className="w-4 h-4 fill-blue-600" /> :

                          <Circle className="w-4 h-4" />
                          }
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {perms.map((permission) =>
                      <div
                        key={permission.key}
                        className={`flex items-start gap-3 p-3 rounded-lg border-2 transition-all ${
                        permissions.includes(permission.key) ?
                        'bg-blue-50 border-blue-200' :
                        'bg-white border-slate-200 hover:border-slate-300'}`
                        }>

                          <Checkbox
                          id={permission.key}
                          checked={permissions.includes(permission.key)}
                          onCheckedChange={() => handleToggle(permission.key)}
                          className="mt-1" />

                          <div className="flex-1">
                            <Label
                            htmlFor={permission.key}
                            className="font-medium text-sm cursor-pointer flex items-center gap-2">

                              {permission.name}
                              {permissions.includes(permission.key) &&
                            <Badge variant="outline" className="text-xs bg-blue-100 text-blue-800 border-blue-300">
                                  Granted
                                </Badge>
                            }
                            </Label>
                            <p className="text-xs text-slate-600 mt-1">{permission.description}</p>
                            <code className="text-xs text-slate-500 mt-1 block">{permission.key}</code>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>);

              })}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>

      {/* Summary */}
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <Shield className="w-4 h-4" />
            <span className="font-medium">Permission Summary:</span>
            <span>{selectedCount} permissions granted across {Object.keys(groupedPermissions).length} categories</span>
          </div>
        </CardContent>
      </Card>
    </div>);

}