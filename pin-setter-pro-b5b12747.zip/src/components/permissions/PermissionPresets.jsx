import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Users, Wrench, Eye, Star, Zap } from "lucide-react";
import { PERMISSION_DEFINITIONS } from "./permissionDefinitions";

const PRESETS = [
{
  id: "full_access",
  name: "Full Access",
  description: "Complete system access with all permissions",
  icon: Zap,
  color: "bg-red-100 text-red-800 border-red-300",
  permissions: "all"
},
{
  id: "service_manager",
  name: "Service Manager",
  description: "Full service operations, scheduling, and analytics",
  icon: Shield,
  color: "bg-blue-100 text-blue-800 border-blue-300",
  permissions: [
  'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_delete',
  'service_call_assign', 'service_call_complete', 'service_call_change_priority', 'service_call_view_history',
  'inventory_view', 'inventory_create', 'inventory_edit', 'inventory_use_parts', 'inventory_adjust_stock', 'inventory_view_costs',
  'maintenance_view', 'maintenance_create', 'maintenance_edit', 'maintenance_delete', 'maintenance_complete',
  'schedule_view', 'schedule_create', 'schedule_edit', 'schedule_delete', 'schedule_manage_templates',
  'analytics_view', 'analytics_export', 'analytics_view_financial',
  'user_view', 'user_create', 'user_edit', 'user_view_sensitive',
  'location_view', 'location_edit', 'location_switch']

},
{
  id: "lead_mechanic",
  name: "Lead Mechanic",
  description: "Senior technician with team coordination access",
  icon: Star,
  color: "bg-purple-100 text-purple-800 border-purple-300",
  permissions: [
  'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_assign',
  'service_call_complete', 'service_call_change_priority', 'service_call_view_history',
  'inventory_view', 'inventory_create', 'inventory_edit', 'inventory_use_parts', 'inventory_adjust_stock',
  'maintenance_view', 'maintenance_create', 'maintenance_edit', 'maintenance_complete',
  'schedule_view', 'schedule_create', 'schedule_edit',
  'analytics_view',
  'user_view',
  'location_view']

},
{
  id: "mechanic",
  name: "Mechanic",
  description: "Field technician with service call and maintenance access",
  icon: Wrench,
  color: "bg-green-100 text-green-800 border-green-300",
  permissions: [
  'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_complete', 'service_call_view_history',
  'inventory_view', 'inventory_use_parts',
  'maintenance_view', 'maintenance_complete',
  'schedule_view', 'schedule_view_own',
  'analytics_view',
  'location_view']

},
{
  id: "technician",
  name: "Technician",
  description: "Basic service call access for entry-level staff",
  icon: Users,
  color: "bg-cyan-100 text-cyan-800 border-cyan-300",
  permissions: [
  'service_call_view', 'service_call_create', 'service_call_edit',
  'inventory_view', 'inventory_use_parts',
  'maintenance_view', 'maintenance_complete',
  'schedule_view', 'schedule_view_own',
  'location_view']

},
{
  id: "read_only",
  name: "Read Only",
  description: "View-only access for oversight and reporting",
  icon: Eye,
  color: "bg-slate-100 text-slate-800 border-slate-300",
  permissions: [
  'service_call_view', 'service_call_view_history',
  'inventory_view',
  'maintenance_view',
  'schedule_view',
  'analytics_view',
  'user_view',
  'location_view']

}];


export default function PermissionPresets({ onApplyPreset, currentPermissions }) {
  const handleApply = (preset) => {
    if (preset.permissions === "all") {
      // Apply all permissions
      const allPermissions = PERMISSION_DEFINITIONS.map((p) => p.key);
      onApplyPreset(allPermissions);
    } else {
      onApplyPreset(preset.permissions);
    }
  };

  const getMatchPercentage = (preset) => {
    if (preset.permissions === "all") {
      const allCount = PERMISSION_DEFINITIONS.length;
      return Math.round(currentPermissions.length / allCount * 100);
    }

    const presetCount = preset.permissions.length;
    const matchCount = preset.permissions.filter((p) => currentPermissions.includes(p)).length;
    return Math.round(matchCount / presetCount * 100);
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-slate-50 mb-1 text-lg font-semibold">Permission Presets</h3>
        <p className="text-sm text-slate-600">
          Quickly apply common permission configurations
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {PRESETS.map((preset) => {
          const Icon = preset.icon;
          const matchPercentage = getMatchPercentage(preset);
          const isFullMatch = matchPercentage === 100;

          return (
            <Card
              key={preset.id}
              className={`transition-all hover:shadow-lg cursor-pointer ${
              isFullMatch ? 'border-2 border-blue-400 bg-blue-50/50' : ''}`
              }>

              <CardHeader className="pb-3">
                <div className="flex items-start justify-between mb-2">
                  <div className={`p-2 rounded-lg ${preset.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  {isFullMatch &&
                  <Badge variant="default" className="bg-blue-600">
                      Active
                    </Badge>
                  }
                  {matchPercentage > 0 && matchPercentage < 100 &&
                  <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-300">
                      {matchPercentage}% match
                    </Badge>
                  }
                </div>
                <CardTitle className="text-base">{preset.name}</CardTitle>
                <CardDescription className="text-xs">
                  {preset.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-600">
                    {preset.permissions === "all" ? "All" : preset.permissions.length} permissions
                  </span>
                  <Button
                    size="sm"
                    variant={isFullMatch ? "outline" : "default"}
                    onClick={() => handleApply(preset)}
                    className={isFullMatch ? "" : "bg-blue-600 hover:bg-blue-700"}>

                    {isFullMatch ? "Applied" : "Apply"}
                  </Button>
                </div>
              </CardContent>
            </Card>);

        })}
      </div>
    </div>);

}