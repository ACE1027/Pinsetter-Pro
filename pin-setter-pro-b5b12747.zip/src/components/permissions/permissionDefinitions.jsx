// Define all available permissions in the system
export const PERMISSION_DEFINITIONS = [
  // Service Calls
  {
    key: 'service_call_view',
    name: 'View Service Calls',
    description: 'View service call list and details',
    category: 'service_calls'
  },
  {
    key: 'service_call_create',
    name: 'Create Service Calls',
    description: 'Create new service calls',
    category: 'service_calls'
  },
  {
    key: 'service_call_edit',
    name: 'Edit Service Calls',
    description: 'Edit existing service calls',
    category: 'service_calls'
  },
  {
    key: 'service_call_delete',
    name: 'Delete Service Calls',
    description: 'Delete service calls',
    category: 'service_calls'
  },
  {
    key: 'service_call_assign',
    name: 'Assign Service Calls',
    description: 'Assign service calls to mechanics',
    category: 'service_calls'
  },
  {
    key: 'service_call_view_history',
    name: 'View Service Call History',
    description: 'Access historical service call records',
    category: 'service_calls'
  },

  // Parts Inventory
  {
    key: 'inventory_view',
    name: 'View Inventory',
    description: 'View parts inventory',
    category: 'inventory'
  },
  {
    key: 'inventory_create',
    name: 'Add Parts',
    description: 'Add new parts to inventory',
    category: 'inventory'
  },
  {
    key: 'inventory_edit',
    name: 'Edit Parts',
    description: 'Edit existing parts',
    category: 'inventory'
  },
  {
    key: 'inventory_delete',
    name: 'Delete Parts',
    description: 'Delete parts from inventory',
    category: 'inventory'
  },
  {
    key: 'inventory_use_parts',
    name: 'Use Parts',
    description: 'Mark parts as used in service calls',
    category: 'inventory'
  },
  {
    key: 'inventory_master_catalog',
    name: 'Manage Master Catalog',
    description: 'Access and manage master parts catalog',
    category: 'inventory'
  },

  // Maintenance
  {
    key: 'maintenance_view',
    name: 'View Maintenance',
    description: 'View maintenance schedules and tasks',
    category: 'maintenance'
  },
  {
    key: 'maintenance_create',
    name: 'Create Maintenance',
    description: 'Create maintenance tasks and schedules',
    category: 'maintenance'
  },
  {
    key: 'maintenance_edit',
    name: 'Edit Maintenance',
    description: 'Edit maintenance tasks and schedules',
    category: 'maintenance'
  },
  {
    key: 'maintenance_delete',
    name: 'Delete Maintenance',
    description: 'Delete maintenance tasks and schedules',
    category: 'maintenance'
  },
  {
    key: 'maintenance_complete',
    name: 'Complete Maintenance',
    description: 'Mark maintenance tasks as complete',
    category: 'maintenance'
  },
  {
    key: 'maintenance_recurring_create',
    name: 'Create Recurring Schedules',
    description: 'Create recurring maintenance schedules',
    category: 'maintenance'
  },
  {
    key: 'maintenance_recurring_delete',
    name: 'Delete Recurring Schedules',
    description: 'Delete recurring maintenance schedules',
    category: 'maintenance'
  },
  {
    key: 'repair_log_view',
    name: 'View Repair Logs',
    description: 'View machine repair logs',
    category: 'maintenance'
  },
  {
    key: 'repair_log_create',
    name: 'Create Repair Logs',
    description: 'Create machine repair logs',
    category: 'maintenance'
  },
  {
    key: 'repair_log_edit',
    name: 'Edit Repair Logs',
    description: 'Edit machine repair logs',
    category: 'maintenance'
  },
  {
    key: 'repair_log_delete',
    name: 'Delete Repair Logs',
    description: 'Delete machine repair logs',
    category: 'maintenance'
  },
  {
    key: 'repair_log_export',
    name: 'Export Repair Logs',
    description: 'Export repair logs to various formats',
    category: 'maintenance'
  },

  // Scheduling
  {
    key: 'schedule_view',
    name: 'View Schedule',
    description: 'View staff schedules',
    category: 'scheduling'
  },
  {
    key: 'schedule_create',
    name: 'Create Schedule',
    description: 'Create staff schedules',
    category: 'scheduling'
  },
  {
    key: 'schedule_edit',
    name: 'Edit Schedule',
    description: 'Edit staff schedules',
    category: 'scheduling'
  },
  {
    key: 'schedule_delete',
    name: 'Delete Schedule',
    description: 'Delete staff schedules',
    category: 'scheduling'
  },

  // Analytics
  {
    key: 'analytics_view',
    name: 'View Analytics',
    description: 'Access analytics and reports',
    category: 'analytics'
  },
  {
    key: 'analytics_export',
    name: 'Export Analytics',
    description: 'Export analytics data',
    category: 'analytics'
  },
  {
    key: 'analytics_view_all_locations',
    name: 'View All Locations Analytics',
    description: 'View analytics across all locations',
    category: 'analytics'
  },
  {
    key: 'analytics_view_financial',
    name: 'View Financial Analytics',
    description: 'Access cost and financial reports',
    category: 'analytics'
  },

  // Users
  {
    key: 'user_view',
    name: 'View Users',
    description: 'View user list and details',
    category: 'users'
  },
  {
    key: 'user_create',
    name: 'Create Users',
    description: 'Invite and create new users',
    category: 'users'
  },
  {
    key: 'user_edit',
    name: 'Edit Users',
    description: 'Edit user details and roles',
    category: 'users'
  },
  {
    key: 'user_delete',
    name: 'Delete Users',
    description: 'Delete or deactivate users',
    category: 'users'
  },
  {
    key: 'role_manage',
    name: 'Manage Roles',
    description: 'Create and manage user roles',
    category: 'users'
  },

  // Locations
  {
    key: 'location_view',
    name: 'View Locations',
    description: 'View bowling alley locations',
    category: 'locations'
  },
  {
    key: 'location_create',
    name: 'Create Locations',
    description: 'Create new locations',
    category: 'locations'
  },
  {
    key: 'location_edit',
    name: 'Edit Locations',
    description: 'Edit location details',
    category: 'locations'
  },
  {
    key: 'location_delete',
    name: 'Delete Locations',
    description: 'Delete locations',
    category: 'locations'
  },
  {
    key: 'location_switch',
    name: 'Switch Between Locations',
    description: 'Access multiple locations',
    category: 'locations'
  },

  // Advanced Permissions
  {
    key: 'service_call_complete',
    name: 'Complete Service Calls',
    description: 'Mark service calls as completed',
    category: 'service_calls'
  },
  {
    key: 'service_call_reopen',
    name: 'Reopen Service Calls',
    description: 'Reopen completed service calls',
    category: 'service_calls'
  },
  {
    key: 'service_call_change_priority',
    name: 'Change Priority',
    description: 'Modify service call priority levels',
    category: 'service_calls'
  },
  {
    key: 'inventory_adjust_stock',
    name: 'Adjust Stock Levels',
    description: 'Manually adjust inventory quantities',
    category: 'inventory'
  },
  {
    key: 'inventory_view_costs',
    name: 'View Part Costs',
    description: 'View cost information for parts',
    category: 'inventory'
  },
  {
    key: 'schedule_view_own',
    name: 'View Own Schedule',
    description: 'View personal schedule only',
    category: 'scheduling'
  },
  {
    key: 'schedule_manage_templates',
    name: 'Manage Schedule Templates',
    description: 'Create and manage schedule templates',
    category: 'scheduling'
  },
  {
    key: 'user_view_sensitive',
    name: 'View Sensitive User Info',
    description: 'View user contact and personal details',
    category: 'users'
  },
  {
    key: 'user_assign_permissions',
    name: 'Assign User Permissions',
    description: 'Modify individual user permissions',
    category: 'users'
  },
  {
    key: 'maintenance_view_all_locations',
    name: 'View Maintenance Across All Locations',
    description: 'Access maintenance data for all locations',
    category: 'maintenance'
  },
  {
    key: 'system_settings',
    name: 'System Settings',
    description: 'Access and modify system settings',
    category: 'system'
  },
  {
    key: 'audit_log_view',
    name: 'View Audit Logs',
    description: 'Access system audit logs',
    category: 'system'
  },
  {
    key: 'notifications_manage',
    name: 'Manage Notifications',
    description: 'Configure notification settings',
    category: 'system'
  }
];

// Organizational hierarchy positions
export const POSITION_HIERARCHY = [
  { value: "general_manager", label: "General Manager", level: 1 },
  { value: "service_manager", label: "Service Manager", level: 2 },
  { value: "assistant_manager", label: "Assistant Manager", level: 3 },
  { value: "senior_mechanic", label: "Senior Mechanic", level: 4 },
  { value: "lead_mechanic", label: "Lead Mechanic", level: 5 },
  { value: "mechanic", label: "Mechanic", level: 6 },
  { value: "mechanic_apprentice", label: "Mechanic Apprentice", level: 7 },
  { value: "front_desk_supervisor", label: "Front Desk Supervisor", level: 8 },
  { value: "front_desk_staff", label: "Front Desk Staff", level: 9 },
];

// Predefined system role configurations mapped to organizational positions
export const SYSTEM_ROLES = [
  {
    name: 'General Manager',
    description: 'Complete operational control with full access to all features and locations',
    is_system_role: true,
    position: 'general_manager',
    permission_keys: PERMISSION_DEFINITIONS.map(p => p.key)
  },
  {
    name: 'Service Manager',
    description: 'Full service operations management including scheduling, analytics, and team oversight',
    is_system_role: true,
    position: 'service_manager',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_delete',
      'service_call_assign', 'service_call_complete', 'service_call_change_priority', 'service_call_view_history',
      'inventory_view', 'inventory_create', 'inventory_edit', 'inventory_use_parts', 'inventory_adjust_stock', 'inventory_view_costs',
      'maintenance_view', 'maintenance_create', 'maintenance_edit', 'maintenance_delete', 'maintenance_complete',
      'maintenance_recurring_create', 'maintenance_recurring_delete',
      'repair_log_view', 'repair_log_create', 'repair_log_edit', 'repair_log_delete', 'repair_log_export',
      'schedule_view', 'schedule_create', 'schedule_edit', 'schedule_delete', 'schedule_manage_templates',
      'analytics_view', 'analytics_export', 'analytics_view_financial',
      'user_view', 'user_create', 'user_edit', 'user_view_sensitive',
      'location_view', 'location_edit', 'location_switch'
    ]
  },
  {
    name: 'Assistant Manager',
    description: 'Support management with service coordination and limited administrative access',
    is_system_role: true,
    position: 'assistant_manager',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_assign',
      'service_call_complete', 'service_call_change_priority', 'service_call_view_history',
      'inventory_view', 'inventory_create', 'inventory_edit', 'inventory_use_parts', 'inventory_adjust_stock',
      'maintenance_view', 'maintenance_create', 'maintenance_edit', 'maintenance_complete',
      'maintenance_recurring_create', 'maintenance_recurring_delete',
      'repair_log_view', 'repair_log_create', 'repair_log_edit', 'repair_log_delete', 'repair_log_export',
      'schedule_view', 'schedule_create', 'schedule_edit',
      'analytics_view', 'analytics_export',
      'user_view',
      'location_view'
    ]
  },
  {
    name: 'Senior Mechanic',
    description: 'Experienced technician with team leadership and advanced service capabilities',
    is_system_role: true,
    position: 'senior_mechanic',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_assign',
      'service_call_complete', 'service_call_view_history',
      'inventory_view', 'inventory_create', 'inventory_edit', 'inventory_use_parts', 'inventory_adjust_stock',
      'maintenance_view', 'maintenance_create', 'maintenance_edit', 'maintenance_complete',
      'repair_log_view', 'repair_log_create', 'repair_log_edit', 'repair_log_delete', 'repair_log_export',
      'schedule_view', 'schedule_create', 'schedule_edit',
      'analytics_view',
      'user_view',
      'location_view'
    ]
  },
  {
    name: 'Lead Mechanic',
    description: 'Team coordinator with service oversight and inventory management',
    is_system_role: true,
    position: 'lead_mechanic',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_assign',
      'service_call_complete', 'service_call_view_history',
      'inventory_view', 'inventory_create', 'inventory_edit', 'inventory_use_parts',
      'maintenance_view', 'maintenance_create', 'maintenance_edit', 'maintenance_complete',
      'repair_log_view', 'repair_log_create', 'repair_log_edit', 'repair_log_export',
      'schedule_view', 'schedule_create',
      'analytics_view',
      'user_view',
      'location_view'
    ]
  },
  {
    name: 'Mechanic',
    description: 'Field technician with full service call and maintenance capabilities',
    is_system_role: true,
    position: 'mechanic',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_edit', 'service_call_complete', 'service_call_view_history',
      'inventory_view', 'inventory_use_parts',
      'maintenance_view', 'maintenance_complete',
      'repair_log_view', 'repair_log_create', 'repair_log_edit', 'repair_log_export',
      'schedule_view', 'schedule_view_own',
      'analytics_view',
      'location_view'
    ]
  },
  {
    name: 'Mechanic Apprentice',
    description: 'Entry-level technician learning the trade with supervised service access',
    is_system_role: true,
    position: 'mechanic_apprentice',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_edit',
      'inventory_view', 'inventory_use_parts',
      'maintenance_view', 'maintenance_complete',
      'repair_log_view', 'repair_log_create',
      'schedule_view', 'schedule_view_own',
      'location_view'
    ]
  },
  {
    name: 'Front Desk Supervisor',
    description: 'Customer-facing supervisor with service call creation and team oversight',
    is_system_role: true,
    position: 'front_desk_supervisor',
    permission_keys: [
      'service_call_view', 'service_call_create', 'service_call_view_history',
      'inventory_view',
      'maintenance_view',
      'repair_log_view',
      'schedule_view', 'schedule_create', 'schedule_edit',
      'analytics_view',
      'user_view',
      'location_view'
    ]
  },
  {
    name: 'Front Desk Staff',
    description: 'Customer service staff with basic service call reporting access',
    is_system_role: true,
    position: 'front_desk_staff',
    permission_keys: [
      'service_call_view', 'service_call_create',
      'inventory_view',
      'maintenance_view',
      'schedule_view', 'schedule_view_own',
      'location_view'
    ]
  },
  {
    name: 'Read Only',
    description: 'View-only access for oversight and reporting purposes',
    is_system_role: true,
    position: null,
    permission_keys: [
      'service_call_view', 'service_call_view_history',
      'inventory_view',
      'maintenance_view',
      'repair_log_view',
      'schedule_view',
      'analytics_view',
      'user_view',
      'location_view'
    ]
  }
];