// Permission system for PinSetter Pro
// Defines roles, permissions, and access control rules

export const ROLES = {
  ADMIN: 'admin',
  USER: 'user',
};

export const DEPARTMENTS = {
  MANAGER: 'manager',
  MECHANIC: 'mechanic',
  FRONT_DESK: 'front_desk',
};

export const POSITIONS = {
  GENERAL_MANAGER: 'general_manager',
  SERVICE_MANAGER: 'service_manager',
  ASSISTANT_MANAGER: 'assistant_manager',
  SENIOR_MECHANIC: 'senior_mechanic',
  LEAD_MECHANIC: 'lead_mechanic',
  MECHANIC: 'mechanic',
  MECHANIC_APPRENTICE: 'mechanic_apprentice',
  FRONT_DESK_SUPERVISOR: 'front_desk_supervisor',
  FRONT_DESK_STAFF: 'front_desk_staff',
};

export const POSITION_LEVELS = {
  [POSITIONS.GENERAL_MANAGER]: 1,
  [POSITIONS.SERVICE_MANAGER]: 2,
  [POSITIONS.ASSISTANT_MANAGER]: 3,
  [POSITIONS.SENIOR_MECHANIC]: 4,
  [POSITIONS.LEAD_MECHANIC]: 5,
  [POSITIONS.MECHANIC]: 6,
  [POSITIONS.MECHANIC_APPRENTICE]: 7,
  [POSITIONS.FRONT_DESK_SUPERVISOR]: 8,
  [POSITIONS.FRONT_DESK_STAFF]: 9,
};

// Permission definitions
export const PERMISSIONS = {
  // Service Calls
  SERVICE_CALLS_VIEW: 'service_calls.view',
  SERVICE_CALLS_CREATE: 'service_calls.create',
  SERVICE_CALLS_UPDATE: 'service_calls.update',
  SERVICE_CALLS_DELETE: 'service_calls.delete',
  SERVICE_CALLS_ASSIGN: 'service_calls.assign',
  SERVICE_CALLS_VIEW_ALL: 'service_calls.view_all',
  
  // Parts Management
  PARTS_VIEW: 'parts.view',
  PARTS_CREATE: 'parts.create',
  PARTS_UPDATE: 'parts.update',
  PARTS_DELETE: 'parts.delete',
  PARTS_CATALOG_MANAGE: 'parts.catalog_manage',
  
  // Staff Schedule
  SCHEDULE_VIEW: 'schedule.view',
  SCHEDULE_CREATE: 'schedule.create',
  SCHEDULE_UPDATE: 'schedule.update',
  SCHEDULE_DELETE: 'schedule.delete',
  SCHEDULE_VIEW_ALL: 'schedule.view_all',
  
  // Preventative Maintenance
  PREVENTATIVE_MAINTENANCE_VIEW: 'preventative_maintenance.view',
  PREVENTATIVE_MAINTENANCE_MANAGE: 'preventative_maintenance.manage',
  
  // Scheduled Maintenance
  SCHEDULED_MAINTENANCE_VIEW: 'scheduled_maintenance.view',
  SCHEDULED_MAINTENANCE_CREATE: 'scheduled_maintenance.create',
  SCHEDULED_MAINTENANCE_UPDATE: 'scheduled_maintenance.update',
  SCHEDULED_MAINTENANCE_DELETE: 'scheduled_maintenance.delete',
  
  // Analytics
  ANALYTICS_VIEW: 'analytics.view',
  ANALYTICS_VIEW_ADVANCED: 'analytics.view_advanced',
  
  // User Management
  USERS_VIEW: 'users.view',
  USERS_CREATE: 'users.create',
  USERS_UPDATE: 'users.update',
  USERS_DELETE: 'users.delete',
  USERS_MANAGE_PERMISSIONS: 'users.manage_permissions',
  
  // Location Management
  LOCATIONS_VIEW: 'locations.view',
  LOCATIONS_CREATE: 'locations.create',
  LOCATIONS_UPDATE: 'locations.update',
  LOCATIONS_DELETE: 'locations.delete',
  LOCATIONS_VIEW_ALL: 'locations.view_all',
};

// Role-based permission mappings
const ROLE_PERMISSIONS = {
  // Admin has all permissions
  [ROLES.ADMIN]: Object.values(PERMISSIONS),
  
  // Manager (department: manager)
  manager: [
    PERMISSIONS.SERVICE_CALLS_VIEW,
    PERMISSIONS.SERVICE_CALLS_CREATE,
    PERMISSIONS.SERVICE_CALLS_UPDATE,
    PERMISSIONS.SERVICE_CALLS_DELETE,
    PERMISSIONS.SERVICE_CALLS_ASSIGN,
    PERMISSIONS.SERVICE_CALLS_VIEW_ALL,
    PERMISSIONS.PARTS_VIEW,
    PERMISSIONS.PARTS_CREATE,
    PERMISSIONS.PARTS_UPDATE,
    PERMISSIONS.PARTS_DELETE,
    PERMISSIONS.SCHEDULE_VIEW,
    PERMISSIONS.SCHEDULE_CREATE,
    PERMISSIONS.SCHEDULE_UPDATE,
    PERMISSIONS.SCHEDULE_DELETE,
    PERMISSIONS.SCHEDULE_VIEW_ALL,
    PERMISSIONS.PREVENTATIVE_MAINTENANCE_VIEW,
    PERMISSIONS.PREVENTATIVE_MAINTENANCE_MANAGE,
    PERMISSIONS.SCHEDULED_MAINTENANCE_VIEW,
    PERMISSIONS.SCHEDULED_MAINTENANCE_CREATE,
    PERMISSIONS.SCHEDULED_MAINTENANCE_UPDATE,
    PERMISSIONS.SCHEDULED_MAINTENANCE_DELETE,
    PERMISSIONS.ANALYTICS_VIEW,
    PERMISSIONS.ANALYTICS_VIEW_ADVANCED,
    PERMISSIONS.USERS_VIEW,
    PERMISSIONS.USERS_CREATE,
    PERMISSIONS.USERS_UPDATE,
    PERMISSIONS.LOCATIONS_VIEW,
    PERMISSIONS.LOCATIONS_CREATE,
    PERMISSIONS.LOCATIONS_UPDATE,
  ],
  
  // Senior positions (lead_mechanic and above - level 5 or lower)
  senior_staff: [
    PERMISSIONS.SERVICE_CALLS_VIEW,
    PERMISSIONS.SERVICE_CALLS_CREATE,
    PERMISSIONS.SERVICE_CALLS_UPDATE,
    PERMISSIONS.SERVICE_CALLS_ASSIGN,
    PERMISSIONS.PARTS_VIEW,
    PERMISSIONS.PARTS_CREATE,
    PERMISSIONS.PARTS_UPDATE,
    PERMISSIONS.SCHEDULE_VIEW,
    PERMISSIONS.SCHEDULE_CREATE,
    PERMISSIONS.SCHEDULE_UPDATE,
    PERMISSIONS.SCHEDULE_VIEW_ALL,
    PERMISSIONS.PREVENTATIVE_MAINTENANCE_VIEW,
    PERMISSIONS.PREVENTATIVE_MAINTENANCE_MANAGE,
    PERMISSIONS.SCHEDULED_MAINTENANCE_VIEW,
    PERMISSIONS.SCHEDULED_MAINTENANCE_CREATE,
    PERMISSIONS.SCHEDULED_MAINTENANCE_UPDATE,
    PERMISSIONS.ANALYTICS_VIEW,
    PERMISSIONS.USERS_VIEW,
    PERMISSIONS.LOCATIONS_VIEW,
  ],
  
  // Mechanic (regular mechanic and apprentice)
  mechanic: [
    PERMISSIONS.SERVICE_CALLS_VIEW,
    PERMISSIONS.SERVICE_CALLS_CREATE,
    PERMISSIONS.SERVICE_CALLS_UPDATE,
    PERMISSIONS.PARTS_VIEW,
    PERMISSIONS.SCHEDULE_VIEW,
    PERMISSIONS.PREVENTATIVE_MAINTENANCE_VIEW,
    PERMISSIONS.SCHEDULED_MAINTENANCE_VIEW,
    PERMISSIONS.ANALYTICS_VIEW,
    PERMISSIONS.LOCATIONS_VIEW,
  ],
  
  // Front desk staff
  front_desk: [
    PERMISSIONS.SERVICE_CALLS_VIEW,
    PERMISSIONS.SERVICE_CALLS_CREATE,
    PERMISSIONS.SCHEDULE_VIEW,
    PERMISSIONS.LOCATIONS_VIEW,
  ],
};

/**
 * Check if a user has a specific permission
 * @param {Object} user - User object with role, department, and position
 * @param {string} permission - Permission to check
 * @returns {boolean}
 */
export function hasPermission(user, permission) {
  if (!user) return false;
  
  // Admins have all permissions
  if (user.role === ROLES.ADMIN) {
    return true;
  }
  
  // Get permissions based on department
  let permissions = [];
  
  if (user.department === DEPARTMENTS.MANAGER) {
    permissions = ROLE_PERMISSIONS.manager;
  } else if (user.department === DEPARTMENTS.MECHANIC) {
    // Check if senior staff (lead mechanic or higher)
    const positionLevel = POSITION_LEVELS[user.position] || 999;
    if (positionLevel <= 5) {
      permissions = ROLE_PERMISSIONS.senior_staff;
    } else {
      permissions = ROLE_PERMISSIONS.mechanic;
    }
  } else if (user.department === DEPARTMENTS.FRONT_DESK) {
    permissions = ROLE_PERMISSIONS.front_desk;
  }
  
  return permissions.includes(permission);
}

/**
 * Check if user has any of the specified permissions
 * @param {Object} user - User object
 * @param {Array<string>} permissions - Array of permissions to check
 * @returns {boolean}
 */
export function hasAnyPermission(user, permissions) {
  return permissions.some(permission => hasPermission(user, permission));
}

/**
 * Check if user has all of the specified permissions
 * @param {Object} user - User object
 * @param {Array<string>} permissions - Array of permissions to check
 * @returns {boolean}
 */
export function hasAllPermissions(user, permissions) {
  return permissions.every(permission => hasPermission(user, permission));
}

/**
 * Get user's effective role for display
 * @param {Object} user - User object
 * @returns {string}
 */
export function getUserRole(user) {
  if (!user) return 'Unknown';
  if (user.role === ROLES.ADMIN) return 'Administrator';
  if (user.department === DEPARTMENTS.MANAGER) return 'Manager';
  if (user.department === DEPARTMENTS.MECHANIC) {
    const positionLevel = POSITION_LEVELS[user.position] || 999;
    if (positionLevel <= 5) return 'Senior Staff';
    return 'Mechanic';
  }
  if (user.department === DEPARTMENTS.FRONT_DESK) return 'Front Desk';
  return 'User';
}

/**
 * Check if user can access a specific location
 * @param {Object} user - User object
 * @param {string} locationId - Location ID to check
 * @returns {boolean}
 */
export function canAccessLocation(user, locationId) {
  if (!user) return false;
  
  // Admins can access all locations
  if (user.role === ROLES.ADMIN) {
    return true;
  }
  
  // Managers can access all locations
  if (user.department === DEPARTMENTS.MANAGER) {
    return true;
  }
  
  // Other users can only access their assigned location
  return user.bowling_alley_id === locationId;
}