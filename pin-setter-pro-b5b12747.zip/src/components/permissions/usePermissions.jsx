import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export function usePermissions() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [permissions, setPermissions] = useState([]);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: roles = [] } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
    initialData: [],
  });

  useEffect(() => {
    if (user && roles.length > 0) {
      // Admin role always has all permissions
      if (user.role === 'admin') {
        setUserRole({ name: 'Admin', permission_keys: ['*'] });
        setPermissions(['*']);
        return;
      }

      // Find user's assigned role
      const role = roles.find(r => r.id === user.role_id);
      if (role) {
        setUserRole(role);
        // Combine role permissions with custom user permissions
        const rolePermissions = role.permission_keys || [];
        const customPermissions = user.custom_permissions || [];
        const combined = [...new Set([...rolePermissions, ...customPermissions])];
        setPermissions(combined);
      } else {
        // No role assigned, use only custom permissions if any
        setPermissions(user.custom_permissions || []);
      }
    }
  }, [user, roles]);

  const hasPermission = (permissionKey) => {
    // Admin always has permission
    if (user?.role === 'admin' || permissions.includes('*')) {
      return true;
    }
    return permissions.includes(permissionKey);
  };

  const hasAnyPermission = (permissionKeys) => {
    if (user?.role === 'admin' || permissions.includes('*')) {
      return true;
    }
    return permissionKeys.some(key => permissions.includes(key));
  };

  const hasAllPermissions = (permissionKeys) => {
    if (user?.role === 'admin' || permissions.includes('*')) {
      return true;
    }
    return permissionKeys.every(key => permissions.includes(key));
  };

  return {
    user,
    userRole,
    permissions,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    isAdmin: user?.role === 'admin',
  };
}