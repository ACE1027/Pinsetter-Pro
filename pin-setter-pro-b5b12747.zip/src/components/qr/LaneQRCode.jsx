import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, Printer, Loader2, AlertCircle } from "lucide-react";

export default function LaneQRCode({ 
  open, 
  onOpenChange, 
  location, 
  laneNumber,
  baseUrl = typeof window !== 'undefined' ? window.location.origin : ''
}) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  if (!location) return null;

  const serviceCallUrl = `${baseUrl}/CreateServiceCall?bowling_alley_id=${location.id}&lane_number=${laneNumber}`;
  // Switch to goqr.me or qrserver as they are often more reliable for simple QR codes
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(serviceCallUrl)}&margin=10`;

  const handleDownload = async () => {
    try {
      const response = await fetch(qrImageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `lane-${laneNumber}-qr-${location.name?.replace(/\s+/g, '-')}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading QR code:', error);
      // Fallback for download if fetch fails (e.g. CORS)
      const link = document.createElement('a');
      link.href = qrImageUrl;
      link.target = "_blank";
      link.download = `lane-${laneNumber}-qr.png`;
      link.click();
    }
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Lane ${laneNumber} QR Code - ${location.name}</title>
          <style>
            body {
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              min-height: 100vh;
              margin: 0;
              font-family: Arial, sans-serif;
            }
            .qr-container {
              text-align: center;
              padding: 20px;
              border: 2px solid #000;
              border-radius: 10px;
              max-width: 400px;
            }
            h1 { font-size: 24px; margin-bottom: 5px; }
            h2 { font-size: 48px; margin: 10px 0; color: #2563eb; }
            img { margin: 20px 0; width: 256px; height: 256px; display: block; margin: 20px auto; }
            p { font-size: 14px; color: #666; }
            @media print {
              body { -webkit-print-color-adjust: exact; }
            }
          </style>
        </head>
        <body>
          <div class="qr-container">
            <h1>${location.name}</h1>
            <h2>Lane ${laneNumber}</h2>
            <img src="${qrImageUrl}" alt="QR Code" />
            <p>Scan to report an issue</p>
          </div>
          <script>
            // Wait for image to load before printing
            const img = document.querySelector('img');
            if (img.complete) {
              setTimeout(() => { window.print(); window.close(); }, 500);
            } else {
              img.onload = () => { setTimeout(() => { window.print(); window.close(); }, 500); };
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">
            Lane {laneNumber} QR Code
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col items-center space-y-4">
          <div className="text-center text-sm text-slate-600 mb-2">
            <p className="font-medium">{location.name}</p>
            <p>Scan to create a service call</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg border-2 border-slate-200 relative min-w-[280px] min-h-[280px] flex items-center justify-center">
            {!imageLoaded && !imageError && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
              </div>
            )}
            
            {imageError ? (
              <div className="text-center text-red-500 flex flex-col items-center p-4">
                <AlertCircle className="w-8 h-8 mb-2" />
                <p>Failed to load QR code</p>
                <Button variant="link" onClick={() => { setImageError(false); setImageLoaded(false); }} className="mt-2">
                  Retry
                </Button>
                <a href={serviceCallUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-600 mt-4 hover:underline">
                  Test Link Directly
                </a>
              </div>
            ) : (
              <img 
                src={qrImageUrl} 
                alt={`QR Code for Lane ${laneNumber}`}
                className={`w-64 h-64 transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
                onLoad={() => setImageLoaded(true)}
                onError={(e) => {
                  console.error("QR Load Error:", e);
                  setImageError(true);
                }}
              />
            )}
          </div>
          
          <p className="text-xs text-slate-500 text-center max-w-xs break-all">
            {serviceCallUrl}
          </p>
          
          <div className="flex gap-3 w-full">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={handleDownload}
              disabled={!imageLoaded}
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
            <Button 
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              onClick={handlePrint}
              disabled={!imageLoaded}
            >
              <Printer className="w-4 h-4 mr-2" />
              Print
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}