import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Clock } from "lucide-react";
import { toast } from "sonner";

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function AvailabilityManager({ user, isDarkMode }) {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAvailability, setEditingAvailability] = useState(null);
  const [formData, setFormData] = useState({
    day_of_week: 0,
    start_time: "08:00",
    end_time: "17:00",
    is_available: true,
    notes: ""
  });

  const { data: availabilities = [] } = useQuery({
    queryKey: ['employeeAvailability', user?.email],
    queryFn: async () => {
      const all = await base44.entities.EmployeeAvailability.list();
      return all.filter(a => a.user_email === user?.email);
    },
    enabled: !!user
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.EmployeeAvailability.create({
      ...data,
      user_email: user.email
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeAvailability'] });
      resetForm();
      toast.success("Availability saved");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EmployeeAvailability.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeAvailability'] });
      resetForm();
      toast.success("Availability updated");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EmployeeAvailability.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeAvailability'] });
      toast.success("Availability deleted");
    }
  });

  const resetForm = () => {
    setDialogOpen(false);
    setEditingAvailability(null);
    setFormData({
      day_of_week: 0,
      start_time: "08:00",
      end_time: "17:00",
      is_available: true,
      notes: ""
    });
  };

  const handleEdit = (availability) => {
    setEditingAvailability(availability);
    setFormData({
      day_of_week: availability.day_of_week,
      start_time: availability.start_time || "08:00",
      end_time: availability.end_time || "17:00",
      is_available: availability.is_available,
      notes: availability.notes || ""
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingAvailability) {
      updateMutation.mutate({ id: editingAvailability.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const groupedByDay = DAYS.map((day, idx) => ({
    day,
    dayIndex: idx,
    availabilities: availabilities.filter(a => a.day_of_week === idx)
  }));

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>My Availability</CardTitle>
          <Button onClick={() => setDialogOpen(true)} size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Add Availability
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {groupedByDay.map(({ day, dayIndex, availabilities: dayAvail }) => (
            <div key={dayIndex} className={`p-3 rounded-lg border ${
              isDarkMode ? 'border-slate-700 bg-slate-800' : 'border-slate-200 bg-slate-50'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <h3 className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {day}
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setFormData({ ...formData, day_of_week: dayIndex });
                    setDialogOpen(true);
                  }}
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
              {dayAvail.length > 0 ? (
                <div className="space-y-2">
                  {dayAvail.map(avail => (
                    <div key={avail.id} className={`flex items-center justify-between p-2 rounded ${
                      avail.is_available ? 
                        (isDarkMode ? 'bg-green-900/20' : 'bg-green-50') : 
                        (isDarkMode ? 'bg-red-900/20' : 'bg-red-50')
                    }`}>
                      <div className="flex items-center gap-2">
                        <Badge variant={avail.is_available ? "default" : "destructive"} className="text-xs">
                          {avail.is_available ? 'Available' : 'Unavailable'}
                        </Badge>
                        {avail.start_time && avail.end_time && (
                          <div className="flex items-center gap-1 text-sm">
                            <Clock className="w-3 h-3" />
                            <span>{avail.start_time} - {avail.end_time}</span>
                          </div>
                        )}
                        {avail.notes && (
                          <span className="text-xs text-slate-500 italic">{avail.notes}</span>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(avail)}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteMutation.mutate(avail.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">No availability set</p>
              )}
            </div>
          ))}
        </div>

        {/* Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingAvailability ? 'Edit Availability' : 'Add Availability'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Day of Week</Label>
                <select
                  className="w-full p-2 border rounded"
                  value={formData.day_of_week}
                  onChange={(e) => setFormData({ ...formData, day_of_week: parseInt(e.target.value) })}
                >
                  {DAYS.map((day, idx) => (
                    <option key={idx} value={idx}>{day}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.is_available}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_available: checked })}
                />
                <Label>Available</Label>
              </div>

              {formData.is_available && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Time</Label>
                    <Input
                      type="time"
                      value={formData.start_time}
                      onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>End Time</Label>
                    <Input
                      type="time"
                      value={formData.end_time}
                      onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Optional notes..."
                  rows={2}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Save
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}