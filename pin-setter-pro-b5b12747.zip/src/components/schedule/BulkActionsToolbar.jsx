import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, Copy, Calendar, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function BulkActionsToolbar({ 
  selectedCount, 
  onBulkDelete, 
  onBulkCopy,
  onClearSelection,
  isDarkMode 
}) {
  const [copyDialogOpen, setCopyDialogOpen] = useState(false);
  const [targetDate, setTargetDate] = useState("");

  const handleBulkCopy = () => {
    if (!targetDate) {
      toast.error("Please select a target date");
      return;
    }
    onBulkCopy(targetDate);
    setCopyDialogOpen(false);
    setTargetDate("");
  };

  if (selectedCount === 0) return null;

  return (
    <>
      <div className={`fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 shadow-2xl rounded-lg border-2 p-4 ${
        isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-300'
      }`}>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-sm">
              {selectedCount} selected
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearSelection}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="h-6 w-px bg-slate-300" />
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCopyDialogOpen(true)}
              className="border-blue-300 text-blue-700 hover:bg-blue-50"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy to Date
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={onBulkDelete}
              className="border-red-300 text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
          </div>
        </div>
      </div>

      {/* Copy Dialog */}
      <Dialog open={copyDialogOpen} onOpenChange={setCopyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Copy {selectedCount} Shift(s)</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="target_date">Target Date</Label>
              <Input
                id="target_date"
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                placeholder="Select date to copy shifts to"
              />
              <p className="text-xs text-slate-500">
                Shifts will be copied to the same day of week at the target date
              </p>
            </div>
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setCopyDialogOpen(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleBulkCopy}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy Shifts
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}