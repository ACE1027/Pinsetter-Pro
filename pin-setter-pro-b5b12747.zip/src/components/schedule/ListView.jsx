import React, { useState } from "react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Edit, Trash2, User, Clock, Calendar, MapPin } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ListView({ 
  schedules, 
  getUserName, 
  getPositionLabel,
  getLocationName,
  onEdit, 
  onDelete, 
  canEdit,
  selectedSchedules,
  onToggleSchedule,
  onToggleAll,
  isDarkMode 
}) {
  const [sortColumn, setSortColumn] = useState('date');
  const [sortDirection, setSortDirection] = useState('asc');

  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const sortedSchedules = [...schedules].sort((a, b) => {
    let aVal, bVal;
    
    switch (sortColumn) {
      case 'date':
        aVal = new Date(a.date);
        bVal = new Date(b.date);
        break;
      case 'employee':
        aVal = getUserName(a.user_email);
        bVal = getUserName(b.user_email);
        break;
      case 'time':
        aVal = a.shift_start;
        bVal = b.shift_start;
        break;
      case 'location':
        aVal = getLocationName(a.bowling_alley_id);
        bVal = getLocationName(b.bowling_alley_id);
        break;
      default:
        return 0;
    }
    
    if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  const allSelected = schedules.length > 0 && selectedSchedules.length === schedules.length;

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Schedule List</span>
          <Badge variant="outline">{schedules.length} shifts</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                {canEdit && (
                  <TableHead className="w-12">
                    <Checkbox
                      checked={allSelected}
                      onCheckedChange={() => onToggleAll(schedules)}
                    />
                  </TableHead>
                )}
                <TableHead 
                  className="cursor-pointer hover:bg-slate-50"
                  onClick={() => handleSort('date')}
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Date {sortColumn === 'date' && (sortDirection === 'asc' ? '↑' : '↓')}
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-50"
                  onClick={() => handleSort('employee')}
                >
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Employee {sortColumn === 'employee' && (sortDirection === 'asc' ? '↑' : '↓')}
                  </div>
                </TableHead>
                <TableHead>Role</TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-50"
                  onClick={() => handleSort('time')}
                >
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Time {sortColumn === 'time' && (sortDirection === 'asc' ? '↑' : '↓')}
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-50"
                  onClick={() => handleSort('location')}
                >
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Location {sortColumn === 'location' && (sortDirection === 'asc' ? '↑' : '↓')}
                  </div>
                </TableHead>
                <TableHead>Notes</TableHead>
                {canEdit && <TableHead className="text-right">Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedSchedules.length > 0 ? (
                sortedSchedules.map((schedule) => (
                  <TableRow key={schedule.id}>
                    {canEdit && (
                      <TableCell>
                        <Checkbox
                          checked={selectedSchedules.includes(schedule.id)}
                          onCheckedChange={() => onToggleSchedule(schedule.id)}
                        />
                      </TableCell>
                    )}
                    <TableCell className="font-medium">
                      {format(new Date(schedule.date.split('T')[0]), 'EEE, MMM d, yyyy')}
                    </TableCell>
                    <TableCell>{getUserName(schedule.user_email)}</TableCell>
                    <TableCell>
                      {schedule.role && (
                        <Badge variant="outline">{getPositionLabel(schedule.role)}</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {schedule.shift_start} - {schedule.shift_end}
                    </TableCell>
                    <TableCell className="text-sm text-slate-600">
                      {getLocationName(schedule.bowling_alley_id)}
                    </TableCell>
                    <TableCell className="text-sm text-slate-600 max-w-xs truncate">
                      {schedule.notes || '-'}
                    </TableCell>
                    {canEdit && (
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onEdit(schedule)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onDelete(schedule)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={canEdit ? 9 : 8} className="text-center py-8 text-slate-500">
                    No schedules found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}