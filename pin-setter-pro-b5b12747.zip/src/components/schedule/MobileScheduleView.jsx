import React from "react";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, Clock, Calendar, MapPin, Edit, Trash2 } from "lucide-react";

export default function MobileScheduleView({ 
  schedules, 
  getUserName, 
  getPositionLabel,
  getLocationName,
  onEdit, 
  onDelete, 
  canEdit,
  isDarkMode 
}) {
  return (
    <div className="space-y-3">
      {schedules.map(schedule => (
        <Card key={schedule.id} className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <CardContent className="p-4">
            <div className="space-y-3">
              {/* Date Header */}
              <div className={`flex items-center justify-between pb-2 border-b ${
                isDarkMode ? 'border-slate-700' : 'border-slate-200'
              }`}>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  <span className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {format(new Date(schedule.date.split('T')[0]), 'EEE, MMM d')}
                  </span>
                </div>
                {schedule.role && (
                  <Badge variant="outline">{getPositionLabel(schedule.role)}</Badge>
                )}
              </div>

              {/* Employee & Time */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-slate-500" />
                  <span className={`font-medium ${isDarkMode ? 'text-slate-200' : 'text-slate-700'}`}>
                    {getUserName(schedule.user_email)}
                  </span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-500" />
                  <span className={`${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                    {schedule.shift_start} - {schedule.shift_end}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-slate-500" />
                  <span className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    {getLocationName(schedule.bowling_alley_id)}
                  </span>
                </div>
              </div>

              {/* Notes */}
              {schedule.notes && (
                <div className={`p-2 rounded text-sm ${
                  isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-50 text-slate-600'
                }`}>
                  {schedule.notes}
                </div>
              )}

              {/* Actions */}
              {canEdit && (
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onEdit(schedule)}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onDelete(schedule)}
                    className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}

      {schedules.length === 0 && (
        <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
          <CardContent className="p-12 text-center">
            <Calendar className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
            <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
              No schedules found
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}