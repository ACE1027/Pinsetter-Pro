import React from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, User, Clock } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

export default function MonthlyCalendar({ 
  currentMonth, 
  setCurrentMonth, 
  schedules, 
  getUserName, 
  getPositionLabel, 
  onScheduleDrop, 
  onScheduleClick, 
  canEdit,
  isDarkMode 
}) {
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  
  // Get first day of week (0 = Sunday)
  const firstDayOfWeek = monthStart.getDay();
  
  // Fill in empty days at start
  const emptyDays = Array(firstDayOfWeek).fill(null);
  
  const getSchedulesForDay = (day) => {
    return schedules.filter(schedule => {
      const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return isSameDay(scheduleDate, day);
    });
  };

  const handleDragEnd = (result) => {
    if (!result.destination || !canEdit) return;
    
    const sourceDate = result.source.droppableId;
    const destDate = result.destination.droppableId;
    const scheduleId = result.draggableId;
    
    if (sourceDate !== destDate) {
      onScheduleDrop(scheduleId, destDate);
    }
  };

  const goToPreviousMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const goToNextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const goToCurrentMonth = () => setCurrentMonth(new Date());

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={goToPreviousMonth} size="sm">
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <div className="text-center">
          <h2 className={`text-xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            {format(currentMonth, 'MMMM yyyy')}
          </h2>
          <Button variant="link" onClick={goToCurrentMonth} className="text-sm">
            Go to Today
          </Button>
        </div>
        <Button variant="outline" onClick={goToNextMonth} size="sm">
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Calendar Grid */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className={`grid grid-cols-7 gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
          {/* Day headers */}
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-xs font-semibold p-2 text-slate-600">
              {day}
            </div>
          ))}
          
          {/* Empty days */}
          {emptyDays.map((_, idx) => (
            <div key={`empty-${idx}`} className="min-h-32" />
          ))}
          
          {/* Calendar days */}
          {days.map(day => {
            const daySchedules = getSchedulesForDay(day);
            const isToday = isSameDay(day, new Date());
            const isCurrentMonth = isSameMonth(day, currentMonth);
            const dateKey = format(day, 'yyyy-MM-dd');
            
            return (
              <Droppable key={dateKey} droppableId={dateKey} isDropDisabled={!canEdit}>
                {(provided, snapshot) => (
                  <Card 
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`min-h-32 transition-colors ${
                      isToday ? 'border-2 border-blue-500 shadow-lg' : 
                      isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                    } ${
                      snapshot.isDraggingOver ? 'bg-blue-50 border-blue-300' : ''
                    } ${
                      !isCurrentMonth ? 'opacity-40' : ''
                    }`}
                  >
                    <CardContent className="p-2">
                      <div className={`text-sm font-semibold mb-2 ${
                        isToday ? 'text-blue-600' : 
                        isDarkMode ? 'text-slate-300' : 'text-slate-900'
                      }`}>
                        {format(day, 'd')}
                      </div>
                      
                      <div className="space-y-1">
                        {daySchedules.map((schedule, idx) => (
                          <Draggable 
                            key={schedule.id} 
                            draggableId={schedule.id} 
                            index={idx}
                            isDragDisabled={!canEdit}
                          >
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                onClick={() => onScheduleClick && onScheduleClick(schedule)}
                                className={`p-1.5 rounded text-xs cursor-pointer transition-all ${
                                  snapshot.isDragging ? 'shadow-lg opacity-75' : ''
                                } ${
                                  isDarkMode ? 'bg-blue-900/30 hover:bg-blue-900/50 border border-blue-800' : 
                                  'bg-blue-50 hover:bg-blue-100 border border-blue-200'
                                }`}
                              >
                                <div className="flex items-center gap-1 mb-0.5">
                                  <User className="w-2.5 h-2.5 text-slate-500 flex-shrink-0" />
                                  <span className={`font-medium truncate ${isDarkMode ? 'text-slate-200' : 'text-slate-700'}`}>
                                    {getUserName(schedule.user_email).split(' ')[0]}
                                  </span>
                                </div>
                                {schedule.role && (
                                  <Badge variant="outline" className="text-[10px] px-1 py-0 h-4">
                                    {getPositionLabel(schedule.role)}
                                  </Badge>
                                )}
                                <div className="flex items-center gap-1 mt-0.5">
                                  <Clock className="w-2.5 h-2.5 text-slate-400" />
                                  <span className="text-[10px] text-slate-500">
                                    {schedule.shift_start}
                                  </span>
                                </div>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                      
                      {daySchedules.length === 0 && canEdit && (
                        <div className="text-[10px] text-slate-400 text-center mt-2">
                          Drop here
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </Droppable>
            );
          })}
        </div>
      </DragDropContext>
    </div>
  );
}