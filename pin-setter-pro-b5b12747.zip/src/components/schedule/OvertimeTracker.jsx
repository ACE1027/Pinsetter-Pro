import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, TrendingUp, Clock } from "lucide-react";
import { format, startOfWeek, endOfWeek, isWithinInterval } from "date-fns";

export default function OvertimeTracker({ schedules, users, currentWeekStart, isDarkMode }) {
  const STANDARD_HOURS = 40;
  const OVERTIME_THRESHOLD = 40;

  const weekStart = startOfWeek(currentWeekStart, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeekStart, { weekStartsOn: 1 });

  const calculateShiftHours = (startTime, endTime) => {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    const start = startHour + startMin / 60;
    const end = endHour + endMin / 60;
    return end > start ? end - start : (24 - start) + end;
  };

  const employeeHours = users.map(user => {
    const userSchedules = schedules.filter(schedule => {
      if (schedule.user_email !== user.email) return false;
      const scheduleDate = new Date(schedule.date.split('T')[0]);
      return isWithinInterval(scheduleDate, { start: weekStart, end: weekEnd });
    });

    const totalHours = userSchedules.reduce((sum, schedule) => 
      sum + calculateShiftHours(schedule.shift_start, schedule.shift_end), 0
    );

    const overtimeHours = Math.max(0, totalHours - OVERTIME_THRESHOLD);
    const regularHours = Math.min(totalHours, STANDARD_HOURS);

    return {
      email: user.email,
      name: user.display_name || user.full_name || user.email,
      totalHours: totalHours.toFixed(1),
      regularHours: regularHours.toFixed(1),
      overtimeHours: overtimeHours.toFixed(1),
      shiftsCount: userSchedules.length,
      isOvertime: totalHours > OVERTIME_THRESHOLD
    };
  }).filter(emp => emp.shiftsCount > 0).sort((a, b) => b.totalHours - a.totalHours);

  const totalOvertime = employeeHours.reduce((sum, emp) => sum + parseFloat(emp.overtimeHours), 0);
  const employeesWithOvertime = employeeHours.filter(emp => emp.isOvertime).length;

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Weekly Hours Tracker
          </span>
          <Badge variant={employeesWithOvertime > 0 ? "destructive" : "default"}>
            {format(weekStart, 'MMM d')} - {format(weekEnd, 'MMM d')}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-blue-50'}`}>
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <span className="text-xs text-slate-600">Total Overtime</span>
            </div>
            <div className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              {totalOvertime.toFixed(1)} hrs
            </div>
          </div>
          <div className={`p-4 rounded-lg ${
            employeesWithOvertime > 0 ? 
              (isDarkMode ? 'bg-red-900/20' : 'bg-red-50') : 
              (isDarkMode ? 'bg-slate-800' : 'bg-green-50')
          }`}>
            <div className="flex items-center gap-2 mb-1">
              <AlertTriangle className={`w-4 h-4 ${employeesWithOvertime > 0 ? 'text-red-600' : 'text-green-600'}`} />
              <span className="text-xs text-slate-600">Employees Over 40h</span>
            </div>
            <div className={`text-2xl font-bold ${
              employeesWithOvertime > 0 ? 'text-red-600' : 
              isDarkMode ? 'text-slate-100' : 'text-slate-900'
            }`}>
              {employeesWithOvertime}
            </div>
          </div>
        </div>

        {/* Employee List */}
        <div className="space-y-2">
          {employeeHours.map(emp => (
            <div 
              key={emp.email} 
              className={`p-3 rounded-lg border ${
                emp.isOvertime ? 
                  (isDarkMode ? 'border-red-800 bg-red-900/10' : 'border-red-200 bg-red-50') : 
                  (isDarkMode ? 'border-slate-700 bg-slate-800' : 'border-slate-200 bg-slate-50')
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="font-medium">{emp.name}</div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {emp.shiftsCount} shifts
                  </Badge>
                  {emp.isOvertime && (
                    <Badge variant="destructive" className="text-xs">
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Overtime
                    </Badge>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div>
                  <span className="text-xs text-slate-500">Total:</span>
                  <span className={`ml-1 font-semibold ${
                    emp.isOvertime ? 'text-red-600' : 
                    isDarkMode ? 'text-slate-100' : 'text-slate-900'
                  }`}>
                    {emp.totalHours}h
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500">Regular:</span>
                  <span className={`ml-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    {emp.regularHours}h
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500">Overtime:</span>
                  <span className={`ml-1 font-semibold ${
                    parseFloat(emp.overtimeHours) > 0 ? 'text-red-600' : 
                    isDarkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    {emp.overtimeHours}h
                  </span>
                </div>
              </div>
              
              {/* Progress Bar */}
              <div className="mt-2 h-2 bg-slate-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${
                    parseFloat(emp.totalHours) > OVERTIME_THRESHOLD ? 'bg-red-500' : 'bg-blue-500'
                  }`}
                  style={{ width: `${Math.min((parseFloat(emp.totalHours) / 60) * 100, 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {employeeHours.length === 0 && (
          <div className="text-center py-8 text-slate-500">
            No scheduled hours for this week
          </div>
        )}
      </CardContent>
    </Card>
  );
}