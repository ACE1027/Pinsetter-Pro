import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, RefreshCw, Play } from "lucide-react";
import { toast } from "sonner";
import { format, addDays, startOfWeek, isBefore, isAfter } from "date-fns";

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function RecurringScheduleManager({ 
  users, 
  locations, 
  effectiveLocationId,
  canEdit,
  getAvailableRoles,
  getPositionLabel,
  isDarkMode 
}) {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    bowling_alley_id: effectiveLocationId || "",
    day_of_week: 0,
    user_email: "",
    shift_start: "08:00",
    shift_end: "16:00",
    role: "",
    active: true,
    start_date: format(new Date(), 'yyyy-MM-dd'),
    end_date: "",
    notes: ""
  });

  const { data: recurringSchedules = [] } = useQuery({
    queryKey: ['recurringSchedules'],
    queryFn: () => base44.entities.RecurringSchedule.list(),
    initialData: []
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RecurringSchedule.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringSchedules'] });
      resetForm();
      toast.success("Recurring schedule created");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RecurringSchedule.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringSchedules'] });
      resetForm();
      toast.success("Recurring schedule updated");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RecurringSchedule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringSchedules'] });
      toast.success("Recurring schedule deleted");
    }
  });

  const generateSchedulesMutation = useMutation({
    mutationFn: async ({ recurringSchedule, weeksAhead }) => {
      const schedules = [];
      const startDate = new Date(recurringSchedule.start_date);
      const endDate = recurringSchedule.end_date ? new Date(recurringSchedule.end_date) : addDays(new Date(), weeksAhead * 7);
      
      let currentWeekStart = startOfWeek(new Date(), { weekStartsOn: 0 });
      
      for (let week = 0; week < weeksAhead; week++) {
        const targetDate = addDays(currentWeekStart, recurringSchedule.day_of_week + (week * 7));
        
        if (!isBefore(targetDate, startDate) && !isAfter(targetDate, endDate)) {
          schedules.push({
            user_email: recurringSchedule.user_email,
            bowling_alley_id: recurringSchedule.bowling_alley_id,
            date: format(targetDate, 'yyyy-MM-dd'),
            shift_start: recurringSchedule.shift_start,
            shift_end: recurringSchedule.shift_end,
            role: recurringSchedule.role,
            notes: recurringSchedule.notes,
            device_timestamp: new Date().toISOString()
          });
        }
      }
      
      return Promise.all(schedules.map(s => base44.entities.UserSchedule.create(s)));
    },
    onSuccess: (_, { schedules }) => {
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      toast.success(`Generated ${schedules?.length || 0} schedules`);
    }
  });

  const resetForm = () => {
    setDialogOpen(false);
    setEditingSchedule(null);
    setFormData({
      name: "",
      bowling_alley_id: effectiveLocationId || "",
      day_of_week: 0,
      user_email: "",
      shift_start: "08:00",
      shift_end: "16:00",
      role: "",
      active: true,
      start_date: format(new Date(), 'yyyy-MM-dd'),
      end_date: "",
      notes: ""
    });
  };

  const handleEdit = (schedule) => {
    setEditingSchedule(schedule);
    setFormData({
      name: schedule.name || "",
      bowling_alley_id: schedule.bowling_alley_id,
      day_of_week: schedule.day_of_week,
      user_email: schedule.user_email,
      shift_start: schedule.shift_start,
      shift_end: schedule.shift_end,
      role: schedule.role || "",
      active: schedule.active,
      start_date: schedule.start_date ? format(new Date(schedule.start_date), 'yyyy-MM-dd') : "",
      end_date: schedule.end_date ? format(new Date(schedule.end_date), 'yyyy-MM-dd') : "",
      notes: schedule.notes || ""
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingSchedule) {
      updateMutation.mutate({ id: editingSchedule.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleGenerate = (schedule) => {
    if (window.confirm(`Generate schedules for the next 4 weeks from this pattern?`)) {
      generateSchedulesMutation.mutate({ recurringSchedule: schedule, weeksAhead: 4 });
    }
  };

  const filteredSchedules = recurringSchedules.filter(s => 
    !effectiveLocationId || s.bowling_alley_id === effectiveLocationId
  );

  return (
    <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5" />
            Recurring Schedules
          </CardTitle>
          {canEdit && (
            <Button onClick={() => setDialogOpen(true)} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Pattern
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {filteredSchedules.map(schedule => (
            <div key={schedule.id} className={`p-4 rounded-lg border ${
              schedule.active ? 
                (isDarkMode ? 'border-blue-800 bg-blue-900/10' : 'border-blue-200 bg-blue-50') : 
                (isDarkMode ? 'border-slate-700 bg-slate-800' : 'border-slate-200 bg-slate-50')
            }`}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {schedule.name || `${DAYS[schedule.day_of_week]} Schedule`}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={schedule.active ? "default" : "secondary"}>
                      {schedule.active ? 'Active' : 'Inactive'}
                    </Badge>
                    <Badge variant="outline">{DAYS[schedule.day_of_week]}</Badge>
                  </div>
                </div>
                {canEdit && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleGenerate(schedule)}
                      className="text-blue-600"
                    >
                      <Play className="w-3 h-3 mr-1" />
                      Generate
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(schedule)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteMutation.mutate(schedule.id)}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-xs text-slate-500">Employee:</span>
                  <p className={`font-medium ${isDarkMode ? 'text-slate-200' : 'text-slate-700'}`}>
                    {users.find(u => u.email === schedule.user_email)?.display_name || schedule.user_email}
                  </p>
                </div>
                <div>
                  <span className="text-xs text-slate-500">Time:</span>
                  <p className={`font-medium ${isDarkMode ? 'text-slate-200' : 'text-slate-700'}`}>
                    {schedule.shift_start} - {schedule.shift_end}
                  </p>
                </div>
                {schedule.role && (
                  <div>
                    <span className="text-xs text-slate-500">Role:</span>
                    <Badge variant="outline" className="ml-2">{getPositionLabel(schedule.role)}</Badge>
                  </div>
                )}
                {schedule.start_date && (
                  <div>
                    <span className="text-xs text-slate-500">Period:</span>
                    <p className={`text-xs ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                      {format(new Date(schedule.start_date), 'MMM d, yyyy')}
                      {schedule.end_date && ` - ${format(new Date(schedule.end_date), 'MMM d, yyyy')}`}
                    </p>
                  </div>
                )}
              </div>
              
              {schedule.notes && (
                <p className={`text-xs mt-2 italic ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {schedule.notes}
                </p>
              )}
            </div>
          ))}

          {filteredSchedules.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              No recurring schedules set up yet
            </div>
          )}
        </div>

        {/* Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingSchedule ? 'Edit Recurring Schedule' : 'Create Recurring Schedule'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Pattern Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Monday Morning Shift"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Location *</Label>
                  <Select
                    value={formData.bowling_alley_id}
                    onValueChange={(value) => setFormData({ ...formData, bowling_alley_id: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.filter(l => l.active !== false).map(location => (
                        <SelectItem key={location.id} value={location.id}>
                          {location.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Day of Week *</Label>
                  <Select
                    value={formData.day_of_week.toString()}
                    onValueChange={(value) => setFormData({ ...formData, day_of_week: parseInt(value) })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DAYS.map((day, idx) => (
                        <SelectItem key={idx} value={idx.toString()}>{day}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Employee *</Label>
                <Select
                  value={formData.user_email}
                  onValueChange={(value) => setFormData({ ...formData, user_email: value, role: "" })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.filter(u => u.active !== false).map(user => (
                      <SelectItem key={user.id} value={user.email}>
                        {user.display_name || user.full_name || user.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Role</Label>
                <Select
                  value={formData.role}
                  onValueChange={(value) => setFormData({ ...formData, role: value })}
                  disabled={!formData.user_email}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableRoles(formData.user_email).map(role => (
                      <SelectItem key={role} value={role}>
                        {getPositionLabel(role)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Shift Start *</Label>
                  <Input
                    type="time"
                    value={formData.shift_start}
                    onChange={(e) => setFormData({ ...formData, shift_start: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Shift End *</Label>
                  <Input
                    type="time"
                    value={formData.shift_end}
                    onChange={(e) => setFormData({ ...formData, shift_end: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date *</Label>
                  <Input
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>End Date (Optional)</Label>
                  <Input
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Additional notes..."
                  rows={2}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.active}
                  onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                />
                <Label>Active</Label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700">
                  {editingSchedule ? 'Update' : 'Create'} Pattern
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}