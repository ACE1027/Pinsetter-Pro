import React from "react";
import { format, addDays, startOfWeek } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Activity } from "lucide-react";

export default function TimelineView({ 
  currentWeekStart,
  setCurrentWeekStart,
  schedules, 
  getUserName, 
  getPositionLabel,
  onScheduleClick,
  isDarkMode 
}) {
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));
  const hours = Array.from({ length: 24 }, (_, i) => i);

  const getSchedulesForDayAndHour = (day, hour) => {
    return schedules.filter(schedule => {
      const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      
      if (scheduleDate.toDateString() !== day.toDateString()) return false;
      
      const startHour = parseInt(schedule.shift_start.split(':')[0]);
      const endHour = parseInt(schedule.shift_end.split(':')[0]);
      
      return hour >= startHour && hour < endHour;
    });
  };

  const goToPreviousWeek = () => setCurrentWeekStart(addDays(currentWeekStart, -7));
  const goToNextWeek = () => setCurrentWeekStart(addDays(currentWeekStart, 7));
  const goToCurrentWeek = () => setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }));

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={goToPreviousWeek} size="sm">
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <div className="text-center">
          <h2 className={`text-xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            {format(currentWeekStart, 'MMM d')} - {format(addDays(currentWeekStart, 6), 'MMM d, yyyy')}
          </h2>
          <Button variant="link" onClick={goToCurrentWeek} className="text-sm">
            Go to Current Week
          </Button>
        </div>
        <Button variant="outline" onClick={goToNextWeek} size="sm">
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Timeline Grid */}
      <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
        <CardContent className="p-4 overflow-x-auto">
          <div className="min-w-[1200px]">
            {/* Day Headers */}
            <div className="grid grid-cols-8 gap-2 mb-2">
              <div className="text-xs font-semibold text-slate-600">Time</div>
              {weekDays.map(day => (
                <div key={day.toISOString()} className="text-center">
                  <div className="text-xs font-semibold">{format(day, 'EEE')}</div>
                  <div className={`text-sm font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {format(day, 'MMM d')}
                  </div>
                </div>
              ))}
            </div>

            {/* Timeline Grid */}
            <div className="space-y-1">
              {hours.map(hour => (
                <div key={hour} className="grid grid-cols-8 gap-2">
                  <div className={`text-xs font-medium py-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    {hour.toString().padStart(2, '0')}:00
                  </div>
                  {weekDays.map(day => {
                    const daySchedules = getSchedulesForDayAndHour(day, hour);
                    return (
                      <div 
                        key={`${day.toISOString()}-${hour}`}
                        className={`min-h-[40px] border rounded p-1 ${
                          isDarkMode ? 'border-slate-700 bg-slate-800/50' : 'border-slate-200 bg-slate-50'
                        }`}
                      >
                        {daySchedules.map(schedule => {
                          const startHour = parseInt(schedule.shift_start.split(':')[0]);
                          if (startHour === hour) {
                            return (
                              <div
                                key={schedule.id}
                                onClick={() => onScheduleClick && onScheduleClick(schedule)}
                                className={`text-xs p-1 rounded cursor-pointer ${
                                  isDarkMode ? 'bg-blue-900/50 hover:bg-blue-900/70 text-slate-200' : 
                                  'bg-blue-100 hover:bg-blue-200 text-blue-900'
                                } border ${isDarkMode ? 'border-blue-800' : 'border-blue-300'}`}
                              >
                                <div className="font-semibold truncate">
                                  {getUserName(schedule.user_email)}
                                </div>
                                <div className="text-[10px] opacity-75">
                                  {schedule.shift_start}-{schedule.shift_end}
                                </div>
                                {schedule.role && (
                                  <Badge variant="outline" className="text-[9px] px-1 py-0 h-3 mt-0.5">
                                    {getPositionLabel(schedule.role)}
                                  </Badge>
                                )}
                              </div>
                            );
                          }
                          return null;
                        })}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}