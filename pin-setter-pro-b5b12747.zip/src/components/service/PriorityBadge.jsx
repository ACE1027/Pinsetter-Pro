import React from 'react';
import { Badge } from "@/components/ui/badge";
import { AlertCircle, ArrowUp, Minus, Zap } from "lucide-react";

const priorityConfig = {
  low: {
    label: "Low",
    color: "bg-slate-100 text-slate-700 border-slate-300",
    icon: Minus
  },
  medium: {
    label: "Medium",
    color: "bg-blue-100 text-blue-700 border-blue-300",
    icon: ArrowUp
  },
  high: {
    label: "High",
    color: "bg-orange-100 text-orange-700 border-orange-300",
    icon: AlertCircle
  },
  urgent: {
    label: "Urgent",
    color: "bg-red-100 text-red-700 border-red-300",
    icon: Zap
  }
};

export default function PriorityBadge({ priority, showIcon = true }) {
  const config = priorityConfig[priority] || priorityConfig.medium;
  const Icon = config.icon;

  return (
    <Badge className={`${config.color} border px-2.5 py-0.5 font-medium`}>
      {showIcon && <Icon className="w-3 h-3 mr-1.5" />}
      {config.label}
    </Badge>
  );
}