import React from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { ChevronRight, User, Calendar, Image as ImageIcon } from "lucide-react";
import StatusBadge from "./StatusBadge";
import PriorityBadge from "./PriorityBadge";
import { useTheme } from "@/components/ThemeContext";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export default function ServiceCallCard({ call }) {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const queryClient = useQueryClient();

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.ServiceCall.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      toast.success("Status updated");
    },
  });

  const handleStatusChange = (e, newStatus) => {
    e.stopPropagation();
    if (newStatus !== call.status) {
      updateStatusMutation.mutate({ id: call.id, status: newStatus });
    }
  };
  
  // Use device timestamp if available, otherwise fall back to created_date
  const displayDate = call.device_timestamp || call.created_date;

  return (
    <Card className={`hover:shadow-lg transition-all duration-200 cursor-pointer active:scale-[0.98] ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}
          onClick={() => navigate(createPageUrl("ServiceCallDetail") + `?id=${call.id}`)}>
      <CardHeader className="pb-2 sm:pb-3 p-3 sm:p-6">
        <div className="flex justify-between items-start gap-2 sm:gap-3">
          <div className="flex-1 min-w-0">
          <h3 className={`font-semibold text-base sm:text-lg mb-1 sm:mb-2 truncate ${theme.text}`}>{call.title}</h3>
          <div className="flex flex-wrap gap-1.5 sm:gap-2">
            <div onClick={(e) => e.stopPropagation()}>
              <Select value={call.status} onValueChange={(value) => handleStatusChange(null, value)}>
                <SelectTrigger className="h-6 w-28 text-xs border-0 shadow-none p-0">
                  <StatusBadge status={call.status} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="waiting_for_parts">Waiting</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <PriorityBadge priority={call.priority} />
              {call.category && (
                <span className={`px-1.5 sm:px-2 py-0.5 rounded-full text-xs font-medium ${isDarkMode ? 'bg-blue-900 text-blue-300' : 'bg-blue-100 text-blue-800'}`}>
                  {call.category.replace(/_/g, ' ')}
                </span>
              )}
            </div>
          </div>
          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-slate-600 flex-shrink-0 h-8 w-8 sm:h-10 sm:w-10">
            <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0 p-3 sm:p-6">
        <div className="space-y-2 text-sm">
          <div className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            <span className="font-medium">Lane:</span>
            <span className={`px-2 py-0.5 rounded font-semibold ${isDarkMode ? 'bg-slate-800 text-slate-200' : 'bg-slate-100'}`}>{call.lane_number}</span>
          </div>
          {call.assigned_to_display_name && (
            <div className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              <User className="w-4 h-4" />
              <span>{call.assigned_to_display_name}</span>
            </div>
          )}
          <div className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
            <Calendar className="w-4 h-4" />
            <span>{format(new Date(displayDate), "MMM d, yyyy h:mm a")}</span>
          </div>
          {call.description && (
            <p className={`line-clamp-2 mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{call.description}</p>
          )}
          {call.attachments && call.attachments.length > 0 && (
            <div className={`flex items-center gap-2 mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              <ImageIcon className="w-4 h-4" />
              <span className="text-xs">{call.attachments.length} attachment{call.attachments.length > 1 ? 's' : ''}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}