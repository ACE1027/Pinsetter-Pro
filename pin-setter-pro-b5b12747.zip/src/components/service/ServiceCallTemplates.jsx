// Service Call Form Templates based on Machine Type

export const MACHINE_TEMPLATES = {
  "Original A Pinsetter": {
    issueTypes: [
      { value: "chassis_jam", label: "Chassis Jam" },
      { value: "pin_elevator_issue", label: "Pin Elevator Issue" },
      { value: "pit_curtain_malfunction", label: "Pit Curtain Malfunction" },
      { value: "ball_return_stoppage", label: "Ball Return Stoppage" },
      { value: "sweep_problem", label: "Sweep Problem" },
      { value: "electrical_short", label: "Electrical Short" },
      { value: "no_power", label: "No Power" },
      { value: "motor_noise", label: "Unusual Motor Noise" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "mechanical_jams", label: "Mechanical Jams" },
      { value: "pin_handling", label: "Pin Handling" },
      { value: "ball_handling", label: "Ball Handling" },
      { value: "electrical_issues", label: "Electrical Issues" },
      { value: "general_malfunctions", label: "General Malfunctions" }
    ],
    subcategories: {
      mechanical_jams: [
        { value: "chassis_binding", label: "Chassis Binding" },
        { value: "pit_cushion_obstruction", label: "Pit Cushion Obstruction" },
        { value: "pin_track_blockage", label: "Pin Track Blockage" },
        { value: "other", label: "Other" }
      ],
      pin_handling: [
        { value: "elevator_chain_slippage", label: "Elevator Chain Slippage" },
        { value: "pin_carrier_fault", label: "Pin Carrier Fault" },
        { value: "pin_setting_inaccuracy", label: "Pin Setting Inaccuracy" },
        { value: "other", label: "Other" }
      ],
      ball_handling: [
        { value: "ball_lift_failure", label: "Ball Lift Failure" },
        { value: "ball_track_jam", label: "Ball Track Jam" },
        { value: "cushion_interference", label: "Cushion Interference" },
        { value: "other", label: "Other" }
      ],
      electrical_issues: [
        { value: "wiring_fault", label: "Wiring Fault" },
        { value: "motor_overload", label: "Motor Overload" },
        { value: "control_box_issue", label: "Control Box Issue" },
        { value: "other", label: "Other" }
      ],
      general_malfunctions: [
        { value: "excessive_vibration", label: "Excessive Vibration" },
        { value: "loud_abnormal_noise", label: "Loud/Abnormal Noise" },
        { value: "intermittent_failure", label: "Intermittent Failure" },
        { value: "other", label: "Other" }
      ]
    }
  },
  "A-2 Pinsetter": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "180_stop", label: "180 Stop" },
      { value: "rake_down", label: "Rake Down" },
      { value: "out_of_range", label: "Out of Range" },
      { value: "re_spot", label: "Re-Spot" },
      { value: "add", label: "Add" },
      { value: "fail_to_trigger", label: "Fail to Trigger" },
      { value: "full_rack", label: "Full Rack" },
      { value: "90_stop", label: "90 Stop" },
      { value: "270_stop", label: "270 Stop" },
      { value: "banana_tree", label: "Banana Tree" },
      { value: "continuous_cycle", label: "Continuous Cycle" },
      { value: "black_out", label: "Black Out" },
      { value: "ball_damage", label: "Ball Damage" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "ball_calls", label: "Ball Calls" },
      { value: "180s", label: "180's" },
      { value: "deck_jams", label: "Deck Jams/Black Outs" },
      { value: "con_cycles", label: "Con. Cycles" },
      { value: "respots", label: "Re-Spots" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      ball_calls: [
        { value: "infront_pit_cushion", label: "Infront of Pit Cushion" },
        { value: "caught_side_cushion", label: "Caught on side of Cushion" },
        { value: "spinning_ball_wheel", label: "Spinning on Ball Wheel" },
        { value: "stuck_sbe", label: "Stuck on SBE" },
        { value: "bottom_corner_lift_rods", label: "Bottom corner of Lift Rods" },
        { value: "yoyo_lift_rods", label: "Yo-Yo on Lift Rods" },
        { value: "top_lift_rods", label: "Top of Lift Rods" },
        { value: "at_y_switch", label: "At the Y - Switch" },
        { value: "behind_ball_stop", label: "Behind Ball Stop" },
        { value: "in_accelerator", label: "In accelerator(Belt Off)" },
        { value: "pin_caught_with_ball", label: "Pin Caught With Ball" },
        { value: "pin_subway_power_lift", label: "Pin in Subway or Power Lift" },
        { value: "ball_in_pinwheel", label: "Ball in Pinwheel" },
        { value: "ghost_ball", label: "Ghost Ball" },
        { value: "other", label: "Other" }
      ],
      "180s": [
        { value: "elevator_pin_guide_jam", label: "Elevator Pin Guide Jam" },
        { value: "turn_pan_jam", label: "Turn Pan Jam" },
        { value: "pin_head_first", label: "Pin Head First" },
        { value: "pin_gate_locked", label: "Pin Gate Locked" },
        { value: "failed_to_index", label: "Failed To Index" },
        { value: "failed_to_index_after_5pin", label: "Failed To Index After 5-Pin" },
        { value: "turret_wire_jam", label: "Turret Wire Jam" },
        { value: "jam_on_top_of_deck", label: "Jam On Top Of Deck" },
        { value: "log_jam_pit_pinwheel", label: "Log Jam In Pit Or Pin Wheel" },
        { value: "other", label: "Other" }
      ],
      deck_jams: [
        { value: "blackout_switch", label: "Blackout On/off Switch" },
        { value: "jam_in_deck_chute", label: "Jam In Deck Chute" },
        { value: "pins_in_top_of_deck", label: "Pins In Top Of Deck" },
        { value: "moving_deck_cable_off", label: "Moving Deck Cable off" },
        { value: "other", label: "Other" }
      ],
      con_cycles: [
        { value: "failed_to_trigger", label: "Failed To Trigger" },
        { value: "90_180_270_stops", label: "90/180//270 Stops" },
        { value: "banana_tree", label: "Banana Tree" },
        { value: "out_of_range", label: "Out of Range" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "deadwood", label: "Deadwood" },
        { value: "other", label: "Other" }
      ]
    }
  },
  "GS-X Machine": {
    issueTypes: [
      { value: "pin_jam_pit", label: "Pin Jam in Pit" },
      { value: "pin_jam_elevator", label: "Pin Jam in Elevator" },
      { value: "ball_jam_return", label: "Ball Jam in Return" },
      { value: "turret_malfunction", label: "Turret Malfunction" },
      { value: "sweep_cycle_issue", label: "Sweep Cycle Issue" },
      { value: "deck_panel_fault", label: "Deck Panel Fault" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "error_code", label: "Error Code Display" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_jams", label: "Pin Jams" },
      { value: "ball_jams", label: "Ball Jams" },
      { value: "machine_cycles", label: "Machine Cycles" },
      { value: "electrical_errors", label: "Electrical Errors" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_jams: [
        { value: "at_pit_entry", label: "At Pit Entry" },
        { value: "in_elevator_belt", label: "In Elevator Belt" },
        { value: "at_turret_infeed", label: "At Turret Infeed" },
        { value: "pin_buffer_area", label: "Pin Buffer Area" },
        { value: "other", label: "Other" }
      ],
      ball_jams: [
        { value: "at_accelerator", label: "At Accelerator" },
        { value: "in_ball_lift", label: "In Ball Lift" },
        { value: "at_cushion", label: "At Cushion" },
        { value: "other", label: "Other" }
      ],
      machine_cycles: [
        { value: "faulty_sweep", label: "Faulty Sweep" },
        { value: "irregular_deck_movement", label: "Irregular Deck Movement" },
        { value: "turret_rotation_issue", label: "Turret Rotation Issue" },
        { value: "pin_delivery_failure", label: "Pin Delivery Failure" },
        { value: "other", label: "Other" }
      ],
      electrical_errors: [
        { value: "motor_fault_specific", label: "Motor Fault (Specify Location)" },
        { value: "sensor_read_error", label: "Sensor Read Error" },
        { value: "control_board_communication", label: "Control Board Communication" },
        { value: "wiring_harness_damage", label: "Wiring Harness Damage" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "unexpected_shutdown", label: "Unexpected Shutdown" },
        { value: "loud_abnormal_noise", label: "Loud/Abnormal Noise" },
        { value: "frame_count_error", label: "Frame Count Error" },
        { value: "other", label: "Other" }
      ]
    }
  },
  
  "String Pin Boost XT": {
    issueTypes: [
      { value: "string_broken", label: "String Broken" },
      { value: "pin_stuck", label: "Pin Stuck" },
      { value: "elevator_issue", label: "Elevator Issue" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "motor_failure", label: "Motor Failure" },
      { value: "string_tension", label: "String Tension Issue" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "string_issues", label: "String Issues" },
      { value: "pin_issues", label: "Pin Issues" },
      { value: "mechanical", label: "Mechanical" },
      { value: "electrical", label: "Electrical" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      string_issues: [
        { value: "broken_string", label: "Broken String" },
        { value: "loose_string", label: "Loose String" },
        { value: "tangled_string", label: "Tangled String" },
        { value: "string_detached", label: "String Detached from Pin" },
        { value: "other", label: "Other" }
      ],
      pin_issues: [
        { value: "pin_not_setting", label: "Pin Not Setting" },
        { value: "pin_stuck_up", label: "Pin Stuck Up" },
        { value: "pin_stuck_down", label: "Pin Stuck Down" },
        { value: "pin_tilted", label: "Pin Tilted" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "elevator_malfunction", label: "Elevator Malfunction" },
        { value: "deck_jam", label: "Deck Jam" },
        { value: "ball_return_issue", label: "Ball Return Issue" },
        { value: "pin_setter_jam", label: "Pin Setter Jam" },
        { value: "other", label: "Other" }
      ],
      electrical: [
        { value: "sensor_fault", label: "Sensor Fault" },
        { value: "motor_error", label: "Motor Error" },
        { value: "control_board", label: "Control Board Issue" },
        { value: "power_issue", label: "Power Issue" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general_issue", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "Brunswick GSX NXT": {
    issueTypes: [
      { value: "pin_elevator_jam", label: "Pin Elevator Jam" },
      { value: "deck_issue", label: "Deck Issue" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_malfunction", label: "Sweep Malfunction" },
      { value: "cushion_issue", label: "Cushion Issue" },
      { value: "motor_fault", label: "Motor Fault" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "control_system", label: "Control System" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_handling", label: "Pin Handling" },
      { value: "ball_handling", label: "Ball Handling" },
      { value: "mechanical", label: "Mechanical Issues" },
      { value: "electronic", label: "Electronic Issues" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_handling: [
        { value: "elevator_jam", label: "Elevator Jam" },
        { value: "pin_distribution", label: "Pin Distribution Error" },
        { value: "pin_spotting", label: "Pin Spotting Issue" },
        { value: "pin_wheel", label: "Pin Wheel Issue" },
        { value: "other", label: "Other" }
      ],
      ball_handling: [
        { value: "ball_return_jam", label: "Ball Return Jam" },
        { value: "ball_lift", label: "Ball Lift Issue" },
        { value: "accelerator", label: "Accelerator Issue" },
        { value: "cushion", label: "Cushion Issue" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_issue", label: "Sweep Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "motor_failure", label: "Motor Failure" },
        { value: "belt_issue", label: "Belt Issue" },
        { value: "other", label: "Other" }
      ],
      electronic: [
        { value: "sensor_fault", label: "Sensor Fault" },
        { value: "control_panel", label: "Control Panel Issue" },
        { value: "wiring", label: "Wiring Issue" },
        { value: "power", label: "Power Issue" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "Jetback Pinsetter": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "180_stop", label: "180 Stop" },
      { value: "rake_down", label: "Rake Down" },
      { value: "out_of_range", label: "Out of Range" },
      { value: "re_spot", label: "Re-Spot" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "black_out", label: "Black Out" },
      { value: "continuous_cycle", label: "Continuous Cycle" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "ball_calls", label: "Ball Calls" },
      { value: "180s", label: "180's" },
      { value: "deck_jams", label: "Deck Jams/Black Outs" },
      { value: "con_cycles", label: "Con. Cycles" },
      { value: "respots", label: "Re-Spots" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      ball_calls: [
        { value: "infront_pit_cushion", label: "Infront of Pit Cushion" },
        { value: "caught_side_cushion", label: "Caught on side of Cushion" },
        { value: "spinning_ball_wheel", label: "Spinning on Ball Wheel" },
        { value: "stuck_sbe", label: "Stuck on SBE" },
        { value: "in_accelerator", label: "In accelerator" },
        { value: "other", label: "Other" }
      ],
      "180s": [
        { value: "elevator_pin_guide_jam", label: "Elevator Pin Guide Jam" },
        { value: "turn_pan_jam", label: "Turn Pan Jam" },
        { value: "pin_head_first", label: "Pin Head First" },
        { value: "failed_to_index", label: "Failed To Index" },
        { value: "other", label: "Other" }
      ],
      deck_jams: [
        { value: "blackout_switch", label: "Blackout On/off Switch" },
        { value: "jam_in_deck_chute", label: "Jam In Deck Chute" },
        { value: "pins_in_top_of_deck", label: "Pins In Top Of Deck" },
        { value: "other", label: "Other" }
      ],
      con_cycles: [
        { value: "failed_to_trigger", label: "Failed To Trigger" },
        { value: "90_180_270_stops", label: "90/180/270 Stops" },
        { value: "out_of_range", label: "Out of Range" },
        { value: "other", label: "Other" }
      ],
      respots: [
        { value: "re_spot_requested", label: "Re-Spot Requested" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "deadwood", label: "Deadwood" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "82-30": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_issue", label: "Sweep Issue" },
      { value: "pin_elevator", label: "Pin Elevator" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "table_issue", label: "Table Issue" },
      { value: "rake_problem", label: "Rake Problem" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_setting", label: "Pin Setting" },
      { value: "ball_return", label: "Ball Return" },
      { value: "mechanical", label: "Mechanical" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_setting: [
        { value: "table_malfunction", label: "Table Malfunction" },
        { value: "pin_jam", label: "Pin Jam" },
        { value: "elevator_issue", label: "Elevator Issue" },
        { value: "spotting_error", label: "Spotting Error" },
        { value: "other", label: "Other" }
      ],
      ball_return: [
        { value: "lift_issue", label: "Lift Issue" },
        { value: "ball_stuck", label: "Ball Stuck" },
        { value: "cushion_problem", label: "Cushion Problem" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_malfunction", label: "Sweep Malfunction" },
        { value: "rake_issue", label: "Rake Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "82-70 Pinspotter": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_issue", label: "Sweep Issue" },
      { value: "pin_elevator", label: "Pin Elevator" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "cushion_issue", label: "Cushion Issue" },
      { value: "table_issue", label: "Table Issue" },
      { value: "rake_problem", label: "Rake Problem" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_setting", label: "Pin Setting" },
      { value: "ball_return", label: "Ball Return" },
      { value: "mechanical", label: "Mechanical" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_setting: [
        { value: "table_malfunction", label: "Table Malfunction" },
        { value: "pin_jam", label: "Pin Jam" },
        { value: "elevator_issue", label: "Elevator Issue" },
        { value: "spotting_error", label: "Spotting Error" },
        { value: "other", label: "Other" }
      ],
      ball_return: [
        { value: "lift_issue", label: "Lift Issue" },
        { value: "ball_stuck", label: "Ball Stuck" },
        { value: "cushion_problem", label: "Cushion Problem" },
        { value: "accelerator", label: "Accelerator Issue" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_malfunction", label: "Sweep Malfunction" },
        { value: "rake_issue", label: "Rake Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "motor_failure", label: "Motor Failure" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "82-90 Pinspotter": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_issue", label: "Sweep Issue" },
      { value: "pin_elevator", label: "Pin Elevator" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "cushion_issue", label: "Cushion Issue" },
      { value: "table_issue", label: "Table Issue" },
      { value: "rake_problem", label: "Rake Problem" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_setting", label: "Pin Setting" },
      { value: "ball_return", label: "Ball Return" },
      { value: "mechanical", label: "Mechanical" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_setting: [
        { value: "table_malfunction", label: "Table Malfunction" },
        { value: "pin_jam", label: "Pin Jam" },
        { value: "elevator_issue", label: "Elevator Issue" },
        { value: "spotting_error", label: "Spotting Error" },
        { value: "other", label: "Other" }
      ],
      ball_return: [
        { value: "lift_issue", label: "Lift Issue" },
        { value: "ball_stuck", label: "Ball Stuck" },
        { value: "cushion_problem", label: "Cushion Problem" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_malfunction", label: "Sweep Malfunction" },
        { value: "rake_issue", label: "Rake Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "90XLI Pinspotter": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "180_stop", label: "180 Stop" },
      { value: "rake_down", label: "Rake Down" },
      { value: "re_spot", label: "Re-Spot" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "sweep_issue", label: "Sweep Issue" },
      { value: "pin_elevator", label: "Pin Elevator" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "ball_calls", label: "Ball Calls" },
      { value: "180s", label: "180's" },
      { value: "deck_jams", label: "Deck Jams/Black Outs" },
      { value: "respots", label: "Re-Spots" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      ball_calls: [
        { value: "infront_pit_cushion", label: "Infront of Pit Cushion" },
        { value: "caught_side_cushion", label: "Caught on side of Cushion" },
        { value: "ball_lift_issue", label: "Ball Lift Issue" },
        { value: "in_accelerator", label: "In accelerator" },
        { value: "other", label: "Other" }
      ],
      "180s": [
        { value: "elevator_pin_guide_jam", label: "Elevator Pin Guide Jam" },
        { value: "turn_pan_jam", label: "Turn Pan Jam" },
        { value: "failed_to_index", label: "Failed To Index" },
        { value: "other", label: "Other" }
      ],
      deck_jams: [
        { value: "jam_in_deck_chute", label: "Jam In Deck Chute" },
        { value: "pins_in_top_of_deck", label: "Pins In Top Of Deck" },
        { value: "other", label: "Other" }
      ],
      respots: [
        { value: "re_spot_requested", label: "Re-Spot Requested" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "deadwood", label: "Deadwood" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "Qubica AMF XLI Edge": {
    issueTypes: [
      { value: "pin_jam", label: "Pin Jam" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_malfunction", label: "Sweep Malfunction" },
      { value: "deck_issue", label: "Deck Issue" },
      { value: "elevator_problem", label: "Elevator Problem" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "motor_fault", label: "Motor Fault" },
      { value: "control_error", label: "Control Error" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_handling", label: "Pin Handling" },
      { value: "ball_handling", label: "Ball Handling" },
      { value: "mechanical", label: "Mechanical Issues" },
      { value: "electronic", label: "Electronic Issues" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_handling: [
        { value: "elevator_jam", label: "Elevator Jam" },
        { value: "pin_distribution", label: "Pin Distribution Error" },
        { value: "pin_spotting", label: "Pin Spotting Issue" },
        { value: "other", label: "Other" }
      ],
      ball_handling: [
        { value: "ball_return_jam", label: "Ball Return Jam" },
        { value: "ball_lift", label: "Ball Lift Issue" },
        { value: "cushion", label: "Cushion Issue" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_issue", label: "Sweep Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "motor_failure", label: "Motor Failure" },
        { value: "other", label: "Other" }
      ],
      electronic: [
        { value: "sensor_fault", label: "Sensor Fault" },
        { value: "control_panel", label: "Control Panel Issue" },
        { value: "wiring", label: "Wiring Issue" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "EDGE Free Fall Pinspotter": {
    issueTypes: [
      { value: "pin_jam", label: "Pin Jam" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_malfunction", label: "Sweep Malfunction" },
      { value: "elevator_issue", label: "Elevator Issue" },
      { value: "deck_problem", label: "Deck Problem" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "control_fault", label: "Control Fault" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_handling", label: "Pin Handling" },
      { value: "ball_handling", label: "Ball Handling" },
      { value: "mechanical", label: "Mechanical Issues" },
      { value: "electronic", label: "Electronic Issues" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_handling: [
        { value: "free_fall_jam", label: "Free Fall Jam" },
        { value: "elevator_jam", label: "Elevator Jam" },
        { value: "pin_distribution", label: "Pin Distribution Error" },
        { value: "spotting_issue", label: "Spotting Issue" },
        { value: "other", label: "Other" }
      ],
      ball_handling: [
        { value: "ball_return_jam", label: "Ball Return Jam" },
        { value: "ball_lift", label: "Ball Lift Issue" },
        { value: "cushion", label: "Cushion Issue" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_issue", label: "Sweep Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "motor_failure", label: "Motor Failure" },
        { value: "other", label: "Other" }
      ],
      electronic: [
        { value: "sensor_fault", label: "Sensor Fault" },
        { value: "control_system", label: "Control System Issue" },
        { value: "wiring", label: "Wiring Issue" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "EDGE String Pin Pinspotter": {
    issueTypes: [
      { value: "string_broken", label: "String Broken" },
      { value: "pin_stuck", label: "Pin Stuck" },
      { value: "elevator_issue", label: "Elevator Issue" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sensor_error", label: "Sensor Error" },
      { value: "string_tension", label: "String Tension Issue" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "string_issues", label: "String Issues" },
      { value: "pin_issues", label: "Pin Issues" },
      { value: "mechanical", label: "Mechanical" },
      { value: "electrical", label: "Electrical" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      string_issues: [
        { value: "broken_string", label: "Broken String" },
        { value: "loose_string", label: "Loose String" },
        { value: "tangled_string", label: "Tangled String" },
        { value: "string_detached", label: "String Detached from Pin" },
        { value: "other", label: "Other" }
      ],
      pin_issues: [
        { value: "pin_not_setting", label: "Pin Not Setting" },
        { value: "pin_stuck_up", label: "Pin Stuck Up" },
        { value: "pin_stuck_down", label: "Pin Stuck Down" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "elevator_malfunction", label: "Elevator Malfunction" },
        { value: "deck_jam", label: "Deck Jam" },
        { value: "ball_return_issue", label: "Ball Return Issue" },
        { value: "other", label: "Other" }
      ],
      electrical: [
        { value: "sensor_fault", label: "Sensor Fault" },
        { value: "motor_error", label: "Motor Error" },
        { value: "control_board", label: "Control Board Issue" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general_issue", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  "82-70 Pinspotter": {
    issueTypes: [
      { value: "dead_wood", label: "Dead Wood" },
      { value: "ball_return", label: "Ball Return" },
      { value: "sweep_issue", label: "Sweep Issue" },
      { value: "pin_elevator", label: "Pin Elevator" },
      { value: "deck_jam", label: "Deck Jam" },
      { value: "cushion_issue", label: "Cushion Issue" },
      { value: "table_issue", label: "Table Issue" },
      { value: "rake_problem", label: "Rake Problem" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "pin_setting", label: "Pin Setting" },
      { value: "ball_return", label: "Ball Return" },
      { value: "mechanical", label: "Mechanical" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      pin_setting: [
        { value: "table_malfunction", label: "Table Malfunction" },
        { value: "pin_jam", label: "Pin Jam" },
        { value: "elevator_issue", label: "Elevator Issue" },
        { value: "spotting_error", label: "Spotting Error" },
        { value: "other", label: "Other" }
      ],
      ball_return: [
        { value: "lift_issue", label: "Lift Issue" },
        { value: "ball_stuck", label: "Ball Stuck" },
        { value: "cushion_problem", label: "Cushion Problem" },
        { value: "accelerator", label: "Accelerator Issue" },
        { value: "other", label: "Other" }
      ],
      mechanical: [
        { value: "sweep_malfunction", label: "Sweep Malfunction" },
        { value: "rake_issue", label: "Rake Issue" },
        { value: "deck_problem", label: "Deck Problem" },
        { value: "motor_failure", label: "Motor Failure" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  },

  // Generic template for "Other" machine types
  "Other": {
    issueTypes: [
      { value: "mechanical_failure", label: "Mechanical Failure" },
      { value: "electrical_issue", label: "Electrical Issue" },
      { value: "pin_issue", label: "Pin Issue" },
      { value: "ball_return", label: "Ball Return" },
      { value: "malfunction", label: "General Malfunction" },
      { value: "other", label: "Other" }
    ],
    descriptionCategories: [
      { value: "mechanical", label: "Mechanical" },
      { value: "electrical", label: "Electrical" },
      { value: "operational", label: "Operational" },
      { value: "miscellaneous", label: "Miscellaneous" }
    ],
    subcategories: {
      mechanical: [
        { value: "jam", label: "Jam" },
        { value: "motor_issue", label: "Motor Issue" },
        { value: "belt_problem", label: "Belt Problem" },
        { value: "other", label: "Other" }
      ],
      electrical: [
        { value: "sensor_fault", label: "Sensor Fault" },
        { value: "wiring", label: "Wiring Issue" },
        { value: "power", label: "Power Issue" },
        { value: "other", label: "Other" }
      ],
      operational: [
        { value: "not_responding", label: "Not Responding" },
        { value: "incorrect_operation", label: "Incorrect Operation" },
        { value: "timing_issue", label: "Timing Issue" },
        { value: "other", label: "Other" }
      ],
      miscellaneous: [
        { value: "general", label: "General Issue" },
        { value: "other", label: "Other" }
      ]
    }
  }
};

// Get template for a machine type, falls back to "Other" if not found
export const getTemplateForMachine = (machineType) => {
  return MACHINE_TEMPLATES[machineType] || MACHINE_TEMPLATES["Other"];
};

// Get all unique machine types from templates
export const getAllMachineTypes = () => {
  return Object.keys(MACHINE_TEMPLATES).filter(type => type !== "Other");
};