import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Circle, Clock, Loader2, Package, CheckCircle2, XCircle } from "lucide-react";

const statusConfig = {
  open: {
    label: "Open",
    color: "bg-blue-100 text-blue-800 border-blue-300",
    icon: Circle
  },
  in_progress: {
    label: "In Progress",
    color: "bg-amber-100 text-amber-800 border-amber-300",
    icon: Loader2
  },
  waiting_for_parts: {
    label: "Waiting for Parts",
    color: "bg-purple-100 text-purple-800 border-purple-300",
    icon: Package
  },
  completed: {
    label: "Completed",
    color: "bg-green-100 text-green-800 border-green-300",
    icon: CheckCircle2
  },
  cancelled: {
    label: "Cancelled",
    color: "bg-slate-100 text-slate-800 border-slate-300",
    icon: XCircle
  }
};

export default function StatusBadge({ status, showIcon = true }) {
  const config = statusConfig[status] || statusConfig.open;
  const Icon = config.icon;

  return (
    <Badge className={`${config.color} border px-2.5 py-0.5 font-medium`}>
      {showIcon && <Icon className="w-3 h-3 mr-1.5" />}
      {config.label}
    </Badge>
  );
}