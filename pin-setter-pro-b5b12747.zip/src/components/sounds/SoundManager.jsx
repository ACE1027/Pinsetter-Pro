export const playSound = (soundType, userPreferences) => {
  if (!userPreferences || userPreferences[soundType] === false) {
    return; // User has disabled this sound
  }

  // Trigger vibration if enabled and on mobile
  if (userPreferences?.vibration_enabled && 'vibrate' in navigator) {
    navigator.vibrate(200); // Vibrate for 200ms
  }

  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  switch (soundType) {
    case 'service_call_created':
      // Rising chime
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.2);
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 3);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 3);
      break;

    case 'service_call_completed':
      // Success melody
      oscillator.frequency.setValueAtTime(523, audioContext.currentTime); // C
      oscillator.frequency.setValueAtTime(659, audioContext.currentTime + 0.15); // E
      oscillator.frequency.setValueAtTime(784, audioContext.currentTime + 0.3); // G
      gainNode.gain.setValueAtTime(0.25, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 2);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 2);
      break;

    case 'notification':
      // Quick notification beep
      oscillator.frequency.setValueAtTime(1000, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.05);
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
      break;

    case 'maintenance_due':
      // Alert tone for maintenance
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime + 0.2);
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime + 0.4);
      gainNode.gain.setValueAtTime(0.25, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1.5);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 1.5);
      break;

    default:
      oscillator.stop();
      return;
  }
};

export const SOUND_TYPES = {
  SERVICE_CALL_CREATED: 'service_call_created',
  SERVICE_CALL_COMPLETED: 'service_call_completed',
  NOTIFICATION: 'notification',
  MAINTENANCE_DUE: 'maintenance_due'
};