import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX, Bell, CheckCircle2, Plus, Vibrate } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";
import { playSound, SOUND_TYPES } from "./SoundManager";

export default function SoundSettings() {
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [soundPreferences, setSoundPreferences] = useState({
    service_call_created: true,
    service_call_completed: true,
    notification: true,
    maintenance_due: true,
    vibration_enabled: true
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u.sound_preferences) {
        setSoundPreferences(u.sound_preferences);
      }
    }).catch(() => {});
  }, []);

  const handleToggle = (key) => {
    setSoundPreferences(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({ sound_preferences: soundPreferences });
      toast.success("Sound settings saved");
    } catch (error) {
      toast.error("Failed to save settings");
    } finally {
      setSaving(false);
    }
  };

  const handleTestSound = (soundType) => {
    playSound(soundType, { [soundType]: true, vibration_enabled: soundPreferences.vibration_enabled });
  };

  const handleTestVibration = () => {
    if ('vibrate' in navigator) {
      navigator.vibrate(200);
      toast.success("Vibration test");
    } else {
      toast.error("Vibration not supported on this device");
    }
  };

  const soundOptions = [
    {
      key: 'service_call_created',
      label: 'Service Call Created',
      description: 'Play sound when creating a new service call',
      icon: Plus,
      color: 'text-blue-500'
    },
    {
      key: 'service_call_completed',
      label: 'Service Call Completed',
      description: 'Play sound when completing a service call',
      icon: CheckCircle2,
      color: 'text-green-500'
    },
    {
      key: 'notification',
      label: 'Notification Alerts',
      description: 'Play sound for new notifications',
      icon: Bell,
      color: 'text-amber-500'
    },
    {
      key: 'maintenance_due',
      label: 'Maintenance Due',
      description: 'Play sound when maintenance tasks are due',
      icon: Bell,
      color: 'text-orange-500'
    }
  ];

  return (
    <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
      <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
        <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
          <Volume2 className="w-5 h-5 text-purple-500" />
          Sound Effects
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <p className={`text-sm mb-6 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
          Control which actions trigger sound effects in the app
        </p>

        <div className="space-y-6">
          {/* Vibration Toggle */}
          {'vibrate' in navigator && (
            <div className={`flex items-start justify-between p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <div className="flex items-start gap-3 flex-1">
                <div className={`p-2 rounded-full ${isDarkMode ? 'bg-slate-700' : 'bg-white'}`}>
                  <Vibrate className="w-5 h-5 text-purple-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Label htmlFor="vibration_enabled" className={`font-semibold cursor-pointer ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      Mobile Vibration
                    </Label>
                  </div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    Vibrate device when notifications play (mobile only)
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleTestVibration}
                    className="mt-2 h-7 text-xs"
                  >
                    Test Vibration
                  </Button>
                </div>
              </div>
              <Switch
                id="vibration_enabled"
                checked={soundPreferences.vibration_enabled}
                onCheckedChange={() => handleToggle('vibration_enabled')}
              />
            </div>
          )}

          {soundOptions.map((option) => (
            <div key={option.key} className={`flex items-start justify-between p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <div className="flex items-start gap-3 flex-1">
                <div className={`p-2 rounded-full ${isDarkMode ? 'bg-slate-700' : 'bg-white'}`}>
                  <option.icon className={`w-5 h-5 ${option.color}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Label htmlFor={option.key} className={`font-semibold cursor-pointer ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      {option.label}
                    </Label>
                  </div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    {option.description}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleTestSound(option.key)}
                    className="mt-2 h-7 text-xs"
                  >
                    Test Sound
                  </Button>
                </div>
              </div>
              <Switch
                id={option.key}
                checked={soundPreferences[option.key]}
                onCheckedChange={() => handleToggle(option.key)}
              />
            </div>
          ))}
        </div>

        <Button
          onClick={handleSave}
          disabled={saving}
          className="w-full mt-6 bg-blue-600 hover:bg-blue-700"
        >
          {saving ? "Saving..." : "Save Settings"}
        </Button>
      </CardContent>
    </Card>
  );
}