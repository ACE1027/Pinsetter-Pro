import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { X, Edit, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function TaskBulkActions({ selectedTasks, onBulkUpdate, onBulkDelete, onClearSelection, users, isDarkMode }) {
  const [bulkEditOpen, setBulkEditOpen] = useState(false);
  const [bulkData, setBulkData] = useState({
    status: "",
    priority: "",
    assigned_to: "",
  });

  const handleBulkEdit = () => {
    const updates = {};
    if (bulkData.status) updates.status = bulkData.status;
    if (bulkData.priority) updates.priority = bulkData.priority;
    if (bulkData.assigned_to) updates.assigned_to = bulkData.assigned_to;
    
    if (Object.keys(updates).length > 0) {
      onBulkUpdate(updates);
      setBulkEditOpen(false);
      setBulkData({ status: "", priority: "", assigned_to: "" });
    }
  };

  if (selectedTasks.length === 0) return null;

  return (
    <>
      <div className={`fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 ${
        isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'
      } border shadow-lg rounded-lg p-4 flex items-center gap-4`}>
        <Badge variant="secondary" className="text-sm">
          {selectedTasks.length} selected
        </Badge>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => setBulkEditOpen(true)}>
            <Edit className="w-4 h-4 mr-2" />
            Edit
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => {
              if (confirm(`Delete ${selectedTasks.length} tasks?`)) {
                onBulkDelete();
              }
            }}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete
          </Button>
        </div>
        <Button size="sm" variant="ghost" onClick={onClearSelection}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <Dialog open={bulkEditOpen} onOpenChange={setBulkEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bulk Edit {selectedTasks.length} Tasks</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>Update Status</Label>
              <Select value={bulkData.status} onValueChange={(v) => setBulkData({...bulkData, status: v})}>
                <SelectTrigger>
                  <SelectValue placeholder="Leave unchanged" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Update Priority</Label>
              <Select value={bulkData.priority} onValueChange={(v) => setBulkData({...bulkData, priority: v})}>
                <SelectTrigger>
                  <SelectValue placeholder="Leave unchanged" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Reassign To</Label>
              <Select value={bulkData.assigned_to} onValueChange={(v) => setBulkData({...bulkData, assigned_to: v})}>
                <SelectTrigger>
                  <SelectValue placeholder="Leave unchanged" />
                </SelectTrigger>
                <SelectContent>
                  {users.map(u => (
                    <SelectItem key={u.id} value={u.email}>
                      {u.full_name || u.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkEditOpen(false)}>Cancel</Button>
            <Button onClick={handleBulkEdit}>Apply Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}