import React, { useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Download, Printer } from 'lucide-react';
import { toast } from 'sonner';

export default function TaskQRCodeDisplay({ task, open, onOpenChange }) {
  const qrRef = useRef(null);

  if (!task) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = async () => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 400;
      canvas.height = 500;

      // White background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Title
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 20px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(task.task_title, 200, 40);

      // QR Code text (as placeholder since we don't have QR generation library)
      ctx.font = '14px monospace';
      ctx.fillText(task.qr_code, 200, 250);

      // Box around code
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.strokeRect(50, 100, 300, 200);

      // Instructions
      ctx.font = '12px Arial';
      ctx.fillText('Scan or enter this code to complete the task', 200, 350);
      ctx.fillText(`Lane: ${task.lane_number || 'N/A'}`, 200, 380);
      ctx.fillText(`Priority: ${task.priority}`, 200, 400);

      const url = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `task-qr-${task.qr_code}.png`;
      link.href = url;
      link.click();
      toast.success('QR Code downloaded');
    } catch (error) {
      toast.error('Failed to download');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Task QR Code</DialogTitle>
        </DialogHeader>
        <div ref={qrRef} className="space-y-4 py-4">
          <div className="text-center">
            <h3 className="font-bold text-lg mb-2">{task.task_title}</h3>
            {task.lane_number && <p className="text-sm text-slate-600">Lane {task.lane_number}</p>}
          </div>
          
          <div className="border-4 border-black p-8 bg-white mx-auto w-fit rounded-lg">
            <div className="text-center space-y-2">
              <div className="font-mono text-xs break-all bg-slate-100 p-4 rounded">
                {task.qr_code}
              </div>
              <p className="text-xs text-slate-500">Scan or enter this code</p>
            </div>
          </div>

          <div className="text-center text-sm text-slate-600">
            <p>Priority: <strong>{task.priority}</strong></p>
            {task.due_date && <p>Due: {new Date(task.due_date).toLocaleDateString()}</p>}
          </div>

          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={handlePrint} className="flex-1">
              <Printer className="w-4 h-4 mr-2" />
              Print
            </Button>
            <Button onClick={handleDownload} className="flex-1">
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}