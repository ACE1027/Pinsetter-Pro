import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { QrCode, Camera } from 'lucide-react';
import { toast } from 'sonner';

export default function TaskQRScanner({ onScan, open, onOpenChange }) {
  const [manualCode, setManualCode] = useState('');

  const handleManualSubmit = () => {
    if (!manualCode.trim()) {
      toast.error('Please enter a task code');
      return;
    }
    onScan(manualCode.trim());
    setManualCode('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5" />
            Complete Task via QR Code
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="taskCode">Enter Task Code</Label>
            <div className="flex gap-2">
              <Input
                id="taskCode"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Enter task code from QR"
                onKeyPress={(e) => e.key === 'Enter' && handleManualSubmit()}
              />
              <Button onClick={handleManualSubmit}>
                Submit
              </Button>
            </div>
            <p className="text-xs text-slate-500">
              Scan the QR code on the task sheet or enter the code manually
            </p>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-center p-8 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
              <div className="text-center">
                <Camera className="w-12 h-12 text-slate-400 mx-auto mb-2" />
                <p className="text-sm text-slate-600">
                  Camera scanning coming soon
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}