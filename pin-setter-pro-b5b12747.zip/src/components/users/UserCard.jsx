import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Calendar, Edit, Building2, ShieldCheck } from "lucide-react";
import { format } from "date-fns";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const positionHierarchy = {
  general_manager: { level: 1, color: "bg-purple-100 text-purple-800 border-purple-300" },
  service_manager: { level: 2, color: "bg-blue-100 text-blue-800 border-blue-300" },
  assistant_manager: { level: 3, color: "bg-indigo-100 text-indigo-800 border-indigo-300" },
  senior_mechanic: { level: 4, color: "bg-teal-100 text-teal-800 border-teal-300" },
  lead_mechanic: { level: 5, color: "bg-cyan-100 text-cyan-800 border-cyan-300" },
  mechanic: { level: 6, color: "bg-green-100 text-green-800 border-green-300" },
  mechanic_apprentice: { level: 7, color: "bg-emerald-100 text-emerald-800 border-emerald-300" },
  front_desk_supervisor: { level: 8, color: "bg-amber-100 text-amber-800 border-amber-300" },
  front_desk_staff: { level: 9, color: "bg-yellow-100 text-yellow-800 border-yellow-300" },
};

export default function UserCard({ user, onEdit, locations = [], currentUser }) {
  const positionConfig = user.position ? positionHierarchy[user.position] : null;
  const userLocation = locations.find(l => l.id === user.bowling_alley_id);
  
  // Count active permissions
  const activePermissions = user.permissions 
    ? Object.values(user.permissions).filter(p => p === true).length 
    : 0;
  
  return (
    <Card className={`hover:shadow-lg transition-all duration-200 ${user.active === false ? 'opacity-60' : ''}`}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 bg-gradient-to-br rounded-full flex items-center justify-center ${
              user.active === false ? 'from-slate-300 to-slate-400' : 'from-slate-200 to-slate-300'
            }`}>
              <span className={`font-bold text-lg ${user.active === false ? 'text-slate-600' : 'text-slate-700'}`}>
                {(user.display_name || user.full_name)?.charAt(0) || user.email?.charAt(0)}
              </span>
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 text-lg flex items-center gap-2">
                {user.display_name || user.full_name || "No Name"}
                {user.role === 'admin' && (
                  <ShieldCheck className="w-4 h-4 text-red-600" />
                )}
              </h3>
              <div className="flex flex-wrap gap-2 mt-1">
                {user.position && (
                  <Badge className={`${positionConfig?.color} border text-xs`}>
                    {user.position.replace(/_/g, ' ')}
                  </Badge>
                )}
                <Badge 
                  variant={user.active === false ? "secondary" : "default"} 
                  className={`text-xs ${
                    user.active === false 
                      ? 'bg-red-100 text-red-800 border-red-300' 
                      : 'bg-green-100 text-green-800 border-green-300'
                  }`}
                >
                  {user.active === false ? 'Inactive' : 'Active'}
                </Badge>
                {user.role === 'admin' && (
                  <Badge className="bg-red-100 text-red-800 border-red-300 text-xs">Admin</Badge>
                )}
              </div>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={() => onEdit(user)} className="h-8 w-8">
            <Edit className="w-4 h-4 text-slate-500" />
          </Button>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-slate-600">
            <Mail className="w-4 h-4 text-slate-400" />
            <span className="truncate">{user.email}</span>
          </div>
          {user.phone && (
            <div className="flex items-center gap-2 text-slate-600">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>{user.phone}</span>
            </div>
          )}
          {userLocation && (
            <div className="flex items-center gap-2 text-slate-600">
              <Building2 className="w-4 h-4 text-slate-400" />
              <span>{userLocation.name}</span>
            </div>
          )}
          {user.hire_date && (
            <div className="flex items-center gap-2 text-slate-600">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Hired: {format(new Date(user.hire_date), "MMM d, yyyy")}</span>
            </div>
          )}
          <div className="pt-2 flex items-center justify-between">
            <span className="text-xs text-slate-500 capitalize">
              Department: {user.department?.replace(/_/g, ' ') || 'Not set'}
            </span>
            {activePermissions > 0 && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="outline" className="text-xs">
                      {activePermissions} permission{activePermissions !== 1 ? 's' : ''}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Custom permissions assigned</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}