import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTheme } from "@/components/ThemeContext";
import {
  Shield,
  Users,
  Building2,
  Wrench,
  Package,
  TrendingUp,
  AlertCircle,
  Clock,
  CheckCircle2,
  Activity,
  Settings,
  BarChart3,
  UserPlus,
  MapPin,
  FileText,
  Calendar,
  Mail,
  ArrowRight,
  Trash2 } from
"lucide-react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, subDays, startOfDay, endOfDay } from "date-fns";
import { usePushNotifications } from "@/components/notifications/PushNotificationManager";
import LiveActivityFeed from "@/components/activity/LiveActivityFeed";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { isDarkMode, theme } = useTheme();
  const [user, setUser] = useState(null);
  const [deleteLocationId, setDeleteLocationId] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Enable push notifications
  usePushNotifications(user);

  // Fetch all data
  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list(),
    initialData: []
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: []
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => base44.entities.Notification.list(),
    initialData: []
  });

  // Delete location mutation
  const deleteLocationMutation = useMutation({
    mutationFn: (locationId) => base44.entities.BowlingAlley.delete(locationId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      toast.success('Location deleted successfully');
      setDeleteLocationId(null);
    },
    onError: (error) => {
      toast.error('Failed to delete location: ' + error.message);
    }
  });

  const handleDeleteLocation = (locationId) => {
    deleteLocationMutation.mutate(locationId);
  };

  // Redirect if not admin
  if (user && user.role !== 'admin') {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <Shield className="w-12 h-12 text-red-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Access Denied</h2>
            <p className="text-slate-600 mb-4">This page is only accessible to administrators.</p>
            <Link to={createPageUrl("Dashboard")}>
              <Button>Return to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>);

  }

  // Calculate metrics
  const openCalls = serviceCalls.filter((c) => c.status === 'open' || c.status === 'in_progress');
  const urgentCalls = serviceCalls.filter((c) => c.priority === 'urgent' && c.status !== 'completed' && c.status !== 'cancelled');
  const completedCalls = serviceCalls.filter((c) => c.status === 'completed');
  const activeUsers = users.filter((u) => u.active !== false);
  const activeLocations = locations.filter((l) => l.active !== false);
  const lowStockParts = parts.filter((p) => p.quantity_in_stock < p.min_quantity);
  const unreadNotifications = notifications.filter((n) => !n.is_read);

  // Calculate average resolution time
  const completedWithTime = completedCalls.filter((c) => c.created_date && c.completed_date);
  const avgResolutionTime = completedWithTime.length > 0 ?
  completedWithTime.reduce((sum, call) => {
    const created = new Date(call.created_date);
    const completed = new Date(call.completed_date);
    return sum + (completed - created);
  }, 0) / completedWithTime.length :
  0;
  const avgHours = Math.round(avgResolutionTime / (1000 * 60 * 60));

  // Service calls by status
  const statusData = [
  { name: 'Open', value: serviceCalls.filter((c) => c.status === 'open').length, color: '#3b82f6' },
  { name: 'In Progress', value: serviceCalls.filter((c) => c.status === 'in_progress').length, color: '#f59e0b' },
  { name: 'Waiting', value: serviceCalls.filter((c) => c.status === 'waiting_for_parts').length, color: '#8b5cf6' },
  { name: 'Completed', value: serviceCalls.filter((c) => c.status === 'completed').length, color: '#10b981' },
  { name: 'Cancelled', value: serviceCalls.filter((c) => c.status === 'cancelled').length, color: '#ef4444' }];


  // Service calls trend (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayName = format(date, 'EEE');
    const created = serviceCalls.filter((c) => c.created_date?.startsWith(dateStr)).length;
    const completed = serviceCalls.filter((c) => c.completed_date?.startsWith(dateStr)).length;
    return { date: dayName, created, completed };
  });

  // User activity by position
  const positionData = users.reduce((acc, user) => {
    const position = user.position || 'unassigned';
    acc[position] = (acc[position] || 0) + 1;
    return acc;
  }, {});
  const positionChartData = Object.entries(positionData).map(([name, count]) => ({
    name: name.replace(/_/g, ' '),
    count
  }));

  // Recent activity
  const recentCalls = [...serviceCalls].
  sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).
  slice(0, 5);

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4 w-full">
        {/* Header */}
        <div className="mb-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                Admin Dashboard
              </h1>
              <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                System-wide overview and management
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          <Link to={createPageUrl("ServiceCalls")}>
            <Card className={`cursor-pointer hover:shadow-md transition-all active:scale-[0.98] ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardContent className="p-3 sm:p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Open Calls</p>
                    <p className={`text-2xl sm:text-3xl font-bold mt-1 truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      {openCalls.length}
                    </p>
                    {urgentCalls.length > 0 &&
                    <Badge className="mt-1 sm:mt-2 bg-red-100 text-red-800 border-red-300 text-xs">
                        {urgentCalls.length} Urgent
                      </Badge>
                    }
                  </div>
                  <div className="p-2 sm:p-3 bg-blue-100 rounded-lg flex-shrink-0">
                    <Wrench className="w-4 h-4 sm:w-6 sm:h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={createPageUrl("ServiceCallHistory")}>
            <Card className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardContent className="p-3 sm:p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Avg Resolution Time</p>
                    <p className={`text-3xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      {avgHours}h
                    </p>
                    <p className={`text-xs mt-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                      {completedCalls.length} completed
                    </p>
                  </div>
                  <div className="p-3 bg-green-100 rounded-lg">
                    <Clock className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={createPageUrl("UserManagement")}>
            <Card className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardContent className="p-3 sm:p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Active Users</p>
                    <p className={`text-3xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      {activeUsers.length}
                    </p>
                    <p className={`text-xs mt-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                      {users.length} total
                    </p>
                  </div>
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={createPageUrl("PartsInventory")}>
            <Card className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardContent className="p-3 sm:p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Low Stock Items</p>
                    <p className={`text-3xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      {lowStockParts.length}
                    </p>
                    <p className={`text-xs mt-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                      {parts.length} total parts
                    </p>
                  </div>
                  <div className="p-3 bg-orange-100 rounded-lg">
                    <Package className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Quick Actions */}
        <Card className={`mb-4 shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
          <CardHeader className="p-4 pb-2">
            <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              <Settings className="w-4 h-4 text-blue-600" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Link to={createPageUrl("UserManagement")}>
                <Button variant="outline" className="w-full justify-start text-xs sm:text-sm h-auto py-2 sm:py-2.5">
                  <UserPlus className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                  <span className="truncate">Users</span>
                </Button>
              </Link>
              <Link to={createPageUrl("Locations")}>
                <Button variant="outline" className="w-full justify-start text-xs sm:text-sm h-auto py-2 sm:py-2.5">
                  <MapPin className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                  <span className="truncate">Locations</span>
                </Button>
              </Link>
              <Link to={createPageUrl("RoleManagement")}>
                <Button variant="outline" className="w-full justify-start text-xs sm:text-sm h-auto py-2 sm:py-2.5">
                  <Shield className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                  <span className="truncate">Roles</span>
                </Button>
              </Link>
              <Link to={createPageUrl("SendUpdateNotification")}>
                <Button variant="outline" className="w-full justify-start text-xs sm:text-sm h-auto py-2 sm:py-2.5">
                  <Mail className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                  <span className="truncate">Updates</span>
                </Button>
              </Link>
              <Link to={createPageUrl("Analytics")}>
                <Button variant="outline" className="w-full justify-start text-xs sm:text-sm h-auto py-2 sm:py-2.5">
                  <BarChart3 className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                  <span className="truncate">Analytics</span>
                </Button>
              </Link>
              <Link to={createPageUrl("ServiceCalls")}>
                <Button variant="outline" className="w-full justify-start text-xs sm:text-sm h-auto py-2 sm:py-2.5">
                  <Wrench className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                  <span className="truncate">Calls</span>
                </Button>
              </Link>
              </div>
          </CardContent>
        </Card>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            {/* Live Activity Feed */}
            <LiveActivityFeed locationId="all" />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Service Calls Status */}
              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Service Calls by Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={statusData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={(entry) => `${entry.name}: ${entry.value}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value">

                        {statusData.map((entry, index) =>
                        <Cell key={`cell-${index}`} fill={entry.color} />
                        )}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* 7-Day Trend */}
              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    7-Day Service Call Trend
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={last7Days}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="created" stroke="#3b82f6" name="Created" />
                      <Line type="monotone" dataKey="completed" stroke="#10b981" name="Completed" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* User Distribution */}
              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Users by Position
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={positionChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#8b5cf6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Locations Overview */}
              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className={`text-base flex items-center justify-between ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Locations Management
                    <Link to={createPageUrl("Locations")}>
                      <Button variant="outline" size="sm">View All</Button>
                    </Link>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <div className="space-y-3">
                    {activeLocations.map((location) => {
                      const locationCalls = serviceCalls.filter((c) => c.bowling_alley_id === location.id);
                      const openAtLocation = locationCalls.filter((c) => c.status === 'open' || c.status === 'in_progress').length;

                      return (
                        <div key={location.id} className="flex items-center justify-between p-3 rounded-lg border">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <Building2 className="w-5 h-5 text-slate-400 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className={`font-medium truncate ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                {location.name}
                              </p>
                              <p className="text-xs text-slate-500">
                                {location.total_lanes || 0} lanes
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={openAtLocation > 0 ? "default" : "outline"}>
                              {openAtLocation} open
                            </Badge>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setDeleteLocationId(location.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>);

                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-4">
            <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader className="p-4 pb-2">
                <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Recent Service Calls
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-2">
                <div className="space-y-3">
                  {recentCalls.map((call) =>
                  <Link key={call.id} to={createPageUrl("ServiceCallDetail") + "?id=" + call.id}>
                      <div className="flex items-center justify-between p-4 rounded-lg border hover:bg-slate-50 transition-colors">
                        <div className="flex items-start gap-3">
                          <Wrench className="w-5 h-5 text-slate-400 mt-1" />
                          <div>
                            <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                              {call.title}
                            </p>
                            <p className="text-sm text-slate-500">
                              Lane {call.lane_number} • {format(new Date(call.created_date), 'MMM d, h:mm a')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={
                        call.priority === 'urgent' ? 'bg-red-100 text-red-800' :
                        call.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                        'bg-blue-100 text-blue-800'
                        }>
                            {call.priority}
                          </Badge>
                          <ArrowRight className="w-4 h-4 text-slate-400" />
                        </div>
                      </div>
                    </Link>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader className="p-4 pb-2">
                <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  User Management
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-2">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="text-sm text-blue-600 font-medium">Total Users</p>
                    <p className="text-2xl font-bold text-blue-900">{users.length}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                    <p className="text-sm text-green-600 font-medium">Active Users</p>
                    <p className="text-2xl font-bold text-green-900">{activeUsers.length}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="text-sm text-purple-600 font-medium">Admins</p>
                    <p className="text-2xl font-bold text-purple-900">
                      {users.filter((u) => u.role === 'admin').length}
                    </p>
                  </div>
                </div>
                <Link to={createPageUrl("UserManagement")}>
                  <Button className="w-full">
                    <Users className="w-4 h-4 mr-2" />
                    Manage All Users
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    System Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 p-4 pt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 text-sm">Database</span>
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Online
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 text-sm">Authentication</span>
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Active
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 text-sm">Total Records</span>
                    <span className="text-slate-200 text-sm font-medium">
                      {serviceCalls.length + users.length + parts.length + locations.length}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className={`text-base ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Quick Links
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 p-4 pt-2">
                  <Link to={createPageUrl("InitializePermissions")}>
                    <Button variant="outline" className="w-full justify-start">
                      <Shield className="w-4 h-4 mr-2" />
                      Initialize Permissions
                    </Button>
                  </Link>
                  <Link to={createPageUrl("PartsInventory")}>
                    <Button variant="outline" className="w-full justify-start">
                      <Package className="w-4 h-4 mr-2" />
                      Inventory Management
                    </Button>
                  </Link>
                  <Link to={createPageUrl("ServiceCallHistory")}>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="w-4 h-4 mr-2" />
                      Service History
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
        </div>
      </div>

      {/* Delete Location Confirmation Dialog */}
      <AlertDialog open={!!deleteLocationId} onOpenChange={() => setDeleteLocationId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Location</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this location? This action cannot be undone and will affect all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => handleDeleteLocation(deleteLocationId)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}