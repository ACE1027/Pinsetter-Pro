import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, Wrench, Package, Clock, AlertTriangle, Target, Calendar } from "lucide-react";
import { useLocation } from "../components/LocationContext";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/components/ThemeContext";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, Eye, ChevronRight, Filter } from "lucide-react";
import StatusBadge from "@/components/service/StatusBadge";
import PriorityBadge from "@/components/service/PriorityBadge";
import { ExportMenu } from "@/components/ExportMenu";

const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#6366f1'];

export default function Analytics() {
  const { theme, isDarkMode } = useTheme();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [dateRange, setDateRange] = useState('30');
  const { selectedLocationId } = useLocation();
  const [selectedCall, setSelectedCall] = useState(null);
  const [drillDownData, setDrillDownData] = useState({ type: null, data: null });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list(),
    initialData: []
  });

  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: []
  });

  const { data: usedParts = [] } = useQuery({
    queryKey: ['usedParts'],
    queryFn: () => base44.entities.UsedPart.list(),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' ?
  selectedLocationId :
  user?.bowling_alley_id;

  // Filter calls by location
  const filteredCalls = serviceCalls.filter((call) => {
    if (!user) return false;
    if (isAdmin && !selectedLocationId) return true;
    if (isAdmin && selectedLocationId === 'all') return true;
    return call.bowling_alley_id === effectiveLocationId;
  });

  // Filter by date range
  const daysAgo = parseInt(dateRange);
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysAgo);

  const recentCalls = filteredCalls.filter((call) =>
  new Date(call.created_date) >= cutoffDate
  );

  // Issue type breakdown
  const issueBreakdown = recentCalls.reduce((acc, call) => {
    const issue = call.title.split(' - ')[0] || 'Other';
    acc[issue] = (acc[issue] || 0) + 1;
    return acc;
  }, {});

  const issueData = Object.entries(issueBreakdown).
  map(([name, value]) => ({ name, value })).
  sort((a, b) => b.value - a.value).
  slice(0, 6);

  // Status breakdown
  const statusBreakdown = recentCalls.reduce((acc, call) => {
    acc[call.status] = (acc[call.status] || 0) + 1;
    return acc;
  }, {});

  const statusData = Object.entries(statusBreakdown).map(([name, value]) => ({
    name: name.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()),
    value
  }));

  // Priority breakdown
  const priorityBreakdown = recentCalls.reduce((acc, call) => {
    acc[call.priority] = (acc[call.priority] || 0) + 1;
    return acc;
  }, {});

  const priorityData = Object.entries(priorityBreakdown).map(([name, value]) => ({
    name: name.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()),
    value
  }));

  // Calls over time (daily)
  const callsOverTime = recentCalls.reduce((acc, call) => {
    const date = new Date(call.created_date).toISOString().split('T')[0];
    acc[date] = (acc[date] || 0) + 1;
    return acc;
  }, {});

  const timelineData = Object.entries(callsOverTime).
  map(([date, count]) => ({ date: new Date(date).toLocaleDateString(), count })).
  sort((a, b) => new Date(a.date) - new Date(b.date));

  // Top lanes with issues
  const laneBreakdown = recentCalls.reduce((acc, call) => {
    const lane = call.lane_number || 'Unknown';
    acc[lane] = (acc[lane] || 0) + 1;
    return acc;
  }, {});

  const topLanes = Object.entries(laneBreakdown).
  map(([lane, count]) => ({ lane: `Lane ${lane}`, count })).
  sort((a, b) => b.count - a.count).
  slice(0, 10);

  // Parts usage stats
  const partsUsageMap = usedParts.reduce((acc, used) => {
    const part = parts.find((p) => p.id === used.part_id);
    if (part) {
      const key = part.name;
      acc[key] = (acc[key] || 0) + used.quantity_used;
    }
    return acc;
  }, {});

  const topParts = Object.entries(partsUsageMap).
  map(([name, quantity]) => ({ name, quantity })).
  sort((a, b) => b.quantity - a.quantity).
  slice(0, 8);

  // Per-lane detailed analysis
  const laneAnalysis = Object.entries(laneBreakdown).map(([laneNumber, totalCalls]) => {
    const laneCalls = recentCalls.filter((c) => c.lane_number === laneNumber);

    // Issue breakdown for this lane
    const laneIssues = laneCalls.reduce((acc, call) => {
      const issue = call.title.split(' - ')[0] || 'Other';
      acc[issue] = (acc[issue] || 0) + 1;
      return acc;
    }, {});

    const topIssue = Object.entries(laneIssues).sort((a, b) => b[1] - a[1])[0];

    // Average resolution time for this lane
    const laneCompletedCalls = laneCalls.filter((c) => c.status === 'completed' && c.completed_date);
    const laneAvgResolution = laneCompletedCalls.length > 0 ?
    laneCompletedCalls.reduce((sum, call) => {
      const created = new Date(call.created_date);
      const completed = new Date(call.completed_date);
      const hours = (completed - created) / (1000 * 60 * 60);
      return sum + hours;
    }, 0) / laneCompletedCalls.length :
    0;

    // Priority breakdown
    const urgentCount = laneCalls.filter((c) => c.priority === 'urgent').length;
    const highCount = laneCalls.filter((c) => c.priority === 'high').length;

    return {
      lane: laneNumber,
      totalCalls,
      topIssue: topIssue ? topIssue[0] : 'N/A',
      topIssueCount: topIssue ? topIssue[1] : 0,
      urgentCalls: urgentCount,
      highPriorityCalls: highCount,
      avgResolutionHours: laneAvgResolution,
      issueBreakdown: laneIssues
    };
  }).sort((a, b) => parseInt(a.lane) - parseInt(b.lane));

  // Average resolution time (completed calls)
  const completedCalls = recentCalls.filter((c) => c.status === 'completed' && c.completed_date);
  const avgResolutionHours = completedCalls.length > 0 ?
  completedCalls.reduce((sum, call) => {
    const created = new Date(call.created_date);
    const completed = new Date(call.completed_date);
    const hours = (completed - created) / (1000 * 60 * 60);
    return sum + hours;
  }, 0) / completedCalls.length :
  0;

  // Average resolution time by issue type
  const resolutionByIssueType = completedCalls.reduce((acc, call) => {
    const issueType = call.title.split(' - ')[0] || 'Other';
    if (!acc[issueType]) {
      acc[issueType] = { totalHours: 0, count: 0 };
    }
    const created = new Date(call.created_date);
    const completed = new Date(call.completed_date);
    const hours = (completed - created) / (1000 * 60 * 60);
    acc[issueType].totalHours += hours;
    acc[issueType].count += 1;
    return acc;
  }, {});

  const avgResolutionByIssueData = Object.entries(resolutionByIssueType)
    .map(([issue, data]) => ({
      issue,
      avgHours: data.totalHours / data.count,
      count: data.count
    }))
    .sort((a, b) => b.avgHours - a.avgHours)
    .slice(0, 8);

  // Average resolution time by mechanic
  const resolutionByMechanic = completedCalls.reduce((acc, call) => {
    if (!call.assigned_to) return acc;
    if (!acc[call.assigned_to]) {
      acc[call.assigned_to] = { totalHours: 0, count: 0 };
    }
    const created = new Date(call.created_date);
    const completed = new Date(call.completed_date);
    const hours = (completed - created) / (1000 * 60 * 60);
    acc[call.assigned_to].totalHours += hours;
    acc[call.assigned_to].count += 1;
    return acc;
  }, {});

  const avgResolutionByMechanicData = Object.entries(resolutionByMechanic)
    .map(([email, data]) => ({
      mechanic: email,
      avgHours: data.totalHours / data.count,
      callsCompleted: data.count
    }))
    .sort((a, b) => a.avgHours - b.avgHours);

  // Service calls per location per week/month
  const callsPerLocation = recentCalls.reduce((acc, call) => {
    const locationId = call.bowling_alley_id;
    if (!acc[locationId]) {
      acc[locationId] = { count: 0, locationName: '' };
    }
    acc[locationId].count += 1;
    const location = locations.find(l => l.id === locationId);
    acc[locationId].locationName = location?.name || 'Unknown';
    return acc;
  }, {});

  const callsPerLocationData = Object.entries(callsPerLocation)
    .map(([id, data]) => ({
      location: data.locationName,
      calls: data.count
    }))
    .sort((a, b) => b.calls - a.calls);

  // SLA breach tracking (SLA: Urgent = 4h, High = 8h, Medium = 24h, Low = 48h)
  const SLA_THRESHOLDS = {
    urgent: 4,
    high: 8,
    medium: 24,
    low: 48
  };

  const slaBreaches = completedCalls.filter(call => {
    const created = new Date(call.created_date);
    const completed = new Date(call.completed_date);
    const hours = (completed - created) / (1000 * 60 * 60);
    const threshold = SLA_THRESHOLDS[call.priority] || SLA_THRESHOLDS.medium;
    return hours > threshold;
  });

  const slaBreachRate = completedCalls.length > 0 
    ? ((slaBreaches.length / completedCalls.length) * 100).toFixed(1)
    : 0;

  const slaBreachesByPriority = slaBreaches.reduce((acc, call) => {
    acc[call.priority] = (acc[call.priority] || 0) + 1;
    return acc;
  }, {});

  const slaBreachData = Object.entries(slaBreachesByPriority).map(([priority, count]) => ({
    priority: priority.charAt(0).toUpperCase() + priority.slice(1),
    breaches: count,
    threshold: `${SLA_THRESHOLDS[priority]}h`
  }));

  // Mechanic performance (calls resolved vs. assigned)
  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const mechanics = allUsers.filter(u => u.department === 'mechanic' || u.department === 'manager');

  const mechanicPerformance = mechanics.map(mechanic => {
    const assignedCalls = recentCalls.filter(c => c.assigned_to === mechanic.email);
    const completedCalls = assignedCalls.filter(c => c.status === 'completed');
    const inProgressCalls = assignedCalls.filter(c => c.status === 'in_progress');
    const openCalls = assignedCalls.filter(c => c.status === 'open');
    
    return {
      name: mechanic.display_name || mechanic.full_name || mechanic.email,
      email: mechanic.email,
      assigned: assignedCalls.length,
      completed: completedCalls.length,
      inProgress: inProgressCalls.length,
      open: openCalls.length,
      completionRate: assignedCalls.length > 0 
        ? ((completedCalls.length / assignedCalls.length) * 100).toFixed(1)
        : 0
    };
  }).filter(m => m.assigned > 0)
    .sort((a, b) => b.completed - a.completed);

  // Stats cards
  const totalCalls = recentCalls.length;
  const completedCount = recentCalls.filter((c) => c.status === 'completed').length;
  const completionRate = totalCalls > 0 ? (completedCount / totalCalls * 100).toFixed(1) : 0;
  const urgentCalls = recentCalls.filter((c) => c.priority === 'urgent').length;

  // Day-to-day report: group service calls by date
  const dailyReport = recentCalls.reduce((acc, call) => {
    const date = new Date(call.created_date).toISOString().split('T')[0];
    if (!acc[date]) {
      acc[date] = {
        date,
        calls: [],
        totalCalls: 0,
        completedCalls: 0,
        urgentCalls: 0,
        partsUsed: []
      };
    }
    acc[date].calls.push(call);
    acc[date].totalCalls += 1;
    if (call.status === 'completed') acc[date].completedCalls += 1;
    if (call.priority === 'urgent') acc[date].urgentCalls += 1;
    return acc;
  }, {});

  // Add parts used per day to the daily report
  usedParts.forEach((used) => {
    const serviceCall = serviceCalls.find((c) => c.id === used.service_call_id);
    if (serviceCall) {
      const date = new Date(serviceCall.created_date).toISOString().split('T')[0];
      if (dailyReport[date]) {
        const part = parts.find((p) => p.id === used.part_id);
        if (part) {
          dailyReport[date].partsUsed.push({
            name: part.name,
            partNumber: part.part_number,
            quantity: used.quantity_used
          });
        }
      }
    }
  });

  const dailyReportData = Object.values(dailyReport).
  sort((a, b) => new Date(b.date) - new Date(a.date));

  // Quick view service call modal
  const ServiceCallQuickView = ({ call, onClose }) => {
    if (!call) return null;
    
    const location = locations.find(l => l.id === call.bowling_alley_id);
    
    return (
      <Dialog open={!!call} onOpenChange={() => onClose()}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wrench className="w-5 h-5 text-blue-600" />
              {call.title}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-600 mb-1">Status</p>
                <StatusBadge status={call.status} showIcon />
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Priority</p>
                <PriorityBadge priority={call.priority} showIcon />
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Lane</p>
                <p className="font-medium">Lane {call.lane_number}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Location</p>
                <p className="font-medium">{location?.name || 'Unknown'}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Created</p>
                <p className="font-medium">{new Date(call.created_date).toLocaleString()}</p>
              </div>
              {call.completed_date && (
                <div>
                  <p className="text-sm text-slate-600 mb-1">Completed</p>
                  <p className="font-medium">{new Date(call.completed_date).toLocaleString()}</p>
                </div>
              )}
            </div>
            {call.description && (
              <div>
                <p className="text-sm text-slate-600 mb-1">Description</p>
                <p className="text-sm bg-slate-50 p-3 rounded-lg border">{call.description}</p>
              </div>
            )}
            <div className="flex gap-2 pt-4">
              <Button onClick={() => navigate(createPageUrl("ServiceCallDetail") + "?id=" + call.id)} className="flex-1">
                <ExternalLink className="w-4 h-4 mr-2" />
                View Full Details
              </Button>
              <Button variant="outline" onClick={onClose}>Close</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  // Drill-down modal for filtered data
  const DrillDownModal = ({ type, data, onClose }) => {
    if (!type || !data) return null;
    
    let title = "";
    let calls = [];
    
    if (type === 'mechanic') {
      title = `Service Calls - ${data.name}`;
      calls = recentCalls.filter(c => c.assigned_to === data.email);
    } else if (type === 'lane') {
      title = `Service Calls - Lane ${data.lane}`;
      calls = recentCalls.filter(c => c.lane_number === data.lane);
    } else if (type === 'issue') {
      title = `Service Calls - ${data.issue}`;
      calls = recentCalls.filter(c => c.title.startsWith(data.issue));
    } else if (type === 'priority') {
      title = `${data.priority} Priority Calls`;
      calls = recentCalls.filter(c => c.priority === data.priority);
    } else if (type === 'status') {
      title = `${data.status} Service Calls`;
      calls = recentCalls.filter(c => c.status === data.status);
    }
    
    return (
      <Dialog open={!!type} onOpenChange={() => onClose()}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-blue-600" />
              {title} ({calls.length})
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            {calls.map(call => (
              <div 
                key={call.id}
                onClick={() => {
                  onClose();
                  setSelectedCall(call);
                }}
                className="flex items-center justify-between p-4 rounded-lg border hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <div className="flex-1">
                  <p className="font-medium">{call.title}</p>
                  <div className="flex gap-3 mt-1 text-sm text-slate-600">
                    <span>Lane {call.lane_number}</span>
                    <span>•</span>
                    <span>{new Date(call.created_date).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={call.status} />
                  <PriorityBadge priority={call.priority} />
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))}
            {calls.length === 0 && (
              <div className="text-center py-8 text-slate-500">No service calls found</div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Analytics & Reports</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Insights into service performance and trends</p>
          </div>
          <div className="flex gap-2">
            <ExportMenu 
              data={recentCalls}
              columns={[
                { header: 'Title', key: 'title' },
                { header: 'Lane', key: 'lane_number' },
                { header: 'Status', key: 'status' },
                { header: 'Priority', key: 'priority' },
                { header: 'Assigned To', key: 'assigned_to' },
                { header: 'Created', key: 'created_date' },
                { header: 'Completed', key: 'completed_date' }
              ]}
              filename={`analytics-calls-${dateRange}days`}
              title={`Service Calls (Last ${dateRange} Days)`}
            />
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="bg-transparent text-slate-50 px-3 py-2 text-sm rounded-md flex h-9 items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 Days</SelectItem>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 90 Days</SelectItem>
                <SelectItem value="365">Last Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Total Calls</p>
                  <p className="text-2xl font-bold text-slate-900">{totalCalls}</p>
                </div>
                <Wrench className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Completion Rate</p>
                  <p className="text-2xl font-bold text-green-600">{completionRate}%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Avg Resolution</p>
                  <p className="text-2xl font-bold text-slate-900">{avgResolutionHours.toFixed(1)}h</p>
                </div>
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Urgent Calls</p>
                  <p className="text-2xl font-bold text-red-600">{urgentCalls}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <Tabs defaultValue="trends" className="space-y-6">
          <TabsList className="grid grid-cols-3 lg:grid-cols-7 overflow-x-auto">
            <TabsTrigger value="trends">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="sla">SLA</TabsTrigger>
            <TabsTrigger value="issues">Issues</TabsTrigger>
            <TabsTrigger value="parts">Parts</TabsTrigger>
            <TabsTrigger value="lanes">Lanes</TabsTrigger>
            <TabsTrigger value="daily-report">Daily</TabsTrigger>
          </TabsList>

          <TabsContent value="trends" className="space-y-6">
            {/* Service Calls Per Location */}
            <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Service Calls by Location</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={callsPerLocationData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="location" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="calls" fill="#3b82f6" name="Service Calls" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Service Calls Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={timelineData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={2} name="Service Calls" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
                <CardHeader>
                  <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Status Distribution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                        {statusData.map((entry, index) =>
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        )}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-2">
                    {statusData.map((item) => (
                      <Button
                        key={item.name}
                        size="sm"
                        variant="outline"
                        onClick={() => setDrillDownData({ 
                          type: 'status', 
                          data: { status: item.name.toLowerCase().replace(/ /g, '_') } 
                        })}
                        className="justify-between"
                      >
                        <span>{item.name}</span>
                        <Badge variant="outline">{item.value}</Badge>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className={`shadow-lg backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
                <CardHeader>
                  <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Priority Distribution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie data={priorityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                        {priorityData.map((entry, index) =>
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        )}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-2">
                    {priorityData.map((item) => (
                      <Button
                        key={item.name}
                        size="sm"
                        variant="outline"
                        onClick={() => setDrillDownData({ 
                          type: 'priority', 
                          data: { priority: item.name.toLowerCase().replace(/ /g, '_') } 
                        })}
                        className="justify-between"
                      >
                        <span>{item.name}</span>
                        <Badge variant="outline">{item.value}</Badge>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Mechanic Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                        <TableHead className="font-semibold">Mechanic</TableHead>
                        <TableHead className="font-semibold">Assigned</TableHead>
                        <TableHead className="font-semibold">Completed</TableHead>
                        <TableHead className="font-semibold">In Progress</TableHead>
                        <TableHead className="font-semibold">Open</TableHead>
                        <TableHead className="font-semibold">Completion Rate</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mechanicPerformance.map((mech) => (
                        <TableRow 
                          key={mech.email} 
                          onClick={() => setDrillDownData({ type: 'mechanic', data: mech })}
                          className="cursor-pointer hover:bg-slate-50 transition-colors"
                        >
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {mech.name}
                              <Eye className="w-3 h-3 text-slate-400 opacity-0 group-hover:opacity-100" />
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-blue-50">
                              {mech.assigned}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">
                              {mech.completed}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-yellow-100 text-yellow-800">
                              {mech.inProgress}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-slate-100 text-slate-800">
                              {mech.open}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-slate-200 rounded-full h-2 max-w-[100px]">
                                <div 
                                  className="bg-green-600 h-2 rounded-full"
                                  style={{ width: `${mech.completionRate}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium">{mech.completionRate}%</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {mechanicPerformance.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No mechanic performance data available
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Completion Rate Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={mechanicPerformance}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="completed" fill="#10b981" name="Completed" />
                    <Bar dataKey="inProgress" fill="#f59e0b" name="In Progress" />
                    <Bar dataKey="open" fill="#6b7280" name="Open" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SLA & Resolution Tab */}
          <TabsContent value="sla" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-600">SLA Compliance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">
                    {(100 - parseFloat(slaBreachRate)).toFixed(1)}%
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {completedCalls.length - slaBreaches.length} of {completedCalls.length} calls met SLA
                  </p>
                </CardContent>
              </Card>

              <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-600">SLA Breaches</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-600">
                    {slaBreaches.length}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {slaBreachRate}% breach rate
                  </p>
                </CardContent>
              </Card>

              <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-600">Avg Resolution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">
                    {avgResolutionHours.toFixed(1)}h
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Across all priorities
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>SLA Thresholds</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <div className="text-xs font-medium text-red-900 mb-1">URGENT</div>
                    <div className="text-2xl font-bold text-red-700">{SLA_THRESHOLDS.urgent}h</div>
                  </div>
                  <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="text-xs font-medium text-orange-900 mb-1">HIGH</div>
                    <div className="text-2xl font-bold text-orange-700">{SLA_THRESHOLDS.high}h</div>
                  </div>
                  <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <div className="text-xs font-medium text-yellow-900 mb-1">MEDIUM</div>
                    <div className="text-2xl font-bold text-yellow-700">{SLA_THRESHOLDS.medium}h</div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="text-xs font-medium text-blue-900 mb-1">LOW</div>
                    <div className="text-2xl font-bold text-blue-700">{SLA_THRESHOLDS.low}h</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {slaBreachData.length > 0 && (
              <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader>
                  <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>SLA Breaches by Priority</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                          <TableHead className="font-semibold">Priority</TableHead>
                          <TableHead className="font-semibold">SLA Threshold</TableHead>
                          <TableHead className="font-semibold">Breaches</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {slaBreachData.map((item) => (
                          <TableRow key={item.priority}>
                            <TableCell className="font-medium">{item.priority}</TableCell>
                            <TableCell>{item.threshold}</TableCell>
                            <TableCell>
                              <Badge className="bg-red-100 text-red-800">
                                {item.breaches}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Avg Resolution Time by Issue Type</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={avgResolutionByIssueData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" label={{ value: 'Hours', position: 'insideBottom', offset: -5 }} />
                    <YAxis type="category" dataKey="issue" width={150} />
                    <Tooltip />
                    <Bar dataKey="avgHours" fill="#3b82f6" name="Avg Hours" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Avg Resolution Time by Mechanic</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                        <TableHead className="font-semibold">Mechanic</TableHead>
                        <TableHead className="font-semibold">Calls Completed</TableHead>
                        <TableHead className="font-semibold">Avg Resolution Time</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {avgResolutionByMechanicData.map((mech) => (
                        <TableRow 
                          key={mech.mechanic}
                          onClick={() => setDrillDownData({ type: 'mechanic', data: { name: mech.mechanic, email: mech.mechanic } })}
                          className="cursor-pointer hover:bg-slate-50 transition-colors"
                        >
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {mech.mechanic}
                              <Eye className="w-3 h-3 text-slate-400" />
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-blue-50">
                              {mech.callsCompleted}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <span className="font-semibold text-blue-600">
                              {mech.avgHours.toFixed(1)}h
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {avgResolutionByMechanicData.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No resolution time data available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="issues" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Top Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={issueData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={150} />
                    <Tooltip cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }} />
                    <Legend />
                    <Bar 
                      dataKey="value" 
                      fill="#3b82f6" 
                      name="Count"
                      onClick={(data) => setDrillDownData({ type: 'issue', data: { issue: data.name } })}
                      className="cursor-pointer"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Issue Breakdown Table</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                      <TableHead className="font-semibold">Issue Type</TableHead>
                      <TableHead className="font-semibold">Count</TableHead>
                      <TableHead className="font-semibold">% of Total</TableHead>
                      <TableHead className="font-semibold">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {issueData.map((issue) => (
                      <TableRow key={issue.name} className="cursor-pointer hover:bg-slate-50">
                        <TableCell className="font-medium">{issue.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-blue-50">
                            {issue.value}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {((issue.value / recentCalls.length) * 100).toFixed(1)}%
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDrillDownData({ type: 'issue', data: { issue: issue.name } })}
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            View Calls
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="parts">
            <Card>
              <CardHeader>
                <CardTitle>Most Used Parts</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={topParts}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="quantity" fill="#8b5cf6" name="Quantity Used" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="lanes" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Lanes with Most Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={topLanes}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="lane" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#ec4899" name="Service Calls" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : ''}`}>
                  <Target className="w-5 h-5 text-blue-600" />
                  In-Depth Lane Analysis
                </CardTitle>
                <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Detailed breakdown of service calls, common issues, and performance metrics per lane
                </p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                        <TableHead className="font-semibold">Lane</TableHead>
                        <TableHead className="font-semibold">Total Calls</TableHead>
                        <TableHead className="font-semibold">Most Common Issue</TableHead>
                        <TableHead className="font-semibold">Issue Count</TableHead>
                        <TableHead className="font-semibold">Urgent Calls</TableHead>
                        <TableHead className="font-semibold">High Priority</TableHead>
                        <TableHead className="font-semibold">Avg Resolution</TableHead>
                        <TableHead className="font-semibold">All Issues</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {laneAnalysis.map((lane) =>
                      <TableRow 
                        key={lane.lane}
                        onClick={() => setDrillDownData({ type: 'lane', data: lane })}
                        className="cursor-pointer hover:bg-slate-50 transition-colors"
                      >
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              Lane {lane.lane}
                              <Eye className="w-3 h-3 text-slate-400" />
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-blue-50">
                              {lane.totalCalls}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium text-slate-900">
                            {lane.topIssue}
                          </TableCell>
                          <TableCell>{lane.topIssueCount}</TableCell>
                          <TableCell>
                            {lane.urgentCalls > 0 ?
                          <Badge className="bg-red-100 text-red-800">
                                {lane.urgentCalls}
                              </Badge> :

                          <span className="text-slate-400">0</span>
                          }
                          </TableCell>
                          <TableCell>
                            {lane.highPriorityCalls > 0 ?
                          <Badge className="bg-orange-100 text-orange-800">
                                {lane.highPriorityCalls}
                              </Badge> :

                          <span className="text-slate-400">0</span>
                          }
                          </TableCell>
                          <TableCell>
                            {lane.avgResolutionHours > 0 ?
                          `${lane.avgResolutionHours.toFixed(1)}h` :
                          'N/A'}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {Object.entries(lane.issueBreakdown).
                            sort((a, b) => b[1] - a[1]).
                            map(([issue, count]) =>
                            <Badge
                              key={issue}
                              variant="outline"
                              className="text-xs bg-slate-50">

                                    {issue}: {count}
                                  </Badge>
                            )}
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>

                {laneAnalysis.length === 0 &&
                <div className="text-center py-8 text-slate-500">
                    No lane data available for the selected date range
                  </div>
                }
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="daily-report" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : ''}`}>
                  <Calendar className="w-5 h-5 text-blue-600" />
                  Day-to-Day Report
                </CardTitle>
                <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Daily breakdown of service calls and parts usage
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dailyReportData.map((day) =>
                  <Card key={day.date} className="border-2 border-slate-200">
                      <CardHeader className="bg-slate-50 pb-3">
                        <div className="flex justify-between items-center">
                          <CardTitle className="text-lg">
                            {new Date(day.date).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                          </CardTitle>
                          <div className="flex gap-2">
                            <Badge className="bg-blue-100 text-blue-800">
                              {day.totalCalls} Calls
                            </Badge>
                            {day.completedCalls > 0 &&
                          <Badge className="bg-green-100 text-green-800">
                                {day.completedCalls} Completed
                              </Badge>
                          }
                            {day.urgentCalls > 0 &&
                          <Badge className="bg-red-100 text-red-800">
                                {day.urgentCalls} Urgent
                              </Badge>
                          }
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-4">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          {/* Service Calls */}
                          <div>
                            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                              <Wrench className="w-4 h-4 text-blue-600" />
                              Service Calls ({day.calls.length})
                            </h4>
                            <div className="space-y-2">
                              {day.calls.map((call) =>
                            <div 
                              key={call.id} 
                              onClick={() => setSelectedCall(call)}
                              className="flex items-start justify-between p-3 bg-slate-50 rounded-lg border border-slate-200 hover:bg-slate-100 transition-colors cursor-pointer group"
                            >
                                  <div className="flex-1">
                                    <p className="font-medium text-sm text-slate-900 flex items-center gap-2">
                                      {call.title}
                                      <Eye className="w-3 h-3 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </p>
                                    <div className="flex gap-2 mt-1">
                                      <span className="text-xs text-slate-600">Lane {call.lane_number}</span>
                                      <span className="text-xs text-slate-400">•</span>
                                      <span className="text-xs text-slate-600 capitalize">
                                        {call.status.replace(/_/g, ' ')}
                                      </span>
                                    </div>
                                  </div>
                                  <Badge
                                className={
                                call.priority === 'urgent' ?
                                'bg-red-100 text-red-800' :
                                call.priority === 'high' ?
                                'bg-orange-100 text-orange-800' :
                                'bg-slate-100 text-slate-800'
                                }>

                                    {call.priority}
                                  </Badge>
                                </div>
                            )}
                            </div>
                          </div>

                          {/* Parts Used */}
                          <div>
                            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                              <Package className="w-4 h-4 text-purple-600" />
                              Parts Used ({day.partsUsed.length})
                            </h4>
                            {day.partsUsed.length > 0 ?
                          <div className="space-y-2">
                                {day.partsUsed.map((part, idx) =>
                            <div key={idx} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg border border-purple-200">
                                    <div>
                                      <p className="font-medium text-sm text-slate-900">{part.name}</p>
                                      <p className="text-xs text-slate-600">{part.partNumber}</p>
                                    </div>
                                    <Badge className="bg-purple-100 text-purple-800">
                                      ×{part.quantity}
                                    </Badge>
                                  </div>
                            )}
                              </div> :

                          <div className="flex items-center justify-center h-32 bg-slate-50 rounded-lg border-2 border-dashed border-slate-200">
                                <p className="text-sm text-slate-500">No parts used this day</p>
                              </div>
                          }
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {dailyReportData.length === 0 &&
                  <div className="text-center py-12 text-slate-500">
                      <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                      <p>No data available for the selected date range</p>
                    </div>
                  }
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Modals */}
      <ServiceCallQuickView call={selectedCall} onClose={() => setSelectedCall(null)} />
      <DrillDownModal 
        type={drillDownData.type} 
        data={drillDownData.data} 
        onClose={() => setDrillDownData({ type: null, data: null })} 
      />
    </div>);

}