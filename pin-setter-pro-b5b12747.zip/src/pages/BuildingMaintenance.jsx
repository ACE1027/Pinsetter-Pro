import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Select as QuickSelect, SelectContent as QuickSelectContent, SelectItem as QuickSelectItem, SelectTrigger as QuickSelectTrigger, SelectValue as QuickSelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Calendar, Plus, Edit, Trash2, CheckCircle2, Clock, AlertCircle, History, Wrench } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useLocation } from "../components/LocationContext";
import { useTheme } from "../components/ThemeContext";
import { ExportMenu } from "@/components/ExportMenu";

export default function BuildingMaintenance() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCall, setEditingCall] = useState(null);
  const [activeTab, setActiveTab] = useState("active");
  const { selectedLocationId } = useLocation();
  
  const [formData, setFormData] = useState({
    bowling_alley_id: "",
    machine_type: "",
    title: "",
    description: "",
    status: "open",
    priority: "medium",
    assigned_to: "",
    category: "building"
  });

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u.bowling_alley_id) {
        setFormData(prev => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});
  }, []);

  const { data: serviceCalls = [], isLoading } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    initialData: [],
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ServiceCall.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      resetForm();
      toast.success("Building maintenance call created");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ServiceCall.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      resetForm();
      toast.success("Call updated successfully");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ServiceCall.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      toast.success("Call deleted successfully");
    },
  });

  const quickUpdateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.ServiceCall.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      toast.success("Status updated");
    },
  });

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  const canEdit = isAdmin || isManager;

  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  const accessibleCalls = serviceCalls.filter(call => {
    // Filter for building category
    if (call.category !== 'building') return false;
    
    if (!user) return false;
    
    // Admin viewing all locations
    if (isAdmin && selectedLocationId === 'all') return true;
    
    // Filter by specific location
    const locationIdToCheck = isAdmin ? selectedLocationId : user.bowling_alley_id;
    return call.bowling_alley_id === locationIdToCheck;
  });

  const activeCalls = accessibleCalls.filter(c => c.status !== 'completed' && c.status !== 'cancelled');
  const historyCalls = accessibleCalls.filter(c => c.status === 'completed' || c.status === 'cancelled');

  const resetForm = () => {
    setDialogOpen(false);
    setEditingCall(null);
    setFormData({
      bowling_alley_id: user?.bowling_alley_id || "",
      machine_type: "",
      title: "",
      description: "",
      status: "open",
      priority: "medium",
      assigned_to: "",
      category: "building"
    });
  };

  const handleEdit = (call) => {
    setEditingCall(call);
    setFormData({
      bowling_alley_id: call.bowling_alley_id || "",
      machine_type: call.machine_type || "",
      title: call.title || "",
      description: call.description || "",
      status: call.status || "open",
      priority: call.priority || "medium",
      assigned_to: call.assigned_to || "",
      category: "building"
    });
    setDialogOpen(true);
  };

  const handleDelete = (call) => {
    if (window.confirm(`Are you sure you want to delete this maintenance call?`)) {
      deleteMutation.mutate(call.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const deviceTimestamp = new Date().toISOString();
    
    const dataToSubmit = {
      ...formData,
      category: "building" // Ensure category is always building
    };
    
    if (editingCall) {
      updateMutation.mutate({ id: editingCall.id, data: dataToSubmit });
    } else {
      createMutation.mutate({ ...dataToSubmit, device_timestamp: deviceTimestamp });
    }
  };

  const getStatusBadge = (status) => {
    const config = {
      open: { color: "bg-blue-100 text-blue-800", icon: AlertCircle, label: "Open" },
      in_progress: { color: "bg-yellow-100 text-yellow-800", icon: Clock, label: "In Progress" },
      waiting_for_parts: { color: "bg-orange-100 text-orange-800", icon: Clock, label: "Waiting for Parts" },
      completed: { color: "bg-green-100 text-green-800", icon: CheckCircle2, label: "Completed" },
      cancelled: { color: "bg-slate-100 text-slate-800", icon: Trash2, label: "Cancelled" },
    };
    const { color, icon: Icon, label } = config[status] || config.open;
    return (
      <Badge className={color}>
        <Icon className="w-3 h-3 mr-1" />
        {label}
      </Badge>
    );
  };

  const getPriorityBadge = (priority) => {
    const config = {
      low: "bg-slate-100 text-slate-800",
      medium: "bg-blue-100 text-blue-800",
      high: "bg-orange-100 text-orange-800",
      urgent: "bg-red-100 text-red-800",
    };
    return (
      <Badge className={config[priority] || config.medium}>
        {priority.charAt(0).toUpperCase() + priority.slice(1)} Priority
      </Badge>
    );
  };

  const getLocationName = (locationId) => {
    const location = locations.find(l => l.id === locationId);
    return location?.name || 'Unknown Location';
  };

  const assignableUsers = allUsers.filter((u) =>
    (u.department === 'mechanic' || u.department === 'manager' || u.role === 'admin') &&
    (u.bowling_alley_id === formData.bowling_alley_id || u.role === 'admin')
  );

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full overflow-x-hidden">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Building Maintenance Calls</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Track and manage building service requests</p>
          </div>
          <div className="flex gap-2">
            <ExportMenu 
              data={activeTab === 'active' ? activeCalls : historyCalls}
              columns={[
                { header: 'Title', key: 'title' },
                { header: 'Status', key: 'status' },
                { header: 'Priority', key: 'priority' },
                { header: 'Assigned To', key: 'assigned_to' },
                { header: 'Description', key: 'description' },
                { header: 'Created Date', key: 'created_date' },
                { header: 'Completed Date', key: 'completed_date' }
              ]}
              filename={`building-maintenance-${activeTab}`}
              title={`Building Maintenance - ${activeTab}`}
            />
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" onClick={() => resetForm()}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Call
                </Button>
              </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingCall ? "Edit Maintenance Call" : "New Building Maintenance Call"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="bowling_alley_id">Location *</Label>
                  <Select 
                    value={formData.bowling_alley_id} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, bowling_alley_id: value }))}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.filter(l => l.active !== false).map(location => (
                        <SelectItem key={location.id} value={location.id}>
                          {location.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="machine_type">Machine Type (Optional)</Label>
                  <Select 
                    value={formData.machine_type} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, machine_type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select if applicable" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None</SelectItem>
                      <SelectItem value="Original A Pinsetter">Original A Pinsetter</SelectItem>
                      <SelectItem value="A-2 Pinsetter">A-2 Pinsetter</SelectItem>
                      <SelectItem value="Jetback Pinsetter">Jetback Pinsetter</SelectItem>
                      <SelectItem value="String Pin Boost XT">String Pin Boost XT</SelectItem>
                      <SelectItem value="GS-X Machine">GS-X Machine</SelectItem>
                      <SelectItem value="Brunswick GSX NXT">Brunswick GSX NXT</SelectItem>
                      <SelectItem value="82-30">82-30</SelectItem>
                      <SelectItem value="82-70 Pinspotter">82-70 Pinspotter</SelectItem>
                      <SelectItem value="82-90 Pinspotter">82-90 Pinspotter</SelectItem>
                      <SelectItem value="90XLI Pinspotter">90XLI Pinspotter</SelectItem>
                      <SelectItem value="Qubica AMF XLI Edge">Qubica AMF XLI Edge</SelectItem>
                      <SelectItem value="EDGE Free Fall Pinspotter">EDGE Free Fall Pinspotter</SelectItem>
                      <SelectItem value="EDGE String Pin Pinspotter">EDGE String Pin Pinspotter</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Issue Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., HVAC Repair, Roof Leak"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select 
                      value={formData.priority} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select 
                      value={formData.status} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="waiting_for_parts">Waiting for Parts</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="assigned_to">Assign To</Label>
                  <Select
                    value={formData.assigned_to}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, assigned_to: value }))}
                    disabled={!formData.bowling_alley_id}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Unassigned" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Unassigned</SelectItem>
                      {assignableUsers.map(u => (
                        <SelectItem key={u.id} value={u.email}>
                          {u.full_name || u.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Detailed description of the building issue..."
                    rows={4}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    {editingCall ? "Update Call" : "Create Call"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="active">
              Active Calls ({activeCalls.length})
            </TabsTrigger>
            <TabsTrigger value="history">
              <History className="w-4 h-4 mr-2" />
              History ({historyCalls.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
              </div>
            ) : activeCalls.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {activeCalls.map(call => (
                  <Card key={call.id} className={`shadow-lg hover:shadow-xl transition-shadow ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-100' : ''}`}>{call.title}</CardTitle>
                            {getPriorityBadge(call.priority)}
                          </div>
                          <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                            {getLocationName(call.bowling_alley_id)}
                          </p>
                        </div>
                        <QuickSelect 
                          value={call.status} 
                          onValueChange={(newStatus) => quickUpdateStatusMutation.mutate({ id: call.id, status: newStatus })}
                        >
                          <QuickSelectTrigger className="h-7 w-32 text-xs">
                            <QuickSelectValue>
                              {getStatusBadge(call.status)}
                            </QuickSelectValue>
                          </QuickSelectTrigger>
                          <QuickSelectContent>
                            <QuickSelectItem value="open">Open</QuickSelectItem>
                            <QuickSelectItem value="in_progress">In Progress</QuickSelectItem>
                            <QuickSelectItem value="waiting_for_parts">Waiting</QuickSelectItem>
                            <QuickSelectItem value="completed">Completed</QuickSelectItem>
                            <QuickSelectItem value="cancelled">Cancelled</QuickSelectItem>
                          </QuickSelectContent>
                        </QuickSelect>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        <span className="font-medium">
                          Created {format(new Date(call.created_date), "MMMM d, yyyy")}
                        </span>
                      </div>
                      {call.machine_type && (
                        <p className="text-sm text-slate-600">
                          <span className="font-medium">Machine:</span> {call.machine_type}
                        </p>
                      )}
                      {call.description && (
                        <p className="text-sm text-slate-700">{call.description}</p>
                      )}
                      {call.assigned_to && (
                        <p className="text-sm text-slate-600">
                          <span className="font-medium">Assigned to:</span> {
                            allUsers.find(u => u.email === call.assigned_to)?.full_name || call.assigned_to
                          }
                        </p>
                      )}
                      <div className="flex gap-2 pt-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(call)}
                          className="flex-1"
                        >
                          <Edit className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                        {canEdit && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(call)}
                            className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            Delete
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="shadow-lg border-slate-200">
                <CardContent className="p-12 text-center">
                  <Wrench className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No Active Building Calls</h3>
                  <p className="text-slate-600">
                    Everything looks good! Create a new call if maintenance is needed.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="history">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
              </div>
            ) : historyCalls.length > 0 ? (
              <div className="space-y-4">
                {historyCalls.map(call => (
                  <Card key={call.id} className="shadow-sm border-slate-200 bg-slate-50">
                    <CardContent className="p-4 flex items-start gap-4">
                      <CheckCircle2 className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <h4 className="font-semibold text-slate-900">{call.title}</h4>
                          {getStatusBadge(call.status)}
                        </div>
                        {call.machine_type && (
                          <p className="text-sm text-slate-600 mt-1 font-medium">Machine: {call.machine_type}</p>
                        )}
                        <p className="text-sm text-slate-600 mt-1">{call.description}</p>
                        <div className="flex flex-wrap gap-4 mt-2 text-xs text-slate-500">
                          <span>Created: {format(new Date(call.created_date), "MMM d, yyyy")}</span>
                          {call.completed_date && (
                            <span>Completed: {format(new Date(call.completed_date), "MMM d, yyyy")}</span>
                          )}
                          {call.assigned_to && (
                            <span>Assigned: {allUsers.find(u => u.email === call.assigned_to)?.full_name || call.assigned_to}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(call)}
                          className="h-8 w-8"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        {canEdit && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(call)}
                            className="h-8 w-8 text-red-600"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="shadow-lg border-slate-200">
                <CardContent className="p-12 text-center">
                  <History className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No History</h3>
                  <p className="text-slate-600">Completed building maintenance calls will appear here</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}