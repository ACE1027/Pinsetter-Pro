import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserCircle, Building2 } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";

const positionHierarchy = [
  { value: "general_manager", label: "General Manager", level: 1 },
  { value: "service_manager", label: "Service Manager", level: 2 },
  { value: "assistant_manager", label: "Assistant Manager", level: 3 },
  { value: "senior_mechanic", label: "Senior Mechanic", level: 4 },
  { value: "lead_mechanic", label: "Lead Mechanic", level: 5 },
  { value: "mechanic", label: "Mechanic", level: 6 },
  { value: "mechanic_apprentice", label: "Mechanic Apprentice", level: 7 },
  { value: "front_desk_supervisor", label: "Front Desk Supervisor", level: 8 },
  { value: "front_desk_staff", label: "Front Desk Staff", level: 9 },
];

export default function CompleteProfile() {
  const navigate = useNavigate();
  const { theme } = useTheme();
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    position: "",
    department: "",
    bowling_alley_id: "",
  });

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      // Pre-fill existing data
      setFormData({
        full_name: u.full_name || "",
        position: u.position || "",
        department: u.department || "",
        bowling_alley_id: u.bowling_alley_id || "",
      });
    }).catch(() => {});
  }, []);

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      toast.success("Profile completed successfully!");
      navigate(createPageUrl("Dashboard"));
    },
  });

  const handleChange = (field, value) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-set department based on position
      if (field === 'position') {
        if (value.includes('manager')) {
          newData.department = 'manager';
        } else if (value.includes('mechanic')) {
          newData.department = 'mechanic';
        } else if (value.includes('front_desk')) {
          newData.department = 'front_desk';
        }
      }
      
      return newData;
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.full_name || !formData.position || !formData.bowling_alley_id) {
      toast.error("Please fill out all required fields");
      return;
    }
    
    updateProfileMutation.mutate(formData);
  };

  return (
    <div className={`min-h-screen ${theme.bg} flex items-center justify-center p-6`}>
      <Card className="w-full max-w-2xl shadow-xl border-slate-200">
        <CardHeader className="border-b border-slate-200 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <UserCircle className="w-7 h-7" />
            </div>
            <div>
              <CardTitle className="text-2xl">Complete Your Profile</CardTitle>
              <p className="text-blue-100 text-sm mt-1">Tell us about yourself to get started</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                <strong>Welcome to PinSetter Pro!</strong> Please complete your profile to access the system.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="full_name">Full Name *</Label>
              <Input
                id="full_name"
                value={formData.full_name}
                onChange={(e) => handleChange('full_name', e.target.value)}
                placeholder="Enter your full name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bowling_alley_id">Your Location *</Label>
              <Select 
                value={formData.bowling_alley_id} 
                onValueChange={(value) => handleChange('bowling_alley_id', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select your bowling alley location" />
                </SelectTrigger>
                <SelectContent>
                  {locations.filter(l => l.active !== false).map(location => (
                    <SelectItem key={location.id} value={location.id}>
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-slate-500" />
                        <span>{location.name}</span>
                        {location.city && <span className="text-slate-500">- {location.city}</span>}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="position">Your Position *</Label>
              <Select 
                value={formData.position} 
                onValueChange={(value) => handleChange('position', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select your job position" />
                </SelectTrigger>
                <SelectContent>
                  {positionHierarchy.map(pos => (
                    <SelectItem key={pos.value} value={pos.value}>
                      {pos.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <p className="text-sm text-slate-600">
                <strong>Email:</strong> {user?.email}
              </p>
            </div>

            <Button
              type="submit"
              disabled={updateProfileMutation.isPending}
              className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6"
            >
              {updateProfileMutation.isPending ? "Saving..." : "Complete Profile & Get Started"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}