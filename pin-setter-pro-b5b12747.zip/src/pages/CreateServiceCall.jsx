import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { useOfflineSync } from "@/components/offline/OfflineManager";
import MobileServiceCallForm from "@/components/mobile/MobileServiceCallForm";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "@/components/ThemeContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Save, Info, Mic, MicOff } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import AttachmentUploader from "@/components/attachments/AttachmentUploader";
import { getTemplateForMachine } from "@/components/service/ServiceCallTemplates";
import { playSound, SOUND_TYPES } from "@/components/sounds/SoundManager";

const PIN_NUMBERS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];

export default function CreateServiceCall() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const { isOnline, queueUpdate } = useOfflineSync();
  const [isListening, setIsListening] = useState(false);

  // Read URL parameters for pre-filling from QR code
  const urlParams = new URLSearchParams(window.location.search);
  const prefillLocationId = urlParams.get('bowling_alley_id');
  const prefillLaneNumber = urlParams.get('lane_number');

  const [formData, setFormData] = useState({
    bowling_alley_id: prefillLocationId || "",
    machine_type: "",
    issue_type: "",
    re_spot_pins: [],
    add_pins: [],
    ball_return_lanes: [],
    custom_issue: "",
    description_category: "",
    subcategory_value: "",
    respot_pins: [],
    additional_description: "",
    priority: "high",
    lane_number: prefillLaneNumber || "",
    assigned_to: "",
    attachments: []
  });

  const [currentTemplate, setCurrentTemplate] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      // Auto-select user's bowling alley if they have one (only if not prefilled from QR)
      if (u.bowling_alley_id && !prefillLocationId) {
        setFormData((prev) => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});

    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [prefillLocationId]);

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const { data: allMechanics = [] } = useQuery({
    queryKey: ['mechanics'],
    queryFn: async () => {
      const users = await base44.entities.User.list();
      return users.filter((u) => u.department === 'mechanic' || u.department === 'manager' || u.role === 'admin');
    },
    initialData: []
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ['schedules', formData.bowling_alley_id],
    queryFn: async () => {
      if (!formData.bowling_alley_id) return [];
      const allSchedules = await base44.entities.UserSchedule.list();
      const today = new Date().toISOString().split('T')[0];
      return allSchedules.filter((s) =>
      s.bowling_alley_id === formData.bowling_alley_id &&
      s.date === today
      );
    },
    enabled: !!formData.bowling_alley_id,
    initialData: []
  });

  // Filter mechanics by selected location
  const mechanics = allMechanics.filter((m) =>
  m.bowling_alley_id === formData.bowling_alley_id || m.role === 'admin'
  );

  // Find mechanic currently on duty
  const findOnDutyMechanic = () => {
    if (!formData.bowling_alley_id || schedules.length === 0) return null;

    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const onDutySchedule = schedules.find((s) => {
      if (s.shift_start <= currentTime && s.shift_end >= currentTime) {
        const mechanic = allMechanics.find((m) => m.email === s.user_email);
        return mechanic && (mechanic.department === 'mechanic' || mechanic.department === 'manager');
      }
      return false;
    });

    return onDutySchedule?.user_email || null;
  };



  const handleAttachmentsChange = (newAttachments) => {
    setFormData((prev) => ({ ...prev, attachments: newAttachments }));
  };

  const createMutation = useMutation({
    mutationFn: async (data) => {
      // Build the title based on issue type
      const template = getTemplateForMachine(data.machine_type);
      let title = "";
      if (data.issue_type === "re_spot" && data.re_spot_pins.length > 0) {
        title = `Re-Spot - Pins ${data.re_spot_pins.join(", ")}`;
      } else if (data.issue_type === "add" && data.add_pins.length > 0) {
        title = `Add - Pins ${data.add_pins.join(", ")}`;
      } else if (data.issue_type === "ball_return" && data.ball_return_lanes.length > 0) {
        title = `Ball Return - Lanes ${data.ball_return_lanes.join(", ")}`;
      } else if (data.issue_type === "other") {
        title = data.custom_issue || "Other Issue";
      } else {
        const issueLabel = template?.issueTypes?.find((t) => t.value === data.issue_type)?.label || data.issue_type;
        title = issueLabel;
      }

      // Build description from dropdowns and additional text
      let description = "";

      if (data.description_category && data.subcategory_value) {
        const template = getTemplateForMachine(data.machine_type);
        const categoryLabel = template?.descriptionCategories?.find(c => c.value === data.description_category)?.label || "";
        const subcategoryLabel = template?.subcategories?.[data.description_category]?.find(s => s.value === data.subcategory_value)?.label || "";
        description = `${categoryLabel} - ${subcategoryLabel}`;
      } else if (data.description_category === "respots" && data.respot_pins.length > 0) {
        description = `Re-Spots - Pins ${data.respot_pins.join(", ")}`;
      }

      if (data.additional_description) {
        description = description ? `${description}\n\n${data.additional_description}` : data.additional_description;
      }



      // Capture device timestamp
      const deviceTimestamp = new Date().toISOString();

      // Create service call with machine_type and device timestamp
      const serviceCallData = {
        bowling_alley_id: data.bowling_alley_id,
        machine_type: data.machine_type,
        title: title,
        description: description,
        category: "lane_machine",
        priority: data.priority,
        lane_number: data.lane_number,
        assigned_to: data.assigned_to || null,
        device_timestamp: deviceTimestamp,
        attachments: data.attachments || []
      };

      return base44.entities.ServiceCall.create(serviceCallData);
    },
    onSuccess: async (createdCall) => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });

      // Play sound based on user preferences
      try {
        const currentUser = await base44.auth.me();
        playSound(SOUND_TYPES.SERVICE_CALL_CREATED, currentUser.sound_preferences);
      } catch (error) {
        // Fallback to playing sound if user preferences not available
        playSound(SOUND_TYPES.SERVICE_CALL_CREATED, { service_call_created: true });
      }

      // Trigger notification
      const notification = {
        id: Date.now().toString(),
        title: 'New Service Call Created',
        message: `${createdCall.title} - Lane ${createdCall.lane_number}`,
        timestamp: new Date().toISOString(),
        read: false,
        serviceCallId: createdCall.id
      };
      window.dispatchEvent(new CustomEvent('newNotification', { detail: notification }));

      navigate(createPageUrl("ServiceCalls"));
    }
  });

  const handleSubmit = (e) => {
    if (e && e.preventDefault) e.preventDefault();

    if (!isOnline) {
      // Queue for offline sync
      const deviceTimestamp = new Date().toISOString();
      queueUpdate('create_service_call', { ...formData, device_timestamp: deviceTimestamp });
      toast.success('Service call saved. Will sync when online.');
      navigate(createPageUrl("ServiceCalls"));
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => {
      const newData = { ...prev, [field]: value };

      // Clear lane number, ball return lanes, and auto-assign on-duty mechanic when location changes
      if (field === 'bowling_alley_id' && value !== prev.bowling_alley_id) {
        newData.lane_number = "";
        newData.ball_return_lanes = [];
        newData.assigned_to = "";

        // Auto-assign on-duty mechanic after state updates
        setTimeout(() => {
          const onDutyMechanic = findOnDutyMechanic();
          if (onDutyMechanic) {
            setFormData((current) => ({ ...current, assigned_to: onDutyMechanic }));
          }
        }, 100);
      }

      // Clear re-spot pins if issue type changes from re_spot
      if (field === 'issue_type' && value !== 're_spot') {
        newData.re_spot_pins = [];
      }

      // Clear add pins if issue type changes from add
      if (field === 'issue_type' && value !== 'add') {
        newData.add_pins = [];
      }

      // Clear ball return lanes if issue type changes from ball_return
      if (field === 'issue_type' && value !== 'ball_return') {
        newData.ball_return_lanes = [];
      }

      // Clear custom issue if issue type changes from other
      if (field === 'issue_type' && value !== 'other') {
        newData.custom_issue = "";
      }

      // Clear subcategory fields when description category changes
      if (field === 'description_category') {
        newData.subcategory_value = "";
        newData.respot_pins = [];
      }

      // Clear issue-related fields when machine type changes
      if (field === 'machine_type') {
        newData.issue_type = "";
        newData.description_category = "";
        newData.subcategory_value = "";
        newData.re_spot_pins = [];
        newData.add_pins = [];
        newData.ball_return_lanes = [];
        newData.custom_issue = "";
        newData.respot_pins = [];
      }

      return newData;
    });
  };

  const handlePinToggle = (pin) => {
    setFormData((prev) => {
      const pins = [...prev.re_spot_pins];
      const index = pins.indexOf(pin);
      if (index > -1) {
        pins.splice(index, 1);
      } else {
        pins.push(pin);
        pins.sort((a, b) => parseInt(a) - parseInt(b));
      }
      return { ...prev, re_spot_pins: pins };
    });
  };

  const handleAddPinToggle = (pin) => {
    setFormData((prev) => {
      const pins = [...prev.add_pins];
      const index = pins.indexOf(pin);
      if (index > -1) {
        pins.splice(index, 1);
      } else {
        pins.push(pin);
        pins.sort((a, b) => parseInt(a) - parseInt(b));
      }
      return { ...prev, add_pins: pins };
    });
  };

  const handleRespotPinToggle = (pin) => {
    setFormData((prev) => {
      const pins = [...prev.respot_pins];
      const index = pins.indexOf(pin);
      if (index > -1) {
        pins.splice(index, 1);
      } else {
        pins.push(pin);
        pins.sort((a, b) => parseInt(a) - parseInt(b));
      }
      return { ...prev, respot_pins: pins };
    });
  };

  const handleBallReturnLaneToggle = (lane) => {
    setFormData((prev) => {
      const lanes = [...prev.ball_return_lanes];
      const index = lanes.indexOf(lane);
      if (index > -1) {
        lanes.splice(index, 1);
      } else {
        lanes.push(lane);
        lanes.sort((a, b) => parseInt(a) - parseInt(b));
      }
      return { ...prev, ball_return_lanes: lanes };
    });
  };

  const selectedLocation = locations.find((l) => l.id === formData.bowling_alley_id);

  // Generate lane options based on selected location
  const laneOptions = selectedLocation?.total_lanes > 0 ?
  Array.from({ length: selectedLocation.total_lanes }, (_, i) => (i + 1).toString()) :
  [];

  // Get available machine types from selected location
  const availableMachineTypes = selectedLocation?.machine_types || [];

  // Redirect to GSX Call Sheet if location only has GS-X machines
  useEffect(() => {
    if (selectedLocation && availableMachineTypes.length === 1 && availableMachineTypes[0] === "GS-X Machine") {
      navigate(createPageUrl("GSXCallSheet") + `?bowling_alley_id=${selectedLocation.id}`);
    }
  }, [selectedLocation, availableMachineTypes, navigate]);

  // Update template when machine type changes
  useEffect(() => {
    if (formData.machine_type) {
      setCurrentTemplate(getTemplateForMachine(formData.machine_type));
    } else {
      setCurrentTemplate(null);
    }
  }, [formData.machine_type]);

  const handleFormChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const parseVoiceInput = (transcript) => {
    const text = transcript.toLowerCase();
    const updates = {};
    let foundStructuredData = false;

    // Parse location
    const locationMatch = locations.find((l) =>
    text.includes(l.name.toLowerCase()) ||
    l.city && text.includes(l.city.toLowerCase())
    );
    if (locationMatch) {
      updates.bowling_alley_id = locationMatch.id;
      foundStructuredData = true;
    }

    // Parse lane number - handle multiple formats including word numbers
    const numberWords = {
      'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
      'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10',
      'eleven': '11', 'twelve': '12', 'thirteen': '13', 'fourteen': '14', 'fifteen': '15',
      'sixteen': '16', 'seventeen': '17', 'eighteen': '18', 'nineteen': '19', 'twenty': '20',
      'thirty': '30', 'forty': '40', 'fifty': '50', 'sixty': '60'
    };
    
    let laneMatch = text.match(/lane[s]?\s*(\d+)/i) || text.match(/(\d+)\s*lane[s]?/i);
    if (laneMatch) {
      updates.lane_number = laneMatch[1];
      foundStructuredData = true;
    } else {
      // Try matching word numbers
      const wordPattern = /lane[s]?\s*(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty)/i;
      const wordMatch = text.match(wordPattern);
      if (wordMatch) {
        updates.lane_number = numberWords[wordMatch[1].toLowerCase()];
        foundStructuredData = true;
      }
    }

    // Parse priority
    if (text.includes('urgent') || text.includes('down')) {
      updates.priority = 'urgent';
      foundStructuredData = true;
    } else if (text.includes('high priority') || text.includes('high')) {
      updates.priority = 'high';
      foundStructuredData = true;
    } else if (text.includes('preventative') || text.includes('maintenance')) {
      updates.priority = 'preventative_maintenance';
      foundStructuredData = true;
    }

    // Parse issue types
    if (text.includes('dead wood') || text.includes('deadwood')) {
      updates.issue_type = 'dead_wood';
      foundStructuredData = true;
    } else if (text.includes('ball return')) {
      updates.issue_type = 'ball_return';
      foundStructuredData = true;
    } else if (text.includes('180') || text.includes('one eighty') || text.includes('one-eighty')) {
      updates.issue_type = '180_stop';
      foundStructuredData = true;
    } else if (text.includes('rake down') || text.includes('rake')) {
      updates.issue_type = 'rake_down';
      foundStructuredData = true;
    } else if (text.includes('out of range')) {
      updates.issue_type = 'out_of_range';
      foundStructuredData = true;
    } else if (text.includes('re spot') || text.includes('respot') || text.includes('re-spot')) {
      updates.issue_type = 're_spot';
      foundStructuredData = true;
    } else if (text.includes('add pin') || text.includes('add pins')) {
      updates.issue_type = 'add';
      foundStructuredData = true;
    } else if (text.includes('fail to trigger') || text.includes('failed to trigger')) {
      updates.issue_type = 'fail_to_trigger';
      foundStructuredData = true;
    } else if (text.includes('full rack')) {
      updates.issue_type = 'full_rack';
      foundStructuredData = true;
    } else if (text.includes('90 stop') || text.includes('ninety stop')) {
      updates.issue_type = '90_stop';
      foundStructuredData = true;
    } else if (text.includes('270 stop')) {
      updates.issue_type = '270_stop';
      foundStructuredData = true;
    } else if (text.includes('banana tree')) {
      updates.issue_type = 'banana_tree';
      foundStructuredData = true;
    } else if (text.includes('continuous cycle') || text.includes('con cycle')) {
      updates.issue_type = 'continuous_cycle';
      foundStructuredData = true;
    } else if (text.includes('blackout') || text.includes('black out')) {
      updates.issue_type = 'black_out';
      foundStructuredData = true;
    } else if (text.includes('ball damage')) {
      updates.issue_type = 'ball_damage';
      foundStructuredData = true;
    }

    // Parse pins (1-10)
    const pinMatches = text.match(/pin[s]?\s*(\d+(?:\s*(?:and|,)\s*\d+)*)/gi);
    if (pinMatches && (updates.issue_type === 're_spot' || text.includes('respot') || text.includes('re spot'))) {
      const pins = [];
      pinMatches.forEach((match) => {
        const numbers = match.match(/\d+/g);
        if (numbers) {
          numbers.forEach((num) => {
            if (num >= '1' && num <= '10' && !pins.includes(num)) {
              pins.push(num);
            }
          });
        }
      });
      if (pins.length > 0) {
        updates.re_spot_pins = pins.sort((a, b) => parseInt(a) - parseInt(b));
        foundStructuredData = true;
      }
    }

    // Parse mechanic assignment
    const mechanicMatch = allMechanics.find((m) =>
    text.includes(m.full_name?.toLowerCase()) ||
    text.includes(m.email?.toLowerCase())
    );
    if (mechanicMatch) {
      updates.assigned_to = mechanicMatch.email;
      foundStructuredData = true;
    }

    // Parse description categories
    if (text.includes('ball call')) {
      updates.description_category = 'ball_calls';
      foundStructuredData = true;

      // Parse specific ball call locations
      BALL_CALL_LOCATIONS.forEach((loc) => {
        if (text.includes(loc.label.toLowerCase())) {
          updates.ball_call_location = loc.value;
        }
      });
    } else if (text.includes('deck jam') || text.includes('blackout')) {
      updates.description_category = 'deck_jams';
      foundStructuredData = true;

      DECK_JAMS_BLACKOUTS.forEach((issue) => {
        if (text.includes(issue.label.toLowerCase())) {
          updates.deck_jam_issue = issue.value;
        }
      });
    } else if (text.includes('con cycle') || text.includes('continuous cycle')) {
      updates.description_category = 'con_cycles';
      foundStructuredData = true;

      CON_CYCLES.forEach((issue) => {
        if (text.includes(issue.label.toLowerCase())) {
          updates.con_cycle_issue = issue.value;
        }
      });
    } else if (text.includes('miscellaneous') || text.includes('misc')) {
      updates.description_category = 'miscellaneous';
      foundStructuredData = true;

      MISCELLANEOUS.forEach((issue) => {
        if (text.includes(issue.label.toLowerCase())) {
          updates.misc_issue = issue.value;
        }
      });
    }

    // Only add to additional description if no structured data was found
    if (!foundStructuredData) {
      updates.additional_description = (formData.additional_description ? formData.additional_description + '\n' : '') + transcript;
    }

    return updates;
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      toast.error('Voice input not supported in this browser');
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      toast.info('Listening... Speak now');
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      toast.success(`Heard: "${transcript}"`);

      const updates = parseVoiceInput(transcript);

      setFormData((prev) => {
        const newData = { ...prev, ...updates };

        // If location changed, clear lane and ball_return_lanes UNLESS they were set in the updates
        if (updates.bowling_alley_id && updates.bowling_alley_id !== prev.bowling_alley_id) {
          if (!updates.lane_number) {
            newData.lane_number = "";
          }
          if (!updates.ball_return_lanes) {
            newData.ball_return_lanes = [];
          }
        }

        // Ensure lane_number is always preserved from voice input
        if (updates.lane_number) {
          newData.lane_number = updates.lane_number;
        }
        // Auto-populate lane_number from ball_return_lanes if no explicit lane specified
        else if (updates.ball_return_lanes && updates.ball_return_lanes.length > 0 && !newData.lane_number) {
          newData.lane_number = updates.ball_return_lanes[0];
        }

        // Auto-assign on-duty mechanic if location changed and not explicitly assigned
        if (updates.bowling_alley_id && updates.bowling_alley_id !== prev.bowling_alley_id && !updates.assigned_to) {
          newData.assigned_to = "";
          // Queue mechanic assignment after state settles
          setTimeout(() => {
            const onDutyMechanic = findOnDutyMechanic();
            if (onDutyMechanic) {
              setFormData((current) => ({ ...current, assigned_to: onDutyMechanic }));
            }
          }, 100);
        }

        return newData;
      });
    };

    recognition.onerror = (event) => {
      setIsListening(false);
      if (event.error !== 'no-speech') {
        toast.error(`Voice input error: ${event.error}`);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  if (isMobile) {
    return (
      <MobileServiceCallForm
        locations={locations}
        mechanics={allMechanics}
        formData={formData}
        onChange={handleFormChange}
        onSubmit={handleSubmit}
        isSubmitting={createMutation.isPending} />);


  }

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-3xl mx-auto w-full">
        <div className="flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                navigate(createPageUrl("Dashboard"));
              }}>

              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>New Service Call</h1>
              <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Create a new pinsetter repair request</p>
            </div>
          </div>
          
          {/* GS-X Call Sheet Link */}
          {selectedLocation && selectedLocation.machine_types?.includes("GS-X Machine") && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => navigate(createPageUrl("GSXCallSheet"))}
                className="text-sm"
              >
                Use GS-X Call Sheet
              </Button>
            </div>
          )}
          <div className="flex gap-2">
            <Button
              variant={isListening ? "destructive" : "outline"}
              onClick={handleVoiceInput}
              disabled={isListening}
              className={`${isListening ? 'animate-pulse' : ''}`}>

              {isListening ?
              <>
                  <MicOff className="w-4 h-4 mr-2" />
                  Listening...
                </> :

              <>
                  <Mic className="w-4 h-4 mr-2" />
                  Voice Input
                </>
              }
            </Button>
          </div>
        </div>



        {('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) &&
        <Alert className={`mb-6 ${isDarkMode ? 'bg-blue-900/20 border-blue-800' : 'bg-blue-50 border-blue-200'}`}>
            <Info className="w-4 h-4" />
            <AlertDescription className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>
              <strong>Voice Input Tip:</strong> Try saying things like "Lane 5 dead wood urgent" or "Ball return lanes 10 through 15 high priority"
            </AlertDescription>
          </Alert>
        }

        <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
          <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
            <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Service Call Details</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="bowling_alley_id" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Bowling Alley Location *</Label>
                <Select value={formData.bowling_alley_id} onValueChange={(value) => handleChange('bowling_alley_id', value)} required>
                  <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.filter((l) => l.active !== false).map((location) =>
                    <SelectItem key={location.id} value={location.id}>
                        {location.name}
                        {location.city && ` - ${location.city}`}
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              {availableMachineTypes.length > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="machine_type" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Machine Type *</Label>
                  <Select value={formData.machine_type} onValueChange={(value) => handleChange('machine_type', value)} required>
                    <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                      <SelectValue placeholder="Select machine type" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableMachineTypes.map((type) =>
                      <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {currentTemplate && (
                <div className="space-y-2">
                  <Label htmlFor="issue_type" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Issue Type *</Label>
                  <Select value={formData.issue_type} onValueChange={(value) => handleChange('issue_type', value)} required>
                    <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                      <SelectValue placeholder="Select issue type" />
                    </SelectTrigger>
                    <SelectContent>
                      {currentTemplate.issueTypes.map((issue) =>
                      <SelectItem key={issue.value} value={issue.value}>
                          {issue.label}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <AnimatePresence mode="wait">
                {formData.issue_type === 're_spot' &&
                <motion.div
                  key="re_spot"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-2 overflow-hidden"
                >
                  <Label>Select Pins to Re-spot *</Label>
                  <div className="grid grid-cols-5 gap-3 p-4 bg-slate-50 rounded-lg">
                    {PIN_NUMBERS.map((pin) =>
                  <div key={pin} className="flex items-center space-x-2">
                        <Checkbox
                      id={`pin-${pin}`}
                      checked={formData.re_spot_pins.includes(pin)}
                      onCheckedChange={() => handlePinToggle(pin)} />

                        <Label
                      htmlFor={`pin-${pin}`}
                      className="text-sm font-medium cursor-pointer">

                          Pin {pin}
                        </Label>
                      </div>
                  )}
                  </div>
                  {formData.re_spot_pins.length > 0 &&
                <p className="text-sm text-slate-600">
                      Selected: {formData.re_spot_pins.join(", ")}
                    </p>
                }
                </motion.div>
                }

                {formData.issue_type === 'add' &&
                <motion.div
                  key="add"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-2 overflow-hidden"
                >
                  <Label>Select Pins to Add *</Label>
                  <div className="grid grid-cols-5 gap-3 p-4 bg-purple-50 rounded-lg border-2 border-purple-300">
                    {PIN_NUMBERS.map((pin) =>
                  <div key={pin} className="flex items-center space-x-2">
                        <Checkbox
                      id={`add-pin-${pin}`}
                      checked={formData.add_pins.includes(pin)}
                      onCheckedChange={() => handleAddPinToggle(pin)} />

                        <Label
                      htmlFor={`add-pin-${pin}`}
                      className="text-sm font-medium cursor-pointer">

                          Pin {pin}
                        </Label>
                      </div>
                  )}
                  </div>
                  {formData.add_pins.length > 0 &&
                <p className="text-sm text-purple-800 font-medium">
                      Selected: Pins {formData.add_pins.join(", ")}
                    </p>
                }
                </motion.div>
                }

                {formData.issue_type === 'ball_return' &&
                <motion.div
                  key="ball_return"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-2 overflow-hidden"
                >
                  <Label>Select Lanes that Need Ball Return *</Label>
                  {laneOptions.length > 0 ? (
                    <>
                      <div className="grid grid-cols-5 gap-3 p-4 bg-green-50 rounded-lg border-2 border-green-300">
                        {laneOptions.map((lane) =>
                      <div key={lane} className="flex items-center space-x-2">
                            <Checkbox
                          id={`ball-return-lane-${lane}`}
                          checked={formData.ball_return_lanes.includes(lane)}
                          onCheckedChange={() => handleBallReturnLaneToggle(lane)} />

                            <Label
                          htmlFor={`ball-return-lane-${lane}`}
                          className="text-sm font-medium cursor-pointer">

                              Lane {lane}
                            </Label>
                          </div>
                      )}
                      </div>
                      {formData.ball_return_lanes.length > 0 &&
                    <p className="text-sm text-green-800 font-medium">
                          Selected: Lanes {formData.ball_return_lanes.join(", ")}
                        </p>
                    }
                    </>
                  ) : (
                    <p className="text-sm text-slate-500 p-4 bg-slate-50 rounded-lg border-2 border-slate-200">
                      Please select a location first to see available lanes
                    </p>
                  )}
                </motion.div>
                }

                {formData.issue_type === 'other' &&
                <motion.div
                  key="other"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-2 overflow-hidden"
                >
                  <Label htmlFor="custom_issue">Describe the Issue *</Label>
                  <Input
                  id="custom_issue"
                  placeholder="Brief description of the issue"
                  value={formData.custom_issue}
                  onChange={(e) => handleChange('custom_issue', e.target.value)}
                  required />

                </motion.div>
                }
              </AnimatePresence>

              <div className="space-y-2">
                <Label htmlFor="assigned_to" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Assign To (Optional)</Label>
                <Select
                  value={formData.assigned_to}
                  onValueChange={(value) => handleChange('assigned_to', value)}
                  disabled={!formData.bowling_alley_id}>

                  <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                    <SelectValue placeholder={formData.bowling_alley_id ? "Unassigned" : "Select location first"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Unassigned</SelectItem>
                    {mechanics.map((mechanic) =>
                    <SelectItem key={mechanic.id} value={mechanic.email}>
                        {mechanic.display_name || mechanic.full_name || mechanic.email}
                        {mechanic.role === 'admin' && ' (Admin)'}
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
                {formData.bowling_alley_id && mechanics.length === 0 &&
                <p className="text-xs text-slate-500">No mechanics assigned to this location</p>
                }
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="lane_number" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Lane Number *</Label>
                  {laneOptions.length > 0 ?
                  <Select
                    value={formData.lane_number}
                    onValueChange={(value) => handleChange('lane_number', value)}
                    required>

                      <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                        <SelectValue placeholder="Select lane" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px]">
                        {laneOptions.map((lane) =>
                      <SelectItem key={lane} value={lane}>
                            Lane {lane}
                          </SelectItem>
                      )}
                      </SelectContent>
                    </Select> :

                  <Input
                    id="lane_number"
                    placeholder={formData.bowling_alley_id ? "Enter lane number" : "Select a location first"}
                    value={formData.lane_number}
                    onChange={(e) => handleChange('lane_number', e.target.value)}
                    disabled={!formData.bowling_alley_id}
                    required />

                  }
                  {selectedLocation?.total_lanes > 0 &&
                  <p className="text-xs text-slate-500">
                      This location has {selectedLocation.total_lanes} lanes
                    </p>
                  }
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Priority *</Label>
                  <Select value={formData.priority} onValueChange={(value) => handleChange('priority', value)} required>
                    <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="preventative_maintenance">Preventative Maintenance</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent - Lane Down</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Description categories based on machine template */}
              {currentTemplate && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="description_category" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Description Category (Optional)</Label>
                    <Select
                      value={formData.description_category}
                      onValueChange={(value) => handleChange('description_category', value)}>
                      <SelectTrigger className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1`}>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>None</SelectItem>
                        {currentTemplate.descriptionCategories.map((cat) =>
                        <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <AnimatePresence mode="wait">
                    {formData.description_category === 'respots' ?
                    <motion.div
                      key="respots"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="space-y-2 pl-4 border-l-2 border-teal-300 bg-teal-50 p-4 rounded-r-lg">
                        <Label>Select Pins to Re-spot *</Label>
                        <div className="grid grid-cols-5 gap-3 p-4 bg-white rounded-lg">
                          {PIN_NUMBERS.map((pin) =>
                          <div key={pin} className="flex items-center space-x-2">
                              <Checkbox
                            id={`respot-pin-${pin}`}
                            checked={formData.respot_pins.includes(pin)}
                            onCheckedChange={() => handleRespotPinToggle(pin)} />
                              <Label
                            htmlFor={`respot-pin-${pin}`}
                            className="text-sm font-medium cursor-pointer">
                                Pin {pin}
                              </Label>
                            </div>
                        )}
                        </div>
                        {formData.respot_pins.length > 0 &&
                      <p className="text-sm text-teal-800">
                            Selected: {formData.respot_pins.join(", ")}
                          </p>
                      }
                      </div>
                    </motion.div> :

                    formData.description_category && currentTemplate.subcategories[formData.description_category] ?
                    <motion.div
                      key={formData.description_category}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="space-y-2 pl-4 border-l-2 border-blue-300 bg-blue-50 p-4 rounded-r-lg">
                        <Label htmlFor="subcategory">Specific Issue *</Label>
                        <Select
                          value={formData.subcategory_value}
                          onValueChange={(value) => handleChange('subcategory_value', value)}
                          required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select specific issue" />
                          </SelectTrigger>
                          <SelectContent>
                            {currentTemplate.subcategories[formData.description_category].map((subcat) =>
                            <SelectItem key={subcat.value} value={subcat.value}>
                                {subcat.label}
                              </SelectItem>
                          )}
                          </SelectContent>
                        </Select>
                      </div>
                    </motion.div> : null
                    }
                  </AnimatePresence>
                </div>
              )}

                <div className="space-y-2">
                  <Label htmlFor="additional_description" className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70`}>Additional Details</Label>
                  <Textarea
                    id="additional_description"
                    placeholder="Provide additional information about the issue..."
                    value={formData.additional_description}
                    onChange={(e) => handleChange('additional_description', e.target.value)}
                    rows={5} className={`bg-transparent ${isDarkMode ? 'text-white' : 'text-black'} px-3 py-2 text-base rounded-md flex min-h-[60px] w-full border border-input shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm`} />

                </div>

              {/* Photo/Video Attachments with Tags */}
              <div className="space-y-2">
                <Label className={`${isDarkMode ? 'text-white' : 'text-black'} text-sm font-medium leading-none`}>Photos & Videos</Label>
                <AttachmentUploader 
                  attachments={formData.attachments}
                  onChange={handleAttachmentsChange}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate(createPageUrl("Dashboard"))}
                  className="flex-1">

                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700">

                  <Save className="w-4 h-4 mr-2" />
                  {createMutation.isPending ? "Creating..." : "Create Service Call"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>);

}