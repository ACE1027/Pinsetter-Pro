import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Star, Send, CheckCircle } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

export default function CustomerFeedback() {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    bowling_alley_id: "",
    customer_name: "",
    customer_email: "",
    customer_phone: "",
    rating: 0,
    feedback_type: "",
    feedback_text: ""
  });

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u.bowling_alley_id) {
        setFormData(prev => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
      if (u.full_name) {
        setFormData(prev => ({ ...prev, customer_name: u.full_name }));
      }
      if (u.email) {
        setFormData(prev => ({ ...prev, customer_email: u.email }));
      }
    }).catch(() => {});
  }, []);

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const submitMutation = useMutation({
    mutationFn: (data) => base44.entities.CustomerFeedback.create(data),
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Thank you for your feedback!");
    },
    onError: () => {
      toast.error("Failed to submit feedback. Please try again.");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.rating === 0) {
      toast.error("Please select a rating");
      return;
    }
    submitMutation.mutate(formData);
  };

  if (submitted) {
    return (
      <div className={`min-h-screen flex items-center justify-center p-4 ${theme.bg}`}>
        <Card className={`max-w-md w-full text-center ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardContent className="pt-12 pb-12">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className={`text-2xl font-bold mb-2 ${theme.text}`}>Thank You!</h2>
            <p className={`mb-6 ${theme.textSecondary}`}>Your feedback has been submitted successfully.</p>
            <Button onClick={() => navigate(createPageUrl("Dashboard"))} className="bg-blue-600 hover:bg-blue-700">
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className={`min-h-screen p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <h1 className={`text-3xl font-bold ${theme.text}`}>Share Your Feedback</h1>
          <p className={`mt-1 ${theme.textSecondary}`}>We'd love to hear about your experience</p>
        </div>

        <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
          <CardHeader>
            <CardTitle className={theme.text}>Tell Us What You Think</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {!user && (
                <div className="space-y-2">
                  <Label htmlFor="bowling_alley_id">Location *</Label>
                  <Select 
                    value={formData.bowling_alley_id} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, bowling_alley_id: value }))}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.map(loc => (
                        <SelectItem key={loc.id} value={loc.id}>{loc.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="customer_name">Your Name *</Label>
                <Input
                  id="customer_name"
                  value={formData.customer_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, customer_name: e.target.value }))}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="customer_email">Email</Label>
                  <Input
                    id="customer_email"
                    type="email"
                    value={formData.customer_email}
                    onChange={(e) => setFormData(prev => ({ ...prev, customer_email: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="customer_phone">Phone</Label>
                  <Input
                    id="customer_phone"
                    type="tel"
                    value={formData.customer_phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, customer_phone: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Overall Rating *</Label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, rating: star }))}
                      className="transition-transform hover:scale-110"
                    >
                      <Star 
                        className={`w-10 h-10 ${star <= formData.rating ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'}`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="feedback_type">Feedback About *</Label>
                <Select 
                  value={formData.feedback_type} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, feedback_type: value }))}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lanes">Lanes</SelectItem>
                    <SelectItem value="service">Service</SelectItem>
                    <SelectItem value="food_beverage">Food & Beverage</SelectItem>
                    <SelectItem value="facilities">Facilities</SelectItem>
                    <SelectItem value="staff">Staff</SelectItem>
                    <SelectItem value="pricing">Pricing</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="feedback_text">Your Feedback *</Label>
                <Textarea
                  id="feedback_text"
                  rows={6}
                  placeholder="Tell us about your experience..."
                  value={formData.feedback_text}
                  onChange={(e) => setFormData(prev => ({ ...prev, feedback_text: e.target.value }))}
                  required
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={submitMutation.isPending}
              >
                <Send className="w-4 h-4 mr-2" />
                {submitMutation.isPending ? "Submitting..." : "Submit Feedback"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}