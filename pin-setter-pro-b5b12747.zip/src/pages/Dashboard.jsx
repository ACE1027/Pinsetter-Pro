import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Wrench, AlertCircle, Clock, CheckCircle2, Plus, Settings, Package } from "lucide-react";
import StatsCard from "../components/dashboard/StatsCard";
import ServiceCallCard from "../components/service/ServiceCallCard";
import { useLocation } from "../components/LocationContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/components/ThemeContext";
import NotificationPanel from "../components/notifications/NotificationPanel";
import MobileQuickActions from "../components/mobile/MobileQuickActions";

const DEFAULT_WIDGETS = {
  showNotifications: true,
  showStats: true,
  showRecentCalls: true,
  showLowStockParts: true,
  showUpcomingMaintenance: true,
};

export default function Dashboard() {
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [widgets, setWidgets] = useState(DEFAULT_WIDGETS);
  const { selectedLocationId } = useLocation();

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u.dashboard_widgets) {
        setWidgets({ ...DEFAULT_WIDGETS, ...u.dashboard_widgets });
      }
    }).catch(() => {});
  }, []);

  const { data: allCalls = [], isLoading } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    initialData: [],
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: [],
  });

  const { data: scheduledMaintenance = [] } = useQuery({
    queryKey: ['scheduledMaintenance'],
    queryFn: () => base44.entities.ScheduledMaintenance.list('-scheduled_date', 5),
    initialData: [],
  });

  const isAdmin = user && user.role === 'admin';

  // Determine which location to show data for
  // Regular users can ONLY see their assigned location
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  // Filter calls - strict location-based access control
  const accessibleCalls = allCalls.filter(call => {
    if (!user) return false;
    
    // Admins can view all if "All Locations" selected
    if (isAdmin && selectedLocationId === 'all') {
      return true;
    }
    
    // All other users (including admins with specific location selected) see only their location's calls
    if (effectiveLocationId && call.bowling_alley_id === effectiveLocationId) {
      return true;
    }
    
    return false;
  });

  const openCalls = accessibleCalls.filter(c => c.status === 'open').length;
  const inProgressCalls = accessibleCalls.filter(c => c.status === 'in_progress').length;
  const urgentCalls = accessibleCalls.filter(c => c.priority === 'urgent' && c.status !== 'completed').length;
  const completedToday = accessibleCalls.filter(c => {
    if (c.status !== 'completed' || !c.completed_date) return false;
    const today = new Date();
    const completed = new Date(c.completed_date);
    return completed.toDateString() === today.toDateString();
  }).length;

  const recentCalls = accessibleCalls.slice(0, 6);

  // Low stock parts
  const lowStockParts = parts.filter(p => 
    p.bowling_alley_id === effectiveLocationId &&
    p.quantity_in_stock > 0 && 
    p.quantity_in_stock <= p.min_quantity && 
    !p.discontinued
  ).slice(0, 5);

  // Upcoming maintenance
  const upcomingMaintenance = scheduledMaintenance.filter(m => 
    m.bowling_alley_id === effectiveLocationId &&
    m.status === 'scheduled'
  ).slice(0, 5);

  return (
    <div className={`min-h-full ${theme.bg}`}>
      <div className="p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4">
          {/* Mobile Quick Actions - Only on small screens */}
          <div className="mb-6 md:hidden">
            <MobileQuickActions user={user} />
          </div>

          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Dashboard</h1>
              <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {(user?.display_name || user?.full_name) ? `Welcome back, ${(user.display_name || user.full_name).split(' ')[0]}` : 'Service Management Overview'}
              </p>
            </div>
            <div className="flex gap-2">
              <Link to={createPageUrl("DashboardSettings")}>
                <Button variant="outline" size="icon">
                  <Settings className="w-4 h-4" />
                </Button>
              </Link>
              <Link to={createPageUrl("CreateServiceCall")}>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  New Service Call
                </Button>
              </Link>
            </div>
          </div>

          {/* Notifications Widget */}
          {widgets.showNotifications && (
            <div className="mb-4">
              <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'} backdrop-blur-sm`}>
                <CardContent className="p-4">
                  <NotificationPanel user={user} compact />
                </CardContent>
              </Card>
            </div>
          )}

          {/* Stats Grid */}
          {widgets.showStats && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
              <StatsCard
                title="Open Calls"
                value={openCalls}
                icon={Wrench}
                bgColor="bg-blue-600"
              />
              <StatsCard
                title="In Progress"
                value={inProgressCalls}
                icon={Clock}
                bgColor="bg-amber-600"
              />
              <StatsCard
                title="Urgent"
                value={urgentCalls}
                icon={AlertCircle}
                bgColor="bg-red-600"
              />
              <StatsCard
                title="Completed Today"
                value={completedToday}
                icon={CheckCircle2}
                bgColor="bg-green-600"
              />
            </div>
          )}

          {/* Low Stock Alerts */}
          {widgets.showLowStockParts && lowStockParts.length > 0 && (
            <Card className={`mb-4 shadow-sm backdrop-blur-sm ${isDarkMode ? 'bg-orange-950/30 border-orange-800' : 'bg-orange-50/80 border-orange-300'}`}>
              <CardHeader className="pb-2 p-4">
                <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-orange-400' : 'text-orange-900'}`}>
                  <Package className="w-4 h-4" />
                  Low Stock Parts
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="space-y-2">
                  {lowStockParts.map(part => (
                    <div key={part.id} className={`flex justify-between items-center p-2 rounded-lg ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                      <div>
                        <p className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : ''}`}>{part.name}</p>
                        <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{part.part_number}</p>
                      </div>
                      <Badge className="bg-orange-100 text-orange-800">
                        {part.quantity_in_stock} left
                      </Badge>
                    </div>
                  ))}
                </div>
                <Link to={createPageUrl("PartsInventory")}>
                  <Button variant="outline" size="sm" className="w-full mt-3">
                    View Inventory
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}

          {/* Upcoming Maintenance */}
          {widgets.showUpcomingMaintenance && upcomingMaintenance.length > 0 && (
            <Card className={`mb-4 shadow-sm backdrop-blur-sm ${isDarkMode ? 'bg-blue-950/30 border-blue-800' : 'bg-blue-50/80 border-blue-300'}`}>
                <CardHeader className="pb-2 p-4">
                  <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-slate-300' : 'text-blue-900'}`}>
                    <Clock className="w-4 h-4" />
                    Upcoming Maintenance
                  </CardTitle>
                </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="space-y-2">
                  {upcomingMaintenance.map(maintenance => (
                    <div key={maintenance.id} className={`flex justify-between items-center p-2 rounded-lg ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                      <div>
                        <p className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : ''}`}>{maintenance.maintenance_type}</p>
                        <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          {maintenance.lane_number && `Lane ${maintenance.lane_number} - `}
                          {new Date(maintenance.scheduled_date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <Link to={createPageUrl("ScheduledMaintenance")}>
                  <Button variant="outline" size="sm" className="w-full mt-3">
                    View Schedule
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}

          {/* Recent Service Calls */}
          {widgets.showRecentCalls && (
            <div className="mb-4">
            <div className="flex justify-between items-center mb-3">
              <h2 className={`text-xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Recent Service Calls</h2>
              <Link to={createPageUrl("ServiceCalls")}>
                <Button variant="outline" size="sm">View All</Button>
              </Link>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {Array(4).fill(0).map((_, i) => (
                  <div key={i} className={`h-48 rounded-lg animate-pulse ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`} />
                ))}
              </div>
            ) : recentCalls.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {recentCalls.map(call => (
                  <ServiceCallCard key={call.id} call={call} />
                ))}
              </div>
            ) : (
              <div className={`rounded-lg border-2 border-dashed p-12 text-center ${isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-300'}`}>
                <Wrench className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>No Service Calls Yet</h3>
                <p className={`mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Create your first service call to get started</p>
                <Link to={createPageUrl("CreateServiceCall")}>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Service Call
                  </Button>
                </Link>
              </div>
            )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}