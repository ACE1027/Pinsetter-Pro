import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Save, Settings, RotateCcw, BarChart3, Wrench, Package, Calendar, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";
import { Badge } from "@/components/ui/badge";

const DEFAULT_WIDGETS = {
  showStats: true,
  showRecentCalls: true,
  showLowStockParts: true,
  showUpcomingMaintenance: true,
};

export default function DashboardSettings() {
  const navigate = useNavigate();
  const { theme } = useTheme();
  const [user, setUser] = useState(null);
  const [widgets, setWidgets] = useState(DEFAULT_WIDGETS);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      // Load saved widget preferences
      if (u.dashboard_widgets) {
        setWidgets({ ...DEFAULT_WIDGETS, ...u.dashboard_widgets });
      }
    }).catch(() => {});
  }, []);

  const handleToggle = (key) => {
    setWidgets(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await base44.auth.updateMe({ dashboard_widgets: widgets });
      toast.success("Dashboard preferences saved");
      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      toast.error("Failed to save preferences");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setWidgets(DEFAULT_WIDGETS);
    toast.info("Reset to default settings");
  };

  const widgetCount = Object.values(widgets).filter(Boolean).length;
  const totalWidgets = Object.keys(widgets).length;

  const widgetDetails = [
    {
      key: 'showStats',
      icon: BarChart3,
      title: 'Statistics Cards',
      description: 'Show open, in-progress, and urgent call counts',
      color: 'text-blue-600'
    },
    {
      key: 'showRecentCalls',
      icon: Wrench,
      title: 'Recent Service Calls',
      description: 'Display list of recent service calls',
      color: 'text-green-600'
    },
    {
      key: 'showLowStockParts',
      icon: Package,
      title: 'Low Stock Alerts',
      description: 'Show parts running low on inventory',
      color: 'text-orange-600'
    },
    {
      key: 'showUpcomingMaintenance',
      icon: Calendar,
      title: 'Upcoming Maintenance',
      description: 'Display scheduled maintenance tasks',
      color: 'text-purple-600'
    }
  ];

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-4xl mx-auto w-full">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-6">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className={`text-3xl font-bold ${theme.text}`}>Dashboard Settings</h1>
            <p className={`mt-1 ${theme.textSecondary}`}>Customize your dashboard layout and widgets</p>
          </div>
          <Badge variant="outline" className="shrink-0">
            {widgetCount} / {totalWidgets} Active
          </Badge>
        </div>

        <Card className={`shadow-lg ${theme.cardBg} ${theme.cardBorder}`}>
          <CardHeader className={`border-b ${theme.cardBorder}`}>
            <CardTitle className={`flex items-center gap-2 ${theme.text}`}>
              <Settings className="w-5 h-5 text-blue-500" />
              Widget Preferences
            </CardTitle>
            <CardDescription className={theme.textTertiary}>
              Choose which widgets to display on your dashboard
            </CardDescription>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 space-y-6">
            <div className="space-y-3">
              {widgetDetails.map((widget) => (
                <div
                  key={widget.key}
                  className={`flex items-start sm:items-center gap-3 sm:gap-4 p-4 rounded-lg border transition-all ${
                    widgets[widget.key]
                      ? theme.cardBg + ' ' + theme.cardBorder + ' shadow-sm'
                      : theme.cardBg + ' border-dashed opacity-60'
                  }`}
                >
                  <div className={`p-2 rounded-lg shrink-0 ${
                    widgets[widget.key] 
                      ? 'bg-blue-50' 
                      : 'bg-slate-100'
                  }`}>
                    <widget.icon className={`w-5 h-5 ${widgets[widget.key] ? widget.color : 'text-slate-400'}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Label htmlFor={widget.key} className={`text-base font-medium cursor-pointer ${theme.text}`}>
                        {widget.title}
                      </Label>
                      {widgets[widget.key] ? (
                        <Eye className="w-4 h-4 text-green-600" />
                      ) : (
                        <EyeOff className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                    <p className={`text-sm ${theme.textTertiary}`}>{widget.description}</p>
                  </div>
                  <Switch
                    id={widget.key}
                    checked={widgets[widget.key]}
                    onCheckedChange={() => handleToggle(widget.key)}
                    className="shrink-0"
                  />
                </div>
              ))}
            </div>

            <div className={`p-4 rounded-lg border-2 border-dashed ${theme.cardBorder}`}>
              <div className="flex items-center gap-3 text-sm">
                <Settings className="w-4 h-4 text-slate-400" />
                <span className={theme.textTertiary}>
                  Changes will take effect immediately after saving
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <Button
                variant="outline"
                onClick={handleReset}
                className="sm:flex-1"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset to Defaults
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate(createPageUrl("Dashboard"))}
                className="sm:flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="sm:flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <Save className="w-4 h-4 mr-2" />
                {isSaving ? "Saving..." : "Save Preferences"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}