import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Send, Image as ImageIcon, X, Trash2, Edit2, Check, Hash, Plus, Lock, Unlock } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";

export default function Discussion() {
  const { theme, isDarkMode } = useTheme();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState(null);
  const [editContent, setEditContent] = useState("");
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [showChannelDialog, setShowChannelDialog] = useState(false);
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelDescription, setNewChannelDescription] = useState("");
  const [newChannelDepartment, setNewChannelDepartment] = useState("all");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: channels = [] } = useQuery({
    queryKey: ['channels', user?.bowling_alley_id],
    queryFn: () => base44.entities.Channel.list(),
    enabled: !!user?.bowling_alley_id,
  });

  const { data: allMessages = [], isLoading } = useQuery({
    queryKey: ['messages', user?.bowling_alley_id],
    queryFn: () => base44.entities.Message.list('-created_date', 100),
    enabled: !!user?.bowling_alley_id,
    refetchInterval: 5000
  });

  const messages = selectedChannel 
    ? allMessages.filter(m => m.channel_id === selectedChannel.id)
    : allMessages.filter(m => !m.channel_id);

  const isManager = user && (user.department === 'manager' || user.role === 'admin');

  const createChannelMutation = useMutation({
    mutationFn: (channelData) => base44.entities.Channel.create(channelData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['channels'] });
      setShowChannelDialog(false);
      setNewChannelName("");
      setNewChannelDescription("");
      setNewChannelDepartment("all");
      toast.success("Channel created");
    },
  });

  const createMessageMutation = useMutation({
    mutationFn: (data) => base44.entities.Message.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      setMessage("");
      setAttachments([]);
      scrollToBottom();
    }
  });

  const updateMessageMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Message.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      setEditingMessageId(null);
      setEditContent("");
      toast.success("Message updated");
    }
  });

  const deleteMessageMutation = useMutation({
    mutationFn: (id) => base44.entities.Message.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      toast.success("Message deleted");
    }
  });

  const toggleChannelLockMutation = useMutation({
    mutationFn: ({ id, isLocked }) => base44.entities.Channel.update(id, { is_locked: isLocked }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['channels'] });
      toast.success("Channel lock status updated");
    }
  });

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages.length]);

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const uploadPromises = files.map(file => 
        base44.integrations.Core.UploadFile({ file })
      );
      const results = await Promise.all(uploadPromises);
      const urls = results.map(r => r.file_url);
      setAttachments([...attachments, ...urls]);
      toast.success(`${files.length} image(s) uploaded`);
    } catch (error) {
      toast.error("Failed to upload images");
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const handleSend = () => {
    if (!message.trim() && attachments.length === 0) return;

    // Check if channel is locked and user is not admin/manager
    if (selectedChannel?.is_locked && !isManager) {
      toast.error("This channel is locked. Only admins and managers can post.");
      return;
    }

    const mentions = [];
    const mentionRegex = /@(\S+)/g;
    let match;
    while ((match = mentionRegex.exec(message)) !== null) {
      mentions.push(match[1]);
    }

    createMessageMutation.mutate({
      bowling_alley_id: user.bowling_alley_id,
      channel_id: selectedChannel?.id || null,
      user_email: user.email,
      user_name: user.display_name || user.full_name || user.email,
      content: message.trim(),
      attachments: attachments,
      mentions
    });
  };

  const handleCreateChannel = () => {
    if (!newChannelName.trim()) {
      toast.error("Channel name is required");
      return;
    }

    createChannelMutation.mutate({
      bowling_alley_id: user.bowling_alley_id,
      name: newChannelName,
      description: newChannelDescription,
      department: newChannelDepartment,
    });
  };

  const handleEdit = (msg) => {
    setEditingMessageId(msg.id);
    setEditContent(msg.content);
  };

  const handleSaveEdit = (msg) => {
    if (!editContent.trim()) return;
    updateMessageMutation.mutate({
      id: msg.id,
      data: { content: editContent, edited: true }
    });
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditContent("");
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto h-[calc(100vh-8rem)]">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${theme.text}`}>Team Discussion</h1>
            <p className={`mt-1 ${theme.textSecondary}`}>Communicate with your team</p>
          </div>
          {isManager && (
            <Button onClick={() => setShowChannelDialog(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Channel
            </Button>
          )}
        </div>

        <div className="grid grid-cols-12 gap-6 h-full">
          {/* Channels Sidebar */}
          <div className="col-span-3">
            <Card className={`h-full ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Hash className="w-4 h-4" />
                  Channels
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1">
                <button
                  onClick={() => setSelectedChannel(null)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    !selectedChannel 
                      ? 'bg-blue-100 text-blue-900' 
                      : `${theme.textSecondary} hover:bg-slate-100`
                  }`}
                >
                  <Hash className="w-4 h-4 inline mr-2" />
                  General
                </button>
                {channels.filter(c => c.active).map(channel => (
                  <button
                    key={channel.id}
                    onClick={() => setSelectedChannel(channel)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                      selectedChannel?.id === channel.id 
                        ? 'bg-blue-100 text-blue-900' 
                        : `${theme.textSecondary} hover:bg-slate-100`
                    }`}
                  >
                    {channel.is_locked ? (
                      <Lock className="w-4 h-4 inline mr-2 text-amber-600" />
                    ) : (
                      <Hash className="w-4 h-4 inline mr-2" />
                    )}
                    {channel.name}
                    {channel.department !== 'all' && (
                      <Badge variant="outline" className="ml-2 text-xs">{channel.department}</Badge>
                    )}
                    {channel.is_locked && (
                      <Badge variant="outline" className="ml-2 text-xs bg-amber-50 text-amber-800 border-amber-300">Locked</Badge>
                    )}
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Messages Area */}
          <div className="col-span-9 flex flex-col">
            <Card className={`flex-1 flex flex-col ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
              <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CardTitle className={`text-lg flex items-center gap-2 ${theme.text}`}>
                      {selectedChannel?.is_locked ? (
                        <Lock className="w-5 h-5 text-amber-600" />
                      ) : (
                        <Hash className="w-5 h-5" />
                      )}
                      {selectedChannel?.name || 'General'}
                    </CardTitle>
                    {selectedChannel?.is_locked && (
                      <Badge className="bg-amber-100 text-amber-800 border-amber-300">
                        <Lock className="w-3 h-3 mr-1" />
                        Locked
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {isManager && selectedChannel && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleChannelLockMutation.mutate({ 
                          id: selectedChannel.id, 
                          isLocked: !selectedChannel.is_locked 
                        })}
                        disabled={toggleChannelLockMutation.isPending}
                      >
                        {selectedChannel.is_locked ? (
                          <>
                            <Unlock className="w-4 h-4 mr-2" />
                            Unlock
                          </>
                        ) : (
                          <>
                            <Lock className="w-4 h-4 mr-2" />
                            Lock
                          </>
                        )}
                      </Button>
                    )}
                    <Badge variant="outline" className="text-sm">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      {messages.length} messages
                    </Badge>
                  </div>
                </div>
                {selectedChannel?.description && (
                  <p className={`text-sm mt-1 ${theme.textTertiary}`}>{selectedChannel.description}</p>
                )}
                {selectedChannel?.is_locked && !isManager && (
                  <p className={`text-sm mt-2 ${isDarkMode ? 'text-amber-400' : 'text-amber-700'}`}>
                    This channel is locked. Only admins and managers can post messages.
                  </p>
                )}
              </CardHeader>
              
              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages Area */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {isLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
                    </div>
                  ) : messages.length > 0 ? (
                    <>
                      {messages.slice().reverse().map((msg) => {
                        const isOwnMessage = msg.user_email === user.email;
                        const isEditing = editingMessageId === msg.id;
                        
                        return (
                          <div
                            key={msg.id}
                            className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                          >
                            <div className={`max-w-[70%] ${isOwnMessage ? 'items-end' : 'items-start'} flex flex-col`}>
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                  {msg.user_name}
                                </span>
                                <span className="text-xs text-slate-500">
                                  {format(new Date(msg.created_date), 'MMM d, h:mm a')}
                                </span>
                                {msg.edited && (
                                  <span className="text-xs text-slate-400 italic">(edited)</span>
                                )}
                              </div>
                              
                              <div className={`rounded-2xl px-4 py-2 ${
                                isOwnMessage 
                                  ? 'bg-blue-600 text-white' 
                                  : isDarkMode ? 'bg-slate-800 text-slate-100' : 'bg-slate-100 text-slate-900'
                              }`}>
                                {isEditing ? (
                                  <div className="space-y-2">
                                    <Textarea
                                      value={editContent}
                                      onChange={(e) => setEditContent(e.target.value)}
                                      className={`min-h-[60px] ${isOwnMessage ? 'bg-blue-500 text-white placeholder:text-blue-200' : ''}`}
                                      autoFocus
                                    />
                                    <div className="flex gap-2">
                                      <Button
                                        size="sm"
                                        onClick={() => handleSaveEdit(msg)}
                                        className="h-7 bg-green-600 hover:bg-green-700"
                                      >
                                        <Check className="w-3 h-3" />
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={handleCancelEdit}
                                        className="h-7"
                                      >
                                        <X className="w-3 h-3" />
                                      </Button>
                                    </div>
                                  </div>
                                ) : (
                                  <p className="text-sm whitespace-pre-wrap break-words">
                                    {msg.content}
                                  </p>
                                )}
                                
                                {msg.attachments && msg.attachments.length > 0 && !isEditing && (
                                  <div className="mt-2 grid grid-cols-2 gap-2">
                                    {msg.attachments.map((url, idx) => (
                                      <img
                                        key={idx}
                                        src={url}
                                        alt="Attachment"
                                        className="rounded-lg max-h-48 object-cover cursor-pointer hover:opacity-90 transition-opacity"
                                        onClick={() => window.open(url, '_blank')}
                                      />
                                    ))}
                                  </div>
                                )}
                              </div>

                              {isOwnMessage && !isEditing && (
                                <div className="flex gap-2 mt-1">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleEdit(msg)}
                                    className="h-6 text-xs"
                                  >
                                    <Edit2 className="w-3 h-3 mr-1" />
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => deleteMessageMutation.mutate(msg.id)}
                                    className="h-6 text-xs text-red-600"
                                  >
                                    <Trash2 className="w-3 h-3 mr-1" />
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <MessageCircle className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          No messages yet. Start the conversation!
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Message Input Area */}
                <div className={`border-t p-4 ${isDarkMode ? 'border-slate-800 bg-slate-800/50' : 'border-slate-200 bg-slate-50'}`}>
                  {attachments.length > 0 && (
                    <div className="mb-3 flex flex-wrap gap-2">
                      {attachments.map((url, idx) => (
                        <div key={idx} className="relative">
                          <img
                            src={url}
                            alt="Preview"
                            className="h-20 w-20 object-cover rounded-lg"
                          />
                          <button
                            onClick={() => removeAttachment(idx)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    <Input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      accept="image/*"
                      multiple
                      className="hidden"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploading}
                      className={isDarkMode ? 'border-slate-700' : ''}
                    >
                      {uploading ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" />
                      ) : (
                        <ImageIcon className="w-4 h-4" />
                      )}
                    </Button>
                    
                    <Textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder={
                        selectedChannel?.is_locked && !isManager
                          ? "This channel is locked"
                          : `Message #${selectedChannel?.name || 'general'}... (Use @username to mention)`
                      }
                      disabled={selectedChannel?.is_locked && !isManager}
                      className={`flex-1 min-h-[60px] max-h-[120px] resize-none ${isDarkMode ? 'bg-slate-900 border-slate-700' : ''}`}
                    />
                    
                    <Button
                      onClick={handleSend}
                      disabled={
                        (!message.trim() && attachments.length === 0) || 
                        createMessageMutation.isPending ||
                        (selectedChannel?.is_locked && !isManager)
                      }
                      className="bg-blue-600 hover:bg-blue-700 self-end"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Create Channel Dialog */}
        <Dialog open={showChannelDialog} onOpenChange={setShowChannelDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Channel</DialogTitle>
              <DialogDescription>Create a channel for team communication</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="channel_name">Channel Name *</Label>
                <Input
                  id="channel_name"
                  placeholder="e.g., mechanics-team"
                  value={newChannelName}
                  onChange={(e) => setNewChannelName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="channel_description">Description</Label>
                <Textarea
                  id="channel_description"
                  placeholder="What is this channel about?"
                  value={newChannelDescription}
                  onChange={(e) => setNewChannelDescription(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <select
                  id="department"
                  value={newChannelDepartment}
                  onChange={(e) => setNewChannelDepartment(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md"
                >
                  <option value="all">All Departments</option>
                  <option value="mechanic">Mechanics</option>
                  <option value="manager">Managers</option>
                  <option value="front_desk">Front Desk</option>
                </select>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreateChannel} disabled={createChannelMutation.isPending} className="bg-blue-600 hover:bg-blue-700">
                  Create Channel
                </Button>
                <Button variant="outline" onClick={() => setShowChannelDialog(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}