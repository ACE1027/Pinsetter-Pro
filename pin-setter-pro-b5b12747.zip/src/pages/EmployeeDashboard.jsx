import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Package, TrendingUp, User, MessageCircle, Users } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";

export default function EmployeeDashboard() {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const tools = [
    {
      title: "Staff Schedule",
      description: "View your work schedule",
      icon: Calendar,
      color: "bg-blue-600",
      hoverColor: "hover:bg-blue-700",
      url: createPageUrl("Schedule")
    },
    {
      title: "Parts Inventory",
      description: "Check parts availability",
      icon: Package,
      color: "bg-purple-600",
      hoverColor: "hover:bg-purple-700",
      url: createPageUrl("PartsInventory")
    },
    {
      title: "Analytics",
      description: "View performance metrics",
      icon: TrendingUp,
      color: "bg-green-600",
      hoverColor: "hover:bg-green-700",
      url: createPageUrl("Analytics")
    },
    {
      title: "Technician Performance",
      description: "Track your metrics",
      icon: TrendingUp,
      color: "bg-indigo-600",
      hoverColor: "hover:bg-indigo-700",
      url: createPageUrl("TechnicianPerformance")
    },
    {
      title: "My Employee Profile",
      description: "View and update your profile",
      icon: User,
      color: "bg-amber-600",
      hoverColor: "hover:bg-amber-700",
      url: user ? createPageUrl("EmployeeProfile") + `?email=${user.email}` : createPageUrl("EmployeeProfile")
    },
    {
      title: "Team Discussion",
      description: "Communicate with your team",
      icon: MessageCircle,
      color: "bg-teal-600",
      hoverColor: "hover:bg-teal-700",
      url: createPageUrl("Discussion")
    },
    {
      title: "Staff Directory",
      description: "Find team members",
      icon: Users,
      color: "bg-pink-600",
      hoverColor: "hover:bg-pink-700",
      url: createPageUrl("StaffDirectory")
    }
  ];

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${theme.bg}`}>
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4 w-full">
        <div className="mb-4">
          <h1 className={`text-3xl font-bold ${theme.text}`}>Employee Dashboard</h1>
          <p className={`mt-1 ${theme.textSecondary}`}>Quick access to your tools and resources</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Card 
                key={tool.title}
                className={`cursor-pointer transition-all hover:shadow-md ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
                onClick={() => navigate(tool.url)}
              >
                <CardHeader className="p-4 pb-2">
                  <div className="flex items-start justify-between">
                    <div className={`w-10 h-10 rounded-lg ${tool.color} flex items-center justify-center shadow-md`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <CardTitle className={`text-base mt-3 ${theme.text}`}>{tool.title}</CardTitle>
                  <p className={`text-xs ${theme.textTertiary}`}>{tool.description}</p>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <Button 
                    size="sm"
                    className={`w-full ${tool.color} ${tool.hoverColor}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(tool.url);
                    }}
                  >
                    Open
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
        </div>
      </div>
    </div>
  );
}