import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { ArrowLeft, User, Phone, Mail, Calendar, Building2, Briefcase, CalendarX, ArrowLeftRight, Edit, Save, Star, FileText, Target, BookOpen, TrendingUp, CheckCircle2, Play, ExternalLink, Award, Plus, Trash2, Shield } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";

export default function EmployeeProfile() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [currentUser, setCurrentUser] = useState(null);
  const [editNotesOpen, setEditNotesOpen] = useState(false);
  const [performanceNotes, setPerformanceNotes] = useState("");
  const [certDialogOpen, setCertDialogOpen] = useState(false);
  const [certForm, setCertForm] = useState({
    type: "certification",
    name: "",
    description: "",
    category: "technical",
    issuing_organization: "",
    issue_date: "",
    expiry_date: ""
  });
  
  const urlParams = new URLSearchParams(window.location.search);
  const employeeEmail = urlParams.get('email');

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: employee, isLoading } = useQuery({
    queryKey: ['employee', employeeEmail],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list();
      return allUsers.find(u => u.email === employeeEmail);
    },
    enabled: !!employeeEmail
  });

  const { data: location } = useQuery({
    queryKey: ['location', employee?.bowling_alley_id],
    queryFn: () => base44.entities.BowlingAlley.get(employee.bowling_alley_id),
    enabled: !!employee?.bowling_alley_id
  });

  const { data: timeOffRequests = [] } = useQuery({
    queryKey: ['employeeTimeOff', employeeEmail],
    queryFn: async () => {
      const requests = await base44.entities.TimeOffRequest.list();
      return requests.filter(r => r.user_email === employeeEmail).sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      );
    },
    enabled: !!employeeEmail
  });

  const { data: tradeRequests = [] } = useQuery({
    queryKey: ['employeeTrades', employeeEmail],
    queryFn: async () => {
      const requests = await base44.entities.ShiftTradeRequest.list();
      return requests.filter(r => 
        r.requester_email === employeeEmail || r.target_email === employeeEmail
      ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    },
    enabled: !!employeeEmail
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ['employeeSchedules', employeeEmail],
    queryFn: async () => {
      const allSchedules = await base44.entities.UserSchedule.list();
      return allSchedules.filter(s => s.user_email === employeeEmail).sort((a, b) => 
        new Date(b.date) - new Date(a.date)
      );
    },
    enabled: !!employeeEmail
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['employeeReviews', employeeEmail],
    queryFn: async () => {
      const allReviews = await base44.entities.PerformanceReview.list();
      return allReviews.filter(r => r.employee_email === employeeEmail).sort((a, b) => 
        new Date(b.review_date) - new Date(a.review_date)
      );
    },
    enabled: !!employeeEmail
  });

  const { data: developmentPlans = [] } = useQuery({
    queryKey: ['employeeDevPlans', employeeEmail],
    queryFn: async () => {
      const plans = await base44.entities.DevelopmentPlan.list();
      return plans.filter(p => p.employee_email === employeeEmail).sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      );
    },
    enabled: !!employeeEmail
  });

  const { data: skillGoals = [] } = useQuery({
    queryKey: ['employeeSkillGoals', employeeEmail],
    queryFn: async () => {
      const goals = await base44.entities.SkillGoal.list();
      return goals.filter(g => g.employee_email === employeeEmail);
    },
    enabled: !!employeeEmail
  });

  const { data: trainingAssignments = [] } = useQuery({
    queryKey: ['employeeTraining', employeeEmail],
    queryFn: async () => {
      const assignments = await base44.entities.TrainingAssignment.list();
      return assignments.filter(a => a.employee_email === employeeEmail).sort((a, b) => 
        new Date(b.assigned_date) - new Date(a.assigned_date)
      );
    },
    enabled: !!employeeEmail
  });

  const { data: myChecklist } = useQuery({
    queryKey: ['myOnboardingChecklist', employeeEmail],
    queryFn: async () => {
      const checklists = await base44.entities.OnboardingChecklist.list();
      return checklists.find(c => c.employee_email === employeeEmail && c.status !== 'completed');
    },
    enabled: !!employeeEmail
  });

  const { data: onboardingTasks = [] } = useQuery({
    queryKey: ['myOnboardingTasks', myChecklist?.id],
    queryFn: async () => {
      const allTasks = await base44.entities.OnboardingTask.list();
      return allTasks.filter(t => t.checklist_id === myChecklist.id);
    },
    enabled: !!myChecklist
  });

  const { data: onboardingResources = [] } = useQuery({
    queryKey: ['onboardingResources'],
    queryFn: () => base44.entities.OnboardingResource.list('order'),
    initialData: []
  });

  const { data: allTrainingModules = [] } = useQuery({
    queryKey: ['trainingModules'],
    queryFn: () => base44.entities.TrainingModule.list(),
    initialData: []
  });

  const { data: certifications = [] } = useQuery({
    queryKey: ['employeeCertifications', employeeEmail],
    queryFn: async () => {
      const certs = await base44.entities.SkillCertification.list();
      return certs.filter(c => c.employee_email === employeeEmail);
    },
    enabled: !!employeeEmail
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.asServiceRole.entities.User.update(employee.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee', employeeEmail] });
      setEditNotesOpen(false);
      toast.success("Performance notes updated");
    }
  });

  const updateGoalMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SkillGoal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeSkillGoals', employeeEmail] });
      toast.success("Goal updated");
    }
  });

  const updateAssignmentMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TrainingAssignment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeTraining', employeeEmail] });
      toast.success("Training updated");
    }
  });

  const updateOnboardingTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.OnboardingTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myOnboardingTasks', myChecklist?.id] });
      const completedTasks = onboardingTasks.filter(t => t.status === 'completed').length + 1;
      const percentage = Math.round((completedTasks / onboardingTasks.length) * 100);
      
      base44.entities.OnboardingChecklist.update(myChecklist.id, {
        completion_percentage: percentage,
        status: percentage === 100 ? 'completed' : 'in_progress'
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['myOnboardingChecklist', employeeEmail] });
        if (percentage === 100) {
          toast.success("🎉 Onboarding completed!");
        }
      });
      
      toast.success("Task completed!");
    }
  });

  const createCertificationMutation = useMutation({
    mutationFn: (data) => base44.entities.SkillCertification.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeCertifications', employeeEmail] });
      setCertDialogOpen(false);
      setCertForm({
        type: "certification",
        name: "",
        description: "",
        category: "technical",
        issuing_organization: "",
        issue_date: "",
        expiry_date: ""
      });
      toast.success("Certification added");
    }
  });

  const deleteCertificationMutation = useMutation({
    mutationFn: (id) => base44.entities.SkillCertification.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeCertifications', employeeEmail] });
      toast.success("Certification deleted");
    }
  });

  const isManager = currentUser && (currentUser.department === 'manager' || currentUser.role === 'admin');
  const canEditNotes = isManager;

  const handleSaveNotes = () => {
    updateUserMutation.mutate({ performance_notes: performanceNotes });
  };

  const positionHierarchy = [
    { value: "general_manager", label: "General Manager" },
    { value: "service_manager", label: "Service Manager" },
    { value: "assistant_manager", label: "Assistant Manager" },
    { value: "senior_mechanic", label: "Senior Mechanic" },
    { value: "lead_mechanic", label: "Lead Mechanic" },
    { value: "mechanic", label: "Mechanic" },
    { value: "mechanic_apprentice", label: "Mechanic Apprentice" },
    { value: "front_desk_supervisor", label: "Front Desk Supervisor" },
    { value: "front_desk_staff", label: "Front Desk Staff" }
  ];

  const getPositionLabel = (value) => {
    const pos = positionHierarchy.find(p => p.value === value);
    return pos?.label || value?.replace(/_/g, ' ');
  };

  const timeOffStatusConfig = {
    pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800' },
    approved: { label: 'Approved', color: 'bg-green-100 text-green-800' },
    denied: { label: 'Denied', color: 'bg-red-100 text-red-800' }
  };

  const tradeStatusConfig = {
    pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800' },
    accepted: { label: 'Accepted', color: 'bg-blue-100 text-blue-800' },
    declined: { label: 'Declined', color: 'bg-red-100 text-red-800' },
    approved: { label: 'Approved', color: 'bg-green-100 text-green-800' },
    rejected: { label: 'Rejected', color: 'bg-red-100 text-red-800' }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <User className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Employee Not Found</h3>
          <Button onClick={() => navigate(-1)}>Go Back</Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-6xl mx-auto w-full">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              Employee Profile
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              {employee.display_name || employee.full_name || employee.email}
            </p>
          </div>
          {isManager && (
            <Button
              onClick={() => navigate(createPageUrl("PerformanceReview") + `?employee=${employee.email}`)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Star className="w-4 h-4 mr-2" />
              New Review
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Contact & Basic Info */}
          <div className="lg:col-span-1 space-y-6">
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                  <User className="w-5 h-5" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs text-slate-500">Full Name</Label>
                  <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {employee.display_name || employee.full_name || 'N/A'}
                  </p>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Email</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <p className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                      {employee.email}
                    </p>
                  </div>
                </div>
                {employee.phone && (
                  <div>
                    <Label className="text-xs text-slate-500">Phone</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Phone className="w-4 h-4 text-slate-400" />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                        {employee.phone}
                      </p>
                    </div>
                  </div>
                )}
                {(employee.emergency_contact_name || employee.emergency_contact_phone) && (
                  <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
                    <Label className="text-xs text-slate-500">Emergency Contact</Label>
                    {employee.emergency_contact_name && (
                      <p className={`text-sm font-medium mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                        {employee.emergency_contact_name}
                      </p>
                    )}
                    {employee.emergency_contact_phone && (
                      <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                        {employee.emergency_contact_phone}
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                  <Briefcase className="w-5 h-5" />
                  Employment Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs text-slate-500">Department</Label>
                  <Badge className="mt-1" variant="outline">
                    {employee.department?.replace(/_/g, ' ').toUpperCase() || 'N/A'}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Primary Position</Label>
                  <p className={`font-medium mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {getPositionLabel(employee.position)}
                  </p>
                </div>
                {employee.roles && employee.roles.length > 0 && (
                  <div>
                    <Label className="text-xs text-slate-500">Additional Roles</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {employee.roles.map((role, idx) => (
                        <Badge key={idx} variant="secondary">
                          {getPositionLabel(role)}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                {employee.bowling_alley_id && location && (
                  <div>
                    <Label className="text-xs text-slate-500">Location</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                        {location.name}
                      </p>
                    </div>
                  </div>
                )}
                {employee.hire_date && (
                  <div>
                    <Label className="text-xs text-slate-500">Hire Date</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                        {format(new Date(employee.hire_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {isManager && (
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Performance Notes</CardTitle>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => {
                        setPerformanceNotes(employee.performance_notes || '');
                        setEditNotesOpen(true);
                      }}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {employee.performance_notes ? (
                    <p className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'} whitespace-pre-wrap`}>
                      {employee.performance_notes}
                    </p>
                  ) : (
                    <p className="text-sm text-slate-500 italic">No notes added yet</p>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Request History */}
          <div className="lg:col-span-2">
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-300' : ''}>Request History</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="reviews" className="w-full">
                  <TabsList className="grid w-full grid-cols-8">
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                    <TabsTrigger value="certifications">Certifications</TabsTrigger>
                    <TabsTrigger value="development">Development</TabsTrigger>
                    <TabsTrigger value="training">Training</TabsTrigger>
                    <TabsTrigger value="onboarding">Onboarding</TabsTrigger>
                    <TabsTrigger value="timeoff">Time Off</TabsTrigger>
                    <TabsTrigger value="trades">Trades</TabsTrigger>
                    <TabsTrigger value="schedules">Schedules</TabsTrigger>
                  </TabsList>

                  <TabsContent value="reviews" className="mt-4">
                    {reviews.length > 0 ? (
                      <div className="space-y-3">
                        {reviews.map(review => (
                          <div 
                            key={review.id} 
                            className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                              isDarkMode 
                                ? 'bg-slate-800 border-slate-700 hover:border-slate-600' 
                                : 'bg-slate-50 border-slate-200 hover:border-blue-300'
                            }`}
                            onClick={() => navigate(createPageUrl("PerformanceReview") + `?id=${review.id}`)}
                          >
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4 text-slate-400" />
                                <span className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                  {format(new Date(review.review_date), 'MMM d, yyyy')}
                                </span>
                                {review.review_period_start && review.review_period_end && (
                                  <span className="text-xs text-slate-500">
                                    ({format(new Date(review.review_period_start), 'MMM d')} - {format(new Date(review.review_period_end), 'MMM d')})
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge className={review.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                                  {review.status}
                                </Badge>
                                <div className="flex items-center gap-1">
                                  <Star className="w-4 h-4 text-yellow-500" />
                                  <span className={`font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                    {review.overall_rating}/5
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="grid grid-cols-5 gap-2 mb-3">
                              <div className="text-center">
                                <p className="text-xs text-slate-500">Technical</p>
                                <p className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{review.technical_skills}/5</p>
                              </div>
                              <div className="text-center">
                                <p className="text-xs text-slate-500">Punctuality</p>
                                <p className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{review.punctuality}/5</p>
                              </div>
                              <div className="text-center">
                                <p className="text-xs text-slate-500">Teamwork</p>
                                <p className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{review.teamwork}/5</p>
                              </div>
                              <div className="text-center">
                                <p className="text-xs text-slate-500">Communication</p>
                                <p className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{review.communication}/5</p>
                              </div>
                              <div className="text-center">
                                <p className="text-xs text-slate-500">Problem Solving</p>
                                <p className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{review.problem_solving}/5</p>
                              </div>
                            </div>

                            {(review.strengths || review.areas_for_improvement || review.goals) && (
                              <div className="space-y-2">
                                {review.strengths && (
                                  <div className={`p-3 rounded ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                                    <Label className="text-xs text-slate-500">Manager Feedback - Strengths</Label>
                                    <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                      {review.strengths}
                                    </p>
                                  </div>
                                )}
                                {review.areas_for_improvement && (
                                  <div className={`p-3 rounded ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                                    <Label className="text-xs text-slate-500">Areas for Improvement</Label>
                                    <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                      {review.areas_for_improvement}
                                    </p>
                                  </div>
                                )}
                                {review.goals && (
                                  <div className={`p-3 rounded ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                                    <Label className="text-xs text-slate-500">Goals</Label>
                                    <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                      {review.goals}
                                    </p>
                                  </div>
                                )}
                                {review.employee_comments && (
                                  <div className={`p-3 rounded ${isDarkMode ? 'bg-blue-950/20' : 'bg-blue-50'}`}>
                                    <Label className="text-xs text-slate-500">Employee Self-Assessment</Label>
                                    <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                      {review.employee_comments}
                                    </p>
                                  </div>
                                )}
                              </div>
                            )}

                            <p className="text-xs text-slate-500 mt-2">
                              Reviewed by {review.reviewer_email}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <FileText className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className="text-sm text-slate-500">No performance reviews yet</p>
                        {isManager && (
                          <Button
                            className="mt-4 bg-blue-600 hover:bg-blue-700"
                            onClick={() => navigate(createPageUrl("PerformanceReview") + `?employee=${employee.email}`)}
                          >
                            <Star className="w-4 h-4 mr-2" />
                            Create First Review
                          </Button>
                        )}
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="certifications" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex justify-end">
                        <Button 
                          onClick={() => setCertDialogOpen(true)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Certification
                        </Button>
                      </div>

                      {certifications.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {certifications.map(cert => {
                            const expiryDate = cert.expiry_date ? new Date(cert.expiry_date) : null;
                            const daysUntilExpiry = expiryDate ? Math.floor((expiryDate - new Date()) / (1000 * 60 * 60 * 24)) : null;
                            const isExpiringSoon = daysUntilExpiry !== null && daysUntilExpiry <= 30 && daysUntilExpiry >= 0;
                            const isExpired = daysUntilExpiry !== null && daysUntilExpiry < 0;

                            return (
                              <div 
                                key={cert.id} 
                                className={`p-4 rounded-lg border ${
                                  isExpired ? isDarkMode ? 'bg-red-950/20 border-red-800' : 'bg-red-50 border-red-200' :
                                  isExpiringSoon ? isDarkMode ? 'bg-yellow-950/20 border-yellow-800' : 'bg-yellow-50 border-yellow-200' :
                                  isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                                }`}
                              >
                                <div className="flex items-start justify-between mb-2">
                                  <div className="flex items-center gap-2">
                                    <Award className={`w-4 h-4 ${
                                      isExpired ? 'text-red-500' :
                                      isExpiringSoon ? 'text-yellow-500' :
                                      'text-green-500'
                                    }`} />
                                    <div>
                                      <p className={`font-semibold text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                        {cert.name}
                                      </p>
                                      <p className="text-xs text-slate-500">
                                        {cert.type === 'certification' ? 'Certification' : 
                                         cert.type === 'license' ? 'License' : 'Skill'}
                                      </p>
                                    </div>
                                  </div>
                                  {isManager && (
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      onClick={() => deleteCertificationMutation.mutate(cert.id)}
                                    >
                                      <Trash2 className="w-3 h-3 text-red-500" />
                                    </Button>
                                  )}
                                </div>

                                {cert.issuing_organization && (
                                  <p className={`text-xs mb-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                    Issued by: {cert.issuing_organization}
                                  </p>
                                )}

                                {cert.description && (
                                  <p className={`text-xs mb-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                    {cert.description}
                                  </p>
                                )}

                                <div className="flex items-center justify-between text-xs mt-2">
                                  {cert.issue_date && (
                                    <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                                      Issued: {format(new Date(cert.issue_date), 'MMM d, yyyy')}
                                    </span>
                                  )}
                                  {expiryDate && (
                                    <Badge className={
                                      isExpired ? 'bg-red-100 text-red-800' :
                                      isExpiringSoon ? 'bg-yellow-100 text-yellow-800' :
                                      'bg-green-100 text-green-800'
                                    }>
                                      {isExpired ? 'Expired' :
                                       isExpiringSoon ? `Expires in ${daysUntilExpiry}d` :
                                       `Expires ${format(expiryDate, 'MMM d, yyyy')}`}
                                    </Badge>
                                  )}
                                </div>

                                {cert.verified_by && (
                                  <div className={`mt-2 pt-2 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                                    <div className="flex items-center gap-1 text-xs text-slate-500">
                                      <Shield className="w-3 h-3" />
                                      Verified by {cert.verified_by}
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <Award className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                          <p className="text-sm text-slate-500">No certifications added yet</p>
                          <Button
                            className="mt-4 bg-green-600 hover:bg-green-700"
                            onClick={() => setCertDialogOpen(true)}
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Add First Certification
                          </Button>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="development" className="mt-4">
                    <div className="space-y-6">
                      {/* Development Plans */}
                      <div>
                        <h3 className={`text-sm font-semibold mb-3 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          Development Plans
                        </h3>
                        {developmentPlans.length > 0 ? (
                          <div className="space-y-3">
                            {developmentPlans.map(plan => (
                              <div key={plan.id} className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                                <div className="flex items-start justify-between mb-2">
                                  <div className="flex items-center gap-2">
                                    <Target className="w-4 h-4 text-blue-500" />
                                    <span className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                      {plan.title}
                                    </span>
                                  </div>
                                  <Badge className={
                                    plan.status === 'active' ? 'bg-blue-100 text-blue-800' :
                                    plan.status === 'completed' ? 'bg-green-100 text-green-800' :
                                    'bg-slate-100 text-slate-800'
                                  }>
                                    {plan.status}
                                  </Badge>
                                </div>
                                <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                  {plan.description}
                                </p>
                                <div className="flex items-center gap-2 text-xs text-slate-500">
                                  <Calendar className="w-3 h-3" />
                                  {format(new Date(plan.start_date), 'MMM d, yyyy')} - {format(new Date(plan.target_completion_date), 'MMM d, yyyy')}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-sm text-slate-500 text-center py-4">No development plans yet</p>
                        )}
                      </div>

                      {/* Skill Goals */}
                      <div>
                        <h3 className={`text-sm font-semibold mb-3 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          Skill Goals
                        </h3>
                        {skillGoals.length > 0 ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {skillGoals.map(goal => {
                              const progress = ((goal.current_level - 1) / (goal.target_level - 1)) * 100;
                              return (
                                <div key={goal.id} className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                                  <div className="flex items-start justify-between mb-2">
                                    <div>
                                      <p className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                        {goal.skill_name}
                                      </p>
                                      <p className="text-xs text-slate-500">{goal.category.replace(/_/g, ' ')}</p>
                                    </div>
                                    <Badge className={
                                      goal.status === 'achieved' ? 'bg-green-100 text-green-800' :
                                      goal.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                      'bg-slate-100 text-slate-800'
                                    }>
                                      {goal.status.replace(/_/g, ' ')}
                                    </Badge>
                                  </div>
                                  <div className="space-y-2">
                                    <div className="flex items-center justify-between text-xs">
                                      <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                                        Level {goal.current_level} → {goal.target_level}
                                      </span>
                                      <span className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                        {Math.round(progress)}%
                                      </span>
                                    </div>
                                    <div className="w-full bg-slate-200 rounded-full h-2">
                                      <div 
                                        className="bg-blue-600 h-2 rounded-full transition-all" 
                                        style={{ width: `${progress}%` }}
                                      />
                                    </div>
                                    {currentUser?.email === employeeEmail && goal.status === 'in_progress' && (
                                      <Button 
                                        size="sm" 
                                        variant="outline"
                                        className="w-full mt-2"
                                        onClick={() => updateGoalMutation.mutate({ 
                                          id: goal.id, 
                                          data: { 
                                            status: 'achieved',
                                            achieved_date: new Date().toISOString().split('T')[0]
                                          }
                                        })}
                                      >
                                        <CheckCircle2 className="w-3 h-3 mr-1" />
                                        Mark Achieved
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <p className="text-sm text-slate-500 text-center py-4">No skill goals yet</p>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="training" className="mt-4">
                    <div className="space-y-4">
                      {/* Completed Training Summary */}
                      {trainingAssignments.filter(a => a.status === 'completed').length > 0 && (
                        <Card className={`${isDarkMode ? 'bg-gradient-to-br from-green-950/30 to-blue-950/30 border-green-800' : 'bg-gradient-to-br from-green-50 to-blue-50 border-green-200'}`}>
                          <CardHeader>
                            <CardTitle className={`text-sm ${isDarkMode ? 'text-slate-300' : ''}`}>Training Progress</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="flex items-center gap-4">
                              <CheckCircle2 className="w-8 h-8 text-green-600" />
                              <div>
                                <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                  {trainingAssignments.filter(a => a.status === 'completed').length}
                                </p>
                                <p className="text-sm text-slate-500">
                                  of {trainingAssignments.length} modules completed
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}

                      {trainingAssignments.length > 0 ? (
                        <div className="space-y-3">
                          {trainingAssignments.map(assignment => {
                            const module = allTrainingModules.find(m => m.id === assignment.training_module_id);
                            const canUpdate = currentUser?.email === employeeEmail;
                            return (
                              <div key={assignment.id} className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                                <div className="flex items-start justify-between mb-2">
                                  <div className="flex items-center gap-2">
                                    <BookOpen className="w-4 h-4 text-green-500" />
                                    <span className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                      {module?.title || "Training Module"}
                                    </span>
                                  </div>
                                  <Badge className={
                                    assignment.status === 'completed' ? 'bg-green-100 text-green-800' :
                                    assignment.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                    assignment.status === 'overdue' ? 'bg-red-100 text-red-800' :
                                    'bg-yellow-100 text-yellow-800'
                                  }>
                                    {assignment.status.replace(/_/g, ' ')}
                                  </Badge>
                                </div>
                                {module?.description && (
                                  <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                    {module.description}
                                  </p>
                                )}
                                <div className="flex items-center gap-4 text-xs text-slate-500 mb-3">
                                  {assignment.due_date && (
                                    <div className="flex items-center gap-1">
                                      <Calendar className="w-3 h-3" />
                                      Due: {format(new Date(assignment.due_date), 'MMM d, yyyy')}
                                    </div>
                                  )}
                                  {module?.estimated_duration_minutes && (
                                    <span>{module.estimated_duration_minutes} min</span>
                                  )}
                                  {assignment.completed_date && (
                                    <Badge className="bg-green-100 text-green-800">
                                      Completed {format(new Date(assignment.completed_date), 'MMM d, yyyy')}
                                    </Badge>
                                  )}
                                </div>
                                {canUpdate && assignment.status !== 'completed' && (
                                  <div className="flex gap-2">
                                    {assignment.status === 'assigned' && (
                                      <Button 
                                        size="sm" 
                                        className="bg-blue-600 hover:bg-blue-700"
                                        onClick={() => updateAssignmentMutation.mutate({ 
                                          id: assignment.id, 
                                          data: { 
                                            status: 'in_progress',
                                            started_date: new Date().toISOString()
                                          }
                                        })}
                                      >
                                        <Play className="w-3 h-3 mr-1" />
                                        Start
                                      </Button>
                                    )}
                                    {assignment.status === 'in_progress' && (
                                      <>
                                        {module?.content_url && (
                                          <Button 
                                            size="sm" 
                                            variant="outline"
                                            onClick={() => window.open(module.content_url, '_blank')}
                                          >
                                            <ExternalLink className="w-3 h-3 mr-1" />
                                            Continue Training
                                          </Button>
                                        )}
                                        <Button 
                                          size="sm" 
                                          className="bg-green-600 hover:bg-green-700"
                                          onClick={() => updateAssignmentMutation.mutate({ 
                                            id: assignment.id, 
                                            data: { 
                                              status: 'completed',
                                              completed_date: new Date().toISOString()
                                            }
                                          })}
                                        >
                                          <CheckCircle2 className="w-3 h-3 mr-1" />
                                          Mark Complete
                                        </Button>
                                      </>
                                    )}
                                  </div>
                                )}
                                {assignment.status === 'completed' && module?.content_url && (
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => window.open(module.content_url, '_blank')}
                                  >
                                    <ExternalLink className="w-3 h-3 mr-1" />
                                    Review Module
                                  </Button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <BookOpen className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                          <p className="text-sm text-slate-500">No training assignments yet</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="onboarding" className="mt-4">
                    {myChecklist ? (
                      <div className="space-y-4">
                        <Card className={`${isDarkMode ? 'bg-gradient-to-br from-blue-950/50 to-purple-950/50 border-blue-800' : 'bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200'}`}>
                          <CardHeader>
                            <CardTitle className={isDarkMode ? 'text-slate-300' : ''}>Onboarding Progress</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Start Date</p>
                                <p className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                  {format(new Date(myChecklist.start_date), 'MMM d, yyyy')}
                                </p>
                              </div>
                              <div>
                                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Status</p>
                                <Badge className={
                                  myChecklist.status === 'completed' ? 'bg-green-100 text-green-800' :
                                  myChecklist.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                  'bg-yellow-100 text-yellow-800'
                                }>
                                  {myChecklist.status.replace(/_/g, ' ')}
                                </Badge>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Overall Progress</span>
                                <span className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                  {myChecklist.completion_percentage || 0}%
                                </span>
                              </div>
                              <Progress value={myChecklist.completion_percentage || 0} className="h-3" />
                            </div>
                          </CardContent>
                        </Card>

                        {onboardingTasks.filter(t => t.assigned_to_role === 'employee').length > 0 && (
                          <div className="space-y-3">
                            {Object.entries(
                              onboardingTasks
                                .filter(t => t.assigned_to_role === 'employee')
                                .reduce((acc, task) => {
                                  if (!acc[task.category]) acc[task.category] = [];
                                  acc[task.category].push(task);
                                  return acc;
                                }, {})
                            ).map(([category, categoryTasks]) => (
                              <Card key={category} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                                <CardHeader>
                                  <CardTitle className={`text-base capitalize ${isDarkMode ? 'text-slate-300' : ''}`}>{category.replace(/_/g, ' ')}</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <div className="space-y-3">
                                    {categoryTasks.map(task => (
                                      <div 
                                        key={task.id} 
                                        className={`p-3 rounded-lg border ${
                                          task.status === 'completed' 
                                            ? isDarkMode ? 'bg-green-950/20 border-green-800' : 'bg-green-50 border-green-200'
                                            : isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                                        }`}
                                      >
                                        <div className="flex items-start gap-3">
                                          {currentUser?.email === employeeEmail && task.status !== 'completed' && (
                                            <Checkbox
                                              checked={false}
                                              onCheckedChange={() => updateOnboardingTaskMutation.mutate({ 
                                                id: task.id, 
                                                data: {
                                                  status: 'completed',
                                                  completed_date: new Date().toISOString(),
                                                  completed_by: currentUser.email
                                                }
                                              })}
                                              className="mt-1"
                                            />
                                          )}
                                          <div className="flex-1">
                                            <h4 className={`font-semibold text-sm ${task.status === 'completed' ? 'line-through opacity-60' : ''} ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                              {task.title}
                                            </h4>
                                            {task.description && (
                                              <p className={`text-xs mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                                {task.description}
                                              </p>
                                            )}
                                            <div className="flex items-center gap-4 text-xs mt-2">
                                              <span className={`flex items-center gap-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                                <Calendar className="w-3 h-3" />
                                                Due: {format(new Date(task.due_date), 'MMM d')}
                                              </span>
                                              {task.status === 'completed' && task.completed_date && (
                                                <span className="flex items-center gap-1 text-green-600">
                                                  <CheckCircle2 className="w-3 h-3" />
                                                  Completed {format(new Date(task.completed_date), 'MMM d')}
                                                </span>
                                              )}
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        )}

                        {onboardingResources.filter(r => 
                          r.active && 
                          (r.position_specific.length === 0 || r.position_specific.includes(employee?.position))
                        ).length > 0 && (
                          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                            <CardHeader>
                              <CardTitle className={`text-base flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                                <BookOpen className="w-4 h-4" />
                                Resources
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {onboardingResources
                                  .filter(r => r.active && (r.position_specific.length === 0 || r.position_specific.includes(employee?.position)))
                                  .map(resource => (
                                  <div 
                                    key={resource.id}
                                    className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}
                                  >
                                    <div className="flex items-start justify-between mb-2">
                                      <h4 className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                        {resource.title}
                                        {resource.required_reading && (
                                          <Badge className="ml-2 text-xs bg-red-100 text-red-800">Required</Badge>
                                        )}
                                      </h4>
                                      <Badge variant="outline" className="text-xs">{resource.category}</Badge>
                                    </div>
                                    {resource.description && (
                                      <p className={`text-xs mb-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                        {resource.description}
                                      </p>
                                    )}
                                    {resource.external_url && (
                                      <a 
                                        href={resource.external_url} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                                      >
                                        View Resource <ExternalLink className="w-3 h-3" />
                                      </a>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <CheckCircle2 className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className="text-sm text-slate-500">No active onboarding</p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="timeoff" className="mt-4">
                    {timeOffRequests.length > 0 ? (
                      <div className="space-y-3">
                        {timeOffRequests.map(request => (
                          <div key={request.id} className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <CalendarX className="w-4 h-4 text-slate-400" />
                                <span className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                  {format(new Date(request.start_date), 'MMM d')} - {format(new Date(request.end_date), 'MMM d, yyyy')}
                                </span>
                              </div>
                              <Badge className={timeOffStatusConfig[request.status]?.color}>
                                {timeOffStatusConfig[request.status]?.label}
                              </Badge>
                            </div>
                            <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                              {request.reason}
                            </p>
                            {request.notes && (
                              <p className={`text-xs italic ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                Manager notes: {request.notes}
                              </p>
                            )}
                            <p className="text-xs text-slate-500 mt-2">
                              Requested {format(new Date(request.created_date), 'MMM d, yyyy')}
                              {request.reviewed_by && ` • Reviewed by ${request.reviewed_by}`}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <CalendarX className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className="text-sm text-slate-500">No time off requests</p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="trades" className="mt-4">
                    {tradeRequests.length > 0 ? (
                      <div className="space-y-3">
                        {tradeRequests.map(request => (
                          <div key={request.id} className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <ArrowLeftRight className="w-4 h-4 text-slate-400" />
                                <span className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                  {request.requester_email === employee.email ? 'Requested' : 'Received'} Trade
                                </span>
                              </div>
                              <Badge className={tradeStatusConfig[request.status]?.color}>
                                {tradeStatusConfig[request.status]?.label}
                              </Badge>
                            </div>
                            <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                              {request.reason}
                            </p>
                            <p className="text-xs text-slate-500">
                              Requested {format(new Date(request.created_date), 'MMM d, yyyy')}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <ArrowLeftRight className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className="text-sm text-slate-500">No shift trade requests</p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="schedules" className="mt-4">
                    {schedules.length > 0 ? (
                      <div className="space-y-3">
                        {schedules.slice(0, 10).map(schedule => (
                          <div key={schedule.id} className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <Calendar className="w-4 h-4 text-slate-400" />
                                  <span className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                    {format(new Date(schedule.date.split('T')[0]), 'EEEE, MMM d, yyyy')}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-slate-600">
                                  <Badge variant="outline">{getPositionLabel(schedule.role)}</Badge>
                                  <span>{schedule.shift_start} - {schedule.shift_end}</span>
                                </div>
                              </div>
                            </div>
                            {schedule.notes && (
                              <p className={`text-xs mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                {schedule.notes}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <Calendar className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className="text-sm text-slate-500">No recent schedules</p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Add Certification Dialog */}
        <Dialog open={certDialogOpen} onOpenChange={setCertDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Certification or Skill</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={certForm.type} onValueChange={(value) => setCertForm({...certForm, type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="certification">Certification</SelectItem>
                    <SelectItem value="license">License</SelectItem>
                    <SelectItem value="skill">Skill</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Name *</Label>
                <Input
                  value={certForm.name}
                  onChange={(e) => setCertForm({...certForm, name: e.target.value})}
                  placeholder="e.g., OSHA Safety Certification"
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={certForm.category} onValueChange={(value) => setCertForm({...certForm, category: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Technical</SelectItem>
                    <SelectItem value="safety">Safety</SelectItem>
                    <SelectItem value="leadership">Leadership</SelectItem>
                    <SelectItem value="compliance">Compliance</SelectItem>
                    <SelectItem value="customer_service">Customer Service</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={certForm.description}
                  onChange={(e) => setCertForm({...certForm, description: e.target.value})}
                  placeholder="Additional details..."
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label>Issuing Organization</Label>
                <Input
                  value={certForm.issuing_organization}
                  onChange={(e) => setCertForm({...certForm, issuing_organization: e.target.value})}
                  placeholder="e.g., OSHA, Brunswick"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Issue Date</Label>
                  <Input
                    type="date"
                    value={certForm.issue_date}
                    onChange={(e) => setCertForm({...certForm, issue_date: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Expiry Date</Label>
                  <Input
                    type="date"
                    value={certForm.expiry_date}
                    onChange={(e) => setCertForm({...certForm, expiry_date: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setCertDialogOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    if (!certForm.name) {
                      toast.error("Please provide a name");
                      return;
                    }
                    createCertificationMutation.mutate({
                      ...certForm,
                      employee_email: employee.email,
                      bowling_alley_id: employee.bowling_alley_id,
                      verified_by: isManager ? currentUser.email : null,
                      verified_date: isManager ? new Date().toISOString() : null,
                      status: 'active'
                    });
                  }}
                  disabled={createCertificationMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  Add
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Performance Notes Dialog */}
        <Dialog open={editNotesOpen} onOpenChange={setEditNotesOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Performance Notes</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="performance_notes">Notes</Label>
                <Textarea
                  id="performance_notes"
                  value={performanceNotes}
                  onChange={(e) => setPerformanceNotes(e.target.value)}
                  placeholder="Add performance notes, feedback, or observations..."
                  rows={6}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditNotesOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSaveNotes}
                  disabled={updateUserMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Notes
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}