import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useTheme } from "@/components/ThemeContext";
import { useLocation } from "../components/LocationContext";
import { Wrench, AlertCircle } from "lucide-react";

const CALL_CODES = [
  { code: "Pin OOR", extendedCode: "Out-of-Range" },
  { code: "Pin1 Ld", extendedCode: "Pin Loading Time Out Pin 1" },
  { code: "Pin2 Ld", extendedCode: "Pin Loading Time Out Pin 2" },
  { code: "Pin3 Ld", extendedCode: "Pin Loading Time Out Pin 3" },
  { code: "Pin4 Ld", extendedCode: "Pin Loading Time Out Pin 4" },
  { code: "Pin5 Ld", extendedCode: "Pin Loading Time Out Pin 5" },
  { code: "Pin6 Ld", extendedCode: "Pin Loading Time Out Pin 6" },
  { code: "Pin7 Ld", extendedCode: "Pin Loading Time Out Pin 7" },
  { code: "Pin8 Ld", extendedCode: "Pin Loading Time Out Pin 8" },
  { code: "Pin9 Ld", extendedCode: "Pin Loading Time Out Pin 9" },
  { code: "Pin10 Ld", extendedCode: "Pin Loading Time Out Pin 10" },
  { code: "Detect10", extendedCode: "#10 Pin Not Detected in Diagnostics" },
  { code: "Detect1", extendedCode: "#1 Pin Not Detected in Diagnostics" },
  { code: "Detect2", extendedCode: "#2 Pin Not Detected in Diagnostics" },
  { code: "Detect3", extendedCode: "#3 Pin Not Detected in Diagnostics" },
  { code: "Detect4", extendedCode: "#4 Pin Not Detected in Diagnostics" },
  { code: "Detect5", extendedCode: "#5 Pin Not Detected in Diagnostics" },
  { code: "Detect6", extendedCode: "#6 Pin Not Detected in Diagnostics" },
  { code: "Detect7", extendedCode: "#7 Pin Not Detected in Diagnostics" },
  { code: "Detect8", extendedCode: "#8 Pin Not Detected in Diagnostics" },
  { code: "Detect9", extendedCode: "#9 Pin Not Detected in Diagnostics" },
  { code: "A Found", extendedCode: "Switch A is Not Expected But Found" },
  { code: "B Found", extendedCode: "Switch B is Not Expected But Found" },
  { code: "C Found", extendedCode: "Switch C is Not Expected But Found" },
  { code: "D Found", extendedCode: "Switch D is Not Expected But Found" },
  { code: "64", extendedCode: "SM Found - Switch SM Not Expected But Found" },
  { code: "65", extendedCode: "G Found - Switch G Not Expected But Found" },
  { code: "66", extendedCode: "STFound - Switch ST Not Expected But Found" },
  { code: "67", extendedCode: "OORFound S-V - OOR Not Expected But Found" },
  { code: "70", extendedCode: "A Ntfnd - Switch A Expected But Not Found" },
  { code: "71", extendedCode: "B Ntfnd - Switch B Expected But Not Found" },
  { code: "72", extendedCode: "C Ntfnd - Switch C Expected But Not Found" },
  { code: "73", extendedCode: "D Ntfnd - Switch D Expected But Not Found" },
  { code: "74", extendedCode: "SM Ntfnd - Switch SM Expected But Not Found" },
  { code: "75", extendedCode: "G Ntfnd - Switch G Expected But Not Found" },
  { code: "76", extendedCode: "ST Ntfnd - Switch ST Expected But Not Found" },
  { code: "90", extendedCode: "Invld 0 - Invalid Machine State 0" },
  { code: "91", extendedCode: "Invld 1 - Invalid Machine State 1" },
  { code: "92", extendedCode: "Invld 2 - Invalid Machine State 2" },
  { code: "93", extendedCode: "Invld 3 - Invalid Machine State 3" },
  { code: "94", extendedCode: "Invld 4 - Invalid Machine State 4" },
  { code: "95", extendedCode: "Invld 5 - Invalid Machine State 5" },
  { code: "EJ", extendedCode: "Elev.Jam - Elevator Jam" },
  { code: "EL", extendedCode: "Pin Cnt - Pin Count Switch Shorted for 5 Seconds" },
  { code: "J1", extendedCode: "TS1 Jam - Jam Switch TS1" },
  { code: "J2", extendedCode: "TS2 Jam - Jam Switch TS2 (Tower)" },
  { code: "BA", extendedCode: "Aceltoff - Accelerator Motor (overload)" },
  { code: "IL", extendedCode: "IL - Interlock Switch Open" },
  { code: "PF", extendedCode: "PwrFail - Power Failure has Occured" },
];

const ISSUE_TYPES = [
  "Pin Loading Issues",
  "Pin Detection Problems",
  "Switch Malfunctions",
  "Machine State Errors",
  "Mechanical Jams",
  "Power/Electrical Issues",
  "General Diagnostics",
  "Other"
];

export default function GSXCallSheet() {
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);

  // Read URL parameters for pre-filling
  const urlParams = new URLSearchParams(window.location.search);
  const prefillLocationId = urlParams.get('bowling_alley_id');

  const [formData, setFormData] = useState({
    bowling_alley_id: prefillLocationId || "",
    lane_number: "",
    call_code: "",
    issue_type: "",
    description: "",
    priority: "medium",
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      // Auto-select user's bowling alley if they have one (only if not prefilled)
      if (u.bowling_alley_id && !prefillLocationId && !formData.bowling_alley_id) {
        setFormData((prev) => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});
  }, [prefillLocationId]);

  const createMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.ServiceCall.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      navigate(createPageUrl("ServiceCalls"));
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const selectedCode = CALL_CODES.find(c => c.code === formData.call_code);
    const codeDescription = selectedCode ? `${selectedCode.code} - ${selectedCode.extendedCode}` : "";
    
    const title = `GS-X ${formData.call_code ? `[${formData.call_code}]` : ""} Lane ${formData.lane_number}`;
    const description = `Issue Type: ${formData.issue_type}\n${codeDescription ? `Call Code: ${codeDescription}\n` : ""}${formData.description ? `\nAdditional Details:\n${formData.description}` : ""}`;

    const serviceCallData = {
      bowling_alley_id: formData.bowling_alley_id || selectedLocationId || user?.bowling_alley_id,
      title,
      description,
      category: "lane_machine",
      machine_type: "GS-X Machine",
      lane_number: formData.lane_number,
      priority: formData.priority,
      status: "open",
      device_timestamp: new Date().toISOString(),
    };

    createMutation.mutate(serviceCallData);
  };

  const selectedCode = CALL_CODES.find(c => c.code === formData.call_code);

  return (
    <div className={`min-h-screen w-full overflow-x-hidden ${theme.bg}`}>
      <div className="p-4 sm:p-6 lg:p-8 w-full">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <h1 className={`text-3xl font-bold flex items-center gap-3 ${theme.text}`}>
              <Wrench className="w-8 h-8" />
              GS-X Call Sheet
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              Report GS-X machine issues with standardized call codes
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'} backdrop-blur-sm`}>
              <CardHeader>
                <CardTitle className={theme.text}>Service Call Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Lane Number */}
                <div>
                  <Label htmlFor="lane_number" className={theme.text}>Lane Number *</Label>
                  <Input
                    id="lane_number"
                    type="text"
                    placeholder="e.g., 12"
                    value={formData.lane_number}
                    onChange={(e) => setFormData({...formData, lane_number: e.target.value})}
                    required
                    className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}
                  />
                </div>

                {/* Issue Type */}
                <div>
                  <Label htmlFor="issue_type" className={theme.text}>Issue Type *</Label>
                  <Select
                    value={formData.issue_type}
                    onValueChange={(value) => setFormData({...formData, issue_type: value})}
                    required
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                      <SelectValue placeholder="Select issue type..." />
                    </SelectTrigger>
                    <SelectContent>
                      {ISSUE_TYPES.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Call Code */}
                <div>
                  <Label htmlFor="call_code" className={theme.text}>Call Code *</Label>
                  <Select
                    value={formData.call_code}
                    onValueChange={(value) => setFormData({...formData, call_code: value})}
                    required
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                      <SelectValue placeholder="Select call code..." />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {CALL_CODES.map((item) => (
                        <SelectItem key={item.code} value={item.code}>
                          {item.code} - {item.extendedCode}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {selectedCode && (
                    <div className={`mt-2 p-3 rounded-lg ${isDarkMode ? 'bg-blue-950/30 border border-blue-800' : 'bg-blue-50 border border-blue-200'}`}>
                      <p className={`text-sm font-medium ${isDarkMode ? 'text-blue-400' : 'text-blue-900'}`}>
                        {selectedCode.code}
                      </p>
                      <p className={`text-xs ${isDarkMode ? 'text-blue-300' : 'text-blue-700'}`}>
                        {selectedCode.extendedCode}
                      </p>
                    </div>
                  )}
                </div>

                {/* Priority */}
                <div>
                  <Label htmlFor="priority" className={theme.text}>Priority *</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({...formData, priority: value})}
                    required
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Additional Description */}
                <div>
                  <Label htmlFor="description" className={theme.text}>Additional Details</Label>
                  <Textarea
                    id="description"
                    placeholder="Add any additional details about the issue..."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className={`min-h-[120px] ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
                  />
                </div>

                {/* Alert Notice */}
                {formData.priority === "urgent" && (
                  <div className={`p-4 rounded-lg flex items-start gap-3 ${isDarkMode ? 'bg-red-950/30 border border-red-800' : 'bg-red-50 border border-red-200'}`}>
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className={`font-semibold text-sm ${isDarkMode ? 'text-red-400' : 'text-red-900'}`}>
                        Urgent Priority
                      </p>
                      <p className={`text-xs ${isDarkMode ? 'text-red-300' : 'text-red-700'}`}>
                        This will trigger immediate notifications to available mechanics
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-3 mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(-1)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {createMutation.isPending ? "Creating..." : "Create Call Sheet"}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}