import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ThemeContext";
import SoundSettings from "@/components/sounds/SoundSettings";
import {
  HelpCircle,
  Mail,
  Book,
  Video,
  FileText,
  MessageCircle,
  Phone,
  ExternalLink } from
"lucide-react";

export default function HelpResources() {
  const { theme, isDarkMode } = useTheme();

  const resources = [
  {
    title: "Getting Started",
    icon: Book,
    description: "Learn the basics of using Pinsetter Pro",
    items: [
    "Creating service calls",
    "Managing your schedule",
    "Tracking inventory",
    "Understanding notifications"]

  },
  {
    title: "Video Tutorials",
    icon: Video,
    description: "Watch step-by-step guides",
    items: [
    "Service call workflow",
    "Parts management",
    "Maintenance tracking",
    "Mobile app usage"]

  },
  {
    title: "User Manual",
    icon: FileText,
    description: "Detailed guides and references",
    items: [
    { text: "Brunswick A, Jetback, A2 Pinsetter", link: "https://www.jayhawkbowling.com/Brunswick/Parts%20Manuals/BB_Service_Service_Manuals_A2-Service-Manual_12-752828-000.pdf" },
    { text: "Brunswick GS-Series", link: "https://brunswickbowling.nyc3.cdn.digitaloceanspaces.com/production/document-library/Service-Manuals/Pinsetters/GS/47-902728-complete.pdf" },
    { text: "Brunswick Boost ST String Pin", link: "https://brunswickbowling.nyc3.cdn.digitaloceanspaces.com/production/document-library/Service-Manuals/Lane-Machines/MAX/55-900001-000_StringPin-Service_Rev-9-28-20.pdf" },
    { text: "AMF 82-30", link: "https://www.grintfarmsupply.com/bowltech/8230manual.pdf" },
    { text: "AMF 82-90 XL", link: "https://schemm.com/pdf/8290XL_Pinspotter.pdf" },
    { text: "Qubica AMF Edge Free Fall", link: "https://www.bowltech.eu/data/uploads/downloads/XLi_EDGE_pinspotter___Service_and_Parts_listings-20220720105207-1000.pdf" },
    { text: "Qubica AMF Edge String Pin", link: "https://www.bowltech.eu/data/uploads/downloads/400_051_202_01_B_EN-20220428093449-550.pdf" },
    "Manager handbook",
    "Mechanic guide",
    "Admin documentation"]

  }];


  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            Help & Resources
          </h1>
          <p className={`mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            Find answers, learn features, and get support
          </p>
        </div>

        {/* Contact Support */}
        <Card className={`mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardHeader>
            <CardTitle className="text-slate-200 font-semibold tracking-tight leading-none flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-blue-500" />
              Contact Support
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-100 rounded-full">
                    <Mail className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Email Support</p>
                    <p className="text-xs text-slate-500">Response within 24 hours</p>
                  </div>
                </div>
                <a
                  href="mailto:pinsetterpro2025@gmail.com"
                  className="text-sm text-blue-600 hover:underline font-medium">

                  pinsetterpro2025@gmail.com
                </a>
              </div>

              <div className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-green-100 rounded-full">
                    <Phone className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Emergency Support</p>
                    <p className="text-xs text-slate-500">For urgent issues</p>
                  </div>
                </div>
                <p className="text-sm text-slate-500">Contact your admin</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Resource Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {resources.map((resource, idx) =>
          <Card key={idx} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className="text-slate-200 text-lg font-semibold tracking-tight flex items-center gap-2">
                  <resource.icon className="w-5 h-5 text-blue-500" />
                  {resource.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-sm mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {resource.description}
                </p>
                <ul className="space-y-2">
                  {resource.items.map((item, itemIdx) =>
                <li key={itemIdx} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                      {typeof item === 'object' && item.link ? (
                        <a 
                          href={item.link} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className={`text-sm hover:underline flex items-center gap-1 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}
                        >
                          {item.text}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                          {item}
                        </span>
                      )}
                    </li>
                )}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Quick Links */}
        <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
          <CardHeader>
            <CardTitle className="text-slate-200 font-semibold tracking-tight leading-none flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-purple-500" />
              Quick Links
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="justify-start h-auto py-3"
                onClick={() => window.open('mailto:pinsetterpro2025@gmail.com?subject=Feature Request', '_blank')}>

                <div className="flex items-center gap-3 w-full">
                  <MessageCircle className="w-4 h-4 text-blue-500" />
                  <div className="text-left">
                    <p className="font-semibold text-sm">Submit Feedback</p>
                    <p className="text-xs text-slate-500">Share ideas or suggestions</p>
                  </div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start h-auto py-3"
                onClick={() => window.open('mailto:pinsetterpro2025@gmail.com?subject=Bug Report', '_blank')}>

                <div className="flex items-center gap-3 w-full">
                  <FileText className="w-4 h-4 text-red-500" />
                  <div className="text-left">
                    <p className="font-semibold text-sm">Report a Bug</p>
                    <p className="text-xs text-slate-500">Help us improve</p>
                  </div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start h-auto py-3"
                onClick={() => window.open('mailto:pinsetterpro2025@gmail.com?subject=Training Request', '_blank')}>

                <div className="flex items-center gap-3 w-full">
                  <Video className="w-4 h-4 text-green-500" />
                  <div className="text-left">
                    <p className="font-semibold text-sm">Request Training</p>
                    <p className="text-xs text-slate-500">Schedule a session</p>
                  </div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="justify-start h-auto py-3"
                onClick={() => window.open('mailto:pinsetterpro2025@gmail.com?subject=Technical Support', '_blank')}>

                <div className="flex items-center gap-3 w-full">
                  <Phone className="w-4 h-4 text-purple-500" />
                  <div className="text-left">
                    <p className="font-semibold text-sm">Technical Support</p>
                    <p className="text-xs text-slate-500">Get help with issues</p>
                  </div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Sound Effects Settings */}
        <div className="mt-6">
          <SoundSettings />
        </div>

        {/* FAQ Section */}
        <Card className={`mt-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardHeader>
            <CardTitle className="text-slate-200 font-semibold tracking-tight leading-none flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-amber-500" />
              Frequently Asked Questions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
              {
                q: "How do I create a new service call?",
                a: "Navigate to the Dashboard and click 'New Service Call' button, or use the quick action in the sidebar."
              },
              {
                q: "How do I request time off?",
                a: "Go to the Staff Schedule page, click on the 'Time Off' tab, and submit a new request with your dates and reason."
              },
              {
                q: "Where can I see my schedule?",
                a: "Your schedule is available on the Staff Schedule page. You'll see all your upcoming shifts and can request trades if needed."
              },
              {
                q: "How do I update my profile?",
                a: "Click on your profile picture in the sidebar, then select 'Profile' to edit your information."
              }].
              map((faq, idx) =>
              <div key={idx} className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                  <p className={`font-semibold text-sm mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {faq.q}
                  </p>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    {faq.a}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

}