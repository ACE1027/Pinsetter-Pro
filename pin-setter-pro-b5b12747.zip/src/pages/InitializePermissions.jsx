import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { PERMISSION_DEFINITIONS, SYSTEM_ROLES } from "../components/permissions/permissionDefinitions";

export default function InitializePermissions() {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState({ permissions: null, roles: null });

  const { data: existingPermissions = [] } = useQuery({
    queryKey: ['permissions'],
    queryFn: () => base44.entities.Permission.list(),
    initialData: [],
  });

  const { data: existingRoles = [] } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
    initialData: [],
  });

  const initializePermissions = async () => {
    setStatus(prev => ({ ...prev, permissions: 'loading' }));
    try {
      // Check which permissions don't exist yet
      const existingKeys = existingPermissions.map(p => p.key);
      const newPermissions = PERMISSION_DEFINITIONS.filter(p => !existingKeys.includes(p.key));

      if (newPermissions.length > 0) {
        await base44.entities.Permission.bulkCreate(newPermissions);
        toast.success(`Created ${newPermissions.length} permissions`);
      } else {
        toast.info('All permissions already exist');
      }

      setStatus(prev => ({ ...prev, permissions: 'success' }));
      queryClient.invalidateQueries({ queryKey: ['permissions'] });
    } catch (error) {
      console.error('Error initializing permissions:', error);
      setStatus(prev => ({ ...prev, permissions: 'error' }));
      toast.error('Failed to initialize permissions');
    }
  };

  const initializeRoles = async () => {
    setStatus(prev => ({ ...prev, roles: 'loading' }));
    try {
      // Check which roles don't exist yet
      const existingRoleNames = existingRoles.map(r => r.name);
      const newRoles = SYSTEM_ROLES.filter(r => !existingRoleNames.includes(r.name));

      if (newRoles.length > 0) {
        await base44.entities.Role.bulkCreate(newRoles);
        toast.success(`Created ${newRoles.length} default roles`);
      } else {
        toast.info('All default roles already exist');
      }

      setStatus(prev => ({ ...prev, roles: 'success' }));
      queryClient.invalidateQueries({ queryKey: ['roles'] });
    } catch (error) {
      console.error('Error initializing roles:', error);
      setStatus(prev => ({ ...prev, roles: 'error' }));
      toast.error('Failed to initialize roles');
    }
  };

  const initializeAll = async () => {
    await initializePermissions();
    await initializeRoles();
  };

  const StatusIcon = ({ status }) => {
    if (status === 'loading') return <Loader2 className="w-5 h-5 animate-spin text-blue-500" />;
    if (status === 'success') return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (status === 'error') return <AlertCircle className="w-5 h-5 text-red-500" />;
    return <Shield className="w-5 h-5 text-slate-500" />;
  };

  return (
    <div className="min-h-screen bg-slate-900 p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-100">Initialize Permission System</h1>
          <p className="text-slate-400 mt-1">Set up default permissions and roles for your system</p>
        </div>

        <div className="grid gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <StatusIcon status={status.permissions} />
                  <CardTitle className="text-slate-100">Permissions</CardTitle>
                </div>
                <Button
                  onClick={initializePermissions}
                  disabled={status.permissions === 'loading'}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Initialize Permissions
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">
                This will create {PERMISSION_DEFINITIONS.length} permission definitions in your database.
              </p>
              <div className="text-sm text-slate-500">
                <p>Existing: {existingPermissions.length}</p>
                <p>To be created: {Math.max(0, PERMISSION_DEFINITIONS.length - existingPermissions.length)}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <StatusIcon status={status.roles} />
                  <CardTitle className="text-slate-100">Default Roles</CardTitle>
                </div>
                <Button
                  onClick={initializeRoles}
                  disabled={status.roles === 'loading'}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Initialize Roles
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">
                This will create {SYSTEM_ROLES.length} default roles with pre-configured permissions.
              </p>
              <div className="space-y-2 mb-4">
                {SYSTEM_ROLES.map(role => (
                  <div key={role.name} className="flex items-center justify-between p-2 bg-slate-700/50 rounded">
                    <div>
                      <p className="text-slate-300 font-medium">{role.name}</p>
                      <p className="text-xs text-slate-500">{role.description}</p>
                    </div>
                    <span className="text-xs text-slate-400">{role.permission_keys.length} permissions</span>
                  </div>
                ))}
              </div>
              <div className="text-sm text-slate-500">
                <p>Existing: {existingRoles.length}</p>
                <p>To be created: {Math.max(0, SYSTEM_ROLES.length - existingRoles.length)}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-slate-100 mb-2">Initialize Everything</h3>
                  <p className="text-slate-400 text-sm">Create all permissions and roles at once</p>
                </div>
                <Button
                  onClick={initializeAll}
                  disabled={status.permissions === 'loading' || status.roles === 'loading'}
                  size="lg"
                  className="bg-green-600 hover:bg-green-700"
                >
                  Initialize All
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}