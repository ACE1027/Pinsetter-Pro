import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Mail, Shield } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";

const positionHierarchy = [
  { value: "general_manager", label: "General Manager", level: 1 },
  { value: "service_manager", label: "Service Manager", level: 2 },
  { value: "assistant_manager", label: "Assistant Manager", level: 3 },
  { value: "senior_mechanic", label: "Senior Mechanic", level: 4 },
  { value: "lead_mechanic", label: "Lead Mechanic", level: 5 },
  { value: "mechanic", label: "Mechanic", level: 6 },
  { value: "mechanic_apprentice", label: "Mechanic Apprentice", level: 7 },
  { value: "front_desk_supervisor", label: "Front Desk Supervisor", level: 8 },
  { value: "front_desk_staff", label: "Front Desk Staff", level: 9 },
];

export default function InviteUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    email: "",
    notes: "",
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  
  // Check if user is lead mechanic or higher (level 5 or lower in hierarchy)
  const userPositionLevel = user?.position ? positionHierarchy.find(p => p.value === user.position)?.level : 999;
  const isLeadOrHigher = userPositionLevel <= 5;
  
  const canInvite = isAdmin || isManager || isLeadOrHigher;

  const sendEmailMutation = useMutation({
    mutationFn: async (data) => {
      const emailBody = `Hello,

You have been invited to join the PinSetter Pro service management system.

${data.notes ? `Notes from ${user?.full_name || user?.email}:\n${data.notes}\n\n` : ''}To complete your registration:

1. An administrator will send you an invitation link via the Base44 dashboard
2. Click the invitation link in your email
3. Create your account password
4. Complete your profile by selecting your position and location

If you have any questions, please contact ${user?.full_name || user?.email}.

---
This is an automated message from PinSetter Pro.`;

      return base44.integrations.Core.SendEmail({
        to: data.email,
        subject: "Invitation to PinSetter Pro - Action Required",
        body: emailBody,
        from_name: "PinSetter Pro"
      });
    },
    onSuccess: () => {
      toast.success("Invitation email sent! Please complete the invite in the Base44 dashboard.");
      setFormData({ email: "", notes: "" });
    },
    onError: () => {
      toast.error("Failed to send invitation email");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.email) {
      toast.error("Please enter an email address");
      return;
    }
    
    sendEmailMutation.mutate(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!canInvite) {
    return (
      <div className="min-h-screen bg-slate-50 p-6 lg:p-8">
        <div className="max-w-4xl mx-auto text-center py-12">
          <Shield className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Restricted</h2>
          <p className="text-slate-600">Only lead mechanics and above can invite new users.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6 lg:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("UserManagement"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Invite New User</h1>
            <p className="text-slate-600 mt-1">Send an invitation to join your team</p>
          </div>
        </div>

        <Card className="shadow-lg border-slate-200">
          <CardHeader className="border-b border-slate-200">
            <CardTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-600" />
              New User Invitation
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <Alert className="mb-6 bg-blue-50 border-blue-200">
              <AlertDescription className="text-blue-900 text-sm">
                <strong>New Self-Service Process:</strong> The invited user will receive an email notification and then complete their own profile after accepting the invitation. They will select their own position and location during onboarding.
              </AlertDescription>
            </Alert>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="user@example.com"
                  required
                />
                <p className="text-xs text-slate-500">
                  This person will receive instructions to complete their registration
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Welcome Message (Optional)</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleChange('notes', e.target.value)}
                  placeholder="Add a personal welcome message for the new user..."
                  rows={4}
                />
              </div>

              <Alert className="bg-amber-50 border-amber-200">
                <AlertDescription className="text-amber-900 text-sm">
                  <strong>Next Steps:</strong> After sending this notification, you must complete the invitation process through the Base44 dashboard:
                  <ol className="list-decimal list-inside mt-2 space-y-1">
                    <li>Go to Dashboard → Users → Invite User</li>
                    <li>Enter the same email address: <strong>{formData.email || "[email]"}</strong></li>
                    <li>Send the official invitation</li>
                    <li>The user will complete their profile after accepting</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate(createPageUrl("UserManagement"))}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={sendEmailMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {sendEmailMutation.isPending ? "Sending..." : "Send Invitation Notice"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}