import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useTheme } from "@/components/ThemeContext";
import { useLocation } from "../components/LocationContext";
import { Wrench, AlertCircle } from "lucide-react";
import { getTemplateForMachine } from "../components/service/ServiceCallTemplates";

export default function JetbackCallSheet() {
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);

  const urlParams = new URLSearchParams(window.location.search);
  const prefillLocationId = urlParams.get('bowling_alley_id');

  const template = getTemplateForMachine("Jetback Pinsetter");

  const [formData, setFormData] = useState({
    bowling_alley_id: prefillLocationId || "",
    lane_number: "",
    issue_type: "",
    category: "",
    subcategory: "",
    description: "",
    priority: "medium",
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.bowling_alley_id && !prefillLocationId && !formData.bowling_alley_id) {
        setFormData((prev) => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});
  }, [prefillLocationId]);

  const createMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.ServiceCall.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      navigate(createPageUrl("ServiceCalls"));
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const title = `Jetback - ${formData.issue_type} - Lane ${formData.lane_number}`;
    const description = `Issue Type: ${formData.issue_type}\nCategory: ${formData.category}\nSubcategory: ${formData.subcategory}\n\nAdditional Details:\n${formData.description}`;

    const serviceCallData = {
      bowling_alley_id: formData.bowling_alley_id || selectedLocationId || user?.bowling_alley_id,
      title,
      description,
      category: "lane_machine",
      machine_type: "Jetback Pinsetter",
      lane_number: formData.lane_number,
      priority: formData.priority,
      status: "open",
      device_timestamp: new Date().toISOString(),
    };

    createMutation.mutate(serviceCallData);
  };

  const availableSubcategories = formData.category ? template.subcategories[formData.category] || [] : [];

  return (
    <div className={`min-h-screen w-full overflow-x-hidden ${theme.bg}`}>
      <div className="p-4 sm:p-6 lg:p-8 w-full">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <h1 className={`text-3xl font-bold flex items-center gap-3 ${theme.text}`}>
              <Wrench className="w-8 h-8" />
              Jetback Pinsetter Call Sheet
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              Report Jetback Pinsetter machine issues
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'} backdrop-blur-sm`}>
              <CardHeader>
                <CardTitle className={theme.text}>Service Call Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="lane_number" className={theme.text}>Lane Number *</Label>
                  <Input
                    id="lane_number"
                    type="text"
                    placeholder="e.g., 12"
                    value={formData.lane_number}
                    onChange={(e) => setFormData({...formData, lane_number: e.target.value})}
                    required
                    className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}
                  />
                </div>

                <div>
                  <Label htmlFor="issue_type" className={theme.text}>Issue Type *</Label>
                  <Select
                    value={formData.issue_type}
                    onValueChange={(value) => setFormData({...formData, issue_type: value})}
                    required
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                      <SelectValue placeholder="Select issue type..." />
                    </SelectTrigger>
                    <SelectContent>
                      {template.issueTypes.map((type) => (
                        <SelectItem key={type.value} value={type.label}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="category" className={theme.text}>Category *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({...formData, category: value, subcategory: ""})}
                    required
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                      <SelectValue placeholder="Select category..." />
                    </SelectTrigger>
                    <SelectContent>
                      {template.descriptionCategories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {formData.category && (
                  <div>
                    <Label htmlFor="subcategory" className={theme.text}>Subcategory *</Label>
                    <Select
                      value={formData.subcategory}
                      onValueChange={(value) => setFormData({...formData, subcategory: value})}
                      required
                    >
                      <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                        <SelectValue placeholder="Select subcategory..." />
                      </SelectTrigger>
                      <SelectContent>
                        {availableSubcategories.map((sub) => (
                          <SelectItem key={sub.value} value={sub.label}>{sub.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div>
                  <Label htmlFor="priority" className={theme.text}>Priority *</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({...formData, priority: value})}
                    required
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description" className={theme.text}>Additional Details</Label>
                  <Textarea
                    id="description"
                    placeholder="Add any additional details about the issue..."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className={`min-h-[120px] ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
                  />
                </div>

                {formData.priority === "urgent" && (
                  <div className={`p-4 rounded-lg flex items-start gap-3 ${isDarkMode ? 'bg-red-950/30 border border-red-800' : 'bg-red-50 border border-red-200'}`}>
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className={`font-semibold text-sm ${isDarkMode ? 'text-red-400' : 'text-red-900'}`}>
                        Urgent Priority
                      </p>
                      <p className={`text-xs ${isDarkMode ? 'text-red-300' : 'text-red-700'}`}>
                        This will trigger immediate notifications to available mechanics
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex gap-3 mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(-1)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {createMutation.isPending ? "Creating..." : "Create Call Sheet"}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}