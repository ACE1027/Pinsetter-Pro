
import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, Wrench, Package, Plus, LogOut, Users, Building2, User, History, Calendar, TrendingUp, Shield, Moon, Sun, Settings, HelpCircle, Mail, ArrowLeft, MessageCircle, ClipboardList, CalendarPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { base44 } from "@/api/base44Client";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LocationProvider } from "@/components/LocationContext";
import LocationSelector from "@/components/LocationSelector";
import NotificationBell from "@/components/NotificationBell";
import { OfflineIndicator } from "@/components/offline/OfflineManager";
import GlobalSearch from "@/components/GlobalSearch";
import { useEnhancedNotifications } from "@/components/notifications/EnhancedNotificationSystem";
import { usePermissions } from "@/components/permissions/usePermissions";
import { ThemeProvider, useTheme, THEMES } from "@/components/ThemeContext";
import { useRealTimeNotifications } from "@/components/notifications/RealTimeNotificationMonitor";
import { LaneAlertMonitor } from "@/components/notifications/LaneAlertMonitor";
import { CertificationMonitor } from "@/components/certifications/CertificationMonitor";
import { Palette, Check, Search } from "lucide-react";
import LowStockAlerts from "@/components/inventory/LowStockAlerts";

function LayoutContent({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = React.useState(null);
  const [profileChecked, setProfileChecked] = React.useState(false);
  const { hasPermission, isAdmin } = usePermissions();
  const { theme, isDarkMode, currentTheme, changeTheme, toggleDarkMode } = useTheme();
  const [supportOpen, setSupportOpen] = React.useState(false);
  const [searchOpen, setSearchOpen] = React.useState(false);

  React.useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      
      // Check if user needs to complete profile
      // Skip check if already on CompleteProfile page
      if (currentPageName !== 'CompleteProfile') {
        const needsProfileCompletion = !u.position || !u.bowling_alley_id || !u.full_name;
        if (needsProfileCompletion) {
          navigate(createPageUrl("CompleteProfile"));
        }
      }
      
      setProfileChecked(true);
    }).catch(() => {
      setProfileChecked(true);
    });
  }, [currentPageName, navigate]);

  // Enhanced notifications
  useEnhancedNotifications(user);

  // Real-time notifications
  useRealTimeNotifications(user);

  // Lane alert monitoring
  const shouldMonitorLanes = user && (
    user.position === 'lead_mechanic' || 
    user.department === 'manager' || 
    user.role === 'admin'
  );

  // Don't render layout until profile check is complete
  if (!profileChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  // If on CompleteProfile page, render without sidebar
  if (currentPageName === 'CompleteProfile') {
    return children;
  }

  const isManager = user && (user.department === 'manager' || user.role === 'admin');

  // If user is not loaded yet, show loading
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  const navigationItems = [];

  // Dashboard - always visible
  navigationItems.push({
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  });

  // Service Calls
  if (hasPermission('service_call_view')) {
    navigationItems.push({
      title: "Service Calls",
      url: createPageUrl("ServiceCalls"),
      icon: Wrench,
    });
  }



  // Mechanics Dashboard
  if (user.department === 'mechanic' || user.department === 'manager' || user.role === 'admin') {
    navigationItems.push({
      title: "Mechanics Dashboard",
      url: createPageUrl("MechanicsDashboard"),
      icon: Settings,
    });
  }

  // Mobile Mechanic Hub (mechanics only, not managers/admins)
  if (user.department === 'mechanic' && user.role !== 'admin') {
    navigationItems.push({
      title: "Mobile Hub",
      url: createPageUrl("MobileMechanicHub"),
      icon: Wrench,
    });
  }

  // Manager Dashboard
  if (user.department === 'manager' || user.role === 'admin') {
    navigationItems.push({
      title: "Manager Dashboard",
      url: createPageUrl("ManagerDashboard"),
      icon: LayoutDashboard,
    });
    navigationItems.push({
      title: "Task Scheduling",
      url: createPageUrl("TaskScheduling"),
      icon: CalendarPlus,
    });
  }

  // Admin Dashboard
  if (user.role === 'admin') {
    navigationItems.push({
      title: "Admin Dashboard",
      url: createPageUrl("AdminDashboard"),
      icon: Shield,
    });
  }

  // Employee Dashboard
  navigationItems.push({
    title: "Employee Dashboard",
    url: createPageUrl("EmployeeDashboard"),
    icon: User,
  });

  // Help & Resources
  navigationItems.push({
    title: "Help & Resources",
    url: createPageUrl("HelpResources"),
    icon: HelpCircle,
  });

  // User Management
  if (hasPermission('user_view')) {
    navigationItems.push({
      title: "User Management",
      url: createPageUrl("UserManagement"),
      icon: Users,
    });
  }

  const handleLogout = () => {
    base44.auth.logout();
  };

  return (
    <LocationProvider>
      <SidebarProvider>
        <div className={`min-h-screen flex w-full max-w-full overflow-x-hidden ${theme.bg}`}>
          <OfflineIndicator />
          {shouldMonitorLanes && <LaneAlertMonitor user={user} />}
          <CertificationMonitor user={user} />
          <LowStockAlerts user={user} />
          <Sidebar className={`border-r ${theme.cardBorder} ${theme.cardBg}`}>
            <SidebarHeader className={`border-b p-4 ${theme.cardBorder}`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                  <Wrench className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-500">Pinsetter Pro</h2>
                  <p className="text-xs text-slate-500">Service Management</p>
                </div>
              </div>
            </SidebarHeader>
            
            <SidebarContent className="p-2">
              {/* Location Selector */}
              <SidebarGroup>
                <SidebarGroupContent>
                  <div className="px-2 mb-4">
                    <LocationSelector />
                    </div>
                    </SidebarGroupContent>
                    </SidebarGroup>

                    {(hasPermission('service_call_create') || user.department === 'mechanic' || user.department === 'manager' || user.role === 'admin') && (
                    <SidebarGroup>
                    <SidebarGroupLabel className={`text-xs font-semibold uppercase tracking-wider px-2 py-2 ${theme.textTertiary}`}>
                    Quick Actions
                    </SidebarGroupLabel>
                    <SidebarGroupContent>
                    <SidebarMenu>
                    {hasPermission('service_call_create') && (
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild className={`transition-colors rounded-lg ${theme.navHover}`}>
                        <Link to={createPageUrl("CreateServiceCall")} className={`flex items-center gap-3 px-3 py-2 text-slate-500`}>
                          <Plus className="w-5 h-5" />
                          <span>New Service Call</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    )}
                    {(user.department === 'mechanic' || user.department === 'manager' || user.role === 'admin') && (
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild className={`transition-colors rounded-lg ${theme.navHover}`}>
                        <Link to={createPageUrl("MyTasks")} className={`flex items-center gap-3 px-3 py-2 text-slate-500`}>
                          <ClipboardList className="w-5 h-5" />
                          <span>My Tasks</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    )}
                    </SidebarMenu>
                    </SidebarGroupContent>
                    </SidebarGroup>
                    )}

                    <SidebarGroup>
                    <SidebarGroupLabel className={`text-xs font-semibold uppercase tracking-wider px-2 py-2 ${theme.textTertiary}`}>
                    Navigation
                    </SidebarGroupLabel>
                    <SidebarGroupContent>
                    <SidebarMenu>
                    {navigationItems.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`transition-colors duration-200 rounded-lg mb-1 ${
                            location.pathname === item.url 
                              ? `${theme.navActive} text-white font-semibold shadow-md` 
                              : `text-slate-500 ${theme.navHover}`
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-3 py-2">
                            {React.createElement(item.icon, { className: "w-5 h-5" })}
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                    </SidebarMenu>
                    </SidebarGroupContent>
                    </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className={`border-t p-4 ${theme.cardBorder} mt-auto`}>
              {user ? (
                <div className="space-y-3">
                  <Link to={createPageUrl("Profile")} className={`flex items-center gap-3 rounded-lg p-2 transition-colors hover:bg-blue-600/10`}>
                        <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-md">
                          <span className="font-semibold text-sm text-white">
                            {(user.display_name || user.full_name)?.charAt(0) || user.email?.charAt(0)}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate text-slate-500">{user.display_name || user.full_name || user.email}</p>
                          <p className="text-xs truncate capitalize text-slate-500">
                            {user.department?.replace(/_/g, ' ') || user.role}
                          </p>
                        </div>
                      </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="outline"
                        className={`w-full flex items-center justify-center gap-2 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-white'}`}
                      >
                        <Settings className="w-4 h-4" />
                        <span>Settings</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel>App Settings</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate(createPageUrl("Profile"))}>
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setSupportOpen(true)}>
                        <HelpCircle className="w-4 h-4 mr-2" />
                        Help & Support
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="text-xs text-slate-500">Appearance</DropdownMenuLabel>
                      <DropdownMenuItem onClick={toggleDarkMode}>
                        {isDarkMode ? <Sun className="w-4 h-4 mr-2" /> : <Moon className="w-4 h-4 mr-2" />}
                        {isDarkMode ? 'Light Mode' : 'Dark Mode'}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="text-xs text-slate-500">Color Theme</DropdownMenuLabel>
                      {Object.values(THEMES).map((t) => (
                        <DropdownMenuItem 
                          key={t.id}
                          onClick={() => changeTheme(t.id)}
                          className={currentTheme === t.id ? 'bg-blue-50 text-blue-700' : ''}
                        >
                          <Palette className="w-4 h-4 mr-2" />
                          {t.name}
                          {currentTheme === t.id && <Check className="w-4 h-4 ml-auto" />}
                        </DropdownMenuItem>
                      ))}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate(createPageUrl("DashboardSettings"))}>
                        <LayoutDashboard className="w-4 h-4 mr-2" />
                        Dashboard Settings
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                        <LogOut className="w-4 h-4 mr-2" />
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                    </DropdownMenu>
                </div>
              ) : null}
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col min-w-0 max-w-full overflow-x-hidden">
            <header className={`border-b px-4 sm:px-6 py-4 ${theme.cardBg} ${theme.cardBorder} backdrop-blur-md`}>
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <SidebarTrigger className={`p-2 rounded-lg transition-colors lg:hidden hover:bg-blue-600/10 ${theme.text}`} />
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      navigate(-1);
                    }}
                    className={`${theme.text}`}
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <h1 className={`text-xl font-bold lg:hidden ${theme.text}`}>Pinsetter Pro</h1>
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setSearchOpen(true)}
                    className={`${theme.text}`}
                  >
                    <Search className="w-5 h-5" />
                  </Button>
                  <NotificationBell />
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild className="lg:hidden">
                      <Button variant="ghost" size="icon" className={`${theme.text}`}>
                        <Settings className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel>App Settings</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate(createPageUrl("Profile"))}>
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setSupportOpen(true)}>
                        <HelpCircle className="w-4 h-4 mr-2" />
                        Help & Support
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="text-xs text-slate-500">Appearance</DropdownMenuLabel>
                      <DropdownMenuItem onClick={toggleDarkMode}>
                        {isDarkMode ? <Sun className="w-4 h-4 mr-2" /> : <Moon className="w-4 h-4 mr-2" />}
                        {isDarkMode ? 'Light Mode' : 'Dark Mode'}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="text-xs text-slate-500">Color Theme</DropdownMenuLabel>
                      {Object.values(THEMES).map((t) => (
                        <DropdownMenuItem 
                          key={t.id}
                          onClick={() => changeTheme(t.id)}
                          className={currentTheme === t.id ? 'bg-blue-50 text-blue-700' : ''}
                        >
                          <Palette className="w-4 h-4 mr-2" />
                          {t.name}
                          {currentTheme === t.id && <Check className="w-4 h-4 ml-auto" />}
                        </DropdownMenuItem>
                      ))}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate(createPageUrl("DashboardSettings"))}>
                        <LayoutDashboard className="w-4 h-4 mr-2" />
                        Dashboard Settings
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                        <LogOut className="w-4 h-4 mr-2" />
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </header>

            <div className="flex-1 overflow-x-hidden overflow-y-auto max-w-full">
              {children}
            </div>
          </main>
        </div>
        <Dialog open={supportOpen} onOpenChange={setSupportOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Help & Support</DialogTitle>
              <DialogDescription>
                Contact the administration team for bug reports or assistance.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                <div className="p-2 bg-blue-100 rounded-full">
                  <Mail className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500">Email Support</p>
                  <a href="mailto:pinsetterpro2025@gmail.com" className="text-sm font-semibold text-blue-600 hover:underline">
                    pinsetterpro2025@gmail.com
                  </a>
                </div>
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={() => setSupportOpen(false)}>Close</Button>
            </div>
          </DialogContent>
        </Dialog>
        <GlobalSearch open={searchOpen} onOpenChange={setSearchOpen} />
        </SidebarProvider>
        </LocationProvider>
        );
        }

        export default function Layout({ children, currentPageName }) {
        return (
        <ThemeProvider>
        <LayoutContent children={children} currentPageName={currentPageName} />
        </ThemeProvider>
        );
        }
