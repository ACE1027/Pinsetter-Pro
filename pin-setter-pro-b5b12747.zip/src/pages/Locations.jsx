import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Building2, MapPin, Phone, Plus, Edit, Users as UsersIcon, Search, User, Upload, Image as ImageIcon, QrCode, Trash2 } from "lucide-react";
import LaneQRCode from "@/components/qr/LaneQRCode";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const positionHierarchy = {
  general_manager: { level: 1, label: "General Manager" },
  service_manager: { level: 2, label: "Service Manager" },
  assistant_manager: { level: 3, label: "Assistant Manager" },
  senior_mechanic: { level: 4, label: "Senior Mechanic" },
  lead_mechanic: { level: 5, label: "Lead Mechanic" },
  mechanic: { level: 6, label: "Mechanic" },
  mechanic_apprentice: { level: 7, label: "Mechanic Apprentice" },
  front_desk_supervisor: { level: 8, label: "Front Desk Supervisor" },
  front_desk_staff: { level: 9, label: "Front Desk Staff" },
};

export default function Locations() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState(null);
  const [staffDialogOpen, setStaffDialogOpen] = useState(false);
  const [selectedLocationForStaff, setSelectedLocationForStaff] = useState(null);
  const [qrDialogOpen, setQrDialogOpen] = useState(false);
  const [selectedLocationForQR, setSelectedLocationForQR] = useState(null);
  const [selectedLaneForQR, setSelectedLaneForQR] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [locationToDelete, setLocationToDelete] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    zip_code: "",
    phone: "",
    total_lanes: 0,
    machine_types: [],
    image_url: "",
    active: true,
  });
  const [uploadingImage, setUploadingImage] = useState(false);

  const machineTypeOptions = [
    "Original A Pinsetter",
    "A-2 Pinsetter",
    "Jetback Pinsetter",
    "String Pin Boost XT",
    "GS-X Machine",
    "Brunswick GSX NXT",
    "82-30",
    "82-70 Pinspotter",
    "82-90 Pinspotter",
    "90XLI Pinspotter",
    "Qubica AMF XLI Edge",
    "EDGE Free Fall Pinspotter",
    "EDGE String Pin Pinspotter",
    "Other"
  ];

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allLocations = [], isLoading } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BowlingAlley.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      resetForm();
      toast.success("Location added successfully");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BowlingAlley.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      resetForm();
      toast.success("Location updated successfully");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.BowlingAlley.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      toast.success("Location deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete location: " + error.message);
    }
  });

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  const canManage = isAdmin || isManager;

  // Render access restricted message if user cannot manage locations
  if (user === null || (!user && !isLoading) ) {
    return (
      <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
        <div className="max-w-4xl mx-auto w-full text-center py-12">
          <Building2 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h2 className={`text-2xl font-bold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Loading User Data...</h2>
          <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Please wait while we determine your access level.</p>
        </div>
      </div>
    );
  }

  if (!canManage) {
    return (
      <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
        <div className="max-w-4xl mx-auto w-full text-center py-12">
          <Building2 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h2 className={`text-2xl font-bold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Access Restricted</h2>
          <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Only managers and administrators can access location management.</p>
        </div>
      </div>
    );
  }

  // Managers only see their assigned location, Admins see all locations
  const locations = isAdmin 
    ? allLocations 
    : allLocations.filter(l => l.id === user.bowling_alley_id);

  const filteredLocations = locations.filter(location => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      location.name?.toLowerCase().includes(query) ||
      location.city?.toLowerCase().includes(query) ||
      location.state?.toLowerCase().includes(query) ||
      location.phone?.includes(query)
    );
  });

  const resetForm = () => {
    setDialogOpen(false);
    setEditingLocation(null);
    setFormData({
      name: "",
      address: "",
      city: "",
      state: "",
      zip_code: "",
      phone: "",
      total_lanes: 0,
      machine_types: [],
      image_url: "",
      active: true,
    });
  };

  const toggleMachineType = (machineType) => {
    setFormData(prev => {
      const current = prev.machine_types || [];
      if (current.includes(machineType)) {
        return { ...prev, machine_types: current.filter(t => t !== machineType) };
      } else {
        return { ...prev, machine_types: [...current, machineType] };
      }
    });
  };

  const handleEdit = (location) => {
    setEditingLocation(location);
    setFormData({
      name: location.name || "",
      address: location.address || "",
      city: location.city || "",
      state: location.state || "",
      zip_code: location.zip_code || "",
      phone: location.phone || "",
      total_lanes: location.total_lanes || 0,
      machine_types: location.machine_types || [],
      image_url: location.image_url || "",
      active: location.active !== false,
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingLocation) {
      updateMutation.mutate({ id: editingLocation.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      handleChange('image_url', file_url);
      toast.success("Image uploaded successfully");
    } catch (error) {
      toast.error("Failed to upload image");
    } finally {
      setUploadingImage(false);
    }
  };

  const getStaffCount = (locationId) => {
    return allUsers.filter(u => u.bowling_alley_id === locationId && u.active !== false).length;
  };

  const getLocationStaff = (locationId) => {
    return allUsers
      .filter(u => u.bowling_alley_id === locationId)
      .sort((a, b) => {
        const aLevel = positionHierarchy[a.position]?.level || 999;
        const bLevel = positionHierarchy[b.position]?.level || 999;
        return aLevel - bLevel;
      });
  };

  const handleViewStaff = (location) => {
    setSelectedLocationForStaff(location);
    setStaffDialogOpen(true);
  };

  const handleGenerateQR = (location, laneNumber) => {
    setSelectedLocationForQR(location);
    setSelectedLaneForQR(laneNumber);
    setQrDialogOpen(true);
  };

  const handleDeleteClick = (location) => {
    setLocationToDelete(location);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (locationToDelete) {
      deleteMutation.mutate(locationToDelete.id);
      setDeleteDialogOpen(false);
      setLocationToDelete(null);
    }
  };

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Locations</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              {isAdmin ? 'Manage all bowling center locations' : 'View your location details'}
            </p>
          </div>
          {isAdmin && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" onClick={() => setEditingLocation(null)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Location
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{editingLocation ? "Edit Location" : "Add New Location"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="image">Location Photo</Label>
                    <div className="flex items-center gap-4">
                      {formData.image_url ? (
                        <div className="relative w-32 h-32 rounded-lg overflow-hidden border-2 border-slate-200">
                          <img 
                            src={formData.image_url} 
                            alt="Location" 
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() => handleChange('image_url', '')}
                            className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </button>
                        </div>
                      ) : (
                        <div className="w-32 h-32 rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center">
                          <ImageIcon className="w-8 h-8 text-slate-400" />
                        </div>
                      )}
                      <div className="flex-1">
                        <Input
                          id="image"
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          disabled={uploadingImage}
                          className="cursor-pointer"
                        />
                        <p className="text-xs text-slate-500 mt-1">
                          {uploadingImage ? 'Uploading...' : 'Upload a photo of your location'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="name">Location Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleChange('name', e.target.value)}
                      placeholder="e.g., Downtown Bowl"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Street Address</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleChange('address', e.target.value)}
                      placeholder="123 Main Street"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => handleChange('city', e.target.value)}
                        placeholder="City"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        value={formData.state}
                        onChange={(e) => handleChange('state', e.target.value)}
                        placeholder="CA"
                        maxLength={2}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="zip_code">ZIP Code</Label>
                      <Input
                        id="zip_code"
                        value={formData.zip_code}
                        onChange={(e) => handleChange('zip_code', e.target.value)}
                        placeholder="12345"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => handleChange('phone', e.target.value)}
                        placeholder="(555) 123-4567"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="total_lanes">Total Lanes</Label>
                    <Input
                      id="total_lanes"
                      type="number"
                      min="0"
                      value={formData.total_lanes}
                      onChange={(e) => handleChange('total_lanes', parseInt(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Machine Types</Label>
                    <div className="border rounded-lg p-4 max-h-64 overflow-y-auto space-y-2">
                      {machineTypeOptions.map((machineType) => (
                        <div key={machineType} className="flex items-center space-x-2">
                          <Checkbox
                            id={machineType}
                            checked={(formData.machine_types || []).includes(machineType)}
                            onCheckedChange={() => toggleMachineType(machineType)}
                          />
                          <label
                            htmlFor={machineType}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            {machineType}
                          </label>
                        </div>
                      ))}
                    </div>
                    {formData.machine_types && formData.machine_types.length > 0 && (
                      <p className="text-xs text-slate-500 mt-2">
                        {formData.machine_types.length} machine type{formData.machine_types.length !== 1 ? 's' : ''} selected
                      </p>
                    )}
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createMutation.isPending || updateMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      {editingLocation ? "Update Location" : "Create Location"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search locations by name, city, state, or phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Locations Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-white rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredLocations.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLocations.map(location => (
              <Card key={location.id} className="hover:shadow-lg transition-shadow overflow-hidden">
                {location.image_url && (
                  <div className="h-48 w-full overflow-hidden">
                    <img 
                      src={location.image_url} 
                      alt={location.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex items-start gap-3">
                      {!location.image_url && (
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Building2 className="w-6 h-6 text-blue-600" />
                        </div>
                      )}
                      <div>
                        <CardTitle className="text-lg">{location.name}</CardTitle>
                        <Badge variant={location.active === false ? "secondary" : "default"} className="mt-2">
                          {location.active === false ? 'Inactive' : 'Active'}
                        </Badge>
                      </div>
                    </div>
                    {isAdmin && (
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(location)}>
                          <Edit className="w-4 h-4 text-slate-500" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDeleteClick(location)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {location.address && (
                    <div className="flex items-start gap-2 text-sm text-slate-600">
                      <MapPin className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <p>{location.address}</p>
                        {(location.city || location.state) && (
                          <p>{location.city}{location.city && location.state ? ', ' : ''}{location.state} {location.zip_code}</p>
                        )}
                      </div>
                    </div>
                  )}
                  {location.phone && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Phone className="w-4 h-4 text-slate-400" />
                      <span>{location.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <UsersIcon className="w-4 h-4 text-slate-400" />
                      <span>{getStaffCount(location.id)} staff members</span>
                    </div>
                    {getStaffCount(location.id) > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewStaff(location)}
                        className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 h-7 px-2"
                      >
                        View
                      </Button>
                    )}
                  </div>
                  {location.machine_types && location.machine_types.length > 0 && (
                    <div className="pt-2 border-t border-slate-200">
                      <p className="text-xs font-medium text-slate-500 mb-2">Machines:</p>
                      <div className="flex flex-wrap gap-1">
                        {location.machine_types.map((type, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {location.total_lanes > 0 && (
                    <div className="pt-2 border-t border-slate-200">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-slate-900">
                          {location.total_lanes} bowling lanes
                        </p>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-blue-600">
                              <QrCode className="w-4 h-4 mr-1" />
                              QR Codes
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="max-h-64 overflow-y-auto">
                            <DropdownMenuLabel>Generate QR Code for Lane</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {Array.from({ length: location.total_lanes }, (_, i) => i + 1).map(lane => (
                              <DropdownMenuItem 
                                key={lane} 
                                onClick={() => handleGenerateQR(location, lane.toString())}
                              >
                                Lane {lane}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-2 border-dashed border-slate-300">
            <CardContent className="p-12 text-center">
              <Building2 className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">No locations found</h3>
              <p className="text-slate-600 mb-4">
                {searchQuery 
                  ? "Try adjusting your search" 
                  : isAdmin 
                    ? "Add your first location to get started" 
                    : "No location assigned or available for your account."}
              </p>
              {isAdmin && !searchQuery && (
                <Button onClick={() => setDialogOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Location
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* QR Code Dialog */}
        <LaneQRCode 
          open={qrDialogOpen}
          onOpenChange={setQrDialogOpen}
          location={selectedLocationForQR}
          laneNumber={selectedLaneForQR}
        />

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Location</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete <strong>{locationToDelete?.name}</strong>? This action cannot be undone and will affect all associated data including service calls, staff assignments, and maintenance records.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleConfirmDelete}
                className="bg-red-600 hover:bg-red-700"
              >
                Delete Location
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Staff Dialog */}
        <Dialog open={staffDialogOpen} onOpenChange={setStaffDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UsersIcon className="w-5 h-5 text-blue-600" />
                Staff at {selectedLocationForStaff?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {selectedLocationForStaff && getLocationStaff(selectedLocationForStaff.id).length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50">
                      <TableHead>Name</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getLocationStaff(selectedLocationForStaff.id).map(staff => (
                      <TableRow key={staff.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center">
                              <User className="w-4 h-4 text-slate-600" />
                            </div>
                            <span className="font-medium">{staff.full_name || "No Name"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {positionHierarchy[staff.position]?.label || staff.position?.replace(/_/g, ' ') || '-'}
                          </Badge>
                        </TableCell>
                        <TableCell className="capitalize">
                          {staff.department?.replace(/_/g, ' ') || '-'}
                        </TableCell>
                        <TableCell className="text-sm text-slate-600">{staff.email}</TableCell>
                        <TableCell>
                          <Badge className={staff.active === false ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                            {staff.active === false ? 'Inactive' : 'Active'}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="p-8 text-center">
                  <UsersIcon className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No Staff Found</h3>
                  <p className="text-slate-600">No staff members are assigned to this location yet.</p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}