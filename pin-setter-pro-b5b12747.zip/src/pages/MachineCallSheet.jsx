import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTheme } from "@/components/ThemeContext";
import { useLocation } from "../components/LocationContext";
import { Wrench, ArrowRight } from "lucide-react";

const MACHINE_TYPE_ROUTES = {
  "Original A Pinsetter": "OriginalACallSheet",
  "A-2 Pinsetter": "A2CallSheet",
  "Jetback Pinsetter": "JetbackCallSheet",
  "String Pin Boost XT": "StringPinCallSheet",
  "GS-X Machine": "GSXCallSheet",
  "Brunswick GSX NXT": "GSXCallSheet",
  "82-30": "A2CallSheet",
  "82-70 Pinspotter": "A2CallSheet",
  "82-90 Pinspotter": "A2CallSheet",
  "90XLI Pinspotter": "A2CallSheet",
  "Qubica AMF XLI Edge": "StringPinCallSheet",
  "EDGE Free Fall Pinspotter": "StringPinCallSheet",
  "EDGE String Pin Pinspotter": "StringPinCallSheet",
};

export default function MachineCallSheet() {
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const effectiveLocationId = selectedLocationId || user?.bowling_alley_id;
  const currentLocation = locations.find(l => l.id === effectiveLocationId);

  const machineTypes = currentLocation?.machine_types || [];

  // If only one machine type, auto-redirect
  useEffect(() => {
    if (machineTypes.length === 1 && currentLocation) {
      const routeName = MACHINE_TYPE_ROUTES[machineTypes[0]];
      if (routeName) {
        navigate(createPageUrl(routeName) + `?bowling_alley_id=${currentLocation.id}`);
      }
    }
  }, [machineTypes, currentLocation, navigate]);

  const handleSelectMachine = (machineType) => {
    const routeName = MACHINE_TYPE_ROUTES[machineType];
    if (routeName) {
      navigate(createPageUrl(routeName) + `?bowling_alley_id=${currentLocation.id}`);
    } else {
      // Fallback to general service call form
      navigate(createPageUrl("CreateServiceCall"));
    }
  };

  if (!currentLocation) {
    return (
      <div className={`min-h-screen w-full overflow-x-hidden ${theme.bg}`}>
        <div className="p-4 sm:p-6 lg:p-8 w-full">
          <div className="max-w-3xl mx-auto">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'} backdrop-blur-sm`}>
              <CardContent className="p-12 text-center">
                <Wrench className={`w-16 h-16 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                <h2 className={`text-2xl font-bold mb-2 ${theme.text}`}>No Location Selected</h2>
                <p className={`mb-6 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Please select a location to create a service call
                </p>
                <Button onClick={() => navigate(createPageUrl("Dashboard"))}>
                  Go to Dashboard
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (machineTypes.length === 0) {
    return (
      <div className={`min-h-screen w-full overflow-x-hidden ${theme.bg}`}>
        <div className="p-4 sm:p-6 lg:p-8 w-full">
          <div className="max-w-3xl mx-auto">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'} backdrop-blur-sm`}>
              <CardContent className="p-12 text-center">
                <Wrench className={`w-16 h-16 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                <h2 className={`text-2xl font-bold mb-2 ${theme.text}`}>No Machine Types Configured</h2>
                <p className={`mb-6 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {currentLocation.name} doesn't have any machine types configured yet.
                </p>
                <Button onClick={() => navigate(createPageUrl("CreateServiceCall"))}>
                  Use General Service Call Form
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // If we get here, there are multiple machine types
  return (
    <div className={`min-h-screen w-full overflow-x-hidden ${theme.bg}`}>
      <div className="p-4 sm:p-6 lg:p-8 w-full">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <h1 className={`text-3xl font-bold flex items-center gap-3 ${theme.text}`}>
              <Wrench className="w-8 h-8" />
              Select Machine Type
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              {currentLocation.name} - Choose the machine type for your service call
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {machineTypes.map((machineType) => (
              <Card
                key={machineType}
                className={`shadow-md hover:shadow-xl transition-all duration-200 cursor-pointer ${
                  isDarkMode ? 'bg-slate-900/80 border-slate-800 hover:border-blue-700' : 'bg-white/80 border-slate-200 hover:border-blue-500'
                } backdrop-blur-sm`}
                onClick={() => handleSelectMachine(machineType)}
              >
                <CardHeader>
                  <CardTitle className={`flex items-center justify-between ${theme.text}`}>
                    <span>{machineType}</span>
                    <ArrowRight className="w-5 h-5 text-blue-600" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    Create a call sheet for this machine type
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-6 text-center">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("CreateServiceCall"))}
            >
              Use General Service Call Form Instead
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}