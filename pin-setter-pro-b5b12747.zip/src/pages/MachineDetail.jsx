import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/components/ThemeContext";
import {
  ArrowLeft,
  Wrench,
  Calendar,
  MapPin,
  TrendingUp,
  Clock,
  AlertCircle,
  CheckCircle2,
  Activity
} from "lucide-react";
import { format, differenceInDays } from "date-fns";
import ServiceCallCard from "@/components/service/ServiceCallCard";

export default function MachineDetail() {
  const { theme, isDarkMode } = useTheme();
  const location = useLocation();
  const [user, setUser] = useState(null);
  const searchParams = new URLSearchParams(location.search);
  const machineId = searchParams.get("id");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: machine, isLoading: machineLoading } = useQuery({
    queryKey: ['machine', machineId],
    queryFn: () => base44.entities.Machine.list().then(m => m.find(x => x.id === machineId)),
    enabled: !!machineId,
  });

  const { data: bowlingAlley } = useQuery({
    queryKey: ['location', machine?.bowling_alley_id],
    queryFn: () => base44.entities.BowlingAlley.list().then(l => l.find(x => x.id === machine?.bowling_alley_id)),
    enabled: !!machine?.bowling_alley_id,
  });

  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls', machineId],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    enabled: !!machineId,
  });

  const { data: scheduledMaintenance = [] } = useQuery({
    queryKey: ['scheduledMaintenance', machineId],
    queryFn: () => base44.entities.ScheduledMaintenance.list('-scheduled_date'),
    enabled: !!machineId,
  });

  const { data: repairLogs = [] } = useQuery({
    queryKey: ['repairLogs', machineId],
    queryFn: () => base44.entities.MachineRepairLog.list('-created_date'),
    enabled: !!machineId,
  });

  if (machineLoading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme.bg}`}>
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  if (!machine) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme.bg}`}>
        <div className="text-center">
          <h2 className={`text-xl font-bold mb-2 ${theme.text}`}>Machine Not Found</h2>
          <Link to={createPageUrl("MachineInventory")}>
            <Button variant="outline">Back to Machines</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Filter service calls for this machine
  const machineServiceCalls = serviceCalls.filter(call => 
    call.machine_type === machine.machine_type && 
    call.lane_number === machine.lane_number &&
    call.bowling_alley_id === machine.bowling_alley_id
  );

  // Filter maintenance for this machine
  const machineMaintenance = scheduledMaintenance.filter(m =>
    m.machine_type === machine.machine_type &&
    m.lane_number === machine.lane_number &&
    m.bowling_alley_id === machine.bowling_alley_id
  );

  // Filter repair logs for this machine
  const machineRepairLogs = repairLogs.filter(log =>
    log.machine_type === machine.machine_type &&
    log.lane_number === machine.lane_number &&
    log.bowling_alley_id === machine.bowling_alley_id
  );

  // Calculate statistics
  const totalServiceCalls = machineServiceCalls.length;
  const openCalls = machineServiceCalls.filter(c => c.status === 'open').length;
  const completedCalls = machineServiceCalls.filter(c => c.status === 'completed').length;
  const avgResolutionTime = machineServiceCalls
    .filter(c => c.status === 'completed' && c.completed_date)
    .reduce((acc, call) => {
      const created = new Date(call.created_date);
      const completed = new Date(call.completed_date);
      return acc + differenceInDays(completed, created);
    }, 0) / (completedCalls || 1);

  const installDate = machine.installation_date ? new Date(machine.installation_date) : null;
  const daysInService = installDate ? differenceInDays(new Date(), installDate) : 0;
  const uptime = totalServiceCalls > 0 ? ((daysInService - totalServiceCalls) / daysInService * 100).toFixed(1) : 100;

  const maintenanceCompleted = machineMaintenance.filter(m => m.status === 'completed').length;
  const maintenancePending = machineMaintenance.filter(m => m.status === 'scheduled' || m.status === 'in_progress').length;

  return (
    <div className={`min-h-screen ${theme.bg}`}>
      <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6 w-full overflow-x-hidden">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("MachineInventory")}>
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className={`text-3xl font-bold ${theme.text}`}>
              {machine.machine_type} - Lane {machine.lane_number}
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              {bowlingAlley?.name || 'Loading location...'}
            </p>
          </div>
          <Badge className={machine.status === 'operational' ? 'bg-green-600' : machine.status === 'maintenance' ? 'bg-yellow-600' : 'bg-red-600'}>
            {machine.status || 'Unknown'}
          </Badge>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Service Calls</p>
                  <p className={`text-2xl font-bold mt-1 ${theme.text}`}>{totalServiceCalls}</p>
                </div>
                <Wrench className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Uptime</p>
                  <p className={`text-2xl font-bold mt-1 ${theme.text}`}>{uptime}%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Avg Resolution</p>
                  <p className={`text-2xl font-bold mt-1 ${theme.text}`}>{avgResolutionTime.toFixed(1)}d</p>
                </div>
                <Clock className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Days in Service</p>
                  <p className={`text-2xl font-bold mt-1 ${theme.text}`}>{daysInService}</p>
                </div>
                <Activity className="w-8 h-8 text-amber-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Machine Details */}
        <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
          <CardHeader>
            <CardTitle className={theme.text}>Machine Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Machine Type</p>
                  <p className={`mt-1 ${theme.text}`}>{machine.machine_type}</p>
                </div>
                <div>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Lane Number</p>
                  <p className={`mt-1 ${theme.text}`}>{machine.lane_number}</p>
                </div>
                <div>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Serial Number</p>
                  <p className={`mt-1 ${theme.text}`}>{machine.serial_number || 'N/A'}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Installation Date</p>
                  <p className={`mt-1 ${theme.text}`}>
                    {installDate ? format(installDate, 'MMM dd, yyyy') : 'N/A'}
                  </p>
                </div>
                <div>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Last Service Date</p>
                  <p className={`mt-1 ${theme.text}`}>
                    {machine.last_service_date ? format(new Date(machine.last_service_date), 'MMM dd, yyyy') : 'N/A'}
                  </p>
                </div>
                <div>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Notes</p>
                  <p className={`mt-1 ${theme.text}`}>{machine.notes || 'No notes available'}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for History */}
        <Tabs defaultValue="service_calls" className="w-full">
          <TabsList className={`grid w-full grid-cols-3 ${isDarkMode ? 'bg-slate-800' : ''}`}>
            <TabsTrigger value="service_calls">
              Service Calls ({totalServiceCalls})
            </TabsTrigger>
            <TabsTrigger value="maintenance">
              Maintenance ({machineMaintenance.length})
            </TabsTrigger>
            <TabsTrigger value="repair_logs">
              Repair Logs ({machineRepairLogs.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="service_calls" className="mt-6">
            {machineServiceCalls.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 w-full">
                {machineServiceCalls.map(call => (
                  <ServiceCallCard key={call.id} call={call} />
                ))}
              </div>
            ) : (
              <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardContent className="p-12 text-center">
                  <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <p className={theme.text}>No service calls recorded for this machine</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="maintenance" className="mt-6">
            {machineMaintenance.length > 0 ? (
              <div className="space-y-4 w-full">
                {machineMaintenance.map(maintenance => (
                  <Card key={maintenance.id} className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className={`font-semibold ${theme.text}`}>{maintenance.maintenance_type}</h3>
                            <Badge className={
                              maintenance.status === 'completed' ? 'bg-green-600' :
                              maintenance.status === 'in_progress' ? 'bg-blue-600' :
                              maintenance.status === 'overdue' ? 'bg-red-600' :
                              'bg-slate-600'
                            }>
                              {maintenance.status}
                            </Badge>
                          </div>
                          <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                            {maintenance.description}
                          </p>
                          <div className={`flex items-center gap-4 mt-3 text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Scheduled: {format(new Date(maintenance.scheduled_date), 'MMM dd, yyyy')}
                            </span>
                            {maintenance.due_date && (
                              <span className="flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                Due: {format(new Date(maintenance.due_date), 'MMM dd, yyyy')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardContent className="p-12 text-center">
                  <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className={theme.text}>No maintenance scheduled for this machine</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="repair_logs" className="mt-6">
            {machineRepairLogs.length > 0 ? (
              <div className="space-y-4 w-full">
                {machineRepairLogs.map(log => (
                  <Card key={log.id} className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className="bg-blue-600 capitalize">
                              {log.repair_type?.replace(/_/g, ' ')}
                            </Badge>
                            <Badge variant="outline" className={
                              log.status === 'completed' ? 'border-green-600 text-green-600' :
                              log.status === 'in_progress' ? 'border-blue-600 text-blue-600' :
                              'border-slate-600 text-slate-600'
                            }>
                              {log.status}
                            </Badge>
                          </div>
                          <p className={`text-sm font-medium ${theme.text}`}>{log.description}</p>
                        </div>
                        <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          {format(new Date(log.created_date), 'MMM dd, yyyy')}
                        </p>
                      </div>
                      {log.parts_used && (
                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          <strong>Parts:</strong> {log.parts_used}
                        </p>
                      )}
                      {log.time_spent && (
                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          <strong>Time:</strong> {log.time_spent} minutes
                        </p>
                      )}
                      {log.notes && (
                        <p className={`text-sm mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          {log.notes}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardContent className="p-12 text-center">
                  <Wrench className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className={theme.text}>No repair logs recorded for this machine</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}