import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Plus, Search, Settings, AlertCircle, CheckCircle2, XCircle, Edit, Trash2, Calendar, Hash, Activity, AlertTriangle, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { useLocation as useLocationContext } from "@/components/LocationContext";
import { useTheme } from "@/components/ThemeContext";
import { format, differenceInDays } from "date-fns";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const MACHINE_TYPES = [
  "Original A Pinsetter",
  "A-2 Pinsetter",
  "Jetback Pinsetter",
  "String Pin Boost XT",
  "GS-X Machine",
  "Brunswick GSX NXT",
  "82-30",
  "82-70 Pinspotter",
  "82-90 Pinspotter",
  "90XLI Pinspotter",
  "Qubica AMF XLI Edge",
  "EDGE Free Fall Pinspotter",
  "EDGE String Pin Pinspotter",
  "Other"
];

export default function MachineInventory() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocationContext();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [machineTypeFilter, setMachineTypeFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMachine, setEditingMachine] = useState(null);
  const [formData, setFormData] = useState({
    machine_type: "",
    serial_number: "",
    lane_number: "",
    installation_date: "",
    status: "operational",
    manufacturer: "",
    model_number: "",
    last_service_date: "",
    next_service_due: "",
    warranty_expiration: "",
    notes: "",
    purchase_cost: "",
    photo_url: ""
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allMachines = [], isLoading } = useQuery({
    queryKey: ['machines'],
    queryFn: () => base44.entities.Machine.list('-created_date'),
    initialData: [],
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    initialData: [],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: maintenanceTasks = [] } = useQuery({
    queryKey: ['preventativeMaintenance'],
    queryFn: () => base44.entities.PreventativeMaintenanceTask.list(),
    initialData: [],
    refetchInterval: 30000,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Machine.create({
      ...data,
      bowling_alley_id: effectiveLocationId
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['machines'] });
      resetForm();
      toast.success("Machine added successfully");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Machine.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['machines'] });
      resetForm();
      toast.success("Machine updated successfully");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Machine.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['machines'] });
      toast.success("Machine deleted successfully");
    },
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  const accessibleMachines = allMachines.filter(machine => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && machine.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const filteredMachines = accessibleMachines.filter(machine => {
    const matchesStatus = statusFilter === 'all' || machine.status === statusFilter;
    const matchesType = machineTypeFilter === 'all' || machine.machine_type === machineTypeFilter;
    const matchesSearch = !searchQuery || 
      machine.serial_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      machine.lane_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      machine.model_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      machine.manufacturer?.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesType && matchesSearch;
  });

  const statusCounts = {
    all: accessibleMachines.length,
    operational: accessibleMachines.filter(m => m.status === 'operational').length,
    needs_maintenance: accessibleMachines.filter(m => m.status === 'needs_maintenance').length,
    down: accessibleMachines.filter(m => m.status === 'down').length,
    decommissioned: accessibleMachines.filter(m => m.status === 'decommissioned').length,
  };

  const resetForm = () => {
    setFormData({
      machine_type: "",
      serial_number: "",
      lane_number: "",
      installation_date: "",
      status: "operational",
      manufacturer: "",
      model_number: "",
      last_service_date: "",
      next_service_due: "",
      warranty_expiration: "",
      notes: "",
      purchase_cost: "",
      photo_url: ""
    });
    setEditingMachine(null);
    setDialogOpen(false);
  };

  const handleEdit = (machine) => {
    setEditingMachine(machine);
    setFormData({
      machine_type: machine.machine_type || "",
      serial_number: machine.serial_number || "",
      lane_number: machine.lane_number || "",
      installation_date: machine.installation_date || "",
      status: machine.status || "operational",
      manufacturer: machine.manufacturer || "",
      model_number: machine.model_number || "",
      last_service_date: machine.last_service_date || "",
      next_service_due: machine.next_service_due || "",
      warranty_expiration: machine.warranty_expiration || "",
      notes: machine.notes || "",
      purchase_cost: machine.purchase_cost || "",
      photo_url: machine.photo_url || ""
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingMachine) {
      updateMutation.mutate({ id: editingMachine.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const getLocationName = (locationId) => {
    return locations.find(l => l.id === locationId)?.name || "Unknown Location";
  };

  const getActiveIssues = (laneNumber, locationId) => {
    return serviceCalls.filter(call => 
      call.bowling_alley_id === locationId &&
      call.lane_number === laneNumber &&
      call.status !== 'completed' && 
      call.status !== 'cancelled'
    );
  };

  const getMaintenanceHistory = (laneNumber, locationId) => {
    return serviceCalls.filter(call => 
      call.bowling_alley_id === locationId &&
      call.lane_number === laneNumber &&
      call.category === 'lane_machine' && 
      call.status === 'completed'
    );
  };

  const isServiceDue = (nextServiceDate) => {
    if (!nextServiceDate) return false;
    const daysUntilService = differenceInDays(new Date(nextServiceDate), new Date());
    return daysUntilService <= 7 && daysUntilService >= 0;
  };

  const isServiceOverdue = (nextServiceDate) => {
    if (!nextServiceDate) return false;
    return new Date(nextServiceDate) < new Date();
  };

  // Calculate real-time statistics
  const stats = {
    total: accessibleMachines.length,
    operational: accessibleMachines.filter(m => m.status === 'operational').length,
    needsMaintenance: accessibleMachines.filter(m => m.status === 'needs_maintenance').length,
    down: accessibleMachines.filter(m => m.status === 'down').length,
    serviceDue: accessibleMachines.filter(m => isServiceDue(m.next_service_due) || isServiceOverdue(m.next_service_due)).length,
    activeIssues: serviceCalls.filter(call => 
      accessibleMachines.some(m => m.lane_number === call.lane_number && m.bowling_alley_id === call.bowling_alley_id) &&
      call.status !== 'completed' && 
      call.status !== 'cancelled'
    ).length
  };

  const uptime = stats.total > 0 ? ((stats.operational / stats.total) * 100).toFixed(1) : 0;

  const statusConfig = {
    operational: { icon: CheckCircle2, color: 'bg-green-100 text-green-800', label: 'Operational' },
    needs_maintenance: { icon: AlertCircle, color: 'bg-yellow-100 text-yellow-800', label: 'Needs Maintenance' },
    down: { icon: XCircle, color: 'bg-red-100 text-red-800', label: 'Down' },
    decommissioned: { icon: XCircle, color: 'bg-slate-100 text-slate-800', label: 'Decommissioned' }
  };

  const canManage = user && (user.role === 'admin' || user.department === 'manager');

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${theme.text}`}>Machine Status Dashboard</h1>
            <p className={`mt-1 ${theme.textSecondary}`}>Real-time machine monitoring and status updates</p>
          </div>
          {canManage && effectiveLocationId && (
            <Button 
              onClick={() => setDialogOpen(true)} 
              className="bg-blue-600 hover:bg-blue-700 shadow-lg"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Machine
            </Button>
          )}
        </div>

        {/* Real-time Statistics Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">System Uptime</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className={`text-3xl font-bold ${theme.text}`}>{uptime}%</span>
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                </div>
                <Progress value={uptime} className="h-2" />
                <p className="text-xs text-slate-500">{stats.operational} of {stats.total} operational</p>
              </div>
            </CardContent>
          </Card>

          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">Active Issues</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className={`text-3xl font-bold ${stats.activeIssues > 0 ? 'text-red-600' : theme.text}`}>
                    {stats.activeIssues}
                  </span>
                  <Activity className={`w-5 h-5 ${stats.activeIssues > 0 ? 'text-red-500' : 'text-slate-400'}`} />
                </div>
                <p className="text-xs text-slate-500">Open service calls</p>
              </div>
            </CardContent>
          </Card>

          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">Maintenance Due</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className={`text-3xl font-bold ${stats.serviceDue > 0 ? 'text-yellow-600' : theme.text}`}>
                    {stats.serviceDue}
                  </span>
                  <AlertTriangle className={`w-5 h-5 ${stats.serviceDue > 0 ? 'text-yellow-500' : 'text-slate-400'}`} />
                </div>
                <p className="text-xs text-slate-500">Machines need service</p>
              </div>
            </CardContent>
          </Card>

          <Card className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">Machines Down</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className={`text-3xl font-bold ${stats.down > 0 ? 'text-red-600' : theme.text}`}>
                    {stats.down}
                  </span>
                  <XCircle className={`w-5 h-5 ${stats.down > 0 ? 'text-red-500' : 'text-slate-400'}`} />
                </div>
                <p className="text-xs text-slate-500">Currently offline</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className={`rounded-lg shadow-lg border p-4 mb-6 ${theme.cardBg} ${theme.cardBorder}`}>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search by serial, lane, model, or manufacturer..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
                />
              </div>
              <Select value={machineTypeFilter} onValueChange={setMachineTypeFilter}>
                <SelectTrigger className={`w-full sm:w-48 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : ''}`}>
                  <SelectValue placeholder="Filter by type..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {MACHINE_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Tabs value={statusFilter} onValueChange={setStatusFilter}>
              <TabsList className="grid grid-cols-5 w-full">
                <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
                <TabsTrigger value="operational">Operational ({statusCounts.operational})</TabsTrigger>
                <TabsTrigger value="needs_maintenance">Needs Service ({statusCounts.needs_maintenance})</TabsTrigger>
                <TabsTrigger value="down">Down ({statusCounts.down})</TabsTrigger>
                <TabsTrigger value="decommissioned">Decommissioned ({statusCounts.decommissioned})</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Machines Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className={`h-64 rounded-lg animate-pulse ${theme.cardBg}`} />
            ))}
          </div>
        ) : filteredMachines.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredMachines.map(machine => {
              const StatusIcon = statusConfig[machine.status]?.icon || Settings;
              const activeIssues = getActiveIssues(machine.lane_number, machine.bowling_alley_id);
              const maintenanceHistory = getMaintenanceHistory(machine.lane_number, machine.bowling_alley_id);
              const serviceDue = isServiceDue(machine.next_service_due);
              const serviceOverdue = isServiceOverdue(machine.next_service_due);
              
              return (
                <Card key={machine.id} className={`hover:shadow-lg transition-shadow ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : ''
                } ${activeIssues.length > 0 ? 'ring-2 ring-red-500' : ''}`}>
                  {machine.photo_url && (
                    <div className="h-40 overflow-hidden">
                      <img src={machine.photo_url} alt={machine.machine_type} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <Link to={createPageUrl("MachineDetail") + "?id=" + machine.id}>
                          <CardTitle className={`text-lg hover:text-blue-600 transition-colors cursor-pointer ${theme.text}`}>
                            {machine.machine_type}
                          </CardTitle>
                        </Link>
                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                          <Badge variant="outline" className="text-xs">
                            Lane {machine.lane_number || 'N/A'}
                          </Badge>
                          <Badge className={statusConfig[machine.status]?.color}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {statusConfig[machine.status]?.label}
                          </Badge>
                          {activeIssues.length > 0 && (
                            <Badge className="bg-red-100 text-red-800">
                              <Activity className="w-3 h-3 mr-1" />
                              {activeIssues.length} Active
                            </Badge>
                          )}
                          {serviceOverdue && (
                            <Badge className="bg-red-100 text-red-800">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Overdue
                            </Badge>
                          )}
                          {serviceDue && !serviceOverdue && (
                            <Badge className="bg-yellow-100 text-yellow-800">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Service Due
                            </Badge>
                          )}
                        </div>
                      </div>
                      {canManage && (
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(machine)}>
                            <Edit className="w-4 h-4 text-slate-500" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => {
                              if (confirm('Delete this machine?')) {
                                deleteMutation.mutate(machine.id);
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* Active Issues Section */}
                    {activeIssues.length > 0 && (
                      <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-red-950/20 border border-red-800' : 'bg-red-50 border border-red-200'}`}>
                        <p className="text-xs font-semibold text-red-600 mb-2">Active Issues:</p>
                        {activeIssues.slice(0, 2).map(issue => (
                          <div key={issue.id} className="flex items-start gap-2 mb-1">
                            <AlertCircle className="w-3 h-3 text-red-500 mt-0.5" />
                            <p className="text-xs text-red-700 flex-1">{issue.title}</p>
                          </div>
                        ))}
                        {activeIssues.length > 2 && (
                          <p className="text-xs text-red-600 mt-1">+{activeIssues.length - 2} more</p>
                        )}
                      </div>
                    )}

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Hash className="w-4 h-4 text-slate-400" />
                        <span className={`font-medium ${theme.textSecondary}`}>S/N: {machine.serial_number}</span>
                      </div>
                      {machine.model_number && (
                        <p className={`text-sm ${theme.textTertiary}`}>
                          Model: {machine.model_number}
                        </p>
                      )}
                      {machine.manufacturer && (
                        <p className={`text-sm ${theme.textTertiary}`}>
                          Manufacturer: {machine.manufacturer}
                        </p>
                      )}
                    </div>

                    {/* Service Timeline */}
                    <div className={`pt-3 border-t space-y-2 ${theme.cardBorder}`}>
                      {machine.last_service_date && (
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500">Last Service:</span>
                          <span className={theme.textSecondary}>{format(new Date(machine.last_service_date), 'MMM d, yyyy')}</span>
                        </div>
                      )}
                      {machine.next_service_due && (
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500">Next Service:</span>
                          <span className={`${serviceOverdue ? 'text-red-600 font-semibold' : serviceDue ? 'text-yellow-600 font-semibold' : theme.textSecondary}`}>
                            {format(new Date(machine.next_service_due), 'MMM d, yyyy')}
                          </span>
                        </div>
                      )}
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500">Service History:</span>
                        <span className={theme.textSecondary}>{maintenanceHistory.length} completed</span>
                      </div>
                    </div>

                    {isAdmin && (
                      <p className={`text-xs pt-2 border-t ${theme.cardBorder} ${theme.textTertiary}`}>
                        {getLocationName(machine.bowling_alley_id)}
                      </p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className={`rounded-lg border-2 border-dashed p-12 text-center ${theme.cardBg} ${theme.cardBorder}`}>
            <Settings className={`w-12 h-12 mx-auto mb-2 ${theme.textTertiary}`} />
            <h3 className={`text-lg font-semibold mb-2 ${theme.text}`}>No machines found</h3>
            <p className={`mb-4 ${theme.textSecondary}`}>
              {searchQuery || statusFilter !== 'all' || machineTypeFilter !== 'all'
                ? "Try adjusting your filters" 
                : canManage && effectiveLocationId
                  ? "Add your first machine to get started"
                  : "No machines in inventory"}
            </p>
            {canManage && effectiveLocationId && !searchQuery && (
              <Button onClick={() => setDialogOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Machine
              </Button>
            )}
          </div>
        )}

        {/* Add/Edit Machine Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingMachine ? "Edit Machine" : "Add New Machine"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="machine_type">Machine Type *</Label>
                  <Select 
                    value={formData.machine_type} 
                    onValueChange={(value) => setFormData({...formData, machine_type: value})}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {MACHINE_TYPES.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="serial_number">Serial Number *</Label>
                  <Input
                    id="serial_number"
                    value={formData.serial_number}
                    onChange={(e) => setFormData({...formData, serial_number: e.target.value})}
                    placeholder="e.g., A2-12345"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="lane_number">Lane Number</Label>
                  <Input
                    id="lane_number"
                    value={formData.lane_number}
                    onChange={(e) => setFormData({...formData, lane_number: e.target.value})}
                    placeholder="e.g., 5"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">Status *</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value) => setFormData({...formData, status: value})}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="operational">Operational</SelectItem>
                      <SelectItem value="needs_maintenance">Needs Maintenance</SelectItem>
                      <SelectItem value="down">Down</SelectItem>
                      <SelectItem value="decommissioned">Decommissioned</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="manufacturer">Manufacturer</Label>
                  <Input
                    id="manufacturer"
                    value={formData.manufacturer}
                    onChange={(e) => setFormData({...formData, manufacturer: e.target.value})}
                    placeholder="e.g., Brunswick"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="model_number">Model Number</Label>
                  <Input
                    id="model_number"
                    value={formData.model_number}
                    onChange={(e) => setFormData({...formData, model_number: e.target.value})}
                    placeholder="e.g., A-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="installation_date">Installation Date</Label>
                  <Input
                    id="installation_date"
                    type="date"
                    value={formData.installation_date}
                    onChange={(e) => setFormData({...formData, installation_date: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="last_service_date">Last Service</Label>
                  <Input
                    id="last_service_date"
                    type="date"
                    value={formData.last_service_date}
                    onChange={(e) => setFormData({...formData, last_service_date: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="next_service_due">Next Service Due</Label>
                  <Input
                    id="next_service_due"
                    type="date"
                    value={formData.next_service_due}
                    onChange={(e) => setFormData({...formData, next_service_due: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="warranty_expiration">Warranty Expiration</Label>
                  <Input
                    id="warranty_expiration"
                    type="date"
                    value={formData.warranty_expiration}
                    onChange={(e) => setFormData({...formData, warranty_expiration: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="purchase_cost">Purchase Cost ($)</Label>
                  <Input
                    id="purchase_cost"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.purchase_cost}
                    onChange={(e) => setFormData({...formData, purchase_cost: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Additional notes about this machine..."
                  rows={3}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {editingMachine ? "Update Machine" : "Add Machine"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}