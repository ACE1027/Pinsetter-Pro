import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wrench, Plus, Clock, Search, Edit, Trash2, Download, FileText, FileSpreadsheet, File, Image as ImageIcon, Video } from "lucide-react";
import AttachmentUploader from "@/components/attachments/AttachmentUploader";
import AttachmentGallery from "@/components/attachments/AttachmentGallery";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "../components/LocationContext";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";
import { format } from "date-fns";

export default function MachineRepairLog() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingLog, setEditingLog] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [repairTypeFilter, setRepairTypeFilter] = useState("all");
  const { selectedLocationId } = useLocation();

  const [formData, setFormData] = useState({
    bowling_alley_id: "",
    repair_type: "lane",
    lane_number: "",
    machine_type: "",
    description: "",
    parts_used: "",
    time_spent: "",
    notes: "",
    selected_parts: [],
    parts_category_filter: "all",
    assigned_to: "",
    log_date: format(new Date(), 'yyyy-MM-dd'),
    attachments: []
  });
  const [expandedLog, setExpandedLog] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.bowling_alley_id) {
        setFormData((prev) => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});
  }, []);

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['machineRepairLogs'],
    queryFn: () => base44.entities.MachineRepairLog.list('-created_date'),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: allParts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: []
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MachineRepairLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['machineRepairLogs'] });
      resetForm();
      toast.success("Repair log created successfully");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MachineRepairLog.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['machineRepairLogs'] });
      resetForm();
      toast.success("Repair log updated successfully");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MachineRepairLog.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['machineRepairLogs'] });
      toast.success("Repair log deleted successfully");
    }
  });

  const isAdmin = user && user.role === 'admin';
  const canCreate = user && (user.role === 'admin' || user.department === 'manager' || user.department === 'mechanic');

  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  const filteredLogs = logs.filter((log) => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    return log.bowling_alley_id === effectiveLocationId;
  }).filter((log) => {
    const matchesType = repairTypeFilter === 'all' || log.repair_type === repairTypeFilter;
    const matchesSearch = !searchQuery || (
      log.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.machine_type?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.lane_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.parts_used?.toLowerCase().includes(searchQuery.toLowerCase())
    );
    return matchesType && matchesSearch;
  });

  const resetForm = () => {
    setDialogOpen(false);
    setEditingLog(null);
    setFormData({
      bowling_alley_id: user?.bowling_alley_id || "",
      repair_type: "lane",
      lane_number: "",
      machine_type: "",
      description: "",
      parts_used: "",
      time_spent: "",
      notes: "",
      selected_parts: [],
      parts_category_filter: "all",
      assigned_to: "",
      log_date: format(new Date(), 'yyyy-MM-dd'),
      attachments: []
    });
  };

  const handleEdit = (log) => {
    setEditingLog(log);
    setFormData({
      bowling_alley_id: log.bowling_alley_id || "",
      repair_type: log.repair_type || "lane",
      lane_number: log.lane_number || "",
      machine_type: log.machine_type || "",
      description: log.description || "",
      parts_used: log.parts_used || "",
      time_spent: log.time_spent || "",
      notes: log.notes || "",
      selected_parts: [],
      parts_category_filter: "all",
      assigned_to: log.assigned_to || "",
      log_date: log.device_timestamp ? format(new Date(log.device_timestamp), 'yyyy-MM-dd') : format(new Date(log.created_date), 'yyyy-MM-dd'),
      attachments: log.attachments || []
    });
    setDialogOpen(true);
  };

  const handleDelete = (log) => {
    if (window.confirm('Are you sure you want to delete this repair log?')) {
      deleteMutation.mutate(log.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Use the selected date with current time
    const selectedDate = new Date(formData.log_date);
    const now = new Date();
    selectedDate.setHours(now.getHours(), now.getMinutes(), now.getSeconds());
    const deviceTimestamp = selectedDate.toISOString();

    const submitData = {
      ...formData,
      time_spent: formData.time_spent ? parseFloat(formData.time_spent) : null,
      device_timestamp: deviceTimestamp,
      attachments: formData.attachments || []
    };
    // Remove UI-only fields
    delete submitData.log_date;
    delete submitData.selected_parts;
    delete submitData.parts_category_filter;

    if (editingLog) {
      updateMutation.mutate({ id: editingLog.id, data: submitData });
    } else {
      createMutation.mutate(submitData);
    }
  };

  const getLocationName = (locationId) => {
    const location = locations.find((l) => l.id === locationId);
    return location?.name || 'Unknown';
  };

  const getUserName = (email) => {
    const foundUser = allUsers.find((u) => u.email === email);
    return foundUser?.full_name || email;
  };

  const selectedLocation = locations.find((l) => l.id === formData.bowling_alley_id);
  const laneOptions = selectedLocation?.total_lanes > 0 
    ? Array.from({ length: selectedLocation.total_lanes }, (_, i) => (i + 1).toString())
    : [];

  const availableParts = allParts.filter(part => {
    if (formData.parts_category_filter === "all") return true;
    return part.category === formData.parts_category_filter;
  });

  const partCategories = [
    "Gearbox Assembly",
    "Detector Assembly",
    "Cross Conveyor Assembly",
    "Turret Assembly",
    "Deck Assembly",
    "Rake Assembly",
    "Elevator Assembly",
    "Pit Assembly",
    "Pit Cushion Assembly",
    "Electrical",
    "Ball Return Assembly",
    "Belts",
    "Hardware",
    "Miscellaneous"
  ];

  // Filter users by selected location for assignment
  const assignableUsers = allUsers.filter((u) =>
    (u.department === 'mechanic' || u.department === 'manager' || u.role === 'admin') &&
    (u.bowling_alley_id === formData.bowling_alley_id || u.role === 'admin')
  );

  const getRepairTypeBadge = (type) => {
    const colors = {
      lane: "bg-blue-100 text-blue-800",
      front_of_house: "bg-purple-100 text-purple-800",
      general_maintenance: "bg-green-100 text-green-800",
      adjustments: "bg-yellow-100 text-yellow-800"
    };
    const labels = {
      lane: "Lane",
      front_of_house: "Front of House",
      general_maintenance: "General Maintenance",
      adjustments: "Adjustments"
    };
    return <Badge className={colors[type]}>{labels[type]}</Badge>;
  };

  const prepareExportData = () => {
    return filteredLogs.map(log => ({
      ...log,
      location_name: getLocationName(log.bowling_alley_id),
      created_by_name: getUserName(log.created_by)
    }));
  };

  const handleExportCSV = () => {
    if (filteredLogs.length === 0) {
      toast.error('No logs to export');
      return;
    }

    const headers = ['Date', 'Type', 'Lane', 'Machine', 'Location', 'Description', 'Parts Used', 'Time (min)', 'Technician', 'Notes'];
    const rows = filteredLogs.map((log) => [
      log.created_date ? format(new Date(log.created_date), 'yyyy-MM-dd HH:mm') : '',
      log.repair_type || '',
      log.lane_number || '',
      log.machine_type || '',
      getLocationName(log.bowling_alley_id),
      (log.description || '').replace(/\n/g, ' '),
      (log.parts_used || '').replace(/\n/g, ' '),
      log.time_spent || '',
      getUserName(log.created_by),
      (log.notes || '').replace(/\n/g, ' ')
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.map((cell) => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `repair-logs-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('CSV exported successfully');
  };

  const handleExportTSV = () => {
    if (filteredLogs.length === 0) {
      toast.error('No logs to export');
      return;
    }

    const headers = ['Date', 'Type', 'Lane', 'Machine', 'Location', 'Description', 'Parts Used', 'Time (min)', 'Technician', 'Notes'];
    const rows = filteredLogs.map((log) => [
      log.created_date ? format(new Date(log.created_date), 'yyyy-MM-dd HH:mm') : '',
      log.repair_type || '',
      log.lane_number || '',
      log.machine_type || '',
      getLocationName(log.bowling_alley_id),
      (log.description || '').replace(/\t/g, ' ').replace(/\n/g, ' '),
      (log.parts_used || '').replace(/\t/g, ' ').replace(/\n/g, ' '),
      log.time_spent || '',
      getUserName(log.created_by),
      (log.notes || '').replace(/\t/g, ' ').replace(/\n/g, ' ')
    ]);

    const tsvContent = [headers.join('\t'), ...rows.map((row) => row.join('\t'))].join('\n');
    const blob = new Blob([tsvContent], { type: 'text/tab-separated-values;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `repair-logs-${format(new Date(), 'yyyy-MM-dd')}.tsv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('TSV exported successfully');
  };

  const handleExportHTML = () => {
    if (filteredLogs.length === 0) {
      toast.error('No logs to export');
      return;
    }

    const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Machine Repair Log</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    h1 { color: #2563eb; }
    table { border-collapse: collapse; width: 100%; margin-top: 20px; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background-color: #2563eb; color: white; }
    tr:nth-child(even) { background-color: #f9fafb; }
    .meta { color: #64748b; margin: 10px 0; }
  </style>
</head>
<body>
  <h1>Machine Repair Log</h1>
  <div class="meta">Generated: ${new Date().toLocaleString()}</div>
  <div class="meta">Total Logs: ${filteredLogs.length}</div>
  <table>
    <thead>
      <tr>
        <th>Date</th>
        <th>Type</th>
        <th>Lane/Machine</th>
        <th>Description</th>
        <th>Location</th>
        <th>Technician</th>
      </tr>
    </thead>
    <tbody>
      ${filteredLogs.map(log => `
      <tr>
        <td>${log.created_date ? format(new Date(log.created_date), 'yyyy-MM-dd HH:mm') : ''}</td>
        <td>${log.repair_type || ''}</td>
        <td>${log.lane_number ? `Lane ${log.lane_number}` : log.machine_type || ''}</td>
        <td>${log.description || ''}</td>
        <td>${getLocationName(log.bowling_alley_id)}</td>
        <td>${getUserName(log.created_by)}</td>
      </tr>`).join('')}
    </tbody>
  </table>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `repair-logs-${format(new Date(), 'yyyy-MM-dd')}.html`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('HTML exported successfully');
  };

  const handleExport = async (exportFormat) => {
    if (filteredLogs.length === 0) {
      toast.error('No logs to export');
      return;
    }

    if (exportFormat === 'csv') {
      handleExportCSV();
      return;
    }
    if (exportFormat === 'tsv') {
      handleExportTSV();
      return;
    }
    if (exportFormat === 'html') {
      handleExportHTML();
      return;
    }

    try {
      toast.info(`Generating ${exportFormat.toUpperCase()} file...`);
      const exportData = prepareExportData();
      const filename = `repair-logs-${format(new Date(), 'yyyy-MM-dd')}`;
      
      const response = await base44.functions.invoke('exportMachineRepairLog', {
        logs: exportData,
        format: exportFormat,
        filename
      });

      const blob = new Blob([response.data], { 
        type: exportFormat === 'pdf' ? 'application/pdf' : 
              exportFormat === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' :
              exportFormat === 'ods' ? 'application/vnd.oasis.opendocument.spreadsheet' :
              'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      });
      
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `${filename}.${exportFormat}`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success(`${exportFormat.toUpperCase()} exported successfully`);
    } catch (error) {
      toast.error(`Failed to export ${exportFormat.toUpperCase()}`);
      console.error(error);
    }
  };

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${theme.bg}`}>
      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Machine Repair Log</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Track repairs and maintenance</p>
          </div>
          <div className="flex gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>Export Format</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleExport('csv')}>
                  <FileText className="w-4 h-4 mr-2" />
                  CSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('tsv')}>
                  <FileText className="w-4 h-4 mr-2" />
                  TSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('html')}>
                  <File className="w-4 h-4 mr-2" />
                  HTML
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleExport('pdf')}>
                  <FileText className="w-4 h-4 mr-2" />
                  PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('xlsx')}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('ods')}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  OpenDocument (.ods)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('docx')}>
                  <FileText className="w-4 h-4 mr-2" />
                  Word (.docx)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {canCreate && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" onClick={() => resetForm()}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Repair Log
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingLog ? "Edit Repair Log" : "Add New Repair Log"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bowling_alley_id">Location *</Label>
                    <Select
                      value={formData.bowling_alley_id}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, bowling_alley_id: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.filter((l) => l.active !== false).map((location) => (
                          <SelectItem key={location.id} value={location.id}>
                            {location.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="repair_type">Repair Type *</Label>
                    <Select
                      value={formData.repair_type}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, repair_type: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lane">Lane</SelectItem>
                        <SelectItem value="front_of_house">Front of House</SelectItem>
                        <SelectItem value="general_maintenance">General Maintenance</SelectItem>
                        <SelectItem value="adjustments">Adjustments</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="lane_number">Lane Number (Optional)</Label>
                    {laneOptions.length > 0 ? (
                      <Select
                        value={formData.lane_number}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, lane_number: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select lane or N/A" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                          <SelectItem value="N/A">N/A</SelectItem>
                          {laneOptions.map((lane) => (
                            <SelectItem key={lane} value={lane}>
                              Lane {lane}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input
                        id="lane_number"
                        value={formData.lane_number}
                        onChange={(e) => setFormData((prev) => ({ ...prev, lane_number: e.target.value }))}
                        placeholder="Select a location first"
                        disabled={!formData.bowling_alley_id}
                      />
                    )}
                  </div>

                  {formData.repair_type === 'lane' && (
                    <div className="space-y-2">
                      <Label htmlFor="machine_type">Machine Type</Label>
                      <Select
                        value={formData.machine_type}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, machine_type: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select machine type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Original A Pinsetter">Original A Pinsetter</SelectItem>
                          <SelectItem value="A-2 Pinsetter">A-2 Pinsetter</SelectItem>
                          <SelectItem value="Jetback Pinsetter">Jetback Pinsetter</SelectItem>
                          <SelectItem value="String Pin Boost XT">String Pin Boost XT</SelectItem>
                          <SelectItem value="GS-X Machine">GS-X Machine</SelectItem>
                          <SelectItem value="Brunswick GSX NXT">Brunswick GSX NXT</SelectItem>
                          <SelectItem value="82-30">82-30</SelectItem>
                          <SelectItem value="82-70 Pinspotter">82-70 Pinspotter</SelectItem>
                          <SelectItem value="82-90 Pinspotter">82-90 Pinspotter</SelectItem>
                          <SelectItem value="90XLI Pinspotter">90XLI Pinspotter</SelectItem>
                          <SelectItem value="Qubica AMF XLI Edge">Qubica AMF XLI Edge</SelectItem>
                          <SelectItem value="EDGE Free Fall Pinspotter">EDGE Free Fall Pinspotter</SelectItem>
                          <SelectItem value="EDGE String Pin Pinspotter">EDGE String Pin Pinspotter</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                      placeholder="Detailed description of repair work"
                      rows={4}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="parts_category">Parts Selector</Label>
                    <div className="space-y-3">
                      <Select
                        value={formData.parts_category_filter}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, parts_category_filter: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Filter by category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Categories</SelectItem>
                          {partCategories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select
                        value=""
                        onValueChange={(value) => {
                          const part = allParts.find(p => p.id === value);
                          if (part && !formData.selected_parts.find(p => p.id === part.id)) {
                            const newParts = [...formData.selected_parts, part];
                            const partsText = newParts.map(p => `${p.name} (${p.part_number})`).join(', ');
                            setFormData((prev) => ({ 
                              ...prev, 
                              selected_parts: newParts,
                              parts_used: partsText
                            }));
                          }
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select part from inventory" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                          {availableParts.length === 0 ? (
                            <div className="p-2 text-sm text-slate-500 text-center">
                              No parts available
                            </div>
                          ) : (
                            availableParts.map((part) => (
                              <SelectItem key={part.id} value={part.id}>
                                {part.name} - {part.part_number}
                                {part.category && ` (${part.category})`}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>

                      {formData.selected_parts.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {formData.selected_parts.map((part) => (
                            <Badge key={part.id} variant="secondary" className="cursor-pointer">
                              {part.name}
                              <button
                                type="button"
                                onClick={() => {
                                  const newParts = formData.selected_parts.filter(p => p.id !== part.id);
                                  const partsText = newParts.map(p => `${p.name} (${p.part_number})`).join(', ');
                                  setFormData((prev) => ({ 
                                    ...prev, 
                                    selected_parts: newParts,
                                    parts_used: partsText
                                  }));
                                }}
                                className="ml-2 hover:text-red-600"
                              >
                                ×
                              </button>
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="parts_used">Parts Used (Manual Entry)</Label>
                    <Textarea
                      id="parts_used"
                      value={formData.parts_used}
                      onChange={(e) => setFormData((prev) => ({ ...prev, parts_used: e.target.value }))}
                      placeholder="Or manually list parts used"
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time_spent">Time Spent (minutes)</Label>
                    <Input
                      id="time_spent"
                      type="number"
                      value={formData.time_spent}
                      onChange={(e) => setFormData((prev) => ({ ...prev, time_spent: e.target.value }))}
                      placeholder="e.g., 45"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="assigned_to">Assign To (Optional)</Label>
                    <Select
                      value={formData.assigned_to}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, assigned_to: value }))}
                      disabled={!formData.bowling_alley_id}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={formData.bowling_alley_id ? "Unassigned" : "Select location first"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>Unassigned</SelectItem>
                        {assignableUsers.map((mechanic) => (
                          <SelectItem key={mechanic.id} value={mechanic.email}>
                            {mechanic.full_name || mechanic.email}
                            {mechanic.role === 'admin' && ' (Admin)'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                      placeholder="Any additional notes"
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="log_date">Date</Label>
                    <Input
                      id="log_date"
                      type="date"
                      value={formData.log_date}
                      onChange={(e) => setFormData((prev) => ({ ...prev, log_date: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Photos & Videos</Label>
                    <AttachmentUploader 
                      attachments={formData.attachments}
                      onChange={(newAttachments) => setFormData((prev) => ({ ...prev, attachments: newAttachments }))}
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createMutation.isPending || updateMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      {editingLog ? "Update Log" : "Create Log"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
            )}
          </div>
        </div>

        <Card className={`shadow-sm p-3 mb-4 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search repair logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
              />
            </div>

            <div>
              <Label className="text-xs text-slate-600 mb-2 block">Repair Type</Label>
              <Tabs value={repairTypeFilter} onValueChange={setRepairTypeFilter} className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="lane">Lane</TabsTrigger>
                  <TabsTrigger value="front_of_house">Front of House</TabsTrigger>
                  <TabsTrigger value="general_maintenance">Maintenance</TabsTrigger>
                  <TabsTrigger value="adjustments">Adjustments</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </Card>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className={`h-48 rounded-lg animate-pulse ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`} />
            ))}
          </div>
        ) : filteredLogs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredLogs.map((log) => {
              const canEdit = user && (user.role === 'admin' || log.created_by === user.email);
              const canDelete = user && (user.role === 'admin' || (user.department === 'manager' && log.bowling_alley_id === user.bowling_alley_id));

              return (
                <Card 
                  key={log.id} 
                  className={`shadow-sm hover:shadow-md transition-shadow cursor-pointer ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}
                  onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        {getRepairTypeBadge(log.repair_type)}
                        {log.lane_number && (
                          <p className={`text-sm font-medium mt-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            Lane {log.lane_number}
                          </p>
                        )}
                        {log.machine_type && (
                          <p className={`text-sm font-medium mt-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            {log.machine_type}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                        {canEdit && (
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(log)} className="h-8 w-8">
                            <Edit className="w-4 h-4" />
                          </Button>
                        )}
                        {canDelete && (
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(log)} className="h-8 w-8 text-red-600">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className={`text-sm mb-3 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{log.description}</p>
                    
                    {expandedLog === log.id && (
                      <div className="space-y-3 mb-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                        {log.parts_used && (
                          <div>
                            <p className={`text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>Parts Used:</p>
                            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{log.parts_used}</p>
                          </div>
                        )}
                        {log.time_spent && (
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-500" />
                            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              Time Spent: {log.time_spent} minutes
                            </p>
                          </div>
                        )}
                        {log.notes && (
                          <div>
                            <p className={`text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>Notes:</p>
                            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{log.notes}</p>
                          </div>
                        )}
                        {log.assigned_to && (
                          <div>
                            <p className={`text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>Assigned To:</p>
                            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{getUserName(log.assigned_to)}</p>
                          </div>
                        )}
                      </div>
                    )}
                    {/* Attachment Preview */}
                    {log.attachments && log.attachments.length > 0 && expandedLog === log.id && (
                      <div className="mt-3 pt-3 border-t border-slate-200">
                        <p className={`text-xs font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>Attachments:</p>
                        <AttachmentGallery attachments={log.attachments} isDarkMode={isDarkMode} />
                      </div>
                    )}

                    <div className={`text-xs mt-3 pt-3 border-t ${isDarkMode ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'}`}>
                      <p>{getUserName(log.created_by)}</p>
                      <p>{format(new Date(log.created_date), 'MMM d, yyyy h:mm a')}</p>
                      <p className="text-slate-500">{getLocationName(log.bowling_alley_id)}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className={`rounded-lg border-2 border-dashed p-12 text-center ${isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-300'}`}>
            <Wrench className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>No repair logs found</h3>
            <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Start by creating your first repair log</p>
          </div>
        )}
        </div>
      </div>
    </div>
  );
}