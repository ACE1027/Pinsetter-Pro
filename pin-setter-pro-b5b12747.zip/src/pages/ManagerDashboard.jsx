import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CalendarX, ArrowLeftRight, Calendar, Clock, User, Check, X, AlertTriangle, TrendingUp, ExternalLink, Star, DollarSign, BarChart3, FileText, Download, Target, BookOpen, Plus, Search, Play, CheckCircle2, UserPlus, Users as UsersIcon, Trash2, Mail, Building2, MapPin, Phone } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, startOfWeek, addDays, isSameDay } from "date-fns";
import { toast } from "sonner";
import { useLocation } from "../components/LocationContext";
import { useTheme } from "@/components/ThemeContext";
import LiveActivityFeed from "@/components/activity/LiveActivityFeed";

export default function ManagerDashboard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const { selectedLocationId } = useLocation();
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [reviewType, setReviewType] = useState(null); // 'timeoff' or 'trade'
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [reviewNotes, setReviewNotes] = useState("");

  // Development state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [planDialogOpen, setPlanDialogOpen] = useState(false);
  const [goalDialogOpen, setGoalDialogOpen] = useState(false);
  const [trainingDialogOpen, setTrainingDialogOpen] = useState(false);
  const [moduleDialogOpen, setModuleDialogOpen] = useState(false);
  
  const [planForm, setPlanForm] = useState({
    title: "",
    description: "",
    start_date: "",
    target_completion_date: "",
    focus_areas: []
  });

  const [goalForm, setGoalForm] = useState({
    skill_name: "",
    category: "technical",
    current_level: 1,
    target_level: 5,
    target_date: ""
  });

  const [moduleForm, setModuleForm] = useState({
    title: "",
    description: "",
    category: "technical",
    content_type: "document",
    content_url: "",
    estimated_duration_minutes: 30,
    difficulty_level: "beginner",
    skill_tags: []
  });

  const [assignmentForm, setAssignmentForm] = useState({
    training_module_id: "",
    due_date: "",
    manager_notes: ""
  });

  // Onboarding state
  const [checklistDialogOpen, setChecklistDialogOpen] = useState(false);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [resourceDialogOpen, setResourceDialogOpen] = useState(false);
  
  const [checklistForm, setChecklistForm] = useState({
    employee_email: "",
    employee_name: "",
    position: "",
    start_date: "",
    template_id: ""
  });

  const [templateForm, setTemplateForm] = useState({
    name: "",
    description: "",
    position: "",
    tasks: []
  });

  const [resourceForm, setResourceForm] = useState({
    title: "",
    description: "",
    category: "policy",
    external_url: "",
    position_specific: [],
    required_reading: false
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      // Check if user is manager or admin
      if (u.department !== 'manager' && u.role !== 'admin') {
        toast.error("Access denied - Managers only");
        navigate(createPageUrl("Dashboard"));
      }
    }).catch(() => {});
  }, [navigate]);

  const { data: timeOffRequests = [] } = useQuery({
    queryKey: ['timeOffRequests'],
    queryFn: () => base44.entities.TimeOffRequest.list(),
    initialData: []
  });

  const { data: tradeRequests = [] } = useQuery({
    queryKey: ['tradeRequests'],
    queryFn: () => base44.entities.ShiftTradeRequest.list(),
    initialData: []
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ['userSchedules'],
    queryFn: () => base44.entities.UserSchedule.list(),
    initialData: []
  });

  const { data: users = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['performanceReviews'],
    queryFn: () => base44.entities.PerformanceReview.list(),
    initialData: []
  });

  const { data: timeEntries = [] } = useQuery({
    queryKey: ['timeEntries'],
    queryFn: () => base44.entities.TimeEntry.list('-clock_in'),
    initialData: []
  });

  const { data: developmentPlans = [] } = useQuery({
    queryKey: ['developmentPlans'],
    queryFn: () => base44.entities.DevelopmentPlan.list('-created_date'),
    initialData: []
  });

  const { data: skillGoals = [] } = useQuery({
    queryKey: ['skillGoals'],
    queryFn: () => base44.entities.SkillGoal.list(),
    initialData: []
  });

  const { data: trainingModules = [] } = useQuery({
    queryKey: ['trainingModules'],
    queryFn: () => base44.entities.TrainingModule.list(),
    initialData: []
  });

  const { data: trainingAssignments = [] } = useQuery({
    queryKey: ['trainingAssignments'],
    queryFn: () => base44.entities.TrainingAssignment.list('-assigned_date'),
    initialData: []
  });

  const { data: checklists = [] } = useQuery({
    queryKey: ['onboardingChecklists'],
    queryFn: () => base44.entities.OnboardingChecklist.list('-created_date'),
    initialData: []
  });

  const { data: onboardingTemplates = [] } = useQuery({
    queryKey: ['onboardingTemplates'],
    queryFn: () => base44.entities.OnboardingTemplate.list(),
    initialData: []
  });

  const { data: onboardingResources = [] } = useQuery({
    queryKey: ['onboardingResources'],
    queryFn: () => base44.entities.OnboardingResource.list('order'),
    initialData: []
  });

  const { data: onboardingTasks = [] } = useQuery({
    queryKey: ['onboardingTasks'],
    queryFn: () => base44.entities.OnboardingTask.list(),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const updateTimeOffMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TimeOffRequest.update(id, data),
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries({ queryKey: ['timeOffRequests'] });
      await base44.entities.Notification.create({
        user_email: updatedRequest.user_email,
        type: 'time_off_decision',
        title: `Time Off Request ${updatedRequest.status === 'approved' ? 'Approved' : 'Denied'}`,
        message: `Your time off request for ${format(new Date(updatedRequest.start_date), 'MMM d')} - ${format(new Date(updatedRequest.end_date), 'MMM d')} has been ${updatedRequest.status}`,
        priority: 'high',
        bowling_alley_id: updatedRequest.bowling_alley_id
      });
      setReviewDialogOpen(false);
      setSelectedRequest(null);
      setReviewNotes("");
      toast.success(`Request ${updatedRequest.status}`);
    }
  });

  const updateTradeMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ShiftTradeRequest.update(id, data),
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries({ queryKey: ['tradeRequests'] });
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      
      await base44.entities.Notification.create({
        user_email: updatedRequest.requester_email,
        type: 'shift_trade_decision',
        title: `Shift Trade ${updatedRequest.status === 'approved' ? 'Approved' : 'Rejected'}`,
        message: `Your shift trade request has been ${updatedRequest.status} by management`,
        priority: 'high',
        bowling_alley_id: updatedRequest.bowling_alley_id
      });
      
      if (updatedRequest.target_email) {
        await base44.entities.Notification.create({
          user_email: updatedRequest.target_email,
          type: 'shift_trade_decision',
          title: `Shift Trade ${updatedRequest.status === 'approved' ? 'Approved' : 'Rejected'}`,
          message: `The shift trade with ${getUserName(updatedRequest.requester_email)} has been ${updatedRequest.status}`,
          priority: 'high',
          bowling_alley_id: updatedRequest.bowling_alley_id
        });
      }
      
      if (updatedRequest.status === 'approved' && updatedRequest.target_schedule_id) {
        const requesterSchedule = schedules.find(s => s.id === updatedRequest.requester_schedule_id);
        const targetSchedule = schedules.find(s => s.id === updatedRequest.target_schedule_id);
        
        if (requesterSchedule && targetSchedule) {
          await base44.entities.UserSchedule.update(requesterSchedule.id, {
            user_email: targetSchedule.user_email
          });
          await base44.entities.UserSchedule.update(targetSchedule.id, {
            user_email: requesterSchedule.user_email
          });
        }
      }
      
      setReviewDialogOpen(false);
      setSelectedRequest(null);
      setReviewNotes("");
      toast.success(`Request ${updatedRequest.status}`);
    }
  });

  const createPlanMutation = useMutation({
    mutationFn: (data) => base44.entities.DevelopmentPlan.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['developmentPlans'] });
      setPlanDialogOpen(false);
      resetPlanForm();
      toast.success("Development plan created");
    }
  });

  const createGoalMutation = useMutation({
    mutationFn: (data) => base44.entities.SkillGoal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skillGoals'] });
      setGoalDialogOpen(false);
      resetGoalForm();
      toast.success("Skill goal created");
    }
  });

  const createModuleMutation = useMutation({
    mutationFn: (data) => base44.entities.TrainingModule.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trainingModules'] });
      setModuleDialogOpen(false);
      resetModuleForm();
      toast.success("Training module created");
    }
  });

  const createAssignmentMutation = useMutation({
    mutationFn: (data) => base44.entities.TrainingAssignment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trainingAssignments'] });
      setTrainingDialogOpen(false);
      resetAssignmentForm();
      toast.success("Training assigned");
    }
  });

  const createChecklistMutation = useMutation({
    mutationFn: async (data) => {
      const checklist = await base44.entities.OnboardingChecklist.create(data);
      const template = onboardingTemplates.find(t => t.id === data.template_id);
      
      if (template && template.tasks) {
        const startDate = new Date(data.start_date);
        const taskPromises = template.tasks.map(task => 
          base44.entities.OnboardingTask.create({
            checklist_id: checklist.id,
            employee_email: data.employee_email,
            title: task.title,
            description: task.description,
            category: task.category,
            due_date: addDays(startDate, task.due_days || 0).toISOString().split('T')[0],
            assigned_to_role: task.assigned_to_role,
            status: 'pending'
          })
        );
        await Promise.all(taskPromises);
      }
      
      await base44.entities.Notification.create({
        user_email: data.employee_email,
        type: 'onboarding_started',
        title: 'Welcome to the Team!',
        message: `Your onboarding checklist is ready. Complete all tasks by your start date.`,
        priority: 'high'
      });
      
      return checklist;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingChecklists'] });
      queryClient.invalidateQueries({ queryKey: ['onboardingTasks'] });
      setChecklistDialogOpen(false);
      resetChecklistForm();
      toast.success("Onboarding checklist created");
    }
  });

  const createOnboardingTemplateMutation = useMutation({
    mutationFn: (data) => base44.entities.OnboardingTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingTemplates'] });
      setTemplateDialogOpen(false);
      resetOnboardingTemplateForm();
      toast.success("Template created");
    }
  });

  const createOnboardingResourceMutation = useMutation({
    mutationFn: (data) => base44.entities.OnboardingResource.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingResources'] });
      setResourceDialogOpen(false);
      resetResourceForm();
      toast.success("Resource added");
    }
  });

  const deleteResourceMutation = useMutation({
    mutationFn: (id) => base44.entities.OnboardingResource.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingResources'] });
      toast.success("Resource deleted");
    }
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  // Filter requests by location
  const locationTimeOffRequests = timeOffRequests.filter(r => {
    if (isAdmin && selectedLocationId === 'all') return true;
    return r.bowling_alley_id === effectiveLocationId;
  });

  const locationTradeRequests = tradeRequests.filter(r => {
    if (isAdmin && selectedLocationId === 'all') return true;
    return r.bowling_alley_id === effectiveLocationId;
  });

  const locationSchedules = schedules.filter(s => {
    if (isAdmin && selectedLocationId === 'all') return true;
    return s.bowling_alley_id === effectiveLocationId;
  });

  const locationTimeEntries = timeEntries.filter(e => {
    if (isAdmin && selectedLocationId === 'all') return true;
    return e.bowling_alley_id === effectiveLocationId;
  });

  const pendingTimeOff = locationTimeOffRequests.filter(r => r.status === 'pending');
  const pendingTrades = locationTradeRequests.filter(r => r.status === 'accepted');

  // Upcoming reviews
  const today = new Date();
  const upcomingReviews = reviews.filter(r => {
    if (!r.next_review_date) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (r.bowling_alley_id !== effectiveLocationId) return false;
    
    const reviewDate = new Date(r.next_review_date);
    const daysUntil = Math.floor((reviewDate - today) / (1000 * 60 * 60 * 24));
    return daysUntil >= 0 && daysUntil <= 30; // Next 30 days
  }).sort((a, b) => new Date(a.next_review_date) - new Date(b.next_review_date));

  // Current week analysis
  const currentWeekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));
  
  const weekSchedules = locationSchedules.filter(schedule => {
    const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
    const scheduleDate = new Date(year, month - 1, dayNum);
    return weekDays.some(day => isSameDay(scheduleDate, day));
  });

  const calculateShiftHours = (startTime, endTime) => {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    const start = startHour + startMin / 60;
    const end = endHour + endMin / 60;
    return end > start ? end - start : (24 - start) + end;
  };

  const totalWeekHours = weekSchedules.reduce((total, schedule) => 
    total + calculateShiftHours(schedule.shift_start, schedule.shift_end), 0
  );

  const coverageByDay = weekDays.map(day => {
    const daySchedules = weekSchedules.filter(schedule => {
      const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return isSameDay(scheduleDate, day);
    });
    return {
      date: day,
      count: daySchedules.length,
      hours: daySchedules.reduce((total, s) => total + calculateShiftHours(s.shift_start, s.shift_end), 0)
    };
  });

  const lowCoverageDays = coverageByDay.filter(d => d.count < 2);

  const getUserName = (email) => {
    const foundUser = users.find(u => u.email === email);
    return foundUser?.display_name || foundUser?.full_name || email;
  };

  const getScheduleDetails = (scheduleId) => {
    const schedule = schedules.find(s => s.id === scheduleId);
    if (!schedule) return null;
    return {
      date: schedule.date,
      shift_start: schedule.shift_start,
      shift_end: schedule.shift_end
    };
  };

  const handleQuickReview = (type, request) => {
    setReviewType(type);
    setSelectedRequest(request);
    setReviewDialogOpen(true);
  };

  const submitReview = (status) => {
    if (!selectedRequest) return;
    
    const reviewData = {
      status,
      reviewed_by: user.email,
      reviewed_date: new Date().toISOString(),
      notes: reviewNotes
    };

    if (reviewType === 'timeoff') {
      updateTimeOffMutation.mutate({ id: selectedRequest.id, data: reviewData });
    } else {
      updateTradeMutation.mutate({ id: selectedRequest.id, data: reviewData });
    }
  };

  // Analytics calculations
  const defaultHourlyRate = 15; // Default rate if not set
  
  // Calculate labor costs
  const weeklyLaborCost = weekSchedules.reduce((total, schedule) => {
    const hours = calculateShiftHours(schedule.shift_start, schedule.shift_end);
    const userDetails = users.find(u => u.email === schedule.user_email);
    const rate = userDetails?.hourly_rate || defaultHourlyRate;
    return total + (hours * rate);
  }, 0);

  const dailyLaborCost = coverageByDay.map(day => {
    const daySchedules = weekSchedules.filter(schedule => {
      const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return isSameDay(scheduleDate, day.date);
    });
    
    const cost = daySchedules.reduce((total, schedule) => {
      const hours = calculateShiftHours(schedule.shift_start, schedule.shift_end);
      const userDetails = users.find(u => u.email === schedule.user_email);
      const rate = userDetails?.hourly_rate || defaultHourlyRate;
      return total + (hours * rate);
    }, 0);

    return {
      day: format(day.date, 'EEE'),
      cost: cost,
      hours: day.hours
    };
  });

  // Employee hours summary
  const employeeHours = locationSchedules.reduce((acc, schedule) => {
    const email = schedule.user_email;
    if (!acc[email]) {
      acc[email] = {
        name: getUserName(email),
        email: email,
        totalHours: 0,
        shifts: 0
      };
    }
    acc[email].totalHours += calculateShiftHours(schedule.shift_start, schedule.shift_end);
    acc[email].shifts += 1;
    return acc;
  }, {});

  const employeeHoursArray = Object.values(employeeHours).sort((a, b) => b.totalHours - a.totalHours);

  // Coverage data for charts
  const coverageChartData = coverageByDay.map(day => ({
    day: format(day.date, 'EEE'),
    staff: day.count,
    hours: day.hours
  }));

  // Export employee hours
  const exportEmployeeHours = () => {
    const csv = [
      ['Employee', 'Email', 'Total Hours', 'Shifts', 'Est. Cost'],
      ...employeeHoursArray.map(emp => {
        const userDetails = users.find(u => u.email === emp.email);
        const rate = userDetails?.hourly_rate || defaultHourlyRate;
        return [
          emp.name,
          emp.email,
          emp.totalHours.toFixed(2),
          emp.shifts,
          `$${(emp.totalHours * rate).toFixed(2)}`
        ];
      })
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `employee-hours-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    toast.success('Hours report exported');
  };

  const resetPlanForm = () => {
    setPlanForm({
      title: "",
      description: "",
      start_date: "",
      target_completion_date: "",
      focus_areas: []
    });
    setSelectedEmployee(null);
  };

  const resetGoalForm = () => {
    setGoalForm({
      skill_name: "",
      category: "technical",
      current_level: 1,
      target_level: 5,
      target_date: ""
    });
    setSelectedEmployee(null);
  };

  const resetModuleForm = () => {
    setModuleForm({
      title: "",
      description: "",
      category: "technical",
      content_type: "document",
      content_url: "",
      estimated_duration_minutes: 30,
      difficulty_level: "beginner",
      skill_tags: []
    });
  };

  const resetAssignmentForm = () => {
    setAssignmentForm({
      training_module_id: "",
      due_date: "",
      manager_notes: ""
    });
    setSelectedEmployee(null);
  };

  const handleCreatePlan = () => {
    if (!selectedEmployee) {
      toast.error("Please select an employee");
      return;
    }
    createPlanMutation.mutate({
      ...planForm,
      employee_email: selectedEmployee.email,
      bowling_alley_id: user.bowling_alley_id,
      created_by: user.email
    });
  };

  const handleCreateGoal = () => {
    if (!selectedEmployee) {
      toast.error("Please select an employee");
      return;
    }
    createGoalMutation.mutate({
      ...goalForm,
      employee_email: selectedEmployee.email,
      bowling_alley_id: user.bowling_alley_id,
      status: 'not_started'
    });
  };

  const handleCreateModule = () => {
    const tags = moduleForm.skill_tags.filter(t => t.trim() !== '');
    createModuleMutation.mutate({
      ...moduleForm,
      skill_tags: tags
    });
  };

  const handleAssignTraining = () => {
    if (!selectedEmployee) {
      toast.error("Please select an employee");
      return;
    }
    createAssignmentMutation.mutate({
      ...assignmentForm,
      employee_email: selectedEmployee.email,
      bowling_alley_id: user.bowling_alley_id,
      assigned_by: user.email,
      assigned_date: new Date().toISOString(),
      status: 'assigned'
    });
  };

  const filteredUsers = users.filter(u => 
    u.bowling_alley_id === user?.bowling_alley_id &&
    (u.display_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
     u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
     u.email?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const resetChecklistForm = () => {
    setChecklistForm({
      employee_email: "",
      employee_name: "",
      position: "",
      start_date: "",
      template_id: ""
    });
  };

  const resetOnboardingTemplateForm = () => {
    setTemplateForm({
      name: "",
      description: "",
      position: "",
      tasks: []
    });
  };

  const resetResourceForm = () => {
    setResourceForm({
      title: "",
      description: "",
      category: "policy",
      external_url: "",
      position_specific: [],
      required_reading: false
    });
  };

  const handleCreateChecklist = () => {
    if (!checklistForm.employee_email || !checklistForm.start_date || !checklistForm.template_id) {
      toast.error("Please fill in all required fields");
      return;
    }
    createChecklistMutation.mutate({
      ...checklistForm,
      bowling_alley_id: user.bowling_alley_id,
      manager_email: user.email,
      status: 'not_started',
      completion_percentage: 0
    });
  };

  const handleCreateOnboardingTemplate = () => {
    if (!templateForm.name || !templateForm.position) {
      toast.error("Please fill in required fields");
      return;
    }
    createOnboardingTemplateMutation.mutate(templateForm);
  };

  const handleCreateOnboardingResource = () => {
    if (!resourceForm.title) {
      toast.error("Please provide a title");
      return;
    }
    createOnboardingResourceMutation.mutate(resourceForm);
  };

  const addTaskToTemplate = () => {
    setTemplateForm({
      ...templateForm,
      tasks: [...templateForm.tasks, {
        title: "",
        description: "",
        category: "orientation",
        due_days: 0,
        assigned_to_role: "employee"
      }]
    });
  };

  const updateTemplateTask = (index, field, value) => {
    const updatedTasks = [...templateForm.tasks];
    updatedTasks[index][field] = value;
    setTemplateForm({ ...templateForm, tasks: updatedTasks });
  };

  const removeTemplateTask = (index) => {
    const updatedTasks = templateForm.tasks.filter((_, i) => i !== index);
    setTemplateForm({ ...templateForm, tasks: updatedTasks });
  };

  const activeChecklists = checklists.filter(c => c.status !== 'completed');
  const completedChecklists = checklists.filter(c => c.status === 'completed');

  const getChecklistProgress = (checklistId) => {
    const checklistTasks = onboardingTasks.filter(t => t.checklist_id === checklistId);
    if (checklistTasks.length === 0) return 0;
    const completed = checklistTasks.filter(t => t.status === 'completed').length;
    return Math.round((completed / checklistTasks.length) * 100);
  };

  if (!user || (user.department !== 'manager' && user.role !== 'admin')) {
    return null;
  }

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${theme.bg}`}>
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4 w-full">
        <div className="mb-4">
          <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            Manager Dashboard
          </h1>
          <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            Quick overview and actions for schedule management
          </p>
        </div>

        <Tabs defaultValue="overview" className="mb-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics">Reporting & Analytics</TabsTrigger>
            <TabsTrigger value="development">Employee Development</TabsTrigger>
            <TabsTrigger value="onboarding">Onboarding</TabsTrigger>
            <TabsTrigger value="locations">Locations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">

        {/* Live Activity Feed */}
        <LiveActivityFeed locationId={effectiveLocationId} />

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button
            onClick={() => navigate(createPageUrl("Schedule"))}
            className="h-20 bg-blue-600 hover:bg-blue-700"
          >
            <Calendar className="w-5 h-5 mr-2" />
            Manage Schedule
          </Button>
          <Button
            onClick={() => navigate(createPageUrl("PerformanceReview"))}
            className="h-20 bg-purple-600 hover:bg-purple-700"
          >
            <Star className="w-5 h-5 mr-2" />
            Performance Reviews
          </Button>
          <Button
            onClick={() => navigate(createPageUrl("UserManagement"))}
            className="h-20 bg-green-600 hover:bg-green-700"
          >
            <User className="w-5 h-5 mr-2" />
            Manage Team
          </Button>
          {user?.role === 'admin' && (
            <Button
              onClick={() => navigate(createPageUrl("SendUpdateNotification"))}
              className="h-20 bg-amber-600 hover:bg-amber-700"
            >
              <Mail className="w-5 h-5 mr-2" />
              Send Update
            </Button>
          )}
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-2 p-3">
              <CardTitle className={`text-xs font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                <CalendarX className="w-3 h-3 text-orange-500" />
                Pending Time Off
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                {pendingTimeOff.length}
              </div>
              <p className="text-xs text-slate-500 mt-1">Awaiting approval</p>
            </CardContent>
          </Card>

          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-2 p-3">
              <CardTitle className={`text-xs font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                <ArrowLeftRight className="w-3 h-3 text-blue-500" />
                Pending Trades
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                {pendingTrades.length}
              </div>
              <p className="text-xs text-slate-500 mt-1">Awaiting approval</p>
            </CardContent>
          </Card>

          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-2 p-3">
              <CardTitle className={`text-xs font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                <TrendingUp className="w-3 h-3 text-green-500" />
                Week Total Hours
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                {totalWeekHours.toFixed(0)}
              </div>
              <p className="text-xs text-slate-500 mt-1">This week</p>
            </CardContent>
          </Card>

          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="pb-2 p-3">
              <CardTitle className={`text-xs font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                <AlertTriangle className="w-3 h-3 text-red-500" />
                Coverage Gaps
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                {lowCoverageDays.length}
              </div>
              <p className="text-xs text-slate-500 mt-1">Days with low coverage</p>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Reviews */}
        {upcomingReviews.length > 0 && (
          <Card className={`mb-4 shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800 border-2 border-blue-500' : 'border-2 border-blue-500'}`}>
            <CardHeader className="p-4 pb-2">
              <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-slate-300' : ''}`}>
                <Star className="w-4 h-4 text-blue-500" />
                Upcoming Performance Reviews
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-2">
              <div className="space-y-2">
                {upcomingReviews.map(review => {
                  const daysUntil = Math.floor((new Date(review.next_review_date) - today) / (1000 * 60 * 60 * 24));
                  return (
                    <div 
                      key={review.id} 
                      className={`p-3 rounded-lg border flex items-center justify-between ${
                        daysUntil <= 7 ? 'bg-red-50 border-red-300' : isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${review.employee_email}`)}
                          className={`font-medium underline ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}
                        >
                          {getUserName(review.employee_email)}
                        </button>
                        <span className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          Due: {format(new Date(review.next_review_date), 'MMM d, yyyy')}
                        </span>
                        {daysUntil <= 7 && (
                          <Badge className="bg-red-600 text-white">
                            {daysUntil === 0 ? 'Due Today' : `${daysUntil} days`}
                          </Badge>
                        )}
                      </div>
                      <Button
                        size="sm"
                        onClick={() => navigate(createPageUrl("PerformanceReview") + `?employee=${review.employee_email}`)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Start Review
                      </Button>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Pending Time Off Requests */}
          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="p-4 pb-2">
              <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-slate-300' : ''}`}>
                <CalendarX className="w-4 h-4 text-orange-500" />
                Pending Time Off Requests
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-2">
              {pendingTimeOff.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {pendingTimeOff.map(request => (
                    <div key={request.id} className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                      <div className="flex items-start justify-between mb-2">
                        <button
                          onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${request.user_email}`)}
                          className="flex items-center gap-2 hover:opacity-80"
                        >
                          <User className="w-4 h-4 text-slate-400" />
                          <span className={`font-medium underline ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                            {getUserName(request.user_email)}
                          </span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                        <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                      </div>
                      <div className="text-sm space-y-1 mb-3">
                        <div className="flex items-center gap-2 text-slate-600">
                          <Calendar className="w-3 h-3" />
                          <span>{format(new Date(request.start_date), 'MMM d')} - {format(new Date(request.end_date), 'MMM d')}</span>
                        </div>
                        <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{request.reason}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleQuickReview('timeoff', request)}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          <Check className="w-3 h-3 mr-1" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleQuickReview('timeoff', request)}
                          className="flex-1 text-red-600 hover:text-red-700"
                        >
                          <X className="w-3 h-3 mr-1" />
                          Deny
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <CalendarX className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No pending requests</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pending Shift Trades */}
          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader className="p-4 pb-2">
              <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-slate-300' : ''}`}>
                <ArrowLeftRight className="w-4 h-4 text-blue-500" />
                Pending Shift Trades
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-2">
              {pendingTrades.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {pendingTrades.map(request => {
                    const requesterSchedule = getScheduleDetails(request.requester_schedule_id);
                    return (
                      <div key={request.id} className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-slate-400" />
                            <button
                              onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${request.requester_email}`)}
                              className={`font-medium text-sm underline hover:opacity-80 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}
                            >
                              {getUserName(request.requester_email)}
                            </button>
                            <span className={`text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                              ↔ {request.target_email ? getUserName(request.target_email) : 'Open'}
                            </span>
                          </div>
                          <Badge className="bg-blue-100 text-blue-800">Awaiting</Badge>
                        </div>
                        {requesterSchedule && (
                          <div className="text-sm space-y-1 mb-3">
                            <div className="flex items-center gap-2 text-slate-600">
                              <Calendar className="w-3 h-3" />
                              <span>{format(new Date(requesterSchedule.date.split('T')[0]), 'MMM d')}</span>
                              <Clock className="w-3 h-3 ml-2" />
                              <span>{requesterSchedule.shift_start} - {requesterSchedule.shift_end}</span>
                            </div>
                            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{request.reason}</p>
                          </div>
                        )}
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleQuickReview('trade', request)}
                            className="flex-1 bg-green-600 hover:bg-green-700"
                          >
                            <Check className="w-3 h-3 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleQuickReview('trade', request)}
                            className="flex-1 text-red-600 hover:text-red-700"
                          >
                            <X className="w-3 h-3 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8">
                  <ArrowLeftRight className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No pending trades</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Week Coverage Overview */}
        <Card className={`mt-4 shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardHeader className="p-4 pb-2">
            <CardTitle className={`flex items-center gap-2 text-base ${isDarkMode ? 'text-slate-300' : ''}`}>
              <Calendar className="w-4 h-4 text-blue-500" />
              This Week's Coverage
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-2">
            <div className="grid grid-cols-7 gap-2">
              {coverageByDay.map((day, idx) => (
                <div 
                  key={idx} 
                  className={`p-3 rounded-lg text-center ${
                    day.count < 2 ? 'bg-red-50 border-2 border-red-300' : 
                    isDarkMode ? 'bg-slate-800' : 'bg-slate-50'
                  }`}
                >
                  <div className="text-xs font-semibold text-slate-600 mb-1">
                    {format(day.date, 'EEE')}
                  </div>
                  <div className={`text-xl font-bold ${day.count < 2 ? 'text-red-600' : isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {day.count}
                  </div>
                  <div className="text-xs text-slate-500">
                    {day.hours.toFixed(0)}h
                  </div>
                </div>
              ))}
            </div>
            {lowCoverageDays.length > 0 && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-2 text-red-800 text-sm font-semibold mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  Low Coverage Alert
                </div>
                <p className="text-xs text-red-700">
                  {lowCoverageDays.map(d => format(d.date, 'EEEE')).join(', ')} {lowCoverageDays.length === 1 ? 'has' : 'have'} fewer than 2 staff scheduled
                </p>
              </div>
            )}
          </CardContent>
        </Card>

          </TabsContent>

          <TabsContent value="analytics" className="space-y-4 mt-4">
            {/* Labor Cost Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                <CardHeader className="pb-3">
                  <CardTitle className={`text-sm font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                    <DollarSign className="w-4 h-4 text-green-500" />
                    Daily Labor Cost
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    ${(weeklyLaborCost / 7).toFixed(0)}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Average per day</p>
                </CardContent>
              </Card>

              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                <CardHeader className="pb-3">
                  <CardTitle className={`text-sm font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                    <DollarSign className="w-4 h-4 text-green-500" />
                    Weekly Labor Cost
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    ${weeklyLaborCost.toFixed(0)}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">This week total</p>
                </CardContent>
              </Card>

              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                <CardHeader className="pb-3">
                  <CardTitle className={`text-sm font-medium flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                    <BarChart3 className="w-4 h-4 text-blue-500" />
                    Cost Per Hour
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    ${totalWeekHours > 0 ? (weeklyLaborCost / totalWeekHours).toFixed(2) : '0'}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Average rate</p>
                </CardContent>
              </Card>
            </div>

            {/* Daily Labor Cost Chart */}
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                  <DollarSign className="w-5 h-5 text-green-500" />
                  Daily Labor Costs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={dailyLaborCost}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => `$${value.toFixed(2)}`}
                      contentStyle={{
                        backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                        border: `1px solid ${isDarkMode ? '#334155' : '#e2e8f0'}`
                      }}
                    />
                    <Legend />
                    <Bar dataKey="cost" fill="#10b981" name="Cost ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Coverage Reports */}
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                  <BarChart3 className="w-5 h-5 text-blue-500" />
                  Staffing Levels
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={coverageChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                        border: `1px solid ${isDarkMode ? '#334155' : '#e2e8f0'}`
                      }}
                    />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="staff" stroke="#3b82f6" strokeWidth={2} name="Staff Count" />
                    <Line yAxisId="right" type="monotone" dataKey="hours" stroke="#8b5cf6" strokeWidth={2} name="Total Hours" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Employee Hours Report */}
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                    <FileText className="w-5 h-5 text-purple-500" />
                    Employee Hours Report
                  </CardTitle>
                  <Button
                    size="sm"
                    onClick={exportEmployeeHours}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className={`border-b ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                        <th className="text-left py-2 px-3 text-sm font-semibold">Employee</th>
                        <th className="text-right py-2 px-3 text-sm font-semibold">Shifts</th>
                        <th className="text-right py-2 px-3 text-sm font-semibold">Hours</th>
                        <th className="text-right py-2 px-3 text-sm font-semibold">Est. Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      {employeeHoursArray.map((emp, idx) => {
                        const userDetails = users.find(u => u.email === emp.email);
                        const rate = userDetails?.hourly_rate || defaultHourlyRate;
                        const cost = emp.totalHours * rate;
                        return (
                          <tr 
                            key={idx}
                            className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-100'}`}
                          >
                            <td className="py-3 px-3">
                              <button
                                onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${emp.email}`)}
                                className={`text-sm font-medium underline hover:opacity-80 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}
                              >
                                {emp.name}
                              </button>
                            </td>
                            <td className={`text-right py-3 px-3 text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                              {emp.shifts}
                            </td>
                            <td className={`text-right py-3 px-3 text-sm font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                              {emp.totalHours.toFixed(1)}
                            </td>
                            <td className={`text-right py-3 px-3 text-sm font-semibold text-green-600`}>
                              ${cost.toFixed(2)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr className={`border-t-2 ${isDarkMode ? 'border-slate-700' : 'border-slate-300'}`}>
                        <td className={`py-3 px-3 text-sm font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          Total
                        </td>
                        <td className={`text-right py-3 px-3 text-sm font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          {employeeHoursArray.reduce((sum, emp) => sum + emp.shifts, 0)}
                        </td>
                        <td className={`text-right py-3 px-3 text-sm font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          {totalWeekHours.toFixed(1)}
                        </td>
                        <td className={`text-right py-3 px-3 text-sm font-bold text-green-600`}>
                          ${weeklyLaborCost.toFixed(2)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Attendance Tracking */}
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                  <Clock className="w-5 h-5 text-amber-500" />
                  Recent Time Entries
                </CardTitle>
              </CardHeader>
              <CardContent>
                {locationTimeEntries.length > 0 ? (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {locationTimeEntries.slice(0, 10).map(entry => (
                      <div 
                        key={entry.id}
                        className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            {getUserName(entry.user_email)}
                          </span>
                          {entry.clock_out ? (
                            <Badge className="bg-green-100 text-green-800">
                              {entry.total_hours?.toFixed(2)}h
                            </Badge>
                          ) : (
                            <Badge className="bg-yellow-100 text-yellow-800">
                              Clocked In
                            </Badge>
                          )}
                        </div>
                        <div className="text-xs text-slate-500 space-y-1">
                          <div>In: {format(new Date(entry.clock_in), 'MMM d, h:mm a')}</div>
                          {entry.clock_out && (
                            <div>Out: {format(new Date(entry.clock_out), 'MMM d, h:mm a')}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Clock className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                    <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No time entries yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="development" className="space-y-4 mt-4">
            <Tabs defaultValue="plans" className="space-y-4">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="plans">Development Plans</TabsTrigger>
                <TabsTrigger value="goals">Skill Goals</TabsTrigger>
                <TabsTrigger value="training">Assignments</TabsTrigger>
                <TabsTrigger value="modules">Training Library</TabsTrigger>
              </TabsList>

              <TabsContent value="plans" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Development Plans
                  </h2>
                  <Button onClick={() => setPlanDialogOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Plan
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {developmentPlans.map(plan => (
                    <Card 
                      key={plan.id} 
                      className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
                      onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${plan.employee_email}`)}
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-300' : ''}`}>{plan.title}</CardTitle>
                            <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              {getUserName(plan.employee_email)}
                            </p>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded ${
                            plan.status === 'active' ? 'bg-blue-100 text-blue-800' : 
                            plan.status === 'completed' ? 'bg-green-100 text-green-800' : 
                            'bg-slate-100 text-slate-800'
                          }`}>
                            {plan.status}
                          </span>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          {plan.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="goals" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Skill Goals
                  </h2>
                  <Button onClick={() => setGoalDialogOpen(true)} className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Goal
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {skillGoals.map(goal => {
                    const progress = ((goal.current_level - 1) / (goal.target_level - 1)) * 100;
                    return (
                      <Card key={goal.id} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className={`text-base ${isDarkMode ? 'text-slate-300' : ''}`}>{goal.skill_name}</CardTitle>
                              <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                {getUserName(goal.employee_email)}
                              </p>
                            </div>
                            <span className={`text-xs px-2 py-1 rounded ${
                              goal.status === 'achieved' ? 'bg-green-100 text-green-800' : 
                              goal.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                              'bg-slate-100 text-slate-800'
                            }`}>
                              {goal.status.replace(/_/g, ' ')}
                            </span>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                                Level {goal.current_level} → {goal.target_level}
                              </span>
                              <span className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                {Math.round(progress)}%
                              </span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="training" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Training Assignments
                  </h2>
                  <Button onClick={() => setTrainingDialogOpen(true)} className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Assign Training
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trainingAssignments.map(assignment => {
                    const module = trainingModules.find(m => m.id === assignment.training_module_id);
                    return (
                      <Card key={assignment.id} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className={`text-base ${isDarkMode ? 'text-slate-300' : ''}`}>{module?.title || "Training"}</CardTitle>
                              <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                {getUserName(assignment.employee_email)}
                              </p>
                            </div>
                            <span className={`text-xs px-2 py-1 rounded ${
                              assignment.status === 'completed' ? 'bg-green-100 text-green-800' : 
                              assignment.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                              assignment.status === 'overdue' ? 'bg-red-100 text-red-800' :
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {assignment.status.replace(/_/g, ' ')}
                            </span>
                          </div>
                        </CardHeader>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="modules" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Training Library
                  </h2>
                  <Button onClick={() => setModuleDialogOpen(true)} className="bg-amber-600 hover:bg-amber-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Module
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {trainingModules.filter(m => m.active).map(module => (
                    <Card key={module.id} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                      <CardHeader className="pb-3">
                        <CardTitle className={`text-base ${isDarkMode ? 'text-slate-300' : ''}`}>{module.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className={`text-sm mb-3 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                          {module.description}
                        </p>
                        <div className="flex items-center justify-between text-xs">
                          <span className={`px-2 py-1 rounded ${isDarkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                            {module.category}
                          </span>
                          <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                            {module.estimated_duration_minutes} min
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="onboarding" className="space-y-4 mt-4">
            <Tabs defaultValue="active" className="space-y-4">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="active">Active ({activeChecklists.length})</TabsTrigger>
                <TabsTrigger value="completed">Completed ({completedChecklists.length})</TabsTrigger>
                <TabsTrigger value="templates">Templates ({onboardingTemplates.length})</TabsTrigger>
                <TabsTrigger value="resources">Resources ({onboardingResources.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="space-y-4">
                <div className="flex justify-end mb-4">
                  <Button onClick={() => setChecklistDialogOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                    <UserPlus className="w-4 h-4 mr-2" />
                    New Hire
                  </Button>
                </div>
                {activeChecklists.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeChecklists.map(checklist => {
                      const progress = getChecklistProgress(checklist.id);
                      return (
                        <Card 
                          key={checklist.id} 
                          className={`cursor-pointer hover:shadow-lg transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
                          onClick={() => navigate(createPageUrl("OnboardingDetail") + `?id=${checklist.id}`)}
                        >
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div>
                                <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-300' : ''}`}>{checklist.employee_name}</CardTitle>
                                <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                  {checklist.position}
                                </p>
                              </div>
                              <Badge className={
                                checklist.status === 'completed' ? 'bg-green-100 text-green-800' :
                                checklist.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {checklist.status.replace(/_/g, ' ')}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                                Start Date: {format(new Date(checklist.start_date), 'MMM d, yyyy')}
                              </span>
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Progress</span>
                                <span className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{progress}%</span>
                              </div>
                              <Progress value={progress} className="h-2" />
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                ) : (
                  <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                    <CardContent className="text-center py-12">
                      <UsersIcon className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No active onboarding in progress</p>
                      <Button onClick={() => setChecklistDialogOpen(true)} className="mt-4 bg-blue-600 hover:bg-blue-700">
                        <UserPlus className="w-4 h-4 mr-2" />
                        Start New Hire Onboarding
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="completed" className="space-y-4">
                {completedChecklists.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {completedChecklists.map(checklist => (
                      <Card 
                        key={checklist.id} 
                        className={`cursor-pointer hover:shadow-lg transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
                        onClick={() => navigate(createPageUrl("OnboardingDetail") + `?id=${checklist.id}`)}
                      >
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-300' : ''}`}>{checklist.employee_name}</CardTitle>
                              <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                {checklist.position}
                              </p>
                            </div>
                            <Badge className="bg-green-100 text-green-800">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              Completed
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                            Started: {format(new Date(checklist.start_date), 'MMM d, yyyy')}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                    <CardContent className="text-center py-12">
                      <CheckCircle2 className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No completed onboarding yet</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="templates" className="space-y-4">
                <div className="flex justify-end">
                  <Button onClick={() => setTemplateDialogOpen(true)} className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Template
                  </Button>
                </div>
                {onboardingTemplates.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {onboardingTemplates.map(template => (
                      <Card key={template.id} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-300' : ''}`}>{template.name}</CardTitle>
                              <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                For: {template.position}
                              </p>
                            </div>
                            <Badge variant="outline">{template.tasks?.length || 0} tasks</Badge>
                          </div>
                        </CardHeader>
                        {template.description && (
                          <CardContent>
                            <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              {template.description}
                            </p>
                          </CardContent>
                        )}
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                    <CardContent className="text-center py-12">
                      <FileText className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No templates created yet</p>
                      <Button onClick={() => setTemplateDialogOpen(true)} className="mt-4 bg-purple-600 hover:bg-purple-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Create First Template
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="resources" className="space-y-4">
                <div className="flex justify-end">
                  <Button onClick={() => setResourceDialogOpen(true)} className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Resource
                  </Button>
                </div>
                {onboardingResources.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {onboardingResources.filter(r => r.active).map(resource => (
                      <Card key={resource.id} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle className={`text-base ${isDarkMode ? 'text-slate-300' : ''}`}>{resource.title}</CardTitle>
                              <Badge className="mt-2" variant="outline">{resource.category}</Badge>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteResourceMutation.mutate(resource.id);
                              }}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </CardHeader>
                        <CardContent>
                          {resource.description && (
                            <p className={`text-sm mb-3 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              {resource.description}
                            </p>
                          )}
                          {resource.external_url && (
                            <a 
                              href={resource.external_url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-sm text-blue-600 hover:underline flex items-center gap-1"
                            >
                              View Resource <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                    <CardContent className="text-center py-12">
                      <BookOpen className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                      <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>No resources added yet</p>
                      <Button onClick={() => setResourceDialogOpen(true)} className="mt-4 bg-green-600 hover:bg-green-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add First Resource
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="locations" className="space-y-4 mt-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                Manage Locations
              </h2>
              <Button onClick={() => navigate(createPageUrl("Locations"))} className="bg-blue-600 hover:bg-blue-700">
                <Building2 className="w-4 h-4 mr-2" />
                View All Locations
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {locations.filter(l => l.active !== false).map(location => (
                <Card 
                  key={location.id} 
                  className={`cursor-pointer hover:shadow-lg transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
                  onClick={() => navigate(createPageUrl("Locations"))}
                >
                  {location.image_url && (
                    <div className="h-32 overflow-hidden">
                      <img src={location.image_url} alt={location.name} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-300' : ''}`}>{location.name}</CardTitle>
                    {location.city && (
                      <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                        {location.city}, {location.state}
                      </p>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {location.address && (
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="w-4 h-4 text-slate-400" />
                        <span className={theme.textTertiary}>{location.address}</span>
                      </div>
                    )}
                    {location.phone && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="w-4 h-4 text-slate-400" />
                        <span className={theme.textTertiary}>{location.phone}</span>
                      </div>
                    )}
                    {location.total_lanes && (
                      <Badge variant="outline">{location.total_lanes} lanes</Badge>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Create Checklist Dialog */}
        <Dialog open={checklistDialogOpen} onOpenChange={setChecklistDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Start New Hire Onboarding</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Employee Email *</Label>
                <Input
                  type="email"
                  value={checklistForm.employee_email}
                  onChange={(e) => setChecklistForm({...checklistForm, employee_email: e.target.value})}
                  placeholder="employee@example.com"
                />
              </div>
              <div className="space-y-2">
                <Label>Employee Name *</Label>
                <Input
                  value={checklistForm.employee_name}
                  onChange={(e) => setChecklistForm({...checklistForm, employee_name: e.target.value})}
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-2">
                <Label>Position *</Label>
                <Input
                  value={checklistForm.position}
                  onChange={(e) => setChecklistForm({...checklistForm, position: e.target.value})}
                  placeholder="Mechanic"
                />
              </div>
              <div className="space-y-2">
                <Label>Start Date *</Label>
                <Input
                  type="date"
                  value={checklistForm.start_date}
                  onChange={(e) => setChecklistForm({...checklistForm, start_date: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Template *</Label>
                <Select value={checklistForm.template_id} onValueChange={(value) => setChecklistForm({...checklistForm, template_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select template" />
                  </SelectTrigger>
                  <SelectContent>
                    {onboardingTemplates.filter(t => t.active).map(template => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name} - {template.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setChecklistDialogOpen(false); resetChecklistForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateChecklist} disabled={createChecklistMutation.isPending} className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Start Onboarding
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Create Onboarding Template Dialog */}
        <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Onboarding Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Template Name *</Label>
                <Input
                  value={templateForm.name}
                  onChange={(e) => setTemplateForm({...templateForm, name: e.target.value})}
                  placeholder="New Mechanic Onboarding"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={templateForm.description}
                  onChange={(e) => setTemplateForm({...templateForm, description: e.target.value})}
                  placeholder="Describe the onboarding process..."
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label>Position *</Label>
                <Input
                  value={templateForm.position}
                  onChange={(e) => setTemplateForm({...templateForm, position: e.target.value})}
                  placeholder="Mechanic"
                />
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Tasks</Label>
                  <Button type="button" size="sm" onClick={addTaskToTemplate} variant="outline">
                    <Plus className="w-3 h-3 mr-1" />
                    Add Task
                  </Button>
                </div>
                {templateForm.tasks.map((task, index) => (
                  <div key={index} className={`p-3 rounded-lg border space-y-2 ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50'}`}>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Task {index + 1}</span>
                      <Button type="button" size="sm" variant="ghost" onClick={() => removeTemplateTask(index)}>
                        <Trash2 className="w-3 h-3 text-red-500" />
                      </Button>
                    </div>
                    <Input
                      placeholder="Task title"
                      value={task.title}
                      onChange={(e) => updateTemplateTask(index, 'title', e.target.value)}
                    />
                    <Textarea
                      placeholder="Task description"
                      value={task.description}
                      onChange={(e) => updateTemplateTask(index, 'description', e.target.value)}
                      rows={2}
                    />
                    <div className="grid grid-cols-3 gap-2">
                      <Select value={task.category} onValueChange={(value) => updateTemplateTask(index, 'category', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="paperwork">Paperwork</SelectItem>
                          <SelectItem value="training">Training</SelectItem>
                          <SelectItem value="equipment">Equipment</SelectItem>
                          <SelectItem value="orientation">Orientation</SelectItem>
                          <SelectItem value="introduction">Introduction</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        placeholder="Due days"
                        value={task.due_days}
                        onChange={(e) => updateTemplateTask(index, 'due_days', parseInt(e.target.value))}
                      />
                      <Select value={task.assigned_to_role} onValueChange={(value) => updateTemplateTask(index, 'assigned_to_role', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="employee">Employee</SelectItem>
                          <SelectItem value="manager">Manager</SelectItem>
                          <SelectItem value="hr">HR</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setTemplateDialogOpen(false); resetOnboardingTemplateForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateOnboardingTemplate} disabled={createOnboardingTemplateMutation.isPending} className="flex-1 bg-purple-600 hover:bg-purple-700">
                  Create Template
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add Onboarding Resource Dialog */}
        <Dialog open={resourceDialogOpen} onOpenChange={setResourceDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Onboarding Resource</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Title *</Label>
                <Input
                  value={resourceForm.title}
                  onChange={(e) => setResourceForm({...resourceForm, title: e.target.value})}
                  placeholder="Employee Handbook"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={resourceForm.description}
                  onChange={(e) => setResourceForm({...resourceForm, description: e.target.value})}
                  placeholder="Describe the resource..."
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={resourceForm.category} onValueChange={(value) => setResourceForm({...resourceForm, category: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="policy">Policy</SelectItem>
                    <SelectItem value="handbook">Handbook</SelectItem>
                    <SelectItem value="form">Form</SelectItem>
                    <SelectItem value="guide">Guide</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="faq">FAQ</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>External URL</Label>
                <Input
                  value={resourceForm.external_url}
                  onChange={(e) => setResourceForm({...resourceForm, external_url: e.target.value})}
                  placeholder="https://..."
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setResourceDialogOpen(false); resetResourceForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateOnboardingResource} disabled={createOnboardingResourceMutation.isPending} className="flex-1 bg-green-600 hover:bg-green-700">
                  Add Resource
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Development Plan Dialog */}
        <Dialog open={planDialogOpen} onOpenChange={setPlanDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Development Plan</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Employee</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="Search employees..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                {searchQuery && (
                  <div className={`max-h-40 overflow-y-auto border rounded-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'}`}>
                    {filteredUsers.map(u => (
                      <button
                        key={u.email}
                        onClick={() => {
                          setSelectedEmployee(u);
                          setSearchQuery("");
                        }}
                        className={`w-full text-left px-3 py-2 hover:bg-slate-100 ${isDarkMode ? 'hover:bg-slate-800' : ''}`}
                      >
                        {u.display_name || u.full_name || u.email}
                      </button>
                    ))}
                  </div>
                )}
                {selectedEmployee && (
                  <div className={`p-2 rounded border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50'}`}>
                    Selected: {selectedEmployee.display_name || selectedEmployee.full_name}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Plan Title</Label>
                <Input
                  value={planForm.title}
                  onChange={(e) => setPlanForm({...planForm, title: e.target.value})}
                  placeholder="e.g., Lead Mechanic Development Track"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={planForm.description}
                  onChange={(e) => setPlanForm({...planForm, description: e.target.value})}
                  placeholder="Describe the development goals..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input
                    type="date"
                    value={planForm.start_date}
                    onChange={(e) => setPlanForm({...planForm, start_date: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Target Completion</Label>
                  <Input
                    type="date"
                    value={planForm.target_completion_date}
                    onChange={(e) => setPlanForm({...planForm, target_completion_date: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setPlanDialogOpen(false); resetPlanForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreatePlan} disabled={createPlanMutation.isPending} className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Create Plan
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Skill Goal Dialog */}
        <Dialog open={goalDialogOpen} onOpenChange={setGoalDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Skill Goal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Employee</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="Search employees..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                {searchQuery && (
                  <div className={`max-h-40 overflow-y-auto border rounded-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'}`}>
                    {filteredUsers.map(u => (
                      <button
                        key={u.email}
                        onClick={() => {
                          setSelectedEmployee(u);
                          setSearchQuery("");
                        }}
                        className={`w-full text-left px-3 py-2 hover:bg-slate-100 ${isDarkMode ? 'hover:bg-slate-800' : ''}`}
                      >
                        {u.display_name || u.full_name || u.email}
                      </button>
                    ))}
                  </div>
                )}
                {selectedEmployee && (
                  <div className={`p-2 rounded border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50'}`}>
                    Selected: {selectedEmployee.display_name || selectedEmployee.full_name}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Skill Name</Label>
                <Input
                  value={goalForm.skill_name}
                  onChange={(e) => setGoalForm({...goalForm, skill_name: e.target.value})}
                  placeholder="e.g., Advanced Troubleshooting"
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={goalForm.category} onValueChange={(value) => setGoalForm({...goalForm, category: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Technical</SelectItem>
                    <SelectItem value="leadership">Leadership</SelectItem>
                    <SelectItem value="communication">Communication</SelectItem>
                    <SelectItem value="customer_service">Customer Service</SelectItem>
                    <SelectItem value="safety">Safety</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Current Level (1-5)</Label>
                  <Input
                    type="number"
                    min="1"
                    max="5"
                    value={goalForm.current_level}
                    onChange={(e) => setGoalForm({...goalForm, current_level: parseInt(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Target Level (1-5)</Label>
                  <Input
                    type="number"
                    min="1"
                    max="5"
                    value={goalForm.target_level}
                    onChange={(e) => setGoalForm({...goalForm, target_level: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Target Date</Label>
                <Input
                  type="date"
                  value={goalForm.target_date}
                  onChange={(e) => setGoalForm({...goalForm, target_date: e.target.value})}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setGoalDialogOpen(false); resetGoalForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateGoal} disabled={createGoalMutation.isPending} className="flex-1 bg-purple-600 hover:bg-purple-700">
                  Add Goal
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Assign Training Dialog */}
        <Dialog open={trainingDialogOpen} onOpenChange={setTrainingDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Assign Training</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Employee</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="Search employees..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                {searchQuery && (
                  <div className={`max-h-40 overflow-y-auto border rounded-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'}`}>
                    {filteredUsers.map(u => (
                      <button
                        key={u.email}
                        onClick={() => {
                          setSelectedEmployee(u);
                          setSearchQuery("");
                        }}
                        className={`w-full text-left px-3 py-2 hover:bg-slate-100 ${isDarkMode ? 'hover:bg-slate-800' : ''}`}
                      >
                        {u.display_name || u.full_name || u.email}
                      </button>
                    ))}
                  </div>
                )}
                {selectedEmployee && (
                  <div className={`p-2 rounded border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50'}`}>
                    Selected: {selectedEmployee.display_name || selectedEmployee.full_name}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Training Module</Label>
                <Select value={assignmentForm.training_module_id} onValueChange={(value) => setAssignmentForm({...assignmentForm, training_module_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select module" />
                  </SelectTrigger>
                  <SelectContent>
                    {trainingModules.filter(m => m.active).map(module => (
                      <SelectItem key={module.id} value={module.id}>
                        {module.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Due Date</Label>
                <Input
                  type="date"
                  value={assignmentForm.due_date}
                  onChange={(e) => setAssignmentForm({...assignmentForm, due_date: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Notes (Optional)</Label>
                <Textarea
                  value={assignmentForm.manager_notes}
                  onChange={(e) => setAssignmentForm({...assignmentForm, manager_notes: e.target.value})}
                  placeholder="Add instructions..."
                  rows={2}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setTrainingDialogOpen(false); resetAssignmentForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleAssignTraining} disabled={createAssignmentMutation.isPending} className="flex-1 bg-green-600 hover:bg-green-700">
                  Assign
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Training Module Dialog */}
        <Dialog open={moduleDialogOpen} onOpenChange={setModuleDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Training Module</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Module Title</Label>
                <Input
                  value={moduleForm.title}
                  onChange={(e) => setModuleForm({...moduleForm, title: e.target.value})}
                  placeholder="e.g., Advanced Pin Setter Maintenance"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={moduleForm.description}
                  onChange={(e) => setModuleForm({...moduleForm, description: e.target.value})}
                  placeholder="Describe what this training covers..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={moduleForm.category} onValueChange={(value) => setModuleForm({...moduleForm, category: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technical">Technical</SelectItem>
                      <SelectItem value="leadership">Leadership</SelectItem>
                      <SelectItem value="communication">Communication</SelectItem>
                      <SelectItem value="customer_service">Customer Service</SelectItem>
                      <SelectItem value="safety">Safety</SelectItem>
                      <SelectItem value="compliance">Compliance</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Content Type</Label>
                  <Select value={moduleForm.content_type} onValueChange={(value) => setModuleForm({...moduleForm, content_type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="video">Video</SelectItem>
                      <SelectItem value="document">Document</SelectItem>
                      <SelectItem value="online_course">Online Course</SelectItem>
                      <SelectItem value="external_link">External Link</SelectItem>
                      <SelectItem value="in_person">In-Person</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Content URL (Optional)</Label>
                <Input
                  value={moduleForm.content_url}
                  onChange={(e) => setModuleForm({...moduleForm, content_url: e.target.value})}
                  placeholder="https://..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Duration (minutes)</Label>
                  <Input
                    type="number"
                    value={moduleForm.estimated_duration_minutes}
                    onChange={(e) => setModuleForm({...moduleForm, estimated_duration_minutes: parseInt(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Difficulty Level</Label>
                  <Select value={moduleForm.difficulty_level} onValueChange={(value) => setModuleForm({...moduleForm, difficulty_level: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => {setModuleDialogOpen(false); resetModuleForm();}} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCreateModule} disabled={createModuleMutation.isPending} className="flex-1 bg-amber-600 hover:bg-amber-700">
                  Add Module
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Review Dialog */}
        <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {reviewType === 'timeoff' ? 'Review Time Off Request' : 'Review Shift Trade'}
              </DialogTitle>
            </DialogHeader>
            {selectedRequest && (
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-semibold">
                    {reviewType === 'timeoff' ? 'Requester' : 'Trade Between'}
                  </Label>
                  <p className="text-sm">
                    {reviewType === 'timeoff' 
                      ? getUserName(selectedRequest.user_email)
                      : `${getUserName(selectedRequest.requester_email)} ↔ ${selectedRequest.target_email ? getUserName(selectedRequest.target_email) : 'Open'}`
                    }
                  </p>
                </div>
                {reviewType === 'timeoff' && (
                  <div>
                    <Label className="text-sm font-semibold">Dates</Label>
                    <p className="text-sm">
                      {format(new Date(selectedRequest.start_date), 'MMM d, yyyy')} - {format(new Date(selectedRequest.end_date), 'MMM d, yyyy')}
                    </p>
                  </div>
                )}
                <div>
                  <Label className="text-sm font-semibold">Reason</Label>
                  <p className="text-sm">{selectedRequest.reason}</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="review_notes">Manager Notes (Optional)</Label>
                  <Textarea
                    id="review_notes"
                    value={reviewNotes}
                    onChange={(e) => setReviewNotes(e.target.value)}
                    placeholder="Add notes about your decision..."
                    rows={3}
                  />
                </div>
                <div className="flex gap-3 pt-4">
                  <Button
                    onClick={() => submitReview(reviewType === 'timeoff' ? 'approved' : 'approved')}
                    disabled={updateTimeOffMutation.isPending || updateTradeMutation.isPending}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                  <Button
                    onClick={() => submitReview(reviewType === 'timeoff' ? 'denied' : 'rejected')}
                    disabled={updateTimeOffMutation.isPending || updateTradeMutation.isPending}
                    variant="outline"
                    className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="w-4 h-4 mr-2" />
                    {reviewType === 'timeoff' ? 'Deny' : 'Reject'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
        </div>
      </div>
    </div>
  );
}