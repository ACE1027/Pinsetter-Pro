import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wrench, Calendar, Building2, Settings, History, Activity, AlertTriangle, CheckCircle2, Clock, X, ExternalLink, Package, TrendingUp, Users, BarChart3 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useTheme } from "@/components/ThemeContext";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "@/components/LocationContext";
import { differenceInDays, format, subDays } from "date-fns";
import ServiceCallCard from "@/components/service/ServiceCallCard";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function MechanicsDashboard() {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const [user, setUser] = useState(null);
  const [activeDialog, setActiveDialog] = useState(null); // 'urgent', 'down', 'overdue', 'open'

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    initialData: [],
    refetchInterval: 30000,
  });

  const { data: machines = [] } = useQuery({
    queryKey: ['machines'],
    queryFn: () => base44.entities.Machine.list(),
    initialData: [],
    refetchInterval: 30000,
  });

  const { data: maintenanceTasks = [] } = useQuery({
    queryKey: ['preventativeMaintenance'],
    queryFn: () => base44.entities.PreventativeMaintenanceTask.list(),
    initialData: [],
    refetchInterval: 30000,
  });

  const { data: scheduledMaintenance = [] } = useQuery({
    queryKey: ['scheduledMaintenance'],
    queryFn: () => base44.entities.ScheduledMaintenance.list(),
    initialData: [],
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const { data: parts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: [],
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  const accessibleCalls = serviceCalls.filter(call => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && call.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const accessibleMachines = machines.filter(machine => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && machine.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const accessibleTasks = maintenanceTasks.filter(task => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && task.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const accessibleScheduled = scheduledMaintenance.filter(task => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && task.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const openCalls = accessibleCalls.filter(c => c.status !== 'completed' && c.status !== 'cancelled');
  const urgentCalls = openCalls.filter(c => c.priority === 'urgent');
  const machinesDown = accessibleMachines.filter(m => m.status === 'down');
  const machinesNeedService = accessibleMachines.filter(m => m.status === 'needs_maintenance');
  const overdueTasks = accessibleTasks.filter(t => t.status !== 'completed' && t.due_date && new Date(t.due_date) < new Date());
  const upcomingScheduled = accessibleScheduled.filter(s => {
    if (s.status === 'completed') return false;
    const daysUntil = differenceInDays(new Date(s.scheduled_date), new Date());
    return daysUntil >= 0 && daysUntil <= 7;
  });

  const getLocationName = (locationId) => {
    return locations.find(l => l.id === locationId)?.name || "Unknown Location";
  };

  // Additional metrics
  const accessibleParts = parts.filter(part => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && part.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const mechanics = allUsers.filter(u => 
    u.department === 'mechanic' && 
    ((isAdmin && selectedLocationId === 'all') || u.bowling_alley_id === effectiveLocationId)
  );

  const lowStockParts = accessibleParts.filter(p => p.quantity_in_stock < p.min_quantity);
  const completedToday = accessibleCalls.filter(c => 
    c.status === 'completed' && 
    c.completed_date && 
    new Date(c.completed_date).toDateString() === new Date().toDateString()
  );

  // Calculate average resolution time
  const completedCalls = accessibleCalls.filter(c => c.status === 'completed' && c.created_date && c.completed_date);
  const avgResolutionTime = completedCalls.length > 0 ?
    completedCalls.reduce((sum, call) => {
      const created = new Date(call.created_date);
      const completed = new Date(call.completed_date);
      return sum + (completed - created);
    }, 0) / completedCalls.length : 0;
  const avgHours = Math.round(avgResolutionTime / (1000 * 60 * 60));

  // Service calls trend (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayName = format(date, 'EEE');
    const created = accessibleCalls.filter(c => c.created_date?.startsWith(dateStr)).length;
    const completed = accessibleCalls.filter(c => c.completed_date?.startsWith(dateStr)).length;
    return { date: dayName, created, completed };
  });

  // Calls by priority
  const priorityData = [
    { name: 'Urgent', count: accessibleCalls.filter(c => c.priority === 'urgent' && c.status !== 'completed').length },
    { name: 'High', count: accessibleCalls.filter(c => c.priority === 'high' && c.status !== 'completed').length },
    { name: 'Preventative', count: accessibleCalls.filter(c => c.priority === 'preventative_maintenance' && c.status !== 'completed').length },
  ];

  const tools = [
    {
      title: "Preventative Maintenance",
      description: "Daily, weekly, monthly tasks",
      icon: Wrench,
      color: "bg-blue-600",
      hoverColor: "hover:bg-blue-700",
      url: createPageUrl("PreventativeMaintenance"),
      badge: overdueTasks.length > 0 ? { text: `${overdueTasks.length} Overdue`, color: "bg-red-100 text-red-800" } : null
    },
    {
      title: "Scheduled Maintenance",
      description: "Planned maintenance schedule",
      icon: Calendar,
      color: "bg-purple-600",
      hoverColor: "hover:bg-purple-700",
      url: createPageUrl("ScheduledMaintenance"),
      badge: upcomingScheduled.length > 0 ? { text: `${upcomingScheduled.length} This Week`, color: "bg-yellow-100 text-yellow-800" } : null
    },
    {
      title: "Building Maintenance",
      description: "Facility and infrastructure",
      icon: Building2,
      color: "bg-green-600",
      hoverColor: "hover:bg-green-700",
      url: createPageUrl("BuildingMaintenance")
    },
    {
      title: "Machine Repair Log",
      description: "Document repairs and fixes",
      icon: Settings,
      color: "bg-amber-600",
      hoverColor: "hover:bg-amber-700",
      url: createPageUrl("MachineRepairLog")
    },
    {
      title: "Service History",
      description: "View past service calls",
      icon: History,
      color: "bg-indigo-600",
      hoverColor: "hover:bg-indigo-700",
      url: createPageUrl("ServiceCallHistory")
    },
    {
      title: "Machine Inventory",
      description: "Real-time machine status",
      icon: Activity,
      color: "bg-teal-600",
      hoverColor: "hover:bg-teal-700",
      url: createPageUrl("MachineInventory"),
      badge: (machinesDown.length > 0 || machinesNeedService.length > 0) ? { 
        text: `${machinesDown.length + machinesNeedService.length} Need Attention`, 
        color: "bg-red-100 text-red-800" 
      } : null
    }
  ];

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${theme.bg}`}>
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4 w-full">
        <div className="mb-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg">
              <Wrench className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className={`text-3xl font-bold ${theme.text}`}>Mechanics Dashboard</h1>
              <p className={`mt-1 ${theme.textSecondary}`}>Maintenance operations and service management</p>
            </div>
          </div>
        </div>

        {/* Alert Summary - Clickable Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          <Card 
            className={`cursor-pointer hover:shadow-md transition-all ${urgentCalls.length > 0 ? 'ring-2 ring-red-500' : ''} ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
            onClick={() => setActiveDialog('urgent')}
          >
            <CardHeader className="pb-2 p-3">
              <CardTitle className="text-xs font-medium text-slate-500">Urgent Calls</CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold ${urgentCalls.length > 0 ? 'text-red-600' : theme.text}`}>
                  {urgentCalls.length}
                </span>
                <AlertTriangle className={`w-5 h-5 ${urgentCalls.length > 0 ? 'text-red-500' : 'text-slate-400'}`} />
              </div>
              <p className="text-xs text-slate-500 mt-2">Click to view</p>
            </CardContent>
          </Card>

          <Card 
            className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
            onClick={() => setActiveDialog('down')}
          >
            <CardHeader className="pb-2 p-3">
              <CardTitle className="text-xs font-medium text-slate-500">Machines Down</CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold ${machinesDown.length > 0 ? 'text-red-600' : theme.text}`}>
                  {machinesDown.length}
                </span>
                <Settings className={`w-5 h-5 ${machinesDown.length > 0 ? 'text-red-500' : 'text-slate-400'}`} />
              </div>
              <p className="text-xs text-slate-500 mt-2">Click to view</p>
            </CardContent>
          </Card>

          <Card 
            className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
            onClick={() => setActiveDialog('overdue')}
          >
            <CardHeader className="pb-2 p-3">
              <CardTitle className="text-xs font-medium text-slate-500">Overdue Tasks</CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold ${overdueTasks.length > 0 ? 'text-yellow-600' : theme.text}`}>
                  {overdueTasks.length}
                </span>
                <Clock className={`w-5 h-5 ${overdueTasks.length > 0 ? 'text-yellow-500' : 'text-slate-400'}`} />
              </div>
              <p className="text-xs text-slate-500 mt-2">Click to view</p>
            </CardContent>
          </Card>

          <Card 
            className={`cursor-pointer hover:shadow-md transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
            onClick={() => setActiveDialog('open')}
          >
            <CardHeader className="pb-2 p-3">
              <CardTitle className="text-xs font-medium text-slate-500">Open Service Calls</CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold ${theme.text}`}>{openCalls.length}</span>
                <Activity className="w-5 h-5 text-blue-500" />
              </div>
              <p className="text-xs text-slate-500 mt-2">Click to view</p>
            </CardContent>
          </Card>
        </div>

        {/* Additional Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Completed Today</p>
                  <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {completedToday.length}
                  </p>
                </div>
                <div className="p-2 bg-green-100 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Avg Resolution</p>
                  <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {avgHours}h
                  </p>
                </div>
                <div className="p-2 bg-blue-100 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Low Stock Parts</p>
                  <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {lowStockParts.length}
                  </p>
                </div>
                <div className="p-2 bg-orange-100 rounded-lg">
                  <Package className="w-5 h-5 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-sm ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Active Mechanics</p>
                  <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {mechanics.length}
                  </p>
                </div>
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="tools" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tools">Tools & Actions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          </TabsList>

          {/* Tools Tab */}
          <TabsContent value="tools" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Card 
                key={tool.title}
                className={`cursor-pointer transition-all hover:shadow-xl ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
                onClick={() => navigate(tool.url)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className={`w-12 h-12 rounded-lg ${tool.color} flex items-center justify-center shadow-lg`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    {tool.badge && (
                      <Badge className={tool.badge.color}>
                        {tool.badge.text}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className={`text-lg mt-4 ${theme.text}`}>{tool.title}</CardTitle>
                  <p className={`text-sm ${theme.textTertiary}`}>{tool.description}</p>
                </CardHeader>
                <CardContent>
                  <Button 
                    className={`w-full ${tool.color} ${tool.hoverColor}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(tool.url);
                    }}
                  >
                    Open
                  </Button>
                </CardContent>
              </Card>
            );
          })}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* 7-Day Trend */}
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}>
                <CardHeader>
                  <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    <BarChart3 className="w-5 h-5 text-blue-600" />
                    7-Day Service Call Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={last7Days}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="created" stroke="#3b82f6" name="Created" />
                      <Line type="monotone" dataKey="completed" stroke="#10b981" name="Completed" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Calls by Priority */}
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}>
                <CardHeader>
                  <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    <AlertTriangle className="w-5 h-5 text-orange-600" />
                    Open Calls by Priority
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={priorityData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#f59e0b" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Performance Summary */}
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}>
                <CardHeader>
                  <CardTitle className={isDarkMode ? 'text-slate-100' : 'text-slate-900'}>
                    Performance Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="text-sm text-blue-600 font-medium">Total Service Calls</span>
                      <span className="text-2xl font-bold text-blue-900">{accessibleCalls.length}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="text-sm text-green-600 font-medium">Completed</span>
                      <span className="text-2xl font-bold text-green-900">{completedCalls.length}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="text-sm text-yellow-600 font-medium">In Progress</span>
                      <span className="text-2xl font-bold text-yellow-900">
                        {accessibleCalls.filter(c => c.status === 'in_progress').length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="text-sm text-purple-600 font-medium">Completion Rate</span>
                      <span className="text-2xl font-bold text-purple-900">
                        {accessibleCalls.length > 0 ? Math.round((completedCalls.length / accessibleCalls.length) * 100) : 0}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Machines Status */}
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}>
                <CardHeader>
                  <CardTitle className={isDarkMode ? 'text-slate-100' : 'text-slate-900'}>
                    Machine Status Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                        <span className={theme.textSecondary}>Operational</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        {accessibleMachines.filter(m => m.status === 'operational').length}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="w-5 h-5 text-yellow-500" />
                        <span className={theme.textSecondary}>Needs Maintenance</span>
                      </div>
                      <Badge className="bg-yellow-100 text-yellow-800">
                        {machinesNeedService.length}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <X className="w-5 h-5 text-red-500" />
                        <span className={theme.textSecondary}>Down</span>
                      </div>
                      <Badge className="bg-red-100 text-red-800">
                        {machinesDown.length}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Recent Activity Tab */}
          <TabsContent value="activity" className="space-y-4">
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  <Activity className="w-5 h-5 text-blue-600" />
                  Recent Service Calls
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {accessibleCalls.slice(0, 10).map(call => (
                    <ServiceCallCard key={call.id} call={call} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Urgent Calls Dialog */}
        <Dialog open={activeDialog === 'urgent'} onOpenChange={(open) => !open && setActiveDialog(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                Urgent Service Calls ({urgentCalls.length})
              </DialogTitle>
              <DialogDescription>Lanes down requiring immediate attention</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 mt-4">
              {urgentCalls.length > 0 ? (
                urgentCalls.map(call => <ServiceCallCard key={call.id} call={call} />)
              ) : (
                <p className="text-center py-8 text-slate-500">No urgent calls</p>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Machines Down Dialog */}
        <Dialog open={activeDialog === 'down'} onOpenChange={(open) => !open && setActiveDialog(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-red-500" />
                Machines Down ({machinesDown.length})
              </DialogTitle>
              <DialogDescription>Machines currently offline</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 mt-4">
              {machinesDown.length > 0 ? (
                machinesDown.map(machine => (
                  <div 
                    key={machine.id} 
                    className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className={`font-semibold ${theme.text}`}>{machine.machine_type}</h3>
                          <Badge className="bg-red-100 text-red-800">Down</Badge>
                        </div>
                        <div className="space-y-1 text-sm">
                          <p className={theme.textSecondary}>Lane {machine.lane_number || 'N/A'}</p>
                          <p className={theme.textTertiary}>S/N: {machine.serial_number}</p>
                          {isAdmin && (
                            <p className="text-xs text-slate-500">{getLocationName(machine.bowling_alley_id)}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center py-8 text-slate-500">No machines down</p>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Overdue Tasks Dialog */}
        <Dialog open={activeDialog === 'overdue'} onOpenChange={(open) => !open && setActiveDialog(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-yellow-500" />
                Overdue Maintenance Tasks ({overdueTasks.length})
              </DialogTitle>
              <DialogDescription>Tasks past their due date</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 mt-4">
              {overdueTasks.length > 0 ? (
                overdueTasks.map(task => {
                  const daysOverdue = Math.abs(differenceInDays(new Date(), new Date(task.due_date)));
                  return (
                    <div 
                      key={task.id} 
                      className={`p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-red-50 border-red-200'}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className={`font-semibold ${theme.text}`}>{task.task_text}</h3>
                            <Badge className="bg-red-100 text-red-800">{daysOverdue}d overdue</Badge>
                          </div>
                          <div className="space-y-1 text-sm">
                            <p className={theme.textSecondary}>Period: {task.period}</p>
                            <p className={theme.textTertiary}>Due: {format(new Date(task.due_date), 'MMM d, yyyy')}</p>
                            {task.assigned_to && (
                              <p className="text-xs text-slate-500">Assigned to: {task.assigned_to}</p>
                            )}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(createPageUrl("PreventativeMaintenance"));
                          }}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          View
                        </Button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-center py-8 text-slate-500">No overdue tasks</p>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Open Service Calls Dialog */}
        <Dialog open={activeDialog === 'open'} onOpenChange={(open) => !open && setActiveDialog(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-500" />
                Open Service Calls ({openCalls.length})
              </DialogTitle>
              <DialogDescription>All active service calls</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 mt-4">
              {openCalls.length > 0 ? (
                openCalls.map(call => <ServiceCallCard key={call.id} call={call} />)
              ) : (
                <p className="text-center py-8 text-slate-500">No open service calls</p>
              )}
            </div>
          </DialogContent>
        </Dialog>
        </div>
      </div>
    </div>
  );
}