import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wrench, Clock, CheckCircle2, AlertCircle, Package, Download, WifiOff, Wifi } from "lucide-react";
import { useLocation } from "../components/LocationContext";
import { useOfflineSync } from "../components/offline/OfflineManager";
import { useTheme } from "@/components/ThemeContext";
import { usePushNotifications } from "../components/notifications/PushNotificationManager";
import MobileQuickActions from "../components/mobile/MobileQuickActions";
import OfflineDataManager from "../components/mobile/OfflineDataManager";
import TouchOptimizedList from "../components/mobile/TouchOptimizedList";
import ServiceCallCard from "../components/service/ServiceCallCard";

export default function MobileMechanicHub() {
  const { isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const { selectedLocationId } = useLocation();
  const { isOnline, getCachedData, OFFLINE_KEYS } = useOfflineSync();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Enable push notifications
  usePushNotifications(user);

  const { data: onlineServiceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-updated_date'),
    initialData: [],
    enabled: isOnline,
  });

  const { data: onlineParts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: [],
    enabled: isOnline,
  });

  // Use cached data when offline
  const serviceCalls = isOnline ? onlineServiceCalls : getCachedData(OFFLINE_KEYS.SERVICE_CALLS);
  const parts = isOnline ? onlineParts : getCachedData(OFFLINE_KEYS.PARTS);

  const effectiveLocationId = user?.bowling_alley_id;

  // Filter calls by location and assignment
  const myCalls = serviceCalls.filter(call => {
    const locationMatch = effectiveLocationId ? call.bowling_alley_id === effectiveLocationId : true;
    const assignmentMatch = call.assigned_to === user?.email;
    const notCompleted = call.status !== 'completed' && call.status !== 'cancelled';
    return locationMatch && assignmentMatch && notCompleted;
  });

  const urgentCalls = myCalls.filter(c => c.priority === 'urgent');
  const inProgressCalls = myCalls.filter(c => c.status === 'in_progress');

  // Low stock parts
  const lowStockParts = parts.filter(p => 
    p.bowling_alley_id === effectiveLocationId &&
    p.quantity_in_stock > 0 && 
    p.quantity_in_stock <= p.min_quantity
  ).slice(0, 3);

  return (
    <div className={`min-h-screen w-full overflow-x-hidden ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <div className="p-4 pb-20 space-y-4 w-full overflow-x-hidden">
        {/* Offline Banner */}
        {!isOnline && (
          <div className="bg-orange-500 text-white p-3 rounded-lg flex items-center gap-2">
            <WifiOff className="w-5 h-5" />
            <div className="flex-1">
              <p className="font-semibold text-sm">Offline Mode</p>
              <p className="text-xs opacity-90">Using cached data</p>
            </div>
          </div>
        )}

        {/* Header */}
        <div>
          <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            Mechanic Hub
          </h1>
          <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            Welcome, {user?.display_name || user?.full_name}
          </p>
        </div>

        {/* Quick Actions */}
        <MobileQuickActions user={user} />

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardContent className="p-3 text-center">
              <div className="flex flex-col items-center gap-1">
                <AlertCircle className="w-5 h-5 text-red-500" />
                <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {urgentCalls.length}
                </p>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Urgent</p>
              </div>
            </CardContent>
          </Card>

          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardContent className="p-3 text-center">
              <div className="flex flex-col items-center gap-1">
                <Clock className="w-5 h-5 text-amber-500" />
                <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {inProgressCalls.length}
                </p>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Active</p>
              </div>
            </CardContent>
          </Card>

          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardContent className="p-3 text-center">
              <div className="flex flex-col items-center gap-1">
                <Wrench className="w-5 h-5 text-blue-500" />
                <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {myCalls.length}
                </p>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Total</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Low Stock Alert */}
        {lowStockParts.length > 0 && (
          <Card className={`border-orange-300 ${isDarkMode ? 'bg-orange-950/30' : 'bg-orange-50'}`}>
            <CardHeader className="pb-2">
              <CardTitle className={`text-sm flex items-center gap-2 ${isDarkMode ? 'text-orange-400' : 'text-orange-900'}`}>
                <Package className="w-4 h-4" />
                Low Stock Alert
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {lowStockParts.map(part => (
                <div key={part.id} className={`p-2 rounded ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-slate-100' : ''}`}>{part.name}</p>
                  <p className="text-xs text-orange-600">{part.quantity_in_stock} left</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Priority Calls - Urgent First */}
        {urgentCalls.length > 0 && (
          <div>
            <h2 className={`text-lg font-bold mb-3 flex items-center gap-2 ${isDarkMode ? 'text-red-400' : 'text-red-700'}`}>
              <AlertCircle className="w-5 h-5" />
              Urgent Priority
            </h2>
            <div className="space-y-3">
              {urgentCalls.map(call => (
                <ServiceCallCard key={call.id} call={call} />
              ))}
            </div>
          </div>
        )}

        {/* In Progress Calls */}
        {inProgressCalls.length > 0 && (
          <div>
            <h2 className={`text-lg font-bold mb-3 flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              <Clock className="w-5 h-5" />
              In Progress
            </h2>
            <div className="space-y-3">
              {inProgressCalls.map(call => (
                <ServiceCallCard key={call.id} call={call} />
              ))}
            </div>
          </div>
        )}

        {/* All My Calls */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className={`text-lg font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              All My Assignments
            </h2>
            <Link to={createPageUrl("ServiceCalls")}>
              <Button variant="outline" size="sm">View All</Button>
            </Link>
          </div>
          
          {myCalls.length > 0 ? (
            <div className="space-y-3">
              {myCalls.filter(c => c.priority !== 'urgent' && c.status !== 'in_progress').slice(0, 3).map(call => (
                <ServiceCallCard key={call.id} call={call} />
              ))}
            </div>
          ) : (
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardContent className="p-8 text-center">
                <CheckCircle2 className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  No active assignments
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Offline Data Manager */}
        <OfflineDataManager />
      </div>
    </div>
  );
}