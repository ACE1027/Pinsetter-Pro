import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "@/components/ThemeContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Wrench, CalendarDays, ClipboardList, FileSignature, Camera, QrCode } from "lucide-react";
import { format, parseISO } from "date-fns";
import AttachmentUploader from "@/components/attachments/AttachmentUploader";
import AttachmentGallery from "@/components/attachments/AttachmentGallery";
import SignaturePad from "@/components/tasks/SignaturePad";
import TaskQRScanner from "@/components/tasks/TaskQRScanner";

const MyTasks = () => {
  const { theme, isDarkMode } = useTheme();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [selectedTask, setSelectedTask] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentNotes, setCurrentNotes] = useState("");
  const [currentAttachments, setCurrentAttachments] = useState([]);
  const [currentStatus, setCurrentStatus] = useState("");
  const [signatureDialogOpen, setSignatureDialogOpen] = useState(false);
  const [qrScannerOpen, setQrScannerOpen] = useState(false);
  const [completionPhotos, setCompletionPhotos] = useState([]);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: repairLogs = [], isLoading: isLoadingRepairLogs } = useQuery({
    queryKey: ['myRepairLogs', user?.email],
    queryFn: () => base44.entities.MachineRepairLog.filter({ assigned_to: user?.email || "N/A" }, '-created_date'),
    enabled: !!user?.email,
  });

  const { data: scheduledMaintenance = [], isLoading: isLoadingScheduledMaintenance } = useQuery({
    queryKey: ['myScheduledMaintenance', user?.email],
    queryFn: () => base44.entities.ScheduledMaintenance.filter({ assigned_to: user?.email || "N/A" }, '-scheduled_date'),
    enabled: !!user?.email,
  });

  const { data: scheduledTasks = [], isLoading: isLoadingScheduledTasks } = useQuery({
    queryKey: ['myScheduledTasks', user?.email],
    queryFn: () => base44.entities.ScheduledTask.filter({ assigned_to: user?.email || "N/A" }, '-scheduled_date'),
    enabled: !!user?.email,
  });

  const { data: preventativeTasks = [], isLoading: isLoadingPreventativeTasks } = useQuery({
    queryKey: ['preventativeMaintenanceTasks', user?.bowling_alley_id],
    queryFn: () => base44.entities.PreventativeMaintenanceTask.filter({ 
      bowling_alley_id: user?.bowling_alley_id || "N/A",
      status: { $ne: 'completed' }
    }, '-due_date'),
    enabled: !!user?.bowling_alley_id,
  });

  const allTasks = React.useMemo(() => {
    const combined = [];
    repairLogs.forEach(log => combined.push({ ...log, type: 'repair_log', isAssigned: log.assigned_to === user?.email }));
    scheduledMaintenance.forEach(task => combined.push({ ...task, type: 'scheduled_maintenance', isAssigned: task.assigned_to === user?.email }));
    scheduledTasks.forEach(task => combined.push({ ...task, type: 'scheduled_task', isAssigned: task.assigned_to === user?.email }));
    preventativeTasks.forEach(task => combined.push({ ...task, type: 'preventative_maintenance', isAssigned: task.assigned_to === user?.email }));
    
    // Sort: assigned tasks first, then by date
    return combined.sort((a, b) => {
      if (a.isAssigned && !b.isAssigned) return -1;
      if (!a.isAssigned && b.isAssigned) return 1;
      return new Date(b.created_date || b.scheduled_date || b.due_date) - new Date(a.created_date || a.scheduled_date || a.due_date);
    });
  }, [repairLogs, scheduledMaintenance, scheduledTasks, preventativeTasks, user?.email]);

  const filteredTasks = allTasks.filter(task => {
    if (activeTab === "repair_logs" && task.type !== "repair_log") return false;
    if (activeTab === "scheduled_maintenance" && task.type !== "scheduled_maintenance") return false;
    if (activeTab === "scheduled_tasks" && task.type !== "scheduled_task") return false;
    if (activeTab === "preventative_maintenance" && task.type !== "preventative_maintenance") return false;
    return true;
  });

  const updateRepairLogMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MachineRepairLog.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myRepairLogs'] });
      toast.success("Repair log updated successfully");
      setDialogOpen(false);
    },
    onError: (error) => toast.error(`Failed to update: ${error.message}`),
  });

  const updateScheduledMaintenanceMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ScheduledMaintenance.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myScheduledMaintenance'] });
      toast.success("Maintenance updated successfully");
      setDialogOpen(false);
    },
    onError: (error) => toast.error(`Failed to update: ${error.message}`),
  });

  const updateScheduledTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ScheduledTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myScheduledTasks'] });
      toast.success("Task updated successfully");
      setDialogOpen(false);
      setSignatureDialogOpen(false);
    },
    onError: (error) => toast.error(`Failed to update: ${error.message}`),
  });

  const updatePreventativeTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PreventativeMaintenanceTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['preventativeMaintenanceTasks'] });
      toast.success("Preventative maintenance updated successfully");
      setDialogOpen(false);
    },
    onError: (error) => toast.error(`Failed to update: ${error.message}`),
  });

  const handleOpenTaskDetails = (task) => {
    setSelectedTask(task);
    setCurrentNotes(task.notes || "");
    setCurrentAttachments(task.attachments || []);
    setCompletionPhotos(task.completion_photos || []);
    setCurrentStatus(task.status || (task.type === 'repair_log' ? 'open' : task.type === 'scheduled_task' ? 'pending' : 'scheduled'));
    setDialogOpen(true);
  };

  const handleUpdateTask = () => {
    if (!selectedTask) return;

    const updateData = {
      notes: currentNotes,
      attachments: currentAttachments,
      status: currentStatus,
    };

    if (selectedTask.type === 'scheduled_task') {
      updateData.completion_photos = completionPhotos;
      if (currentStatus === 'completed' && !selectedTask.completed_at) {
        updateData.completed_at = new Date().toISOString();
        updateData.completed_by = user?.email;
      }
    }

    if (selectedTask.type === 'repair_log') {
      updateRepairLogMutation.mutate({ id: selectedTask.id, data: updateData });
    } else if (selectedTask.type === 'scheduled_maintenance') {
      updateScheduledMaintenanceMutation.mutate({ id: selectedTask.id, data: updateData });
    } else if (selectedTask.type === 'scheduled_task') {
      updateScheduledTaskMutation.mutate({ id: selectedTask.id, data: updateData });
    } else if (selectedTask.type === 'preventative_maintenance') {
      updatePreventativeTaskMutation.mutate({ id: selectedTask.id, data: updateData });
    }
  };

  const handleSignatureComplete = ({ signatureData, signerName }) => {
    if (!selectedTask) return;
    
    const updateData = {
      signature_data: signatureData,
      signature_name: signerName,
      signed_at: new Date().toISOString(),
      status: 'completed',
      completed_at: new Date().toISOString(),
      completed_by: user?.email,
    };

    updateScheduledTaskMutation.mutate({ id: selectedTask.id, data: updateData });
  };

  const handleQRScan = async (qrCode) => {
    try {
      const tasks = await base44.entities.ScheduledTask.filter({ qr_code: qrCode });
      if (tasks.length === 0) {
        toast.error('Invalid task code');
        return;
      }
      
      const task = tasks[0];
      const updateData = {
        status: 'completed',
        completed_at: new Date().toISOString(),
        completed_by: user?.email,
        completed_via_qr: true,
      };

      await base44.entities.ScheduledTask.update(task.id, updateData);
      queryClient.invalidateQueries({ queryKey: ['myScheduledTasks'] });
      toast.success('Task marked as completed!');
      setQrScannerOpen(false);
    } catch (error) {
      toast.error('Failed to complete task');
    }
  };

  const handleTakePhoto = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment';
    input.onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setCompletionPhotos(prev => [...prev, file_url]);
        toast.success('Photo added');
      } catch (error) {
        toast.error('Failed to upload photo');
      }
    };
    input.click();
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      open: { color: "bg-blue-100 text-blue-800", label: "Open" },
      scheduled: { color: "bg-blue-100 text-blue-800", label: "Scheduled" },
      in_progress: { color: "bg-yellow-100 text-yellow-800", label: "In Progress" },
      on_hold: { color: "bg-red-100 text-red-800", label: "On Hold" },
      completed: { color: "bg-green-100 text-green-800", label: "Completed" },
      overdue: { color: "bg-orange-100 text-orange-800", label: "Overdue" },
    };
    const { color, label } = statusMap[status] || statusMap.open;
    return <Badge className={color}>{label}</Badge>;
  };

  const getTaskTitle = (task) => {
    if (task.type === 'repair_log') {
      return task.description?.substring(0, 50) + (task.description?.length > 50 ? '...' : '');
    } else if (task.type === 'scheduled_maintenance') {
      return task.maintenance_type;
    } else if (task.type === 'scheduled_task') {
      return task.task_title;
    } else if (task.type === 'preventative_maintenance') {
      return `${task.period.charAt(0).toUpperCase() + task.period.slice(1)}: ${task.task_text}`;
    }
    return "Unknown Task";
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className={`min-h-full ${theme.bg}`}>
      <div className="p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-3">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>My Tasks</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>View and manage your assigned tasks</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setQrScannerOpen(true)}>
              <QrCode className="w-4 h-4 mr-2" />
              Scan QR Code
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full max-w-3xl grid-cols-5">
            <TabsTrigger value="all">All ({allTasks.length})</TabsTrigger>
            <TabsTrigger value="scheduled_tasks">Scheduled ({scheduledTasks.length})</TabsTrigger>
            <TabsTrigger value="repair_logs">Repairs ({repairLogs.length})</TabsTrigger>
            <TabsTrigger value="scheduled_maintenance">Maintenance ({scheduledMaintenance.length})</TabsTrigger>
            <TabsTrigger value="preventative_maintenance">Preventative ({preventativeTasks.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <TaskList tasks={filteredTasks} isLoading={isLoadingRepairLogs || isLoadingScheduledMaintenance || isLoadingScheduledTasks || isLoadingPreventativeTasks} onOpenDetails={handleOpenTaskDetails} theme={theme} isDarkMode={isDarkMode} getStatusBadge={getStatusBadge} getTaskTitle={getTaskTitle} />
          </TabsContent>
          <TabsContent value="scheduled_tasks">
            <TaskList tasks={filteredTasks} isLoading={isLoadingScheduledTasks} onOpenDetails={handleOpenTaskDetails} theme={theme} isDarkMode={isDarkMode} getStatusBadge={getStatusBadge} getTaskTitle={getTaskTitle} />
          </TabsContent>
          <TabsContent value="repair_logs">
            <TaskList tasks={filteredTasks} isLoading={isLoadingRepairLogs} onOpenDetails={handleOpenTaskDetails} theme={theme} isDarkMode={isDarkMode} getStatusBadge={getStatusBadge} getTaskTitle={getTaskTitle} />
          </TabsContent>
          <TabsContent value="scheduled_maintenance">
            <TaskList tasks={filteredTasks} isLoading={isLoadingScheduledMaintenance} onOpenDetails={handleOpenTaskDetails} theme={theme} isDarkMode={isDarkMode} getStatusBadge={getStatusBadge} getTaskTitle={getTaskTitle} />
          </TabsContent>
          <TabsContent value="preventative_maintenance">
            <TaskList tasks={filteredTasks} isLoading={isLoadingPreventativeTasks} onOpenDetails={handleOpenTaskDetails} theme={theme} isDarkMode={isDarkMode} getStatusBadge={getStatusBadge} getTaskTitle={getTaskTitle} />
          </TabsContent>
        </Tabs>

        {selectedTask && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{getTaskTitle(selectedTask)}</DialogTitle>
                <div className="flex items-center gap-2 flex-wrap mt-2">
                  {getStatusBadge(selectedTask.status)}
                  {selectedTask.lane_number && <Badge variant="secondary">Lane {selectedTask.lane_number}</Badge>}
                  {selectedTask.machine_type && <Badge variant="secondary">{selectedTask.machine_type}</Badge>}
                </div>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg">Details</h3>
                  {selectedTask.type === 'repair_log' && (
                    <>
                      <p><strong>Description:</strong> {selectedTask.description}</p>
                      {selectedTask.parts_used && <p><strong>Parts Used:</strong> {selectedTask.parts_used}</p>}
                      {selectedTask.time_spent && <p><strong>Time Spent:</strong> {selectedTask.time_spent} minutes</p>}
                    </>
                  )}
                  {selectedTask.type === 'scheduled_maintenance' && (
                    <>
                      <p><strong>Maintenance Type:</strong> {selectedTask.maintenance_type}</p>
                      <p><strong>Scheduled:</strong> {format(parseISO(selectedTask.scheduled_date), 'MMM d, yyyy h:mm a')}</p>
                      {selectedTask.due_date && <p><strong>Due:</strong> {format(parseISO(selectedTask.due_date), 'MMM d, yyyy h:mm a')}</p>}
                      {selectedTask.description && <p><strong>Description:</strong> {selectedTask.description}</p>}
                    </>
                  )}
                  {selectedTask.type === 'scheduled_task' && (
                    <>
                      <p><strong>Task:</strong> {selectedTask.task_title}</p>
                      <p><strong>Scheduled:</strong> {format(parseISO(selectedTask.scheduled_date), 'MMM d, yyyy h:mm a')}</p>
                      {selectedTask.due_date && <p><strong>Due:</strong> {format(parseISO(selectedTask.due_date), 'MMM d, yyyy h:mm a')}</p>}
                      {selectedTask.description && <p><strong>Description:</strong> {selectedTask.description}</p>}
                      {selectedTask.qr_code && <p><strong>QR Code:</strong> {selectedTask.qr_code}</p>}
                      {selectedTask.signature_name && (
                        <>
                          <p><strong>Signed by:</strong> {selectedTask.signature_name}</p>
                          <p><strong>Signed at:</strong> {format(parseISO(selectedTask.signed_at), 'MMM d, yyyy h:mm a')}</p>
                        </>
                      )}
                    </>
                  )}
                  {selectedTask.type === 'preventative_maintenance' && (
                    <>
                      <p><strong>Task:</strong> {selectedTask.task_text}</p>
                      <p><strong>Period:</strong> {selectedTask.period}</p>
                      {selectedTask.category && <p><strong>Category:</strong> {selectedTask.category}</p>}
                      {selectedTask.due_date && <p><strong>Due:</strong> {format(parseISO(selectedTask.due_date), 'MMM d, yyyy')}</p>}
                      {selectedTask.assigned_to && <p><strong>Assigned to:</strong> {selectedTask.assigned_to}</p>}
                    </>
                  )}
                  <p className="text-sm text-slate-500">Created: {format(parseISO(selectedTask.created_date || selectedTask.device_timestamp || selectedTask.scheduled_date), 'MMM d, yyyy h:mm a')}</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="taskStatus">Update Status</Label>
                  <Select value={currentStatus} onValueChange={setCurrentStatus}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedTask.type === 'repair_log' ? (
                        <>
                          <SelectItem value="open">Open</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="on_hold">On Hold</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </>
                      ) : selectedTask.type === 'scheduled_task' ? (
                        <>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </>
                      ) : selectedTask.type === 'preventative_maintenance' ? (
                        <>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="overdue">Overdue</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="scheduled">Scheduled</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="on_hold">On Hold</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="overdue">Overdue</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="taskNotes">Add/Update Notes</Label>
                  <Textarea id="taskNotes" value={currentNotes} onChange={(e) => setCurrentNotes(e.target.value)} placeholder="Add notes about the task..." rows={4} />
                </div>

                <div className="space-y-2">
                  <Label>Photos & Videos</Label>
                  <AttachmentUploader attachments={currentAttachments} onChange={setCurrentAttachments} />
                  {currentAttachments.length > 0 && (
                    <div className="mt-2">
                      <AttachmentGallery attachments={currentAttachments} isDarkMode={isDarkMode} />
                    </div>
                  )}
                </div>

                {selectedTask.type === 'scheduled_task' && (
                  <>
                    <div className="space-y-2">
                      <Label>Completion Photos</Label>
                      <Button type="button" variant="outline" onClick={handleTakePhoto} className="w-full">
                        <Camera className="w-4 h-4 mr-2" />
                        Take Photo
                      </Button>
                      {completionPhotos.length > 0 && (
                        <div className="grid grid-cols-3 gap-2 mt-2">
                          {completionPhotos.map((url, idx) => (
                            <img key={idx} src={url} alt="Completion" className="w-full h-24 object-cover rounded" />
                          ))}
                        </div>
                      )}
                    </div>

                    {selectedTask.requires_signature && !selectedTask.signature_data && (
                      <div className="pt-4 border-t">
                        <Button 
                          type="button" 
                          onClick={() => setSignatureDialogOpen(true)} 
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          <FileSignature className="w-4 h-4 mr-2" />
                          Sign to Complete Task
                        </Button>
                      </div>
                    )}

                    {selectedTask.signature_data && (
                      <div className="space-y-2">
                        <Label>Signature</Label>
                        <div className="border rounded-lg p-2 bg-slate-50">
                          <img src={selectedTask.signature_data} alt="Signature" className="max-h-32" />
                          <p className="text-xs text-slate-600 mt-2">Signed by: {selectedTask.signature_name}</p>
                        </div>
                      </div>
                    )}
                  </>
                )}

                <div className="flex justify-end gap-3 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
                  <Button onClick={handleUpdateTask} disabled={updateRepairLogMutation.isPending || updateScheduledMaintenanceMutation.isPending || updateScheduledTaskMutation.isPending || updatePreventativeTaskMutation.isPending}>
                    {(updateRepairLogMutation.isPending || updateScheduledMaintenanceMutation.isPending || updateScheduledTaskMutation.isPending || updatePreventativeTaskMutation.isPending) ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {selectedTask && (
          <Dialog open={signatureDialogOpen} onOpenChange={setSignatureDialogOpen}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Sign Task Completion</DialogTitle>
              </DialogHeader>
              <SignaturePad 
                onSave={handleSignatureComplete}
                onCancel={() => setSignatureDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>
        )}

        <TaskQRScanner
          open={qrScannerOpen}
          onOpenChange={setQrScannerOpen}
          onScan={handleQRScan}
        />
        </div>
      </div>
    </div>
  );
};

const TaskList = ({ tasks, isLoading, onOpenDetails, theme, isDarkMode, getStatusBadge, getTaskTitle }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array(3).fill(0).map((_, i) => (
          <div key={i} className={`h-48 rounded-lg animate-pulse ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`} />
        ))}
      </div>
    );
  }

  if (tasks.length === 0) {
    return (
      <div className={`rounded-lg border-2 border-dashed p-12 text-center ${isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-300'}`}>
        <ClipboardList className="w-12 h-12 text-slate-400 mx-auto mb-4" />
        <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>No tasks assigned</h3>
        <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>You're all caught up!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {tasks.map(task => (
        <Card key={task.id} className={`shadow-sm hover:shadow-md transition-shadow cursor-pointer ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`} onClick={() => onOpenDetails(task)}>
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                {task.type === 'repair_log' ? <Wrench className="w-5 h-5 text-blue-600 flex-shrink-0" /> : <CalendarDays className="w-5 h-5 text-green-600 flex-shrink-0" />}
                <CardTitle className="text-base truncate">{getTaskTitle(task)}</CardTitle>
              </div>
              {getStatusBadge(task.status)}
            </div>
          </CardHeader>
          <CardContent className={isDarkMode ? 'text-slate-300' : 'text-slate-600'}>
            {task.lane_number && <p className="text-sm">Lane: {task.lane_number}</p>}
            {task.machine_type && <p className="text-sm">Machine: {task.machine_type}</p>}
            <p className="text-xs text-slate-500 mt-2">
              {task.type === 'repair_log' 
                ? `Logged: ${format(parseISO(task.created_date), 'MMM d, yyyy')}` 
                : task.type === 'preventative_maintenance'
                  ? task.due_date ? `Due: ${format(parseISO(task.due_date), 'MMM d, yyyy')}` : `Period: ${task.period}`
                  : `Scheduled: ${format(parseISO(task.scheduled_date), 'MMM d, yyyy')}`}
            </p>
            {task.isAssigned && <Badge variant="outline" className="mt-1 text-xs">Assigned to you</Badge>}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default MyTasks;