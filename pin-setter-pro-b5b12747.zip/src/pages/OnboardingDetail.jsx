import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Clock, User, Calendar, ExternalLink, BookOpen } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";

export default function OnboardingDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  
  const urlParams = new URLSearchParams(window.location.search);
  const checklistId = urlParams.get('id');

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: checklist } = useQuery({
    queryKey: ['onboardingChecklist', checklistId],
    queryFn: () => base44.entities.OnboardingChecklist.get(checklistId),
    enabled: !!checklistId
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['onboardingTasks', checklistId],
    queryFn: async () => {
      const allTasks = await base44.entities.OnboardingTask.list();
      return allTasks.filter(t => t.checklist_id === checklistId);
    },
    enabled: !!checklistId
  });

  const { data: resources = [] } = useQuery({
    queryKey: ['onboardingResources'],
    queryFn: () => base44.entities.OnboardingResource.list('order'),
    initialData: []
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.OnboardingTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingTasks', checklistId] });
      const completedTasks = tasks.filter(t => t.status === 'completed').length + 1;
      const percentage = Math.round((completedTasks / tasks.length) * 100);
      
      base44.entities.OnboardingChecklist.update(checklistId, {
        completion_percentage: percentage,
        status: percentage === 100 ? 'completed' : 'in_progress'
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['onboardingChecklist', checklistId] });
      });
      
      toast.success("Task updated");
    }
  });

  const handleToggleTask = (task) => {
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    const updateData = {
      status: newStatus,
      ...(newStatus === 'completed' ? {
        completed_date: new Date().toISOString(),
        completed_by: user.email
      } : {
        completed_date: null,
        completed_by: null
      })
    };
    updateTaskMutation.mutate({ id: task.id, data: updateData });
  };

  if (!checklist) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  const isManager = user && (user.department === 'manager' || user.role === 'admin');
  const isEmployee = user && user.email === checklist.employee_email;
  
  const tasksByCategory = tasks.reduce((acc, task) => {
    if (!acc[task.category]) acc[task.category] = [];
    acc[task.category].push(task);
    return acc;
  }, {});

  const completedCount = tasks.filter(t => t.status === 'completed').length;
  const progress = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  const relevantResources = resources.filter(r => 
    r.active && 
    (r.position_specific.length === 0 || r.position_specific.includes(checklist.position))
  );

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
            Onboarding: {checklist.employee_name}
          </h1>
          <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            {checklist.position}
          </p>
        </div>

        <Card className={`mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className={isDarkMode ? 'text-slate-300' : ''}>Progress Overview</CardTitle>
              <Badge className={
                checklist.status === 'completed' ? 'bg-green-100 text-green-800' :
                checklist.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                'bg-yellow-100 text-yellow-800'
              }>
                {checklist.status.replace(/_/g, ' ')}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Start Date</p>
                <p className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {format(new Date(checklist.start_date), 'MMM d, yyyy')}
                </p>
              </div>
              <div>
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Tasks Completed</p>
                <p className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  {completedCount} / {tasks.length}
                </p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Overall Progress</span>
                <span className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{progress}%</span>
              </div>
              <Progress value={progress} className="h-3" />
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          {Object.entries(tasksByCategory).map(([category, categoryTasks]) => (
            <Card key={category} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`text-lg capitalize ${isDarkMode ? 'text-slate-300' : ''}`}>{category.replace(/_/g, ' ')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {categoryTasks.map(task => (
                    <div 
                      key={task.id} 
                      className={`p-4 rounded-lg border ${
                        task.status === 'completed' 
                          ? isDarkMode ? 'bg-green-950/20 border-green-800' : 'bg-green-50 border-green-200'
                          : isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <Checkbox
                          checked={task.status === 'completed'}
                          onCheckedChange={() => handleToggleTask(task)}
                          disabled={!isManager && !isEmployee}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h4 className={`font-semibold ${task.status === 'completed' ? 'line-through opacity-60' : ''} ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                {task.title}
                              </h4>
                              {task.description && (
                                <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                  {task.description}
                                </p>
                              )}
                            </div>
                            <Badge variant="outline" className="ml-2">
                              {task.assigned_to_role}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-xs">
                            <span className={`flex items-center gap-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              <Calendar className="w-3 h-3" />
                              Due: {format(new Date(task.due_date), 'MMM d')}
                            </span>
                            {task.status === 'completed' && task.completed_date && (
                              <span className="flex items-center gap-1 text-green-600">
                                <CheckCircle2 className="w-3 h-3" />
                                Completed {format(new Date(task.completed_date), 'MMM d')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {relevantResources.length > 0 && (
          <Card className={`mt-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
            <CardHeader>
              <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-300' : ''}`}>
                <BookOpen className="w-5 h-5" />
                Resources
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {relevantResources.map(resource => (
                  <div 
                    key={resource.id}
                    className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className={`font-medium text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                        {resource.title}
                      </h4>
                      <Badge variant="outline" className="text-xs">{resource.category}</Badge>
                    </div>
                    {resource.description && (
                      <p className={`text-xs mb-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                        {resource.description}
                      </p>
                    )}
                    {resource.external_url && (
                      <a 
                        href={resource.external_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                      >
                        View Resource <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}