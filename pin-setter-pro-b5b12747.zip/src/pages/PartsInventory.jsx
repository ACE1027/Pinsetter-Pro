import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow } from
"@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger } from
"@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Search, AlertTriangle, Package, Building2, Edit, Trash2, BookOpen, Lock, XCircle, Ban, ArrowUpDown, ArrowUp, ArrowDown, Settings } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useLocation } from "../components/LocationContext";
import { useNotifications, NotificationPrompt } from "../components/NotificationManager";
import { useTheme } from "@/components/ThemeContext";

const MACHINE_TYPES = [
{ value: "Original A Pinsetter", label: "Original A Pinsetter" },
{ value: "A-2 Pinsetter", label: "A-2 Pinsetter" },
{ value: "Jetback Pinsetter", label: "Jetback Pinsetter" },
{ value: "String Pin Boost XT", label: "String Pin Boost XT" },
{ value: "GS-X Machine", label: "GS-X Machine" },
{ value: "Brunswick GSX NXT", label: "Brunswick GSX NXT" },
{ value: "82-30", label: "82-30" },
{ value: "82-70 Pinspotter", label: "82-70 Pinspotter" },
{ value: "82-90 Pinspotter", label: "82-90 Pinspotter" },
{ value: "90XLI Pinspotter", label: "90XLI Pinspotter" },
{ value: "Qubica AMF XLI Edge", label: "Qubica AMF XLI Edge" },
{ value: "EDGE Free Fall Pinspotter", label: "EDGE Free Fall Pinspotter" },
{ value: "EDGE String Pin Pinspotter", label: "EDGE String Pin Pinspotter" },
{ value: "Other", label: "Other" }];


export default function PartsInventory() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPart, setEditingPart] = useState(null);
  const [activeTab, setActiveTab] = useState("in_stock");
  const [sortField, setSortField] = useState("part_number");
  const [sortDirection, setSortDirection] = useState("asc");
  const [machineTypeFilter, setMachineTypeFilter] = useState("all");
  const { selectedLocationId } = useLocation();
  const { sendNotification } = useNotifications();
  const [notifiedLowStock, setNotifiedLowStock] = useState(new Set());
  const [formData, setFormData] = useState({
    bowling_alley_id: "",
    catalog_type: "pinsetter",
    machine_type: "A-2 Pinsetter",
    category: "",
    part_number: "",
    name: "",
    description: "",
    quantity_in_stock: 0,
    min_quantity: 5,
    location: "",
    cost: 0,
    discontinued: false
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.bowling_alley_id && activeTab === 'in_stock') {
        setFormData((prev) => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});
  }, []);

  const { data: parts = [], isLoading } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list(),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const createMutation = useMutation({
    mutationFn: (data) => {
      const cleanedData = { ...data };
      if (!cleanedData.bowling_alley_id) {
        delete cleanedData.bowling_alley_id;
      }
      return base44.entities.Part.create(cleanedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      resetForm();
      const message = activeTab === 'master' ?
      "Catalog item added successfully" :
      "Part added to inventory";
      toast.success(message);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => {
      const cleanedData = { ...data };
      if (!cleanedData.bowling_alley_id) {
        delete cleanedData.bowling_alley_id;
      }
      return base44.entities.Part.update(id, cleanedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      resetForm();
      toast.success("Part updated successfully");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Part.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      toast.success("Part deleted successfully");
    }
  });

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  const canViewAll = isAdmin || isManager;
  const canEdit = isAdmin || isManager;
  const canAddToCatalog = isAdmin;

  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' ?
  selectedLocationId :
  user?.bowling_alley_id;

  const userLocationParts = effectiveLocationId ?
  parts.filter((p) => p.bowling_alley_id === effectiveLocationId) :
  [];

  const inStockParts = userLocationParts.filter((p) => p.quantity_in_stock > 0 && !p.discontinued);
  const outOfStockParts = userLocationParts.filter((p) => p.quantity_in_stock === 0 && !p.discontinued);
  const discontinuedParts = userLocationParts.filter((p) => p.discontinued === true);
  const masterListParts = parts.filter((p) => !p.bowling_alley_id && (p.catalog_type === 'pinsetter' || !p.catalog_type));
  const centerCatalogParts = parts.filter((p) => !p.bowling_alley_id && p.catalog_type === 'center');

  const displayParts = activeTab === 'master' ?
  masterListParts :
  activeTab === 'center_catalog' ?
  centerCatalogParts :
  activeTab === 'out_of_stock' ?
  outOfStockParts :
  activeTab === 'discontinued' ?
  discontinuedParts :
  inStockParts;

  // Apply machine type filter
  const machineFilteredParts = displayParts.filter((part) => {
    if (machineTypeFilter === 'all') return true;
    return part.machine_type === machineTypeFilter;
  });

  const filteredParts = machineFilteredParts.filter((part) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      part.name?.toLowerCase().includes(query) ||
      part.part_number?.toLowerCase().includes(query) ||
      part.description?.toLowerCase().includes(query));

  });

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedParts = [...filteredParts].sort((a, b) => {
    let aValue = a[sortField];
    let bValue = b[sortField];

    if (aValue === null || aValue === undefined) aValue = '';
    if (bValue === null || bValue === undefined) bValue = '';

    if (typeof aValue === 'string') aValue = aValue.toLowerCase();
    if (typeof bValue === 'string') bValue = bValue.toLowerCase();

    if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  const SortIcon = ({ field }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-4 h-4 ml-1 text-slate-400" />;
    }
    return sortDirection === 'asc' ?
    <ArrowUp className="w-4 h-4 ml-1 text-blue-600" /> :
    <ArrowDown className="w-4 h-4 ml-1 text-blue-600" />;
  };

  const lowStockParts = userLocationParts.filter((p) => p.quantity_in_stock > 0 && p.quantity_in_stock <= p.min_quantity && !p.discontinued);
  const outOfStockList = userLocationParts.filter((p) => p.quantity_in_stock === 0 && !p.discontinued);

  // Monitor for low stock and send notifications
  useEffect(() => {
    lowStockParts.forEach((part) => {
      if (!notifiedLowStock.has(part.id)) {
        sendNotification('⚠️ Low Stock Alert', {
          body: `${part.name} is running low (${part.quantity_in_stock} remaining)`,
          tag: `low-stock-${part.id}`
        });
        setNotifiedLowStock((prev) => new Set([...prev, part.id]));
      }
    });

    outOfStockList.forEach((part) => {
      if (!notifiedLowStock.has(part.id)) {
        sendNotification('🚨 Out of Stock', {
          body: `${part.name} is out of stock`,
          tag: `out-of-stock-${part.id}`
        });
        setNotifiedLowStock((prev) => new Set([...prev, part.id]));
      }
    });
  }, [lowStockParts, outOfStockList, sendNotification]);

  // Clear notification tracking when stock is replenished
  useEffect(() => {
    const currentLowStockIds = new Set(lowStockParts.map((p) => p.id));
    const currentOutOfStockIds = new Set(outOfStockList.map((p) => p.id));

    setNotifiedLowStock((prev) => {
      const updated = new Set(prev);
      prev.forEach((id) => {
        if (!currentLowStockIds.has(id) && !currentOutOfStockIds.has(id)) {
          updated.delete(id);
        }
      });
      return updated;
    });
  }, [lowStockParts, outOfStockList]);

  const resetForm = () => {
    setDialogOpen(false);
    setEditingPart(null);
    const defaultBowlingAlleyId = activeTab === 'in_stock' && user?.bowling_alley_id ? user.bowling_alley_id : "";
    setFormData({
      bowling_alley_id: defaultBowlingAlleyId,
      catalog_type: activeTab === 'center_catalog' ? 'center' : 'pinsetter',
      machine_type: "A-2 Pinsetter",
      category: "",
      part_number: "",
      name: "",
      description: "",
      quantity_in_stock: 0,
      min_quantity: 5,
      location: "",
      cost: 0,
      discontinued: false
    });
  };

  const handleEdit = (part) => {
    if (!part.bowling_alley_id && !isAdmin) {
      toast.error("Only administrators can edit catalog items");
      return;
    }

    setEditingPart(part);
    setFormData({
      bowling_alley_id: part.bowling_alley_id || "",
      catalog_type: part.catalog_type || "pinsetter",
      machine_type: part.machine_type || "A-2 Pinsetter",
      category: part.category || "",
      part_number: part.part_number || "",
      name: part.name || "",
      description: part.description || "",
      quantity_in_stock: part.quantity_in_stock || 0,
      min_quantity: part.min_quantity || 5,
      location: part.location || "",
      cost: part.cost || 0,
      discontinued: part.discontinued || false
    });
    setDialogOpen(true);
  };

  const handleDelete = (part) => {
    if (!part.bowling_alley_id && !isAdmin) {
      toast.error("Only administrators can delete catalog items");
      return;
    }

    if (window.confirm(`Are you sure you want to delete ${part.name}?`)) {
      deleteMutation.mutate(part.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingPart) {
      updateMutation.mutate({ id: editingPart.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => {
      const newData = { ...prev, [field]: value };

      if (field === 'part_number' && activeTab === 'in_stock' && !editingPart) {
        const catalogPart = masterListParts.find((p) => p.part_number === value);
        if (catalogPart) {
          newData.name = catalogPart.name;
          newData.description = catalogPart.description || "";
          newData.cost = catalogPart.cost || 0;
          newData.machine_type = catalogPart.machine_type || "A-2 Pinsetter";
        }
      }

      return newData;
    });
  };

  const handleAddPartClick = () => {
    if (activeTab === 'master' && !isAdmin) {
      toast.error("Only administrators can add items to the true catalog");
      return;
    }

    setEditingPart(null);
    if (activeTab === 'in_stock' || activeTab === 'out_of_stock' || activeTab === 'discontinued') {
      const defaultLocationId = effectiveLocationId || user?.bowling_alley_id;
      setFormData({
        bowling_alley_id: defaultLocationId || "",
        catalog_type: "pinsetter",
        machine_type: "A-2 Pinsetter",
        category: "",
        part_number: "",
        name: "",
        description: "",
        quantity_in_stock: 0,
        min_quantity: 5,
        location: "",
        cost: 0,
        discontinued: false
      });
    } else if (activeTab === 'master' || activeTab === 'center_catalog') {
      setFormData({
        bowling_alley_id: "",
        catalog_type: activeTab === 'center_catalog' ? 'center' : 'pinsetter',
        machine_type: "A-2 Pinsetter",
        category: "",
        part_number: "",
        name: "",
        description: "",
        quantity_in_stock: 0,
        min_quantity: 0,
        location: "",
        cost: 0,
        discontinued: false
      });
    }
    setDialogOpen(true);
  };

  const getLocationName = (locationId) => {
    const location = locations.find((l) => l.id === locationId);
    return location?.name || 'Unknown Location';
  };

  // Get badge color for machine type
  const getMachineTypeBadge = (machineType) => {
    const colors = {
      "Original A Pinsetter": "bg-indigo-100 text-indigo-800 border-indigo-300",
      "A-2 Pinsetter": "bg-blue-100 text-blue-800 border-blue-300",
      "Jetback Pinsetter": "bg-cyan-100 text-cyan-800 border-cyan-300",
      "String Pin Boost XT": "bg-purple-100 text-purple-800 border-purple-300",
      "GS-X Machine": "bg-green-100 text-green-800 border-green-300",
      "Brunswick GSX NXT": "bg-teal-100 text-teal-800 border-teal-300",
      "82-30": "bg-rose-100 text-rose-800 border-rose-300",
      "82-70 Pinspotter": "bg-orange-100 text-orange-800 border-orange-300",
      "82-90 Pinspotter": "bg-amber-100 text-amber-800 border-amber-300",
      "90XLI Pinspotter": "bg-lime-100 text-lime-800 border-lime-300",
      "Qubica AMF XLI Edge": "bg-emerald-100 text-emerald-800 border-emerald-300",
      "EDGE Free Fall Pinspotter": "bg-sky-100 text-sky-800 border-sky-300",
      "EDGE String Pin Pinspotter": "bg-violet-100 text-violet-800 border-violet-300",
      "Other": "bg-slate-100 text-slate-800 border-slate-300"
    };
    return colors[machineType] || colors["Other"];
  };

  const selectedLocation = locations.find((l) => l.id === effectiveLocationId);
  const isAddingToMasterList = (activeTab === 'master' || activeTab === 'center_catalog') && !editingPart;
  const showAddButton = activeTab === 'in_stock' || activeTab === 'out_of_stock' || activeTab === 'discontinued' || ((activeTab === 'master' || activeTab === 'center_catalog') && canAddToCatalog);

  // Count parts by machine type for filter display
  const machineTypeCounts = MACHINE_TYPES.reduce((acc, type) => {
    acc[type.value] = displayParts.filter((p) => p.machine_type === type.value).length;
    return acc;
  }, {});

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full overflow-x-hidden">
        <NotificationPrompt />
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Inventory</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              {selectedLocation ? `${selectedLocation.name} - ` : ''}Manage parts and stock levels
            </p>
            <div className="flex items-center gap-2 mt-2">
              <BookOpen className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-slate-600">
                <strong className="text-blue-700">{masterListParts.length + centerCatalogParts.length}</strong> catalog items available
              </span>
            </div>
          </div>
          {showAddButton ?
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" onClick={handleAddPartClick}>
                  <Plus className="w-4 h-4 mr-2" />
                  {activeTab === 'master' ? 'Add Catalog Item' : 'Add Part'}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    {editingPart ?
                  <>
                        <Edit className="w-5 h-5 text-blue-600" />
                        Edit Part
                      </> :
                  activeTab === 'master' || activeTab === 'center_catalog' ?
                  <>
                        <BookOpen className="w-5 h-5 text-blue-600" />
                        Add {activeTab === 'master' ? 'Pinsetter' : 'Center'} Catalog Item
                      </> :

                  <>
                        <Package className="w-5 h-5 text-blue-600" />
                        Add Part to Location Inventory
                      </>
                  }
                  </DialogTitle>
                </DialogHeader>
                
                {isAddingToMasterList &&
              <Alert className="bg-blue-50 border-blue-200">
                    <BookOpen className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-900 text-sm">
                      <strong>{activeTab === 'master' ? 'Pinsetter' : 'Center'} Catalog Item:</strong> This creates a reference entry in the {activeTab === 'master' ? 'Pinsetter' : 'Center'} catalog without assigning it to any specific location.
                    </AlertDescription>
                  </Alert>
              }

                {!editingPart && (activeTab === 'in_stock' || activeTab === 'out_of_stock' || activeTab === 'discontinued') &&
              <Alert className="bg-green-50 border-green-200">
                    <Package className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-900 text-sm">
                      <strong>Location Inventory:</strong> This adds a part with actual stock quantity at {selectedLocation ? selectedLocation.name : 'a specific location'}. Stock levels and inventory tracking will be maintained for this location.
                    </AlertDescription>
                  </Alert>
              }

                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Machine Type and Category */}
                  <div className="grid grid-cols-2 gap-4">
                    {(formData.catalog_type === 'pinsetter' || activeTab === 'in_stock' || activeTab === 'out_of_stock' || activeTab === 'discontinued') && (
                      <div className="space-y-2">
                        <Label htmlFor="machine_type">Machine Type *</Label>
                        <Select
                        value={formData.machine_type}
                        onValueChange={(value) => handleChange('machine_type', value)}
                        required>

                          <SelectTrigger>
                            <SelectValue placeholder="Select machine type" />
                          </SelectTrigger>
                          <SelectContent>
                            {MACHINE_TYPES.map((type) =>
                          <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                          )}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <div className={formData.catalog_type === 'center' ? "col-span-2 space-y-2" : "space-y-2"}>
                      <Label htmlFor="category">Category</Label>
                      <Select
                      value={formData.category}
                      onValueChange={(value) => handleChange('category', value)}>

                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>None</SelectItem>
                          {formData.catalog_type === 'center' ? (
                            <>
                              <SelectItem value="Kitchen">Kitchen</SelectItem>
                              <SelectItem value="Bar">Bar</SelectItem>
                              <SelectItem value="Janitorial">Janitorial</SelectItem>
                              <SelectItem value="Front Counter">Front Counter</SelectItem>
                              <SelectItem value="Pro Shop">Pro Shop</SelectItem>
                            </>
                          ) : (
                            <>
                              <SelectItem value="Gearbox Assembly">Gearbox Assembly</SelectItem>
                              <SelectItem value="Detector Assembly">Detector Assembly</SelectItem>
                              <SelectItem value="Cross Conveyor Assembly">Cross Conveyor Assembly</SelectItem>
                              <SelectItem value="Turret Assembly">Turret Assembly</SelectItem>
                              <SelectItem value="Deck Assembly">Deck Assembly</SelectItem>
                              <SelectItem value="Rake Assembly">Rake Assembly</SelectItem>
                              <SelectItem value="Elevator Assembly">Elevator Assembly</SelectItem>
                              <SelectItem value="Pit Assembly">Pit Assembly</SelectItem>
                              <SelectItem value="Pit Cushion Assembly">Pit Cushion Assembly</SelectItem>
                              <SelectItem value="Electrical">Electrical</SelectItem>
                              <SelectItem value="Ball Return Assembly">Ball Return Assembly</SelectItem>
                              <SelectItem value="Belts">Belts</SelectItem>
                              <SelectItem value="Hardware">Hardware</SelectItem>
                              <SelectItem value="Miscellaneous">Miscellaneous</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {!isAddingToMasterList &&
                <div className="space-y-2">
                      <Label htmlFor="bowling_alley_id">Location *</Label>
                      {canViewAll ?
                  <Select
                    value={formData.bowling_alley_id || ""}
                    onValueChange={(value) => handleChange('bowling_alley_id', value)}
                    required>

                          <SelectTrigger>
                            <SelectValue placeholder="Select location" />
                          </SelectTrigger>
                          <SelectContent>
                            {locations.filter((l) => l.active !== false).map((location) =>
                      <SelectItem key={location.id} value={location.id}>
                                {location.name}
                              </SelectItem>
                      )}
                          </SelectContent>
                        </Select> :
                  user?.bowling_alley_id ?
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                          <p className="text-sm text-slate-700 font-medium">
                            {getLocationName(user.bowling_alley_id)}
                          </p>
                        </div> :
                  null}
                    </div>
                }

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="part_number">Part Number *</Label>
                      {!editingPart && (activeTab === 'in_stock' || activeTab === 'out_of_stock' || activeTab === 'discontinued') && masterListParts.length > 0 ?
                    <Select
                      value={formData.part_number}
                      onValueChange={(value) => handleChange('part_number', value)}
                      required>

                          <SelectTrigger>
                            <SelectValue placeholder="Select from catalog" />
                          </SelectTrigger>
                          <SelectContent>
                            {masterListParts.map((part) =>
                        <SelectItem key={part.id} value={part.part_number}>
                                {part.part_number} - {part.name}
                              </SelectItem>
                        )}
                          </SelectContent>
                        </Select> :

                    <Input
                      id="part_number"
                      value={formData.part_number}
                      onChange={(e) => handleChange('part_number', e.target.value)}
                      placeholder="e.g., BR01-001"
                      required />

                    }
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="name">Part Name *</Label>
                      <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleChange('name', e.target.value)}
                      placeholder="e.g., Pin Deck Assembly"
                      required />

                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="Detailed description of the part..." />

                  </div>

                  {!isAddingToMasterList &&
                <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="quantity">Quantity in Stock</Label>
                        <Input
                      id="quantity"
                      type="number"
                      min="0"
                      value={formData.quantity_in_stock}
                      onChange={(e) => handleChange('quantity_in_stock', parseInt(e.target.value))} />

                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="min_quantity">Minimum Quantity</Label>
                        <Input
                      id="min_quantity"
                      type="number"
                      min="0"
                      value={formData.min_quantity}
                      onChange={(e) => handleChange('min_quantity', parseInt(e.target.value))} />

                      </div>
                    </div>
                }

                  {!isAddingToMasterList &&
                <div className="space-y-2">
                      <Label htmlFor="location">Storage Location</Label>
                      <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => handleChange('location', e.target.value)}
                    placeholder="e.g., Shelf A3, Bin 12" />

                    </div>
                }

                  <div className="space-y-2">
                    <Label htmlFor="cost">Cost per Unit</Label>
                    <Input
                    id="cost"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.cost}
                    onChange={(e) => handleChange('cost', parseFloat(e.target.value))}
                    placeholder="0.00" />

                  </div>

                  {editingPart && !isAddingToMasterList &&
                <div className="flex items-center space-x-2">
                      <Checkbox
                    id="discontinued"
                    checked={formData.discontinued}
                    onCheckedChange={(checked) => handleChange('discontinued', checked)} />

                      <Label htmlFor="discontinued" className="text-sm cursor-pointer">
                        Mark as discontinued
                      </Label>
                    </div>
                }

                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                      Cancel
                    </Button>
                    <Button
                    type="submit"
                    disabled={createMutation.isPending || updateMutation.isPending}
                    className="flex-1 bg-blue-600 hover:bg-blue-700">

                      {editingPart ? "Update Part" : activeTab === 'master' ? "Add to Catalog" : "Add to Inventory"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog> :

          <div className="flex items-center gap-2 px-4 py-2 bg-slate-100 border border-slate-300 rounded-lg">
              <Lock className="w-4 h-4 text-slate-500" />
              <span className="text-sm text-slate-600">Admin access required</span>
            </div>
          }
        </div>

        {/* Low Stock Alert */}
        {lowStockParts.length > 0 &&
        <Card className="mb-6 border-orange-300 bg-orange-50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-orange-900">
                <AlertTriangle className="w-5 h-5" />
                Low Stock Alert
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-orange-800">
                {lowStockParts.length} part{lowStockParts.length !== 1 ? 's are' : ' is'} running low on stock at your location
              </p>
            </CardContent>
          </Card>
        }

        {/* Out of Stock Alert */}
        {outOfStockParts.length > 0 &&
        <Card className="mb-6 border-red-300 bg-red-50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-red-900">
                <XCircle className="w-5 h-5" />
                Out of Stock
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-red-800">
                {outOfStockParts.length} part{outOfStockParts.length !== 1 ? 's are' : ' is'} out of stock at your location
              </p>
            </CardContent>
          </Card>
        }

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-4xl grid-cols-5">
            <TabsTrigger value="in_stock">
              In Stock ({inStockParts.length})
            </TabsTrigger>
            <TabsTrigger value="out_of_stock">
              Out of Stock ({outOfStockParts.length})
            </TabsTrigger>
            <TabsTrigger value="discontinued">
              Discontinued ({discontinuedParts.length})
            </TabsTrigger>
            <TabsTrigger value="master">
              Pinsetter Catalog ({masterListParts.length})
            </TabsTrigger>
            <TabsTrigger value="center_catalog">
              Center Catalog ({centerCatalogParts.length})
            </TabsTrigger>
          </TabsList>

          {/* Common filter section for all tabs */}
          <div className="space-y-4">
            {/* Machine Type Filter */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search parts by name, number, or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10" />

              </div>
              <div className="w-full sm:w-64">
                <Select value={machineTypeFilter} onValueChange={setMachineTypeFilter}>
                  <SelectTrigger className="bg-transparent text-slate-50 px-3 py-2 text-sm rounded-md flex h-9 w-full items-center justify-between whitespace-nowrap border border-input shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1">
                    <div className="flex items-center gap-2">
                      <Settings className="w-4 h-4 text-slate-500" />
                      <SelectValue placeholder="Filter by machine type" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Machines ({displayParts.length})</SelectItem>
                    {MACHINE_TYPES.map((type) =>
                    <SelectItem key={type.value} value={type.value}>
                        {type.label} ({machineTypeCounts[type.value] || 0})
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Active Filters Display */}
            {(machineTypeFilter !== 'all' || searchQuery) &&
            <div className="flex flex-wrap gap-2 items-center">
                <span className="text-xs text-slate-600 font-medium">Active Filters:</span>
                {machineTypeFilter !== 'all' &&
              <Badge variant="outline" className="bg-blue-50">
                    {MACHINE_TYPES.find((t) => t.value === machineTypeFilter)?.label}
                    <button
                  onClick={() => setMachineTypeFilter('all')}
                  className="ml-2 hover:text-red-600">

                      ×
                    </button>
                  </Badge>
              }
                {searchQuery &&
              <Badge variant="outline" className="bg-amber-50">
                    Search: "{searchQuery}"
                    <button
                  onClick={() => setSearchQuery('')}
                  className="ml-2 hover:text-red-600">

                      ×
                    </button>
                  </Badge>
              }
                <button
                onClick={() => {
                  setMachineTypeFilter('all');
                  setSearchQuery('');
                }}
                className="text-xs text-red-600 hover:text-red-700 underline">

                  Clear all filters
                </button>
              </div>
            }
          </div>

          {/* In Stock Tab */}
          <TabsContent value="in_stock" className="space-y-4">
            <Card className="shadow-lg border-slate-200">
              <CardContent className="p-0">
                {isLoading ?
                <div className="p-12 text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
                  </div> :
                sortedParts.length > 0 ?
                <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead>
                            <button
                            onClick={() => handleSort('bowling_alley_id')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Location
                              <SortIcon field="bowling_alley_id" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button
                            onClick={() => handleSort('machine_type')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Machine
                              <SortIcon field="machine_type" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button
                            onClick={() => handleSort('part_number')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Part Number
                              <SortIcon field="part_number" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button
                            onClick={() => handleSort('name')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Name
                              <SortIcon field="name" />
                            </button>
                          </TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>
                            <button
                            onClick={() => handleSort('location')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Storage
                              <SortIcon field="location" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button
                            onClick={() => handleSort('quantity_in_stock')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Stock
                              <SortIcon field="quantity_in_stock" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button
                            onClick={() => handleSort('cost')}
                            className="flex items-center hover:text-blue-600 font-semibold">

                              Cost
                              <SortIcon field="cost" />
                            </button>
                          </TableHead>
                          <TableHead>Status</TableHead>
                          {canEdit && <TableHead className="text-right">Actions</TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedParts.map((part) => {
                        const isLowStock = part.quantity_in_stock > 0 && part.quantity_in_stock <= part.min_quantity;

                        return (
                          <TableRow key={part.id}>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Building2 className="w-4 h-4 text-slate-400" />
                                  <span className="text-sm">{getLocationName(part.bowling_alley_id)}</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge className={getMachineTypeBadge(part.machine_type)}>
                                  {part.machine_type}
                                </Badge>
                              </TableCell>
                              <TableCell className="font-medium">{part.part_number}</TableCell>
                              <TableCell>{part.name}</TableCell>
                              <TableCell className="max-w-xs truncate">{part.description}</TableCell>
                              <TableCell>{part.location || '-'}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Package className="w-4 h-4 text-slate-400" />
                                  <span>{part.quantity_in_stock}</span>
                                </div>
                              </TableCell>
                              <TableCell>${part.cost?.toFixed(2) || '0.00'}</TableCell>
                              <TableCell>
                                {isLowStock ?
                              <Badge className="bg-orange-100 text-orange-800 border-orange-300">Low Stock</Badge> :

                              <Badge className="bg-green-100 text-green-800 border-green-300">In Stock</Badge>
                              }
                              </TableCell>
                              {canEdit &&
                            <TableCell className="text-right">
                                  <div className="flex justify-end gap-2">
                                    <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEdit(part)}
                                  className="h-8 w-8">

                                      <Edit className="w-4 h-4 text-slate-600" />
                                    </Button>
                                    <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDelete(part)}
                                  className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50">

                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                            }
                            </TableRow>);

                      })}
                      </TableBody>
                    </Table>
                  </div> :

                <div className="p-12 text-center">
                    <Package className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No parts in stock</h3>
                    <p className="text-slate-600 mb-4">
                      {searchQuery || machineTypeFilter !== 'all' ? "Try adjusting your filters" : "Add parts to your inventory"}
                    </p>
                  </div>
                }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Out of Stock Tab */}
          <TabsContent value="out_of_stock" className="space-y-4">
            <Alert className="bg-red-50 border-red-200">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-900">
                <strong>Out of Stock:</strong> These parts have zero quantity at your location. Restock or order more as needed.
              </AlertDescription>
            </Alert>

            <Card className="shadow-lg border-slate-200">
              <CardContent className="p-0">
                {isLoading ?
                <div className="p-12 text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
                  </div> :
                sortedParts.length > 0 ?
                <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead>
                            <button onClick={() => handleSort('bowling_alley_id')} className="flex items-center hover:text-blue-600 font-semibold">
                              Location<SortIcon field="bowling_alley_id" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('machine_type')} className="flex items-center hover:text-blue-600 font-semibold">
                              Machine<SortIcon field="machine_type" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('part_number')} className="flex items-center hover:text-blue-600 font-semibold">
                              Part Number<SortIcon field="part_number" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('name')} className="flex items-center hover:text-blue-600 font-semibold">
                              Name<SortIcon field="name" />
                            </button>
                          </TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('location')} className="flex items-center hover:text-blue-600 font-semibold">
                              Storage<SortIcon field="location" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('cost')} className="flex items-center hover:text-blue-600 font-semibold">
                              Cost<SortIcon field="cost" />
                            </button>
                          </TableHead>
                          {canEdit && <TableHead className="text-right">Actions</TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedParts.map((part) =>
                      <TableRow key={part.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Building2 className="w-4 h-4 text-slate-400" />
                                <span className="text-sm">{getLocationName(part.bowling_alley_id)}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getMachineTypeBadge(part.machine_type)}>
                                {part.machine_type}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">{part.part_number}</TableCell>
                            <TableCell>{part.name}</TableCell>
                            <TableCell className="max-w-xs truncate">{part.description}</TableCell>
                            <TableCell>{part.location || '-'}</TableCell>
                            <TableCell>${part.cost?.toFixed(2) || '0.00'}</TableCell>
                            {canEdit &&
                        <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="ghost" size="icon" onClick={() => handleEdit(part)} className="h-8 w-8">
                                    <Edit className="w-4 h-4 text-slate-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDelete(part)} className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                        }
                          </TableRow>
                      )}
                      </TableBody>
                    </Table>
                  </div> :

                <div className="p-12 text-center">
                    <Package className="w-12 h-12 text-green-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No out of stock parts</h3>
                    <p className="text-slate-600">
                      {searchQuery || machineTypeFilter !== 'all' ? "Try adjusting your filters" : "All parts are currently in stock"}
                    </p>
                  </div>
                }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Discontinued Tab */}
          <TabsContent value="discontinued" className="space-y-4">
            <Alert className="bg-slate-50 border-slate-300">
              <Ban className="h-4 w-4 text-slate-600" />
              <AlertDescription className="text-slate-700">
                <strong>Discontinued Parts:</strong> These parts are no longer in active use. They are kept for historical records and reference.
              </AlertDescription>
            </Alert>

            <Card className="shadow-lg border-slate-200">
              <CardContent className="p-0">
                {isLoading ?
                <div className="p-12 text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
                  </div> :
                sortedParts.length > 0 ?
                <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead>
                            <button onClick={() => handleSort('bowling_alley_id')} className="flex items-center hover:text-blue-600 font-semibold">
                              Location<SortIcon field="bowling_alley_id" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('machine_type')} className="flex items-center hover:text-blue-600 font-semibold">
                              Machine<SortIcon field="machine_type" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('part_number')} className="flex items-center hover:text-blue-600 font-semibold">
                              Part Number<SortIcon field="part_number" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('name')} className="flex items-center hover:text-blue-600 font-semibold">
                              Name<SortIcon field="name" />
                            </button>
                          </TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('quantity_in_stock')} className="flex items-center hover:text-blue-600 font-semibold">
                              Stock<SortIcon field="quantity_in_stock" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('cost')} className="flex items-center hover:text-blue-600 font-semibold">
                              Cost<SortIcon field="cost" />
                            </button>
                          </TableHead>
                          {canEdit && <TableHead className="text-right">Actions</TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedParts.map((part) =>
                      <TableRow key={part.id} className="opacity-60">
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Building2 className="w-4 h-4 text-slate-400" />
                                <span className="text-sm">{getLocationName(part.bowling_alley_id)}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getMachineTypeBadge(part.machine_type)}>
                                {part.machine_type}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">{part.part_number}</TableCell>
                            <TableCell>{part.name}</TableCell>
                            <TableCell className="max-w-xs truncate">{part.description}</TableCell>
                            <TableCell>{part.quantity_in_stock || 0}</TableCell>
                            <TableCell>${part.cost?.toFixed(2) || '0.00'}</TableCell>
                            {canEdit &&
                        <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="ghost" size="icon" onClick={() => handleEdit(part)} className="h-8 w-8">
                                    <Edit className="w-4 h-4 text-slate-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDelete(part)} className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                        }
                          </TableRow>
                      )}
                      </TableBody>
                    </Table>
                  </div> :

                <div className="p-12 text-center">
                    <Ban className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No discontinued parts</h3>
                    <p className="text-slate-600">
                      {searchQuery || machineTypeFilter !== 'all' ? "Try adjusting your filters" : "No parts have been discontinued yet"}
                    </p>
                  </div>
                }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Master Catalog Tab */}
          <TabsContent value="master" className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <BookOpen className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-900">
                <strong>Pinsetter/Pinspotter Catalog:</strong> Standardized reference parts for machines. {!isAdmin && <span className="text-slate-700">Only administrators can add or modify catalog items.</span>}
              </AlertDescription>
            </Alert>

            <Card className="shadow-lg border-slate-200">
              <CardContent className="p-0">
                {isLoading ?
                <div className="p-12 text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
                  </div> :
                sortedParts.length > 0 ?
                <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead>
                            <button onClick={() => handleSort('machine_type')} className="flex items-center hover:text-blue-600 font-semibold">
                              Machine<SortIcon field="machine_type" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('part_number')} className="flex items-center hover:text-blue-600 font-semibold">
                              Part Number<SortIcon field="part_number" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('name')} className="flex items-center hover:text-blue-600 font-semibold">
                              Name<SortIcon field="name" />
                            </button>
                          </TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('cost')} className="flex items-center hover:text-blue-600 font-semibold">
                              Cost<SortIcon field="cost" />
                            </button>
                          </TableHead>
                          {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedParts.map((part) =>
                      <TableRow key={part.id}>
                            <TableCell>
                              <Badge className={getMachineTypeBadge(part.machine_type)}>
                                {part.machine_type}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">{part.part_number}</TableCell>
                            <TableCell>{part.name}</TableCell>
                            <TableCell className="max-w-md">{part.description || '-'}</TableCell>
                            <TableCell>${part.cost?.toFixed(2) || '0.00'}</TableCell>
                            {isAdmin &&
                        <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="ghost" size="icon" onClick={() => handleEdit(part)} className="h-8 w-8">
                                    <Edit className="w-4 h-4 text-slate-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDelete(part)} className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                        }
                          </TableRow>
                      )}
                      </TableBody>
                    </Table>
                  </div> :

                <div className="p-12 text-center">
                    <BookOpen className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No catalog items found</h3>
                    <p className="text-slate-600 mb-4">
                      {searchQuery ? "Try adjusting your filters" : isAdmin ? "Add your first true catalog item to get started" : "No catalog items available yet"}
                    </p>
                  </div>
                }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Center Catalog Tab */}
          <TabsContent value="center_catalog" className="space-y-4">
            <Alert className="bg-purple-50 border-purple-200">
              <BookOpen className="h-4 w-4 text-purple-600" />
              <AlertDescription className="text-purple-900">
                <strong>Center Catalog:</strong> Supplies for Kitchen, Bar, Janitorial, Front Counter, and Pro Shop. {!isAdmin && <span className="text-slate-700">Only administrators can add or modify catalog items.</span>}
              </AlertDescription>
            </Alert>

            <Card className="shadow-lg border-slate-200">
              <CardContent className="p-0">
                {isLoading ?
                <div className="p-12 text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
                  </div> :
                sortedParts.length > 0 ?
                <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead>
                            <button onClick={() => handleSort('category')} className="flex items-center hover:text-blue-600 font-semibold">
                              Category<SortIcon field="category" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('part_number')} className="flex items-center hover:text-blue-600 font-semibold">
                              Item #<SortIcon field="part_number" />
                            </button>
                          </TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('name')} className="flex items-center hover:text-blue-600 font-semibold">
                              Name<SortIcon field="name" />
                            </button>
                          </TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>
                            <button onClick={() => handleSort('cost')} className="flex items-center hover:text-blue-600 font-semibold">
                              Cost<SortIcon field="cost" />
                            </button>
                          </TableHead>
                          {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedParts.map((part) =>
                      <TableRow key={part.id}>
                            <TableCell>
                              <Badge className="bg-purple-100 text-purple-800 border-purple-300">
                                {part.category || 'General'}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">{part.part_number}</TableCell>
                            <TableCell>{part.name}</TableCell>
                            <TableCell className="max-w-md">{part.description || '-'}</TableCell>
                            <TableCell>${part.cost?.toFixed(2) || '0.00'}</TableCell>
                            {isAdmin &&
                        <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="ghost" size="icon" onClick={() => handleEdit(part)} className="h-8 w-8">
                                    <Edit className="w-4 h-4 text-slate-600" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDelete(part)} className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                        }
                          </TableRow>
                      )}
                      </TableBody>
                    </Table>
                  </div> :

                <div className="p-12 text-center">
                    <BookOpen className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No center catalog items found</h3>
                    <p className="text-slate-600 mb-4">
                      {searchQuery ? "Try adjusting your filters" : isAdmin ? "Add items to the Center Catalog" : "No items available yet"}
                    </p>
                  </div>
                }
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>);

}