import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { ArrowLeft, Save, Star } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";

export default function PerformanceReview() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  
  const urlParams = new URLSearchParams(window.location.search);
  const reviewId = urlParams.get('id');
  const employeeEmail = urlParams.get('employee');

  const [formData, setFormData] = useState({
    employee_email: employeeEmail || "",
    review_date: new Date().toISOString().split('T')[0],
    review_period_start: "",
    review_period_end: "",
    technical_skills: 3,
    punctuality: 3,
    teamwork: 3,
    communication: 3,
    problem_solving: 3,
    overall_rating: 3,
    strengths: "",
    areas_for_improvement: "",
    goals: "",
    additional_comments: "",
    status: "draft",
    next_review_date: ""
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.department !== 'manager' && u.role !== 'admin') {
        toast.error("Access denied - Managers only");
        navigate(createPageUrl("ManagerDashboard"));
      }
    }).catch(() => {});
  }, [navigate]);

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: review } = useQuery({
    queryKey: ['review', reviewId],
    queryFn: () => base44.entities.PerformanceReview.get(reviewId),
    enabled: !!reviewId,
    onSuccess: (data) => {
      setFormData({
        employee_email: data.employee_email || "",
        review_date: data.review_date || new Date().toISOString().split('T')[0],
        review_period_start: data.review_period_start || "",
        review_period_end: data.review_period_end || "",
        technical_skills: data.technical_skills || 3,
        punctuality: data.punctuality || 3,
        teamwork: data.teamwork || 3,
        communication: data.communication || 3,
        problem_solving: data.problem_solving || 3,
        overall_rating: data.overall_rating || 3,
        strengths: data.strengths || "",
        areas_for_improvement: data.areas_for_improvement || "",
        goals: data.goals || "",
        additional_comments: data.additional_comments || "",
        status: data.status || "draft",
        next_review_date: data.next_review_date || ""
      });
    }
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.PerformanceReview.create(data),
    onSuccess: async (newReview) => {
      queryClient.invalidateQueries({ queryKey: ['reviews'] });
      queryClient.invalidateQueries({ queryKey: ['employeeReviews'] });
      
      if (newReview.status === 'completed') {
        await base44.entities.Notification.create({
          user_email: newReview.employee_email,
          type: 'performance_review',
          title: 'Performance Review Completed',
          message: `Your performance review has been completed by ${user.display_name || user.full_name}`,
          priority: 'medium',
          bowling_alley_id: newReview.bowling_alley_id
        });
      }
      
      toast.success(newReview.status === 'completed' ? "Review completed and saved" : "Review saved as draft");
      navigate(createPageUrl("EmployeeProfile") + `?email=${newReview.employee_email}`);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PerformanceReview.update(id, data),
    onSuccess: async (updatedReview) => {
      queryClient.invalidateQueries({ queryKey: ['reviews'] });
      queryClient.invalidateQueries({ queryKey: ['review', reviewId] });
      queryClient.invalidateQueries({ queryKey: ['employeeReviews'] });
      
      if (updatedReview.status === 'completed' && review?.status === 'draft') {
        await base44.entities.Notification.create({
          user_email: updatedReview.employee_email,
          type: 'performance_review',
          title: 'Performance Review Completed',
          message: `Your performance review has been completed by ${user.display_name || user.full_name}`,
          priority: 'medium',
          bowling_alley_id: updatedReview.bowling_alley_id
        });
      }
      
      toast.success(updatedReview.status === 'completed' ? "Review completed and saved" : "Review updated");
      navigate(createPageUrl("EmployeeProfile") + `?email=${updatedReview.employee_email}`);
    }
  });

  const handleSubmit = (status) => {
    if (!formData.employee_email) {
      toast.error("Please select an employee");
      return;
    }

    const selectedEmployee = employees.find(e => e.email === formData.employee_email);
    
    const reviewData = {
      ...formData,
      status,
      reviewer_email: user.email,
      bowling_alley_id: selectedEmployee?.bowling_alley_id || user.bowling_alley_id
    };

    if (reviewId) {
      updateMutation.mutate({ id: reviewId, data: reviewData });
    } else {
      createMutation.mutate(reviewData);
    }
  };

  const ratingLabels = {
    1: "Needs Improvement",
    2: "Below Expectations",
    3: "Meets Expectations",
    4: "Exceeds Expectations",
    5: "Outstanding"
  };

  const RatingSlider = ({ label, value, onChange }) => (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <Label className={isDarkMode ? 'text-slate-300' : ''}>{label}</Label>
        <div className="flex items-center gap-2">
          <Star className="w-4 h-4 text-yellow-500" />
          <span className={`font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{value}/5</span>
          <span className="text-xs text-slate-500">({ratingLabels[value]})</span>
        </div>
      </div>
      <Slider
        value={[value]}
        onValueChange={(val) => onChange(val[0])}
        min={1}
        max={5}
        step={1}
        className="w-full"
      />
    </div>
  );

  if (!user || (user.department !== 'manager' && user.role !== 'admin')) {
    return null;
  }

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              {reviewId ? 'Edit' : 'New'} Performance Review
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Evaluate employee performance and set goals
            </p>
          </div>
        </div>

        <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="employee_email">Employee *</Label>
                  <Select
                    value={formData.employee_email}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, employee_email: value }))}
                    disabled={!!reviewId}
                  >
                    <SelectTrigger className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}>
                      <SelectValue placeholder="Select employee" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees
                        .filter(e => e.active !== false && e.bowling_alley_id === user.bowling_alley_id)
                        .map(emp => (
                          <SelectItem key={emp.id} value={emp.email}>
                            {emp.display_name || emp.full_name || emp.email}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="review_date">Review Date *</Label>
                  <Input
                    id="review_date"
                    type="date"
                    value={formData.review_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, review_date: e.target.value }))}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="review_period_start">Review Period Start</Label>
                  <Input
                    id="review_period_start"
                    type="date"
                    value={formData.review_period_start}
                    onChange={(e) => setFormData(prev => ({ ...prev, review_period_start: e.target.value }))}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="review_period_end">Review Period End</Label>
                  <Input
                    id="review_period_end"
                    type="date"
                    value={formData.review_period_end}
                    onChange={(e) => setFormData(prev => ({ ...prev, review_period_end: e.target.value }))}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="next_review_date">Next Review Date</Label>
                <Input
                  id="next_review_date"
                  type="date"
                  value={formData.next_review_date}
                  onChange={(e) => setFormData(prev => ({ ...prev, next_review_date: e.target.value }))}
                  className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                />
              </div>

              {/* Performance Ratings */}
              <div className={`space-y-6 p-6 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
                <h3 className={`font-semibold text-lg ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Performance Ratings
                </h3>

                <RatingSlider
                  label="Technical Skills"
                  value={formData.technical_skills}
                  onChange={(val) => setFormData(prev => ({ ...prev, technical_skills: val }))}
                />

                <RatingSlider
                  label="Punctuality"
                  value={formData.punctuality}
                  onChange={(val) => setFormData(prev => ({ ...prev, punctuality: val }))}
                />

                <RatingSlider
                  label="Teamwork"
                  value={formData.teamwork}
                  onChange={(val) => setFormData(prev => ({ ...prev, teamwork: val }))}
                />

                <RatingSlider
                  label="Communication"
                  value={formData.communication}
                  onChange={(val) => setFormData(prev => ({ ...prev, communication: val }))}
                />

                <RatingSlider
                  label="Problem Solving"
                  value={formData.problem_solving}
                  onChange={(val) => setFormData(prev => ({ ...prev, problem_solving: val }))}
                />

                <div className={`pt-4 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-300'}`}>
                  <RatingSlider
                    label="Overall Rating"
                    value={formData.overall_rating}
                    onChange={(val) => setFormData(prev => ({ ...prev, overall_rating: val }))}
                  />
                </div>
              </div>

              {/* Detailed Feedback */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="strengths">Strengths & Accomplishments</Label>
                  <Textarea
                    id="strengths"
                    value={formData.strengths}
                    onChange={(e) => setFormData(prev => ({ ...prev, strengths: e.target.value }))}
                    placeholder="Highlight the employee's key strengths and accomplishments..."
                    rows={4}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="areas_for_improvement">Areas for Improvement</Label>
                  <Textarea
                    id="areas_for_improvement"
                    value={formData.areas_for_improvement}
                    onChange={(e) => setFormData(prev => ({ ...prev, areas_for_improvement: e.target.value }))}
                    placeholder="Identify areas where the employee can grow and improve..."
                    rows={4}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="goals">Goals for Next Period</Label>
                  <Textarea
                    id="goals"
                    value={formData.goals}
                    onChange={(e) => setFormData(prev => ({ ...prev, goals: e.target.value }))}
                    placeholder="Set clear, measurable goals for the next review period..."
                    rows={4}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="additional_comments">Additional Comments</Label>
                  <Textarea
                    id="additional_comments"
                    value={formData.additional_comments}
                    onChange={(e) => setFormData(prev => ({ ...prev, additional_comments: e.target.value }))}
                    placeholder="Any other comments or observations..."
                    rows={3}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-6">
                <Button
                  variant="outline"
                  onClick={() => handleSubmit('draft')}
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="flex-1"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save as Draft
                </Button>
                <Button
                  onClick={() => handleSubmit('completed')}
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Complete Review
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}