import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { CheckCircle2, Plus, Trash2, History, Calendar, User, AlertTriangle, BookOpen, Download, Clock } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "../components/LocationContext";
import { format, parseISO, differenceInDays, isBefore, startOfDay } from "date-fns";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useMaintenanceTaskReminder } from "@/components/maintenance/MaintenanceTaskReminder";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ExportMenu } from "@/components/ExportMenu";

const CATEGORIES = [
  { value: "pinsetter", label: "Pinsetter" },
  { value: "lane", label: "Lane" },
  { value: "ball_return", label: "Ball Return" },
  { value: "electrical", label: "Electrical" },
  { value: "general", label: "General" },
  { value: "safety", label: "Safety" },
];

function TaskCard({ task, onToggle, onDelete, users, isDarkMode, onAssign, onUpdateDueDate }) {
  const today = startOfDay(new Date());
  const isOverdue = task.due_date && isBefore(parseISO(task.due_date), today) && task.status !== 'completed';
  const daysUntilDue = task.due_date ? differenceInDays(parseISO(task.due_date), today) : null;
  const isCompleted = task.status === 'completed';
  const assignedUser = users.find(u => u.email === task.assigned_to);

  return (
    <div
      className={`flex items-start space-x-3 p-3 rounded-lg border transition-colors ${
        isCompleted
          ? isDarkMode ? 'bg-green-900/20 border-green-800' : 'bg-green-50 border-green-200'
          : isOverdue
          ? isDarkMode ? 'bg-red-900/20 border-red-800' : 'bg-red-50 border-red-200'
          : isDarkMode ? 'bg-slate-800 border-slate-700 hover:bg-slate-700' : 'bg-white border-slate-200 hover:bg-slate-50'
      }`}
    >
      <Checkbox
        id={task.id}
        checked={isCompleted}
        onCheckedChange={() => onToggle(task)}
        className="mt-0.5"
      />
      <div className="flex-1 min-w-0">
        <Label
          htmlFor={task.id}
          className={`block cursor-pointer text-sm ${
            isCompleted ? 'line-through text-slate-500' : isDarkMode ? 'text-slate-100' : 'text-slate-900'
          }`}
        >
          {task.task_text}
        </Label>
        <div className="flex flex-wrap items-center gap-2 mt-2">
          {task.category && (
            <Badge variant="outline" className="text-xs capitalize">
              {task.category}
            </Badge>
          )}
          {task.due_date && (
            <Badge 
              variant="outline" 
              className={`text-xs flex items-center gap-1 ${
                isOverdue ? 'bg-red-100 text-red-800 border-red-300' :
                daysUntilDue <= 7 ? 'bg-yellow-100 text-yellow-800 border-yellow-300' :
                'bg-slate-100 text-slate-800'
              }`}
            >
              <Calendar className="w-3 h-3" />
              {isOverdue ? 'Overdue' : `Due ${format(parseISO(task.due_date), 'MMM d')}`}
            </Badge>
          )}
          {assignedUser && (
            <Badge variant="outline" className="text-xs flex items-center gap-1">
              <User className="w-3 h-3" />
              {assignedUser.full_name || assignedUser.email}
            </Badge>
          )}
        </div>
        {/* Quick actions */}
        <div className="flex flex-wrap gap-2 mt-2">
          <Input
            type="date"
            value={task.due_date || ''}
            onChange={(e) => onUpdateDueDate(task.id, e.target.value)}
            className="h-7 text-xs w-28"
          />
          <Select value={task.assigned_to || ''} onValueChange={(value) => onAssign(task.id, value)}>
            <SelectTrigger className="h-7 text-xs w-32">
              <SelectValue placeholder="Assign to..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Unassigned</SelectItem>
              {users.map(u => (
                <SelectItem key={u.id} value={u.email}>
                  {u.full_name || u.email}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      {isCompleted && <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />}
      {isOverdue && !isCompleted && <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => onDelete(task.id)}
        className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
      >
        <Trash2 className="w-4 h-4" />
      </Button>
    </div>
  );
}

function TaskSection({ title, tasks, onTaskToggle, onAddTask, onDeleteTask, onAssign, onUpdateDueDate, period, isLoading, users, catalogTasks, onImportFromCatalog }) {
  const { theme, isDarkMode } = useTheme();
  const [newTask, setNewTask] = useState("");
  const [showCatalog, setShowCatalog] = useState(false);

  const handleAddTask = () => {
    if (newTask.trim()) {
      onAddTask(newTask.trim());
      setNewTask("");
    }
  };

  const completedCount = tasks.filter(t => t.status === 'completed').length;
  const overdueCount = tasks.filter(t => {
    if (!t.due_date || t.status === 'completed') return false;
    return isBefore(parseISO(t.due_date), startOfDay(new Date()));
  }).length;

  const periodCatalogTasks = catalogTasks.filter(t => t.period === period);

  if (isLoading) {
    return (
      <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
        <CardContent className="p-12 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
      <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
        <div className="flex justify-between items-center">
          <CardTitle className={`font-semibold tracking-tight leading-none ${isDarkMode ? 'text-slate-300' : 'text-slate-900'}`}>{title}</CardTitle>
          <div className="flex items-center gap-3">
            {overdueCount > 0 && (
              <Badge className="bg-red-600 text-white">
                <AlertTriangle className="w-3 h-3 mr-1" />
                {overdueCount} Overdue
              </Badge>
            )}
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <span className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {completedCount} / {tasks.length} Complete
              </span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Add Task Form */}
          <div className="flex gap-2">
            <Input
              placeholder="Add a new maintenance task..."
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddTask()}
              className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
            />
            <Button onClick={handleAddTask} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
            {periodCatalogTasks.length > 0 && (
              <Dialog open={showCatalog} onOpenChange={setShowCatalog}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Catalog
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Import from Task Catalog</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="max-h-96">
                    <div className="space-y-2">
                      {periodCatalogTasks.map(catTask => (
                        <div key={catTask.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-slate-50">
                          <div>
                            <p className="font-medium">{catTask.task_text}</p>
                            {catTask.description && (
                              <p className="text-sm text-slate-500">{catTask.description}</p>
                            )}
                            <div className="flex gap-2 mt-1">
                              {catTask.category && (
                                <Badge variant="outline" className="text-xs capitalize">{catTask.category}</Badge>
                              )}
                              {catTask.estimated_time_minutes && (
                                <Badge variant="outline" className="text-xs">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {catTask.estimated_time_minutes} min
                                </Badge>
                              )}
                            </div>
                          </div>
                          <Button
                            size="sm"
                            onClick={() => {
                              onImportFromCatalog(catTask);
                              toast.success('Task imported from catalog');
                            }}
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Import
                          </Button>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
            )}
          </div>

          {/* Task List */}
          {tasks.length === 0 ? (
            <div className={`text-center py-8 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              <p className="text-sm">No tasks added yet. Create your first maintenance task above.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {tasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onToggle={onTaskToggle}
                  onDelete={onDeleteTask}
                  users={users}
                  isDarkMode={isDarkMode}
                  onAssign={onAssign}
                  onUpdateDueDate={onUpdateDueDate}
                />
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function PreventativeMaintenance() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const [activeTab, setActiveTab] = useState("daily");
  const [viewMode, setViewMode] = useState("tasks");
  const [user, setUser] = useState(null);
  const [catalogDialogOpen, setCatalogDialogOpen] = useState(false);
  const [newCatalogTask, setNewCatalogTask] = useState({
    task_text: "",
    period: "daily",
    category: "",
    description: "",
    estimated_time_minutes: null,
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Initialize reminder system
  useMaintenanceTaskReminder(user);

  const isAdmin = user && user.role === 'admin';
  const isManager = user && (user.department === 'manager' || user.role === 'admin');
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all'
    ? selectedLocationId
    : user?.bowling_alley_id;

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const { data: allTasks = [], isLoading } = useQuery({
    queryKey: ['preventativeMaintenanceTasks'],
    queryFn: () => base44.entities.PreventativeMaintenanceTask.list(),
    initialData: []
  });

  const { data: allLogs = [] } = useQuery({
    queryKey: ['preventativeMaintenanceLogs'],
    queryFn: () => base44.entities.PreventativeMaintenanceLog.list('-completed_date'),
    initialData: []
  });

  const { data: catalogTasks = [] } = useQuery({
    queryKey: ['maintenanceTaskCatalog'],
    queryFn: () => base44.entities.MaintenanceTaskCatalog.list(),
    initialData: []
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const locationTasks = allTasks.filter((task) => task.bowling_alley_id === effectiveLocationId);
  const locationLogs = allLogs.filter((log) => log.bowling_alley_id === effectiveLocationId);

  const assignableUsers = allUsers.filter((u) =>
    (u.department === 'mechanic' || u.department === 'manager' || u.role === 'admin') &&
    (u.bowling_alley_id === effectiveLocationId || u.role === 'admin')
  );

  const tasksByPeriod = {
    daily: locationTasks.filter((t) => t.period === 'daily'),
    weekly: locationTasks.filter((t) => t.period === 'weekly'),
    monthly: locationTasks.filter((t) => t.period === 'monthly'),
    quarterly: locationTasks.filter((t) => t.period === 'quarterly'),
    yearly: locationTasks.filter((t) => t.period === 'yearly')
  };

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.PreventativeMaintenanceTask.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['preventativeMaintenanceTasks'] });
      toast.success('Task created');
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PreventativeMaintenanceTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['preventativeMaintenanceTasks'] });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PreventativeMaintenanceTask.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['preventativeMaintenanceTasks'] });
      toast.success('Task deleted');
    }
  });

  const createLogMutation = useMutation({
    mutationFn: (data) => base44.entities.PreventativeMaintenanceLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['preventativeMaintenanceLogs'] });
    }
  });

  const createCatalogMutation = useMutation({
    mutationFn: (data) => base44.entities.MaintenanceTaskCatalog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maintenanceTaskCatalog'] });
      setCatalogDialogOpen(false);
      setNewCatalogTask({
        task_text: "",
        period: "daily",
        category: "",
        description: "",
        estimated_time_minutes: null,
      });
      toast.success('Task added to catalog');
    }
  });

  const createNotificationMutation = useMutation({
    mutationFn: (data) => base44.entities.Notification.create(data),
  });

  const handleTaskToggle = (task) => {
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    
    updateMutation.mutate({
      id: task.id,
      data: {
        status: newStatus,
        completed_date: newStatus === 'completed' ? new Date().toISOString() : null,
        completed_by: newStatus === 'completed' ? user?.email : null,
      }
    });

    if (newStatus === 'completed') {
      createLogMutation.mutate({
        bowling_alley_id: effectiveLocationId,
        task_id: task.id,
        task_text: task.task_text,
        period: task.period,
        completed_date: new Date().toISOString(),
        device_timestamp: new Date().toISOString()
      });
      toast.success('Task completed');
    }
  };

  const handleAddTask = (period, taskText) => {
    if (effectiveLocationId) {
      createMutation.mutate({
        bowling_alley_id: effectiveLocationId,
        period: period,
        task_text: taskText,
        status: 'pending'
      });
    }
  };

  const handleDeleteTask = (taskId) => {
    deleteMutation.mutate(taskId);
  };

  const handleAssign = (taskId, userEmail) => {
    const task = locationTasks.find(t => t.id === taskId);
    updateMutation.mutate({
      id: taskId,
      data: { assigned_to: userEmail || null }
    });

    // Send notification to assigned user
    if (userEmail && userEmail !== user?.email) {
      createNotificationMutation.mutate({
        user_email: userEmail,
        type: 'maintenance_due',
        title: 'Maintenance Task Assigned',
        message: `You have been assigned: "${task?.task_text}"`,
        priority: 'medium',
        related_entity_type: 'PreventativeMaintenanceTask',
        related_entity_id: taskId,
        bowling_alley_id: effectiveLocationId,
      });
      toast.success('Task assigned and notification sent');
    }
  };

  const handleUpdateDueDate = (taskId, dueDate) => {
    updateMutation.mutate({
      id: taskId,
      data: { due_date: dueDate || null, reminder_sent: false }
    });
  };

  const handleImportFromCatalog = (catalogTask) => {
    if (effectiveLocationId) {
      createMutation.mutate({
        bowling_alley_id: effectiveLocationId,
        period: catalogTask.period,
        task_text: catalogTask.task_text,
        catalog_task_id: catalogTask.id,
        category: catalogTask.category,
        status: 'pending'
      });
    }
  };

  const handleAddToCatalog = (e) => {
    e.preventDefault();
    createCatalogMutation.mutate(newCatalogTask);
  };

  const logsByPeriod = {
    daily: locationLogs.filter((l) => l.period === 'daily'),
    weekly: locationLogs.filter((l) => l.period === 'weekly'),
    monthly: locationLogs.filter((l) => l.period === 'monthly'),
    quarterly: locationLogs.filter((l) => l.period === 'quarterly'),
    yearly: locationLogs.filter((l) => l.period === 'yearly')
  };

  const getCompletedCount = (period) => tasksByPeriod[period].filter(t => t.status === 'completed').length;

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 pb-24 ${theme.bg}`}>
      <div className="max-w-5xl mx-auto w-full">
        <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Preventative Maintenance</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Regular maintenance schedules to keep equipment running smoothly
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {isAdmin && (
              <Dialog open={catalogDialogOpen} onOpenChange={setCatalogDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Manage Catalog
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Add Task to Catalog</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleAddToCatalog} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Task Name *</Label>
                      <Input
                        value={newCatalogTask.task_text}
                        onChange={(e) => setNewCatalogTask(prev => ({ ...prev, task_text: e.target.value }))}
                        placeholder="Enter task name..."
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Period *</Label>
                        <Select value={newCatalogTask.period} onValueChange={(v) => setNewCatalogTask(prev => ({ ...prev, period: v }))}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="quarterly">Quarterly</SelectItem>
                            <SelectItem value="yearly">Yearly</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <Select value={newCatalogTask.category || ''} onValueChange={(v) => setNewCatalogTask(prev => ({ ...prev, category: v }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select..." />
                          </SelectTrigger>
                          <SelectContent>
                            {CATEGORIES.map(c => (
                              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={newCatalogTask.description || ''}
                        onChange={(e) => setNewCatalogTask(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Detailed instructions..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Estimated Time (minutes)</Label>
                      <Input
                        type="number"
                        value={newCatalogTask.estimated_time_minutes || ''}
                        onChange={(e) => setNewCatalogTask(prev => ({ ...prev, estimated_time_minutes: e.target.value ? parseInt(e.target.value) : null }))}
                        placeholder="e.g. 30"
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setCatalogDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                        Add to Catalog
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            )}
            <Button
              variant={viewMode === 'tasks' ? 'default' : 'outline'}
              onClick={() => setViewMode('tasks')}
              className={viewMode === 'tasks' ? 'bg-blue-600' : ''}
            >
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Tasks
            </Button>
            <Button
              variant={viewMode === 'history' ? 'default' : 'outline'}
              onClick={() => setViewMode('history')}
              className={viewMode === 'history' ? 'bg-blue-600' : ''}
            >
              <History className="w-4 h-4 mr-2" />
              History
            </Button>
            <ExportMenu 
              data={viewMode === 'tasks' ? tasksByPeriod[activeTab] : logsByPeriod[activeTab]}
              columns={viewMode === 'tasks' ? [
                { header: 'Task', key: 'task_text' },
                { header: 'Period', key: 'period' },
                { header: 'Status', key: 'status' },
                { header: 'Assigned To', key: 'assigned_to' },
                { header: 'Due Date', key: 'due_date' }
              ] : [
                { header: 'Task', key: 'task_text' },
                { header: 'Period', key: 'period' },
                { header: 'Completed By', key: 'created_by' },
                { header: 'Completed Date', key: 'completed_date' }
              ]}
              filename={`maintenance-${viewMode}-${activeTab}`}
              title={`${activeTab.toUpperCase()} Maintenance ${viewMode === 'tasks' ? 'Tasks' : 'History'}`}
            />
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-3xl grid-cols-5 overflow-x-auto">
            {['daily', 'weekly', 'monthly', 'quarterly', 'yearly'].map(period => (
              <TabsTrigger key={period} value={period} className="capitalize">
                {period}
                {getCompletedCount(period) > 0 && (
                  <span className="ml-2 inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-green-600 rounded-full">
                    {getCompletedCount(period)}
                  </span>
                )}
              </TabsTrigger>
            ))}
          </TabsList>

          {['daily', 'weekly', 'monthly', 'quarterly', 'yearly'].map(period => (
            <TabsContent key={period} value={period}>
              {viewMode === 'tasks' ? (
                <TaskSection
                  title={`${period.charAt(0).toUpperCase() + period.slice(1)} Maintenance Tasks`}
                  tasks={tasksByPeriod[period]}
                  onTaskToggle={handleTaskToggle}
                  onAddTask={(task) => handleAddTask(period, task)}
                  onDeleteTask={handleDeleteTask}
                  onAssign={handleAssign}
                  onUpdateDueDate={handleUpdateDueDate}
                  period={period}
                  isLoading={isLoading}
                  users={assignableUsers}
                  catalogTasks={catalogTasks}
                  onImportFromCatalog={handleImportFromCatalog}
                />
              ) : (
                <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                  <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800 bg-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                    <CardTitle className={isDarkMode ? 'text-slate-300' : ''}>{period.charAt(0).toUpperCase() + period.slice(1)} Maintenance History</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    {logsByPeriod[period].length === 0 ? (
                      <div className={`text-center py-8 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        <History className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                        <p className="text-sm">No completed tasks yet</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {logsByPeriod[period].map((log) => (
                          <div key={log.id} className={`flex items-start gap-3 p-3 rounded-lg border ${isDarkMode ? 'bg-green-900/20 border-green-800' : 'bg-green-50 border-green-200'}`}>
                            <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                              <p className={`text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{log.task_text}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <Calendar className={`w-3 h-3 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
                                <span className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                                  {format(new Date(log.completed_date), "MMM d, yyyy 'at' h:mm a")}
                                </span>
                                <span className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>by {log.created_by}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}