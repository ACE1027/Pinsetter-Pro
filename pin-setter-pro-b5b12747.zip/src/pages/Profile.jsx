import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Save, Mail, Phone, Calendar, Building2, Briefcase } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/components/ThemeContext";



export default function Profile() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [location, setLocation] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [formData, setFormData] = useState({
    full_name: ""
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setFormData({ full_name: u.full_name || "" });

      // Fetch user's location and role
      if (u.bowling_alley_id) {
        base44.entities.BowlingAlley.list().then((locations) => {
          const userLocation = locations.find((l) => l.id === u.bowling_alley_id);
          setLocation(userLocation);
        });
      }

      if (u.role_id) {
        base44.entities.Role.list().then((roles) => {
          const role = roles.find((r) => r.id === u.role_id);
          setUserRole(role);
        });
      }
    }).catch(() => {});
  }, []);

  const updateMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      // Refresh user data
      base44.auth.me().then(setUser);
      toast.success("Profile updated successfully");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.full_name.trim()) {
      toast.error("Full name cannot be empty");
      return;
    }
    updateMutation.mutate(formData);
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  if (!user) {
    return (
      <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
        <div className="max-w-3xl mx-auto text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4" />
          <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Loading profile...</p>
        </div>
      </div>);

  }

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-3xl mx-auto w-full overflow-x-hidden">
        <div className="mb-6">
          <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>My Profile</h1>
          <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>View and edit your personal information</p>
        </div>

        {/* Profile Overview Card */}
        <Card className={`shadow-lg mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
          <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-gradient-to-r from-blue-50 to-slate-50'}`}>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-2xl">
                  {user.full_name?.charAt(0) || user.email?.charAt(0)}
                </span>
              </div>
              <div>
                <CardTitle className="text-slate-200 text-2xl font-semibold tracking-tight">{user.full_name || "No Name Set"}</CardTitle>
                <div className="flex gap-2 mt-2">
                  {user.role === 'admin' &&
                  <Badge className="bg-red-100 text-red-800 border-red-300">Admin</Badge>
                  }
                  {userRole &&
                  <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                      {userRole.name}
                    </Badge>
                  }
                  <Badge className={user.active === false ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                    {user.active === false ? 'Inactive' : 'Active'}
                  </Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-slate-400" />
                  <div>
                    <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>Email</p>
                    <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{user.email}</p>
                  </div>
                </div>
                {user.phone &&
                <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-slate-400" />
                    <div>
                      <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>Phone</p>
                      <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{user.phone}</p>
                    </div>
                  </div>
                }
                {user.department &&
                <div className="flex items-center gap-3">
                    <Briefcase className="w-5 h-5 text-slate-400" />
                    <div>
                      <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>Department</p>
                      <p className={`font-medium capitalize ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{user.department.replace(/_/g, ' ')}</p>
                    </div>
                  </div>
                }
              </div>
              <div className="space-y-4">
                {location &&
                <div className="flex items-center gap-3">
                    <Building2 className="w-5 h-5 text-slate-400" />
                    <div>
                      <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>Location</p>
                      <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{location.name}</p>
                    </div>
                  </div>
                }
                {user.hire_date &&
                <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-slate-400" />
                    <div>
                      <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>Hire Date</p>
                      <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                        {new Date(user.hire_date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                      </p>
                    </div>
                  </div>
                }
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Edit Name Card */}
        <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
          <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
            <CardTitle className="text-slate-200 font-semibold tracking-tight leading-none flex items-center gap-2">
              <User className="w-5 h-5 text-blue-600" />
              Edit Full Name
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="full_name" className="text-slate-500 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">Full Name *</Label>
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={(e) => handleChange('full_name', e.target.value)}
                  placeholder="Enter your full name"
                  required
                  className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''} />

                <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                  This is the name that will be displayed throughout the application
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={updateMutation.isPending || formData.full_name === user.full_name}
                  className="bg-blue-600 hover:bg-blue-700">

                  <Save className="w-4 h-4 mr-2" />
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>);

}