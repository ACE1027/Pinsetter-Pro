import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Shield, Plus, Edit, Lock, History, Clock, User } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PERMISSION_DEFINITIONS, SYSTEM_ROLES } from "../components/permissions/permissionDefinitions";
import { usePermissions } from "../components/permissions/usePermissions";
import { useTheme } from "@/components/ThemeContext";
import { format } from "date-fns";

export default function RoleManagement() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const { hasPermission, isAdmin } = usePermissions();
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRole, setEditingRole] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [activeTab, setActiveTab] = useState("roles");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    permission_keys: [],
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: roles = [], isLoading } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
    initialData: [],
  });

  const { data: allPermissions = [] } = useQuery({
    queryKey: ['permissions'],
    queryFn: () => base44.entities.Permission.list(),
    initialData: [],
  });

  const { data: auditLogs = [] } = useQuery({
    queryKey: ['roleAuditLogs'],
    queryFn: () => base44.entities.RoleAuditLog.list('-timestamp', 100),
    initialData: [],
    enabled: isAdmin,
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const role = await base44.entities.Role.create(data);
      // Log the creation
      await base44.entities.RoleAuditLog.create({
        role_id: role.id,
        role_name: role.name,
        action: 'created',
        changes: { created: data },
        performed_by: user?.email,
        timestamp: new Date().toISOString(),
      });
      return role;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      queryClient.invalidateQueries({ queryKey: ['roleAuditLogs'] });
      resetForm();
      toast.success("Role created successfully");
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data, oldRole }) => {
      const role = await base44.entities.Role.update(id, data);
      // Log the update
      const changes = {
        before: {
          name: oldRole.name,
          description: oldRole.description,
          permission_keys: oldRole.permission_keys,
        },
        after: data,
      };
      await base44.entities.RoleAuditLog.create({
        role_id: id,
        role_name: data.name || oldRole.name,
        action: 'updated',
        changes: changes,
        performed_by: user?.email,
        timestamp: new Date().toISOString(),
      });
      return role;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      queryClient.invalidateQueries({ queryKey: ['roleAuditLogs'] });
      resetForm();
      toast.success("Role updated successfully");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Role.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      toast.success("Role deleted successfully");
    },
  });

  if (!isAdmin && !hasPermission('role_manage')) {
    return (
      <div className={`min-h-screen flex items-center justify-center p-6 ${theme.bg}`}>
        <Card className={isDarkMode ? 'max-w-md bg-slate-900 border-slate-800' : 'max-w-md'}>
          <CardContent className="p-8 text-center">
            <Lock className="w-12 h-12 text-slate-500 mx-auto mb-4" />
            <h2 className={`text-xl font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Access Restricted</h2>
            <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>You don't have permission to manage roles.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const resetForm = () => {
    setDialogOpen(false);
    setEditingRole(null);
    setFormData({
      name: "",
      description: "",
      permission_keys: [],
    });
  };

  const handleEdit = (role) => {
    setEditingRole(role);
    setFormData({
      name: role.name || "",
      description: role.description || "",
      permission_keys: role.permission_keys || [],
    });
    setDialogOpen(true);
  };

  const handleDelete = (role) => {
    if (role.is_system_role) {
      toast.error("Cannot delete system roles");
      return;
    }
    if (window.confirm(`Are you sure you want to delete the role "${role.name}"?`)) {
      deleteMutation.mutate(role.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingRole) {
      updateMutation.mutate({ id: editingRole.id, data: formData, oldRole: editingRole });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleCreateFromTemplate = (template) => {
    setFormData({
      name: template.name,
      description: template.description,
      permission_keys: template.permission_keys,
    });
    setDialogOpen(true);
  };

  const togglePermission = (permissionKey) => {
    setFormData(prev => ({
      ...prev,
      permission_keys: prev.permission_keys.includes(permissionKey)
        ? prev.permission_keys.filter(k => k !== permissionKey)
        : [...prev.permission_keys, permissionKey]
    }));
  };

  const toggleCategoryPermissions = (category) => {
    const categoryPerms = PERMISSION_DEFINITIONS
      .filter(p => p.category === category)
      .map(p => p.key);
    
    const allSelected = categoryPerms.every(k => formData.permission_keys.includes(k));
    
    setFormData(prev => ({
      ...prev,
      permission_keys: allSelected
        ? prev.permission_keys.filter(k => !categoryPerms.includes(k))
        : [...new Set([...prev.permission_keys, ...categoryPerms])]
    }));
  };

  const filteredRoles = roles.filter(role =>
    role.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    role.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = [...new Set(PERMISSION_DEFINITIONS.map(p => p.category))];
  const filteredPermissions = selectedCategory === 'all'
    ? PERMISSION_DEFINITIONS
    : PERMISSION_DEFINITIONS.filter(p => p.category === selectedCategory);

  const getPermissionCount = (role) => {
    return role.permission_keys?.length || 0;
  };

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Role Management</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Manage roles, permissions, and access control</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => resetForm()}>
                <Plus className="w-4 h-4 mr-2" />
                Create Role
              </Button>
            </DialogTrigger>
            <DialogContent className={`max-w-4xl max-h-[90vh] overflow-y-auto ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'}`}>
              <DialogHeader>
                <DialogTitle className={isDarkMode ? 'text-slate-100' : 'text-slate-900'}>
                  {editingRole ? "Edit Role" : "Create New Role"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>Role Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    required
                    className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-white border-slate-300'}
                    disabled={editingRole?.is_system_role}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the role and its responsibilities..."
                    rows={3}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-white border-slate-300'}
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>Permissions</Label>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setFormData(prev => ({ ...prev, permission_keys: PERMISSION_DEFINITIONS.map(p => p.key) }))}
                        className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white border-slate-300 hover:bg-slate-50'}
                      >
                        Select All
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setFormData(prev => ({ ...prev, permission_keys: [] }))}
                        className={isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white border-slate-300 hover:bg-slate-50'}
                      >
                        Clear All
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    <Button
                      type="button"
                      variant={selectedCategory === 'all' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedCategory('all')}
                      className={selectedCategory === 'all' ? 'bg-blue-600' : isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-white border-slate-300'}
                    >
                      All
                    </Button>
                    {categories.map(cat => (
                      <Button
                        key={cat}
                        type="button"
                        variant={selectedCategory === cat ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedCategory(cat)}
                        className={selectedCategory === cat ? 'bg-blue-600' : isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-white border-slate-300'}
                      >
                        {cat.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </Button>
                    ))}
                  </div>

                  <div className={`grid grid-cols-1 gap-4 max-h-96 overflow-y-auto p-4 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                    {categories.map(category => {
                      if (selectedCategory !== 'all' && selectedCategory !== category) return null;
                      
                      const categoryPerms = PERMISSION_DEFINITIONS.filter(p => p.category === category);
                      const allSelected = categoryPerms.every(p => formData.permission_keys.includes(p.key));
                      
                      return (
                        <div key={category} className="space-y-3">
                          <div className={`flex items-center gap-2 pb-2 border-b ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                            <Checkbox
                              id={`cat-${category}`}
                              checked={allSelected}
                              onCheckedChange={() => toggleCategoryPermissions(category)}
                            />
                            <Label htmlFor={`cat-${category}`} className={`font-semibold cursor-pointer ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                              {category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </Label>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 ml-6">
                            {categoryPerms.map(permission => (
                              <div key={permission.key} className="flex items-start gap-2">
                                <Checkbox
                                  id={permission.key}
                                  checked={formData.permission_keys.includes(permission.key)}
                                  onCheckedChange={() => togglePermission(permission.key)}
                                  className="mt-1"
                                />
                                <div className="flex-1">
                                  <Label htmlFor={permission.key} className={`cursor-pointer font-normal ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                    {permission.name}
                                  </Label>
                                  <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>{permission.description}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    Selected: {formData.permission_keys.length} / {PERMISSION_DEFINITIONS.length} permissions
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={resetForm} className={`flex-1 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white border-slate-300 hover:bg-slate-50'}`}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    {editingRole ? "Update Role" : "Create Role"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className={isDarkMode ? 'bg-slate-900' : 'bg-white'}>
            <TabsTrigger value="roles">Roles</TabsTrigger>
            <TabsTrigger value="templates">System Templates</TabsTrigger>
            {isAdmin && <TabsTrigger value="audit">Audit Log</TabsTrigger>}
          </TabsList>

          <TabsContent value="roles">
            <div className="mb-6">
              <Input
                placeholder="Search roles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`max-w-md ${isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100 placeholder:text-slate-500' : 'bg-white border-slate-300'}`}
              />
            </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRoles.map(role => (
              <Card key={role.id} className={`transition-colors ${isDarkMode ? 'bg-slate-900 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-200 hover:border-slate-300'}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-blue-500" />
                      <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{role.name}</CardTitle>
                    </div>
                    {role.is_system_role && (
                      <Badge variant="outline" className={isDarkMode ? 'bg-slate-800 text-slate-300 border-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300'}>
                        System
                      </Badge>
                    )}
                    </div>
                    {role.description && (
                    <p className={`text-sm mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{role.description}</p>
                    )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>Permissions:</p>
                      <Badge className={isDarkMode ? 'bg-blue-600/20 text-blue-400 border-blue-600/30' : 'bg-blue-100 text-blue-700 border-blue-200'}>
                        {getPermissionCount(role)} assigned
                      </Badge>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(role)}
                        className={`flex-1 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white border-slate-300 hover:bg-slate-50'}`}
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

            {filteredRoles.length === 0 && !isLoading && (
              <div className="text-center py-12">
                <Shield className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-900'}`}>No Roles Found</h3>
                <p className={isDarkMode ? 'text-slate-500' : 'text-slate-600'}>Create a role to get started</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="templates">
            <div className="mb-4">
              <h2 className={`text-xl font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Predefined System Roles</h2>
              <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                Use these templates to quickly create roles with common permission sets
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SYSTEM_ROLES.map((template, index) => (
                <Card key={index} className={`transition-colors ${isDarkMode ? 'bg-slate-900 border-slate-800 hover:border-blue-700' : 'bg-white border-slate-200 hover:border-blue-300'}`}>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-blue-500" />
                      <CardTitle className={`text-lg ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{template.name}</CardTitle>
                    </div>
                    <p className={`text-sm mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{template.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className={`text-sm mb-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>Permissions:</p>
                        <Badge className={isDarkMode ? 'bg-blue-600/20 text-blue-400 border-blue-600/30' : 'bg-blue-100 text-blue-700 border-blue-200'}>
                          {template.permission_keys.length} permissions
                        </Badge>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCreateFromTemplate(template)}
                        className={`w-full ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white border-slate-300 hover:bg-slate-50'}`}
                      >
                        <Plus className="w-3 h-3 mr-2" />
                        Create from Template
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {isAdmin && (
            <TabsContent value="audit">
              <div className="mb-4">
                <h2 className={`text-xl font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Audit Log</h2>
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Track all changes made to roles and permissions
                </p>
              </div>
              
              {auditLogs.length === 0 ? (
                <div className="text-center py-12">
                  <History className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-900'}`}>No Audit Records</h3>
                  <p className={isDarkMode ? 'text-slate-500' : 'text-slate-600'}>Changes to roles will be logged here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {auditLogs.map(log => (
                    <Card key={log.id} className={`transition-colors ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge 
                                className={
                                  log.action === 'created' ? 'bg-green-600/20 text-green-400 border-green-600/30' :
                                  log.action === 'updated' ? 'bg-blue-600/20 text-blue-400 border-blue-600/30' :
                                  log.action === 'deleted' ? 'bg-red-600/20 text-red-400 border-red-600/30' :
                                  'bg-amber-600/20 text-amber-400 border-amber-600/30'
                                }
                              >
                                {log.action}
                              </Badge>
                              <span className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                {log.role_name}
                              </span>
                            </div>
                            <div className={`flex items-center gap-4 text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                <span>{log.performed_by}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>{format(new Date(log.timestamp), 'MMM d, yyyy h:mm a')}</span>
                              </div>
                            </div>
                            {log.changes && log.action === 'updated' && log.changes.before && log.changes.after && (
                              <div className={`mt-3 p-3 rounded-lg text-xs ${isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
                                <p className={`font-semibold mb-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>Changes:</p>
                                {log.changes.before.name !== log.changes.after.name && (
                                  <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                                    Name: <span className="line-through">{log.changes.before.name}</span> → {log.changes.after.name}
                                  </p>
                                )}
                                {log.changes.before.permission_keys?.length !== log.changes.after.permission_keys?.length && (
                                  <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                                    Permissions: {log.changes.before.permission_keys?.length || 0} → {log.changes.after.permission_keys?.length || 0}
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}