import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger } from
"@/components/ui/dialog";
import { Calendar, Plus, Edit, Trash2, User, Clock, Filter, Bell, Save, FolderOpen, Printer, CalendarX, ArrowLeftRight, Search, Check, X, ExternalLink, List, Activity, Download, RefreshCw, Users } from "lucide-react";
import { format, startOfWeek, addDays, isSameDay, startOfMonth } from "date-fns";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "../components/LocationContext";
import { NotificationPrompt } from "../components/NotificationManager";
import { useTheme } from "@/components/ThemeContext";
import MonthlyCalendar from "../components/schedule/MonthlyCalendar";
import ListView from "../components/schedule/ListView";
import TimelineView from "../components/schedule/TimelineView";
import BulkActionsToolbar from "../components/schedule/BulkActionsToolbar";
import OvertimeTracker from "../components/schedule/OvertimeTracker";
import RecurringScheduleManager from "../components/schedule/RecurringScheduleManager";
import MobileScheduleView from "../components/schedule/MobileScheduleView";
import AvailabilityManager from "../components/schedule/AvailabilityManager";

export default function Schedule() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState(null);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [loadTemplateDialogOpen, setLoadTemplateDialogOpen] = useState(false);
  const [templateName, setTemplateName] = useState("");
  const [templateDescription, setTemplateDescription] = useState("");
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [currentDay, setCurrentDay] = useState(new Date());
  const [currentMonth, setCurrentMonth] = useState(startOfMonth(new Date()));
  const [viewMode, setViewMode] = useState("week");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [positionFilter, setPositionFilter] = useState("all");
  const [employeeFilter, setEmployeeFilter] = useState("all");
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [selectedSchedules, setSelectedSchedules] = useState([]);
  const [dateRangeStart, setDateRangeStart] = useState("");
  const [dateRangeEnd, setDateRangeEnd] = useState("");
  const [isMobile, setIsMobile] = useState(false);
  const [weekStartDay, setWeekStartDay] = useState(1); // 0=Sunday, 1=Monday
  const { selectedLocationId } = useLocation();
  const [timeOffDialogOpen, setTimeOffDialogOpen] = useState(false);
  const [tradeShiftDialogOpen, setTradeShiftDialogOpen] = useState(false);
  const [timeOffFormData, setTimeOffFormData] = useState({
    start_date: "",
    end_date: "",
    reason: ""
  });
  const [tradeFormData, setTradeFormData] = useState({
    requester_schedule_id: "",
    target_email: "",
    reason: ""
  });
  const [activeTab, setActiveTab] = useState("schedule");
  const [tradeStatusFilter, setTradeStatusFilter] = useState("all");
  const [tradeSearchQuery, setTradeSearchQuery] = useState("");
  const [reviewTradeDialogOpen, setReviewTradeDialogOpen] = useState(false);
  const [selectedTradeRequest, setSelectedTradeRequest] = useState(null);
  const [tradeReviewNotes, setTradeReviewNotes] = useState("");
  const [formData, setFormData] = useState({
    user_email: "",
    bowling_alley_id: "",
    date: "",
    shift_start: "08:00",
    shift_end: "16:00",
    role: "",
    notes: ""
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.bowling_alley_id) {
        setFormData((prev) => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});

    // Check notification permission
    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }

    // Check if mobile
    setIsMobile(window.innerWidth < 768);
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const { data: schedules = [], isLoading } = useQuery({
    queryKey: ['userSchedules'],
    queryFn: () => base44.entities.UserSchedule.list(),
    initialData: []
  });

  const { data: users = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['scheduleTemplates'],
    queryFn: () => base44.entities.ScheduleTemplate.list(),
    initialData: []
  });

  const { data: timeOffRequests = [] } = useQuery({
    queryKey: ['timeOffRequests'],
    queryFn: () => base44.entities.TimeOffRequest.list(),
    initialData: []
  });

  const { data: tradeRequests = [] } = useQuery({
    queryKey: ['tradeRequests'],
    queryFn: () => base44.entities.ShiftTradeRequest.list(),
    initialData: []
  });

  const [timeOffStatusFilter, setTimeOffStatusFilter] = useState("all");
  const [timeOffSearchQuery, setTimeOffSearchQuery] = useState("");
  const [reviewTimeOffDialogOpen, setReviewTimeOffDialogOpen] = useState(false);
  const [selectedTimeOffRequest, setSelectedTimeOffRequest] = useState(null);
  const [timeOffReviewNotes, setTimeOffReviewNotes] = useState("");

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.UserSchedule.create(data),
    onSuccess: (newSchedule) => {
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      resetForm();
      toast.success("Schedule created successfully");

      // Send notification to the scheduled user
      if (notificationsEnabled && newSchedule.user_email === user?.email) {
        new Notification('New Shift Scheduled', {
          body: `You've been scheduled for ${format(new Date(newSchedule.date), 'MMM d')} from ${newSchedule.shift_start} to ${newSchedule.shift_end}`,
          icon: '/favicon.ico'
        });
      }
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UserSchedule.update(id, data),
    onSuccess: (updatedSchedule) => {
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      resetForm();
      toast.success("Schedule updated successfully");

      // Send notification to the scheduled user about the change
      if (notificationsEnabled && updatedSchedule.user_email === user?.email) {
        new Notification('Schedule Updated', {
          body: `Your shift for ${format(new Date(updatedSchedule.date), 'MMM d')} has been updated`,
          icon: '/favicon.ico'
        });
      }
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.UserSchedule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      toast.success("Schedule deleted successfully");
    }
  });

  const saveTemplateMutation = useMutation({
    mutationFn: (data) => base44.entities.ScheduleTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduleTemplates'] });
      setTemplateDialogOpen(false);
      setTemplateName("");
      setTemplateDescription("");
      toast.success("Template saved successfully");
    }
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: (id) => base44.entities.ScheduleTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduleTemplates'] });
      toast.success("Template deleted successfully");
    }
  });

  const createTimeOffMutation = useMutation({
    mutationFn: (data) => base44.entities.TimeOffRequest.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['timeOffRequests'] });
      setTimeOffDialogOpen(false);
      setTimeOffFormData({ start_date: "", end_date: "", reason: "" });
      toast.success("Time off request submitted");
    }
  });

  const createTradeMutation = useMutation({
    mutationFn: (data) => base44.entities.ShiftTradeRequest.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tradeRequests'] });
      setTradeShiftDialogOpen(false);
      setTradeFormData({ requester_schedule_id: "", target_email: "", reason: "" });
      toast.success("Trade request submitted");
    }
  });

  const updateTimeOffMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TimeOffRequest.update(id, data),
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries({ queryKey: ['timeOffRequests'] });
      setReviewTimeOffDialogOpen(false);
      setSelectedTimeOffRequest(null);
      setTimeOffReviewNotes("");
      
      // Create notification for the requester
      await base44.entities.Notification.create({
        user_email: updatedRequest.user_email,
        type: 'time_off_decision',
        title: `Time Off Request ${updatedRequest.status === 'approved' ? 'Approved' : 'Denied'}`,
        message: `Your time off request for ${format(new Date(updatedRequest.start_date), 'MMM d')} - ${format(new Date(updatedRequest.end_date), 'MMM d')} has been ${updatedRequest.status}`,
        priority: 'high',
        bowling_alley_id: updatedRequest.bowling_alley_id
      });
      
      toast.success(`Request ${updatedRequest.status}`);
    }
  });

  const updateTradeMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ShiftTradeRequest.update(id, data),
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries({ queryKey: ['tradeRequests'] });
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      
      if (updatedRequest.status === 'approved' || updatedRequest.status === 'rejected') {
        // Notify requester
        await base44.entities.Notification.create({
          user_email: updatedRequest.requester_email,
          type: 'shift_trade_decision',
          title: `Shift Trade ${updatedRequest.status === 'approved' ? 'Approved' : 'Rejected'}`,
          message: `Your shift trade request has been ${updatedRequest.status} by management`,
          priority: 'high',
          bowling_alley_id: updatedRequest.bowling_alley_id
        });
        
        // Notify target if applicable
        if (updatedRequest.target_email) {
          await base44.entities.Notification.create({
            user_email: updatedRequest.target_email,
            type: 'shift_trade_decision',
            title: `Shift Trade ${updatedRequest.status === 'approved' ? 'Approved' : 'Rejected'}`,
            message: `The shift trade with ${getUserName(updatedRequest.requester_email)} has been ${updatedRequest.status}`,
            priority: 'high',
            bowling_alley_id: updatedRequest.bowling_alley_id
          });
        }
        
        // If approved, swap the schedules
        if (updatedRequest.status === 'approved' && updatedRequest.target_schedule_id) {
          const requesterSchedule = schedules.find(s => s.id === updatedRequest.requester_schedule_id);
          const targetSchedule = schedules.find(s => s.id === updatedRequest.target_schedule_id);
          
          if (requesterSchedule && targetSchedule) {
            await base44.entities.UserSchedule.update(requesterSchedule.id, {
              user_email: targetSchedule.user_email
            });
            await base44.entities.UserSchedule.update(targetSchedule.id, {
              user_email: requesterSchedule.user_email
            });
          }
        }
        
        setReviewTradeDialogOpen(false);
        setSelectedTradeRequest(null);
        setTradeReviewNotes("");
      } else if (updatedRequest.status === 'accepted') {
        // Notify requester that target accepted
        await base44.entities.Notification.create({
          user_email: updatedRequest.requester_email,
          type: 'shift_trade_accepted',
          title: 'Shift Trade Accepted',
          message: `${getUserName(updatedRequest.target_email)} accepted your shift trade. Awaiting manager approval.`,
          priority: 'medium',
          bowling_alley_id: updatedRequest.bowling_alley_id
        });
      }
      
      toast.success(`Request ${updatedRequest.status}`);
    }
  });

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  const canEdit = isAdmin || isManager;
  const canApprove = isAdmin || isManager; // Only managers can approve requests
  const canView = true; // All users can view schedules at their location

  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' ?
  selectedLocationId :
  user?.bowling_alley_id;

  const filteredSchedules = schedules.filter((schedule) => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    return schedule.bowling_alley_id === effectiveLocationId;
  });

  // Apply department, position, employee, and date range filters
  const displayedSchedules = filteredSchedules.filter((schedule) => {
    const scheduleUser = users.find((u) => u.email === schedule.user_email);
    if (!scheduleUser) return true;

    const matchesDepartment = departmentFilter === 'all' || scheduleUser.department === departmentFilter;
    const matchesPosition = positionFilter === 'all' || scheduleUser.position === positionFilter;
    const matchesEmployee = employeeFilter === 'all' || schedule.user_email === employeeFilter;
    
    // Date range filter
    let matchesDateRange = true;
    if (dateRangeStart || dateRangeEnd) {
      const scheduleDate = new Date(schedule.date.split('T')[0]);
      if (dateRangeStart && scheduleDate < new Date(dateRangeStart)) matchesDateRange = false;
      if (dateRangeEnd && scheduleDate > new Date(dateRangeEnd)) matchesDateRange = false;
    }

    return matchesDepartment && matchesPosition && matchesEmployee && matchesDateRange;
  });

  // Monitor schedules for notifications
  useEffect(() => {
    if (!user || !notificationsEnabled) return;

    const checkUpcomingShifts = () => {
      const now = new Date();
      const tomorrow = addDays(now, 1);

      displayedSchedules.forEach((schedule) => {
        if (schedule.user_email !== user.email) return;

        const scheduleDate = new Date(schedule.date);
        if (isSameDay(scheduleDate, tomorrow)) {
          const notificationKey = `shift-reminder-${schedule.id}`;
          const lastNotified = localStorage.getItem(notificationKey);

          if (!lastNotified || Date.now() - parseInt(lastNotified) > 24 * 60 * 60 * 1000) {
            new Notification('Upcoming Shift Reminder', {
              body: `You have a shift tomorrow from ${schedule.shift_start} to ${schedule.shift_end}`,
              icon: '/favicon.ico'
            });
            localStorage.setItem(notificationKey, Date.now().toString());
          }
        }
      });
    };

    const interval = setInterval(checkUpcomingShifts, 60 * 60 * 1000); // Check every hour
    checkUpcomingShifts(); // Check immediately

    return () => clearInterval(interval);
  }, [user, notificationsEnabled, displayedSchedules]);

  const resetForm = () => {
    setDialogOpen(false);
    setEditingSchedule(null);
    setFormData({
      user_email: "",
      bowling_alley_id: user?.bowling_alley_id || "",
      date: "",
      shift_start: "08:00",
      shift_end: "16:00",
      role: "",
      notes: ""
    });
  };

  const handleEdit = (schedule) => {
    setEditingSchedule(schedule);
    setFormData({
      user_email: schedule.user_email || "",
      bowling_alley_id: schedule.bowling_alley_id || "",
      date: schedule.date ? schedule.date.split('T')[0] : "",
      shift_start: schedule.shift_start || "08:00",
      shift_end: schedule.shift_end || "16:00",
      role: schedule.role || "",
      notes: schedule.notes || ""
    });
    setDialogOpen(true);
  };

  const handleDelete = (schedule) => {
    if (window.confirm(`Are you sure you want to delete this schedule?`)) {
      deleteMutation.mutate(schedule.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const deviceTimestamp = new Date().toISOString();

    if (editingSchedule) {
      updateMutation.mutate({ id: editingSchedule.id, data: { ...formData, device_timestamp: deviceTimestamp } });
    } else {
      createMutation.mutate({ ...formData, device_timestamp: deviceTimestamp });
    }
  };

  const getLocationName = (locationId) => {
    const location = locations.find((l) => l.id === locationId);
    return location?.name || 'Unknown Location';
  };

  const getUserName = (email) => {
    const foundUser = users.find((u) => u.email === email);
    return foundUser?.display_name || foundUser?.full_name || email;
  };

  // Generate week days
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));

  const getSchedulesForDay = (day) => {
    return displayedSchedules.filter((schedule) => {
      // Parse date string as local date to avoid timezone issues
      const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return isSameDay(scheduleDate, day);
    });
  };

  const getUserDepartment = (email) => {
    const foundUser = users.find((u) => u.email === email);
    return foundUser?.department || '';
  };

  const getUserPosition = (email) => {
    const foundUser = users.find((u) => u.email === email);
    return foundUser?.position || '';
  };

  const positionHierarchy = [
  { value: "general_manager", label: "General Manager" },
  { value: "service_manager", label: "Service Manager" },
  { value: "assistant_manager", label: "Assistant Manager" },
  { value: "senior_mechanic", label: "Senior Mechanic" },
  { value: "lead_mechanic", label: "Lead Mechanic" },
  { value: "mechanic", label: "Mechanic" },
  { value: "mechanic_apprentice", label: "Mechanic Apprentice" },
  { value: "front_desk_supervisor", label: "Front Desk Supervisor" },
  { value: "front_desk_staff", label: "Front Desk Staff" }];


  const getPositionLabel = (value) => {
    const pos = positionHierarchy.find((p) => p.value === value);
    return pos?.label || value?.replace(/_/g, ' ');
  };

  const getAvailableRoles = (userEmail) => {
    const selectedUser = users.find((u) => u.email === userEmail);
    if (!selectedUser) return [];

    // Return primary position + additional roles
    const roles = [selectedUser.position];
    if (selectedUser.roles && Array.isArray(selectedUser.roles)) {
      selectedUser.roles.forEach((role) => {
        if (!roles.includes(role)) {
          roles.push(role);
        }
      });
    }
    return roles.filter(Boolean);
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      setNotificationsEnabled(permission === 'granted');
      if (permission === 'granted') {
        toast.success('Notifications enabled');
      }
    }
  };

  // Get unique departments and positions
  const departments = ['all', ...new Set(users.map((u) => u.department).filter(Boolean))];
  const positions = ['all', ...new Set(users.map((u) => u.position).filter(Boolean))];

  const goToPreviousWeek = () => {
    setCurrentWeekStart((prev) => addDays(prev, -7));
  };

  const goToNextWeek = () => {
    setCurrentWeekStart((prev) => addDays(prev, 7));
  };

  const goToCurrentWeek = () => {
    setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: weekStartDay }));
  };

  const handleToggleSchedule = (scheduleId) => {
    setSelectedSchedules(prev => 
      prev.includes(scheduleId) 
        ? prev.filter(id => id !== scheduleId)
        : [...prev, scheduleId]
    );
  };

  const handleToggleAll = (schedules) => {
    if (selectedSchedules.length === schedules.length) {
      setSelectedSchedules([]);
    } else {
      setSelectedSchedules(schedules.map(s => s.id));
    }
  };

  const handleBulkDelete = () => {
    if (window.confirm(`Delete ${selectedSchedules.length} selected schedules?`)) {
      Promise.all(selectedSchedules.map(id => base44.entities.UserSchedule.delete(id)))
        .then(() => {
          queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
          setSelectedSchedules([]);
          toast.success(`Deleted ${selectedSchedules.length} schedules`);
        })
        .catch(() => toast.error("Failed to delete schedules"));
    }
  };

  const handleBulkCopy = (targetDate) => {
    const selectedScheduleObjects = schedules.filter(s => selectedSchedules.includes(s.id));
    
    const targetDateObj = new Date(targetDate);
    const sourceDateObj = new Date(selectedScheduleObjects[0].date.split('T')[0]);
    const daysDiff = Math.floor((targetDateObj - sourceDateObj) / (1000 * 60 * 60 * 24));
    
    const newSchedules = selectedScheduleObjects.map(schedule => {
      const scheduleDate = new Date(schedule.date.split('T')[0]);
      const newDate = addDays(scheduleDate, daysDiff);
      
      return {
        user_email: schedule.user_email,
        bowling_alley_id: schedule.bowling_alley_id,
        date: format(newDate, 'yyyy-MM-dd'),
        shift_start: schedule.shift_start,
        shift_end: schedule.shift_end,
        role: schedule.role,
        notes: schedule.notes,
        device_timestamp: new Date().toISOString()
      };
    });
    
    Promise.all(newSchedules.map(s => base44.entities.UserSchedule.create(s)))
      .then(() => {
        queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
        setSelectedSchedules([]);
        toast.success(`Copied ${newSchedules.length} schedules`);
      })
      .catch(() => toast.error("Failed to copy schedules"));
  };

  const handleExportICalendar = () => {
    const icsEvents = displayedSchedules.map(schedule => {
      const scheduleDate = new Date(schedule.date.split('T')[0]);
      const startDateTime = new Date(`${schedule.date.split('T')[0]}T${schedule.shift_start}:00`);
      const endDateTime = new Date(`${schedule.date.split('T')[0]}T${schedule.shift_end}:00`);
      
      return [
        'BEGIN:VEVENT',
        `DTSTART:${startDateTime.toISOString().replace(/[-:]/g, '').split('.')[0]}Z`,
        `DTEND:${endDateTime.toISOString().replace(/[-:]/g, '').split('.')[0]}Z`,
        `SUMMARY:Shift - ${getUserName(schedule.user_email)}`,
        `DESCRIPTION:${schedule.role ? getPositionLabel(schedule.role) : 'Shift'}${schedule.notes ? ` - ${schedule.notes}` : ''}`,
        `LOCATION:${getLocationName(schedule.bowling_alley_id)}`,
        `UID:${schedule.id}@pinsetter-pro`,
        'END:VEVENT'
      ].join('\n');
    }).join('\n');

    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Pinsetter Pro//Staff Schedule//EN',
      'CALSCALE:GREGORIAN',
      icsEvents,
      'END:VCALENDAR'
    ].join('\n');

    const blob = new Blob([icsContent], { type: 'text/calendar' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `schedule-${format(new Date(), 'yyyy-MM-dd')}.ics`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    toast.success('Calendar exported');
  };

  const goToPreviousDay = () => {
    setCurrentDay((prev) => addDays(prev, -1));
  };

  const goToNextDay = () => {
    setCurrentDay((prev) => addDays(prev, 1));
  };

  const goToToday = () => {
    setCurrentDay(new Date());
  };

  const handleSaveAsTemplate = () => {
    if (!effectiveLocationId) {
      toast.error("Please select a location first");
      return;
    }

    const weekSchedules = viewMode === "week" ?
    filteredSchedules.filter((s) => {
      const [year, month, dayNum] = s.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return weekDays.some((day) => isSameDay(scheduleDate, day));
    }) :
    filteredSchedules.filter((s) => {
      const [year, month, dayNum] = s.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return isSameDay(scheduleDate, currentDay);
    });

    if (weekSchedules.length === 0) {
      toast.error("No schedules to save");
      return;
    }

    setTemplateDialogOpen(true);
  };

  const saveTemplate = () => {
    if (!templateName.trim()) {
      toast.error("Please enter a template name");
      return;
    }

    const weekSchedules = viewMode === "week" ?
    filteredSchedules.filter((s) => {
      const [year, month, dayNum] = s.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return weekDays.some((day) => isSameDay(scheduleDate, day));
    }) :
    filteredSchedules.filter((s) => {
      const [year, month, dayNum] = s.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return isSameDay(scheduleDate, currentDay);
    });

    const scheduleData = weekSchedules.map((schedule) => {
      const [year, month, dayNum] = schedule.date.split('T')[0].split('-');
      const scheduleDate = new Date(year, month - 1, dayNum);
      return {
        day_of_week: scheduleDate.getDay(),
        user_email: schedule.user_email,
        shift_start: schedule.shift_start,
        shift_end: schedule.shift_end,
        role: schedule.role,
        notes: schedule.notes
      };
    });

    saveTemplateMutation.mutate({
      name: templateName,
      description: templateDescription,
      bowling_alley_id: effectiveLocationId,
      schedule_data: scheduleData
    });
  };

  const handleLoadTemplate = (template) => {
    const startDate = viewMode === "week" ? currentWeekStart : currentDay;

    const newSchedules = template.schedule_data.map((entry) => {
      let targetDate;
      if (viewMode === "week") {
        targetDate = addDays(currentWeekStart, entry.day_of_week === 0 ? 6 : entry.day_of_week - 1);
      } else {
        targetDate = currentDay;
      }

      return {
        user_email: entry.user_email,
        bowling_alley_id: template.bowling_alley_id,
        date: format(targetDate, 'yyyy-MM-dd'),
        shift_start: entry.shift_start,
        shift_end: entry.shift_end,
        role: entry.role,
        notes: entry.notes,
        device_timestamp: new Date().toISOString()
      };
    });

    Promise.all(newSchedules.map((schedule) => base44.entities.UserSchedule.create(schedule))).
    then(() => {
      queryClient.invalidateQueries({ queryKey: ['userSchedules'] });
      setLoadTemplateDialogOpen(false);
      toast.success(`Applied template: ${template.name}`);
    }).
    catch(() => {
      toast.error("Failed to apply template");
    });
  };

  const handleDeleteTemplate = (templateId) => {
    if (window.confirm("Are you sure you want to delete this template?")) {
      deleteTemplateMutation.mutate(templateId);
    }
  };

  const calculateShiftHours = (startTime, endTime) => {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    const start = startHour + startMin / 60;
    const end = endHour + endMin / 60;
    return end > start ? end - start : (24 - start) + end;
  };

  const getDayTotalHours = (day) => {
    const daySchedules = getSchedulesForDay(day);
    return daySchedules.reduce((total, schedule) => 
      total + calculateShiftHours(schedule.shift_start, schedule.shift_end), 0
    );
  };

  const getWeekTotalHours = () => {
    return weekDays.reduce((total, day) => total + getDayTotalHours(day), 0);
  };

  const handleTimeOffSubmit = (e) => {
    e.preventDefault();
    createTimeOffMutation.mutate({
      ...timeOffFormData,
      user_email: user.email,
      bowling_alley_id: effectiveLocationId
    });
  };

  const handleTradeSubmit = (e) => {
    e.preventDefault();
    const selectedSchedule = displayedSchedules.find(s => s.id === tradeFormData.requester_schedule_id);
    createTradeMutation.mutate({
      ...tradeFormData,
      requester_email: user.email,
      bowling_alley_id: selectedSchedule?.bowling_alley_id || effectiveLocationId
    });
  };

  const submitTimeOffReview = (status) => {
    if (!selectedTimeOffRequest) return;
    
    if (!canApprove) {
      toast.error("Only managers can approve/deny requests");
      return;
    }
    
    updateTimeOffMutation.mutate({
      id: selectedTimeOffRequest.id,
      data: {
        status,
        reviewed_by: user.email,
        reviewed_date: new Date().toISOString(),
        notes: timeOffReviewNotes
      }
    });
  };

  const filteredTimeOffRequests = timeOffRequests.filter(request => {
    if (!user) return false;
    
    // Location filtering
    if (isAdmin && selectedLocationId === 'all') {
      // Show all for admin
    } else if (effectiveLocationId && request.bowling_alley_id !== effectiveLocationId) {
      return false;
    }
    
    // Status filtering
    if (timeOffStatusFilter !== 'all' && request.status !== timeOffStatusFilter) return false;
    
    // Search filtering
    if (timeOffSearchQuery) {
      const requestUser = users.find(u => u.email === request.user_email);
      const userName = requestUser?.display_name || requestUser?.full_name || request.user_email;
      if (!userName.toLowerCase().includes(timeOffSearchQuery.toLowerCase()) &&
          !request.reason?.toLowerCase().includes(timeOffSearchQuery.toLowerCase())) {
        return false;
      }
    }
    
    return true;
  });

  const timeOffStatusConfig = {
    pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800' },
    approved: { label: 'Approved', color: 'bg-green-100 text-green-800' },
    denied: { label: 'Denied', color: 'bg-red-100 text-red-800' }
  };

  const timeOffStatusCounts = {
    all: filteredTimeOffRequests.length,
    pending: filteredTimeOffRequests.filter(r => r.status === 'pending').length,
    approved: filteredTimeOffRequests.filter(r => r.status === 'approved').length,
    denied: filteredTimeOffRequests.filter(r => r.status === 'denied').length
  };

  const filteredTradeRequests = tradeRequests.filter(request => {
    if (!user) return false;
    
    // Location filtering
    if (isAdmin && selectedLocationId === 'all') {
      // Show all for admin
    } else if (effectiveLocationId && request.bowling_alley_id !== effectiveLocationId) {
      return false;
    }
    
    // Status filtering
    if (tradeStatusFilter !== 'all' && request.status !== tradeStatusFilter) return false;
    
    // Search filtering
    if (tradeSearchQuery) {
      const requesterName = getUserName(request.requester_email);
      const targetName = request.target_email ? getUserName(request.target_email) : '';
      if (!requesterName.toLowerCase().includes(tradeSearchQuery.toLowerCase()) &&
          !targetName.toLowerCase().includes(tradeSearchQuery.toLowerCase()) &&
          !request.reason?.toLowerCase().includes(tradeSearchQuery.toLowerCase())) {
        return false;
      }
    }
    
    return true;
  });

  const getScheduleDetails = (scheduleId) => {
    const schedule = schedules.find(s => s.id === scheduleId);
    if (!schedule) return null;
    return {
      date: schedule.date,
      shift_start: schedule.shift_start,
      shift_end: schedule.shift_end,
      user_email: schedule.user_email
    };
  };

  const handleTradeAccept = (request) => {
    updateTradeMutation.mutate({
      id: request.id,
      data: { status: 'accepted' }
    });
  };

  const handleTradeDecline = (request) => {
    updateTradeMutation.mutate({
      id: request.id,
      data: { status: 'declined' }
    });
  };

  const submitTradeReview = (status) => {
    if (!selectedTradeRequest) return;
    
    if (!canApprove) {
      toast.error("Only managers can approve/reject trades");
      return;
    }
    
    updateTradeMutation.mutate({
      id: selectedTradeRequest.id,
      data: {
        status,
        reviewed_by: user.email,
        reviewed_date: new Date().toISOString(),
        notes: tradeReviewNotes
      }
    });
  };

  const tradeStatusConfig = {
    pending: { label: 'Pending User', color: 'bg-yellow-100 text-yellow-800' },
    accepted: { label: 'Awaiting Approval', color: 'bg-blue-100 text-blue-800' },
    declined: { label: 'Declined', color: 'bg-red-100 text-red-800' },
    approved: { label: 'Approved', color: 'bg-green-100 text-green-800' },
    rejected: { label: 'Rejected', color: 'bg-red-100 text-red-800' }
  };

  const tradeStatusCounts = {
    all: filteredTradeRequests.length,
    pending: filteredTradeRequests.filter(r => r.status === 'pending').length,
    accepted: filteredTradeRequests.filter(r => r.status === 'accepted').length,
    approved: filteredTradeRequests.filter(r => r.status === 'approved').length,
    declined: filteredTradeRequests.filter(r => r.status === 'declined' || r.status === 'rejected').length
  };

  const handleScheduleDrop = (scheduleId, newDate) => {
    const schedule = schedules.find(s => s.id === scheduleId);
    if (!schedule) return;

    updateMutation.mutate({
      id: scheduleId,
      data: {
        ...schedule,
        date: newDate,
        device_timestamp: new Date().toISOString()
      }
    });
  };

  const handleScheduleClick = (schedule) => {
    if (canEdit) {
      handleEdit(schedule);
    }
  };

  const handlePrint = () => {
    const schedulesToPrint = viewMode === "week" 
      ? weekDays.map(day => ({
          date: day,
          schedules: getSchedulesForDay(day)
        }))
      : [{ date: currentDay, schedules: getSchedulesForDay(currentDay) }];

    const locationName = effectiveLocationId 
      ? getLocationName(effectiveLocationId) 
      : 'All Locations';

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Staff Schedule - ${locationName}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { text-align: center; margin-bottom: 5px; }
          h2 { text-align: center; color: #666; font-weight: normal; margin-top: 0; }
          .week-header { text-align: center; margin-bottom: 20px; }
          .day-container { margin-bottom: 20px; page-break-inside: avoid; }
          .day-header { background: #f0f0f0; padding: 10px; font-weight: bold; border-radius: 5px 5px 0 0; }
          .schedule-table { width: 100%; border-collapse: collapse; }
          .schedule-table th, .schedule-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          .schedule-table th { background: #f8f8f8; }
          .no-schedules { padding: 20px; text-align: center; color: #999; }
          @media print {
            body { padding: 0; }
            .day-container { page-break-inside: avoid; }
          }
        </style>
      </head>
      <body>
        <h1>Staff Schedule</h1>
        <h2>${locationName}</h2>
        <div class="week-header">
          ${viewMode === "week" 
            ? `Week of ${format(currentWeekStart, 'MMM d')} - ${format(addDays(currentWeekStart, 6), 'MMM d, yyyy')}`
            : format(currentDay, 'EEEE, MMMM d, yyyy')}
        </div>
        ${schedulesToPrint.map(({ date, schedules }) => `
          <div class="day-container">
            <div class="day-header">${format(date, 'EEEE, MMMM d, yyyy')}</div>
            ${schedules.length > 0 ? `
              <table class="schedule-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Shift</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  ${schedules.map(s => `
                    <tr>
                      <td>${getUserName(s.user_email)}</td>
                      <td>${s.role ? getPositionLabel(s.role) : '-'}</td>
                      <td>${s.shift_start} - ${s.shift_end}</td>
                      <td>${s.notes || '-'}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            ` : '<div class="no-schedules">No schedules</div>'}
          </div>
        `).join('')}
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full">
        <NotificationPrompt />
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Staff Schedule</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Manage staff schedules and shifts</p>
          </div>
          <div className="flex gap-2 flex-wrap w-full">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setTimeOffDialogOpen(true)}
              className="border-orange-300 text-orange-700 hover:bg-orange-50 text-xs sm:text-sm">
              <CalendarX className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Time Off
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setTradeShiftDialogOpen(true)}
              className="border-purple-300 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm">
              <ArrowLeftRight className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Trade
            </Button>
            {!notificationsEnabled && 'Notification' in window &&
            <Button
              variant="outline"
              size="sm"
              onClick={requestNotificationPermission}
              className="border-blue-300 text-blue-700 hover:bg-blue-50 text-xs sm:text-sm">

                <Bell className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                Notify
              </Button>
            }
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="border-slate-300 text-slate-700 hover:bg-slate-50 text-xs sm:text-sm">
              <Printer className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Print
            </Button>
            {canEdit &&
            <>
                <Button
                variant="outline"
                size="sm"
                onClick={handleSaveAsTemplate}
                className="border-green-300 text-green-700 hover:bg-green-50 text-xs sm:text-sm">

                  <Save className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  Template
                </Button>
                <Button
                variant="outline"
                size="sm"
                onClick={() => setLoadTemplateDialogOpen(true)}
                className="border-purple-300 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm">

                  <FolderOpen className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  Load
                </Button>
              </>
            }
            {canEdit &&
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" onClick={() => resetForm()}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Schedule
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>
                    {editingSchedule ? "Edit Schedule" : "Add New Schedule"}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bowling_alley_id">Location *</Label>
                    <Select
                      value={formData.bowling_alley_id}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, bowling_alley_id: value }))}
                      required>

                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.filter((l) => l.active !== false).map((location) =>
                        <SelectItem key={location.id} value={location.id}>
                            {location.name}
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="user_email">User *</Label>
                    <Select
                      value={formData.user_email}
                      onValueChange={(value) => {
                        setFormData((prev) => ({ ...prev, user_email: value, role: "" }));
                      }}
                      required>

                      <SelectTrigger>
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.filter((u) => u.active !== false).map((user) =>
                        <SelectItem key={user.id} value={user.email}>
                            {user.display_name || user.full_name || user.email}
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="role">Role for this Shift</Label>
                    <Select
                      value={formData.role}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, role: value }))}
                      disabled={!formData.user_email}>

                      <SelectTrigger>
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        {getAvailableRoles(formData.user_email).map((role) =>
                        <SelectItem key={role} value={role}>
                            {getPositionLabel(role)}
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-slate-500">
                      Only roles assigned to this user are available
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date *</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
                      required />

                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="shift_start">Shift Start *</Label>
                      <Input
                        id="shift_start"
                        type="time"
                        value={formData.shift_start}
                        onChange={(e) => setFormData((prev) => ({ ...prev, shift_start: e.target.value }))}
                        required />

                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="shift_end">Shift End *</Label>
                      <Input
                        id="shift_end"
                        type="time"
                        value={formData.shift_end}
                        onChange={(e) => setFormData((prev) => ({ ...prev, shift_end: e.target.value }))}
                        required />

                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                      placeholder="Additional notes..."
                      rows={3} />

                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createMutation.isPending || updateMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-700">

                      {editingSchedule ? "Update Schedule" : "Add Schedule"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
            }
          </div>
        </div>

        {/* Save Template Dialog */}
        <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Save Schedule as Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="template-name">Template Name *</Label>
                <Input
                  id="template-name"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder="e.g., Standard Week, Holiday Schedule" />

              </div>
              <div className="space-y-2">
                <Label htmlFor="template-description">Description</Label>
                <Textarea
                  id="template-description"
                  value={templateDescription}
                  onChange={(e) => setTemplateDescription(e.target.value)}
                  placeholder="Optional description..."
                  rows={3} />

              </div>
              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setTemplateDialogOpen(false)}
                  className="flex-1">

                  Cancel
                </Button>
                <Button
                  onClick={saveTemplate}
                  disabled={saveTemplateMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700">

                  Save Template
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Time Off Request Dialog */}
        <Dialog open={timeOffDialogOpen} onOpenChange={setTimeOffDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Request Time Off</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleTimeOffSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="start_date">Start Date *</Label>
                <Input
                  id="start_date"
                  type="date"
                  value={timeOffFormData.start_date}
                  onChange={(e) => setTimeOffFormData(prev => ({ ...prev, start_date: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end_date">End Date *</Label>
                <Input
                  id="end_date"
                  type="date"
                  value={timeOffFormData.end_date}
                  onChange={(e) => setTimeOffFormData(prev => ({ ...prev, end_date: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reason">Reason *</Label>
                <Textarea
                  id="reason"
                  value={timeOffFormData.reason}
                  onChange={(e) => setTimeOffFormData(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="Explain your time off request..."
                  rows={3}
                  required
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setTimeOffDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" disabled={createTimeOffMutation.isPending} className="flex-1 bg-orange-600 hover:bg-orange-700">
                  Submit Request
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Trade Shift Dialog */}
        <Dialog open={tradeShiftDialogOpen} onOpenChange={setTradeShiftDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Request Shift Trade</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleTradeSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="requester_schedule_id">Your Shift to Trade *</Label>
                <Select
                  value={tradeFormData.requester_schedule_id}
                  onValueChange={(value) => setTradeFormData(prev => ({ ...prev, requester_schedule_id: value }))}
                  required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your shift" />
                  </SelectTrigger>
                  <SelectContent>
                    {displayedSchedules
                      .filter(s => s.user_email === user?.email && new Date(s.date) >= new Date())
                      .map(schedule => {
                        const scheduleDate = new Date(schedule.date.split('T')[0]);
                        return (
                          <SelectItem key={schedule.id} value={schedule.id}>
                            {format(scheduleDate, 'MMM d, yyyy')} - {schedule.shift_start} to {schedule.shift_end}
                          </SelectItem>
                        );
                      })}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="target_email">Trade With (Optional)</Label>
                <Select
                  value={tradeFormData.target_email}
                  onValueChange={(value) => setTradeFormData(prev => ({ ...prev, target_email: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a coworker or leave blank for open trade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Open Trade (Anyone)</SelectItem>
                    {users
                      .filter(u => u.email !== user?.email && u.active !== false)
                      .map(user => (
                        <SelectItem key={user.id} value={user.email}>
                          {user.display_name || user.full_name || user.email}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="trade_reason">Reason *</Label>
                <Textarea
                  id="trade_reason"
                  value={tradeFormData.reason}
                  onChange={(e) => setTradeFormData(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="Explain why you need to trade this shift..."
                  rows={3}
                  required
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setTradeShiftDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" disabled={createTradeMutation.isPending} className="flex-1 bg-purple-600 hover:bg-purple-700">
                  Submit Request
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Load Template Dialog */}
        <Dialog open={loadTemplateDialogOpen} onOpenChange={setLoadTemplateDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Load Schedule Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {templates.filter((t) => !effectiveLocationId || t.bowling_alley_id === effectiveLocationId).length === 0 ?
              <div className="text-center py-8 text-slate-500">
                  <FolderOpen className="w-12 h-12 mx-auto mb-3 text-slate-400" />
                  <p>No templates available</p>
                </div> :

              <div className="space-y-3 max-h-96 overflow-y-auto">
                  {templates.
                filter((t) => !effectiveLocationId || t.bowling_alley_id === effectiveLocationId).
                map((template) =>
                <Card key={template.id} className="border-slate-200 hover:border-purple-300 transition-colors">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-slate-900">{template.name}</h3>
                              {template.description &&
                        <p className="text-sm text-slate-600 mt-1">{template.description}</p>
                        }
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">
                                  {template.schedule_data?.length || 0} shifts
                                </Badge>
                                <span className="text-xs text-slate-500">
                                  📍 {getLocationName(template.bowling_alley_id)}
                                </span>
                              </div>
                            </div>
                            <div className="flex gap-2 ml-3">
                              <Button
                          size="sm"
                          onClick={() => handleLoadTemplate(template)}
                          className="bg-purple-600 hover:bg-purple-700">

                                Apply
                              </Button>
                              <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteTemplate(template.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50">

                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                )}
                </div>
              }
            </div>
          </DialogContent>
        </Dialog>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <div className="overflow-x-auto">
            <TabsList className="grid grid-cols-5 w-full min-w-max sm:min-w-0 max-w-4xl">
            <TabsTrigger value="schedule">Schedule</TabsTrigger>
            <TabsTrigger value="timeoff">Time Off</TabsTrigger>
            <TabsTrigger value="trades">Shift Trades</TabsTrigger>
            <TabsTrigger value="recurring">Recurring</TabsTrigger>
            <TabsTrigger value="availability">Availability</TabsTrigger>
            </TabsList>
          </div>
        </Tabs>

        {activeTab === "schedule" && (
        <>
        {/* View Mode Toggle */}
        <div className={`rounded-lg shadow-sm border p-4 mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-semibold text-slate-700">View Mode:</span>
            </div>
            <div className="flex gap-2 overflow-x-auto">
              <Tabs value={viewMode} onValueChange={setViewMode} className="w-auto">
                <TabsList className="flex-nowrap">
                  <TabsTrigger value="month">
                    <Calendar className="w-4 h-4 mr-2" />
                    Month
                  </TabsTrigger>
                  <TabsTrigger value="week">
                    <Calendar className="w-4 h-4 mr-2" />
                    Week
                  </TabsTrigger>
                  <TabsTrigger value="timeline">
                    <Activity className="w-4 h-4 mr-2" />
                    Timeline
                  </TabsTrigger>
                  <TabsTrigger value="list">
                    <List className="w-4 h-4 mr-2" />
                    List
                  </TabsTrigger>
                  {isMobile && (
                    <TabsTrigger value="mobile">
                      <Users className="w-4 h-4 mr-2" />
                      Mobile
                    </TabsTrigger>
                  )}
                </TabsList>
              </Tabs>
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportICalendar}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                <Download className="w-4 h-4 mr-2" />
                Export iCal
              </Button>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className={`rounded-lg shadow-sm border p-4 mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex items-center gap-2 mb-3">
            <Filter className="w-4 h-4 text-slate-500" />
            <span className="text-sm font-semibold text-slate-700">Filter by:</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <div>
              <Label htmlFor="employee-filter" className="text-xs text-slate-600 mb-1 block">Employee</Label>
              <Select value={employeeFilter} onValueChange={setEmployeeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All employees" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Employees</SelectItem>
                  {users.filter(u => u.active !== false).map(user => (
                    <SelectItem key={user.id} value={user.email}>
                      {user.display_name || user.full_name || user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="department-filter" className="text-xs text-slate-600 mb-1 block">Department</Label>
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="manager">Managers</SelectItem>
                  <SelectItem value="mechanic">Mechanics</SelectItem>
                  <SelectItem value="front_desk">Front Desk</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="position-filter" className="text-xs text-slate-600 mb-1 block">Position</Label>
              <Select value={positionFilter} onValueChange={setPositionFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All positions" />
                </SelectTrigger>
                <SelectContent>
                  {positions.map((pos) =>
                  <SelectItem key={pos} value={pos}>
                      {pos === 'all' ? 'All Positions' : pos.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase())}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="start-date" className="text-xs text-slate-600 mb-1 block">Start Date</Label>
              <Input
                id="start-date"
                type="date"
                value={dateRangeStart}
                onChange={(e) => setDateRangeStart(e.target.value)}
                className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
              />
            </div>
            <div>
              <Label htmlFor="end-date" className="text-xs text-slate-600 mb-1 block">End Date</Label>
              <Input
                id="end-date"
                type="date"
                value={dateRangeEnd}
                onChange={(e) => setDateRangeEnd(e.target.value)}
                className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
              />
            </div>
          </div>
          {(dateRangeStart || dateRangeEnd) && (
            <div className="mt-2 flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setDateRangeStart("");
                  setDateRangeEnd("");
                }}
                className="text-xs"
              >
                Clear Date Filter
              </Button>
            </div>
          )}
        </div>

        {/* Overtime Tracker for Week View */}
        {viewMode === "week" && (
          <div className="mb-6">
            <OvertimeTracker
              schedules={displayedSchedules}
              users={users}
              currentWeekStart={currentWeekStart}
              isDarkMode={isDarkMode}
            />
          </div>
        )}

        {/* Bulk Actions Toolbar */}
        <BulkActionsToolbar
          selectedCount={selectedSchedules.length}
          onBulkDelete={handleBulkDelete}
          onBulkCopy={handleBulkCopy}
          onClearSelection={() => setSelectedSchedules([])}
          isDarkMode={isDarkMode}
        />

        {/* Navigation */}
        {viewMode === "month" ? (
          <MonthlyCalendar
            currentMonth={currentMonth}
            setCurrentMonth={setCurrentMonth}
            schedules={displayedSchedules}
            getUserName={getUserName}
            getPositionLabel={getPositionLabel}
            onScheduleDrop={handleScheduleDrop}
            onScheduleClick={handleScheduleClick}
            canEdit={canEdit}
            isDarkMode={isDarkMode}
          />
        ) : viewMode === "timeline" ? (
          <TimelineView
            currentWeekStart={currentWeekStart}
            setCurrentWeekStart={setCurrentWeekStart}
            schedules={displayedSchedules}
            getUserName={getUserName}
            getPositionLabel={getPositionLabel}
            onScheduleClick={handleScheduleClick}
            isDarkMode={isDarkMode}
          />
        ) : viewMode === "list" ? (
          <ListView
            schedules={displayedSchedules}
            getUserName={getUserName}
            getPositionLabel={getPositionLabel}
            getLocationName={getLocationName}
            onEdit={handleEdit}
            onDelete={handleDelete}
            canEdit={canEdit}
            selectedSchedules={selectedSchedules}
            onToggleSchedule={handleToggleSchedule}
            onToggleAll={handleToggleAll}
            isDarkMode={isDarkMode}
          />
        ) : viewMode === "mobile" && isMobile ? (
          <MobileScheduleView
            schedules={displayedSchedules}
            getUserName={getUserName}
            getPositionLabel={getPositionLabel}
            getLocationName={getLocationName}
            onEdit={handleEdit}
            onDelete={handleDelete}
            canEdit={canEdit}
            isDarkMode={isDarkMode}
          />
        ) : viewMode === "week" ?
        <div className="flex justify-between items-center gap-2 mb-6">
            <Button variant="outline" size="sm" onClick={goToPreviousWeek} className="shrink-0">
              ← Prev
            </Button>
            <div className="text-center flex-1 min-w-0">
              <h2 className={`text-sm sm:text-xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'} truncate`}>
                {format(currentWeekStart, 'MMM d')} - {format(addDays(currentWeekStart, 6), 'MMM d, yyyy')}
              </h2>
              <Button variant="link" onClick={goToCurrentWeek} className="text-xs sm:text-sm">
                Today
              </Button>
            </div>
            <Button variant="outline" size="sm" onClick={goToNextWeek} className="shrink-0">
              Next →
            </Button>
          </div> :

        <div className="flex justify-between items-center gap-2 mb-6">
            <Button variant="outline" size="sm" onClick={goToPreviousDay} className="shrink-0">
              ← Prev
            </Button>
            <div className="text-center flex-1 min-w-0">
              <h2 className={`text-sm sm:text-xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'} truncate`}>
                {format(currentDay, 'EEEE, MMMM d, yyyy')}
              </h2>
              <Button variant="link" onClick={goToToday} className="text-xs sm:text-sm">
                Today
              </Button>
            </div>
            <Button variant="outline" size="sm" onClick={goToNextDay} className="shrink-0">
              Next →
            </Button>
          </div>
        }

        {/* Schedule View */}
        {isLoading ?
        <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
          </div> :
        viewMode === "week" ? (
        <>
          {/* Week Total Hours */}
          <div className={`rounded-lg shadow-sm border p-4 mb-4 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center">
              <h3 className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                Total Week Hours
              </h3>
              <div className={`text-2xl font-bold ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                {getWeekTotalHours().toFixed(1)} hrs
              </div>
            </div>
          </div>
        <div className="overflow-x-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4 min-w-max lg:min-w-0">
            {weekDays.map((day, index) => {
            const daySchedules = getSchedulesForDay(day);
            const isToday = isSameDay(day, new Date());

            return (
              <Card key={index} className={`${isToday ? 'border-2 border-blue-500 shadow-lg' : 'border-slate-200'}`}>
                  <CardHeader className={`pb-3 ${isToday ? 'bg-blue-50' : 'bg-slate-50'}`}>
                    <CardTitle className="text-sm">
                      <div className="text-center">
                        <div className="font-semibold">{format(day, 'EEE')}</div>
                        <div className={`text-2xl font-bold ${isToday ? 'text-blue-600' : 'text-slate-900'}`}>
                          {format(day, 'd')}
                        </div>
                        <div className="text-xs text-slate-600">{format(day, 'MMM')}</div>
                        <div className="text-xs font-semibold text-blue-600 mt-1">
                          {getDayTotalHours(day).toFixed(1)} hrs
                        </div>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-3">
                    {daySchedules.length > 0 ?
                  <div className="space-y-2">
                        {daySchedules.map((schedule) =>
                    <div key={schedule.id} className="p-2 bg-blue-50 rounded-lg border border-blue-200">
                            <div className="flex items-start justify-between">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1 mb-1">
                                  <User className="w-3 h-3 text-slate-600 flex-shrink-0" />
                                  <button
                                    onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${schedule.user_email}`)}
                                    className="text-xs font-medium text-blue-600 hover:text-blue-800 underline truncate text-left"
                                  >
                                    {getUserName(schedule.user_email)}
                                  </button>
                                </div>
                                <div className="flex flex-wrap gap-1 mb-1">
                                  {schedule.role &&
                            <Badge variant="default" className="text-xs bg-blue-100 text-blue-800">
                                      {getPositionLabel(schedule.role)}
                                    </Badge>
                            }
                                  {getUserDepartment(schedule.user_email) &&
                            <Badge variant="outline" className="text-xs">
                                      {getUserDepartment(schedule.user_email).replace(/_/g, ' ')}
                                    </Badge>
                            }
                                </div>
                                <div className="flex items-center gap-1">
                                  <Clock className="w-3 h-3 text-slate-500 flex-shrink-0" />
                                  <p className="text-xs text-slate-600">
                                    {schedule.shift_start} - {schedule.shift_end}
                                  </p>
                                </div>
                                {schedule.notes &&
                          <p className="text-xs text-slate-500 mt-1 truncate">{schedule.notes}</p>
                          }
                              </div>
                              {canEdit &&
                        <div className="flex gap-1 ml-1">
                                  <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(schedule)}
                            className="h-6 w-6">

                                    <Edit className="w-3 h-3" />
                                  </Button>
                                  <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(schedule)}
                            className="h-6 w-6 text-red-600 hover:text-red-700 hover:bg-red-50">

                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </div>
                        }
                            </div>
                          </div>
                    )}
                      </div> :

                  <div className="text-center py-6 text-slate-400 text-xs">
                        No schedules
                      </div>
                  }
                  </CardContent>
                </Card>);

          })}
          </div>
        </div>
        </>) :

        <div className="max-w-4xl mx-auto">
            {/* Day Total Hours */}
            <div className={`rounded-lg shadow-sm border p-4 mb-4 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex justify-between items-center">
                <h3 className={`font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Total Day Hours
                </h3>
                <div className={`text-2xl font-bold ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                  {getDayTotalHours(currentDay).toFixed(1)} hrs
                </div>
              </div>
            </div>
            <Card>
              <CardHeader className="bg-blue-50 border-b">
                <CardTitle className="text-center">
                  {format(currentDay, 'EEEE, MMMM d, yyyy')}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {getSchedulesForDay(currentDay).length > 0 ?
              <div className="space-y-4">
                    {getSchedulesForDay(currentDay).map((schedule) =>
                <Card key={schedule.id} className="border-blue-200 bg-blue-50">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <User className="w-5 h-5 text-slate-600" />
                                <button
                                  onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${schedule.user_email}`)}
                                  className="text-lg font-semibold text-blue-600 hover:text-blue-800 underline"
                                >
                                  {getUserName(schedule.user_email)}
                                </button>
                              </div>
                              <div className="space-y-2 ml-7">
                                <div className="flex items-center gap-2 flex-wrap">
                                  {schedule.role &&
                            <Badge variant="default" className="bg-blue-100 text-blue-800">
                                      {getPositionLabel(schedule.role)}
                                    </Badge>
                            }
                                  {getUserDepartment(schedule.user_email) &&
                            <Badge variant="outline">
                                      {getUserDepartment(schedule.user_email).replace(/_/g, ' ')}
                                    </Badge>
                            }
                                  {getUserPosition(schedule.user_email) &&
                            <Badge variant="outline" className="bg-white">
                                      Primary: {getPositionLabel(getUserPosition(schedule.user_email))}
                                    </Badge>
                            }
                                </div>
                                <div className="flex items-center gap-2">
                                  <Clock className="w-4 h-4 text-slate-500" />
                                  <p className="text-sm text-slate-700 font-medium">
                                    {schedule.shift_start} - {schedule.shift_end}
                                  </p>
                                </div>
                                {schedule.notes &&
                          <p className="text-sm text-slate-600 bg-white p-2 rounded border border-slate-200">
                                    {schedule.notes}
                                  </p>
                          }
                                {getLocationName(schedule.bowling_alley_id) &&
                          <p className="text-xs text-slate-500">
                                    📍 {getLocationName(schedule.bowling_alley_id)}
                                  </p>
                          }
                              </div>
                            </div>
                            {canEdit &&
                      <div className="flex gap-2">
                                <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(schedule)}>

                                  <Edit className="w-4 h-4 mr-1" />
                                  Edit
                                </Button>
                                <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(schedule)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50">

                                  <Trash2 className="w-4 h-4 mr-1" />
                                  Delete
                                </Button>
                              </div>
                      }
                          </div>
                        </CardContent>
                      </Card>
                )}
                  </div> :

              <div className="text-center py-12">
                    <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No Schedules</h3>
                    <p className="text-slate-600">No shifts scheduled for this day</p>
                  </div>
              }
              </CardContent>
            </Card>
          </div>
        }
        </>
        )}

        {/* Time Off Requests Tab */}
        {activeTab === "timeoff" && (
          <>
            {/* Filters */}
            <div className={`rounded-lg shadow-sm border p-4 mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search by name or reason..."
                    value={timeOffSearchQuery}
                    onChange={(e) => setTimeOffSearchQuery(e.target.value)}
                    className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
                  />
                </div>
              </div>
              <div className="overflow-x-auto mt-4">
                <Tabs value={timeOffStatusFilter} onValueChange={setTimeOffStatusFilter}>
                  <TabsList className="grid grid-cols-4 w-full min-w-max sm:min-w-0">
                  <TabsTrigger value="all">All ({timeOffStatusCounts.all})</TabsTrigger>
                  <TabsTrigger value="pending">Pending ({timeOffStatusCounts.pending})</TabsTrigger>
                  <TabsTrigger value="approved">Approved ({timeOffStatusCounts.approved})</TabsTrigger>
                  <TabsTrigger value="denied">Denied ({timeOffStatusCounts.denied})</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>

            {/* Requests List */}
            {filteredTimeOffRequests.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {filteredTimeOffRequests.map(request => (
                  <Card key={request.id} className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <User className="w-5 h-5 text-slate-400" />
                            <button
                              onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${request.user_email}`)}
                              className={`text-lg font-semibold hover:underline ${isDarkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'}`}
                            >
                              {getUserName(request.user_email)}
                            </button>
                            <Badge className={timeOffStatusConfig[request.status]?.color}>
                              {timeOffStatusConfig[request.status]?.label}
                            </Badge>
                          </div>
                          
                          <div className={`space-y-2 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-slate-400" />
                              <span className="font-medium">
                                {format(new Date(request.start_date), 'MMM d, yyyy')} - {format(new Date(request.end_date), 'MMM d, yyyy')}
                              </span>
                            </div>
                            
                            <div>
                              <Label className="text-xs text-slate-500">Reason:</Label>
                              <p className="text-sm mt-1">{request.reason}</p>
                            </div>

                            {request.notes && (
                              <div>
                                <Label className="text-xs text-slate-500">Manager Notes:</Label>
                                <p className="text-sm mt-1 italic">{request.notes}</p>
                              </div>
                            )}

                            {request.reviewed_by && (
                              <p className="text-xs text-slate-500">
                                Reviewed by {getUserName(request.reviewed_by)} on {format(new Date(request.reviewed_date), 'MMM d, yyyy')}
                              </p>
                            )}

                            <p className="text-xs text-slate-500">
                              Requested on {format(new Date(request.created_date), 'MMM d, yyyy h:mm a')}
                            </p>
                          </div>
                        </div>

                        {canApprove && request.status === 'pending' && (
                          <div className="flex md:flex-col gap-2">
                            <Button
                              onClick={() => { setSelectedTimeOffRequest(request); setReviewTimeOffDialogOpen(true); }}
                              className="flex-1 bg-green-600 hover:bg-green-700"
                            >
                              <Check className="w-4 h-4 mr-2" />
                              Approve
                            </Button>
                            <Button
                              onClick={() => { setSelectedTimeOffRequest(request); setReviewTimeOffDialogOpen(true); }}
                              variant="outline"
                              className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <X className="w-4 h-4 mr-2" />
                              Deny
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                <CardContent className="p-12 text-center">
                  <CalendarX className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                  <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    No requests found
                  </h3>
                  <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                    {timeOffSearchQuery || timeOffStatusFilter !== 'all' 
                      ? 'Try adjusting your filters' 
                      : 'No time off requests yet'}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Review Time Off Dialog */}
            <Dialog open={reviewTimeOffDialogOpen} onOpenChange={setReviewTimeOffDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Review Time Off Request</DialogTitle>
                </DialogHeader>
                {selectedTimeOffRequest && (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-semibold">Requester</Label>
                      <p className="text-sm">{getUserName(selectedTimeOffRequest.user_email)}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Dates</Label>
                      <p className="text-sm">
                        {format(new Date(selectedTimeOffRequest.start_date), 'MMM d, yyyy')} - {format(new Date(selectedTimeOffRequest.end_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Reason</Label>
                      <p className="text-sm">{selectedTimeOffRequest.reason}</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="timeoff_review_notes">Manager Notes (Optional)</Label>
                      <Textarea
                        id="timeoff_review_notes"
                        value={timeOffReviewNotes}
                        onChange={(e) => setTimeOffReviewNotes(e.target.value)}
                        placeholder="Add notes about your decision..."
                        rows={3}
                      />
                    </div>
                    <div className="flex gap-3 pt-4">
                      <Button
                        onClick={() => submitTimeOffReview('approved')}
                        disabled={updateTimeOffMutation.isPending}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        <Check className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => submitTimeOffReview('denied')}
                        disabled={updateTimeOffMutation.isPending}
                        variant="outline"
                        className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Deny
                      </Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </>
        )}

        {/* Shift Trades Tab */}
        {activeTab === "trades" && (
          <>
            {/* Filters */}
            <div className={`rounded-lg shadow-sm border p-4 mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search by name or reason..."
                    value={tradeSearchQuery}
                    onChange={(e) => setTradeSearchQuery(e.target.value)}
                    className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}
                  />
                </div>
              </div>
              <div className="overflow-x-auto mt-4">
                <Tabs value={tradeStatusFilter} onValueChange={setTradeStatusFilter}>
                  <TabsList className="grid grid-cols-5 w-full min-w-max sm:min-w-0">
                  <TabsTrigger value="all">All ({tradeStatusCounts.all})</TabsTrigger>
                  <TabsTrigger value="pending">Pending ({tradeStatusCounts.pending})</TabsTrigger>
                  <TabsTrigger value="accepted">Awaiting ({tradeStatusCounts.accepted})</TabsTrigger>
                  <TabsTrigger value="approved">Approved ({tradeStatusCounts.approved})</TabsTrigger>
                  <TabsTrigger value="declined">Declined ({tradeStatusCounts.declined})</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>

            {/* Requests List */}
            {filteredTradeRequests.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {filteredTradeRequests.map(request => {
                  const requesterSchedule = getScheduleDetails(request.requester_schedule_id);
                  const targetSchedule = request.target_schedule_id ? getScheduleDetails(request.target_schedule_id) : null;
                  const isTargetUser = user && request.target_email === user.email;
                  
                  return (
                    <Card key={request.id} className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                      <CardContent className="p-6">
                        <div className="flex flex-col gap-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <ArrowLeftRight className="w-5 h-5 text-blue-500" />
                              <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                                {getUserName(request.requester_email)} 
                                {request.target_email ? ` ↔ ${getUserName(request.target_email)}` : ' (Open Trade)'}
                              </h3>
                            </div>
                            <Badge className={tradeStatusConfig[request.status]?.color}>
                              {tradeStatusConfig[request.status]?.label}
                            </Badge>
                          </div>

                          <div className="grid md:grid-cols-2 gap-4">
                            {requesterSchedule && (
                              <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-blue-50'} border border-blue-200`}>
                                <Label className="text-xs text-slate-500 mb-2 block">Requesting to Trade</Label>
                                <div className={`space-y-1 text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                  <div className="flex items-center gap-2">
                                    <Calendar className="w-4 h-4 text-slate-400" />
                                    <span>{format(new Date(requesterSchedule.date.split('T')[0]), 'MMM d, yyyy')}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4 text-slate-400" />
                                    <span>{requesterSchedule.shift_start} - {requesterSchedule.shift_end}</span>
                                  </div>
                                </div>
                              </div>
                            )}

                            {targetSchedule && (
                              <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-green-50'} border border-green-200`}>
                                <Label className="text-xs text-slate-500 mb-2 block">In Exchange For</Label>
                                <div className={`space-y-1 text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                                  <div className="flex items-center gap-2">
                                    <Calendar className="w-4 h-4 text-slate-400" />
                                    <span>{format(new Date(targetSchedule.date.split('T')[0]), 'MMM d, yyyy')}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4 text-slate-400" />
                                    <span>{targetSchedule.shift_start} - {targetSchedule.shift_end}</span>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>

                          <div>
                            <Label className="text-xs text-slate-500">Reason:</Label>
                            <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{request.reason}</p>
                          </div>

                          {request.notes && (
                            <div>
                              <Label className="text-xs text-slate-500">Manager Notes:</Label>
                              <p className="text-sm mt-1 italic">{request.notes}</p>
                            </div>
                          )}

                          <p className="text-xs text-slate-500">
                            Requested on {format(new Date(request.created_date), 'MMM d, yyyy h:mm a')}
                          </p>

                          {/* Action Buttons */}
                          <div className="flex gap-2 pt-2">
                            {isTargetUser && request.status === 'pending' && (
                              <>
                                <Button
                                  onClick={() => handleTradeAccept(request)}
                                  disabled={updateTradeMutation.isPending}
                                  className="flex-1 bg-green-600 hover:bg-green-700"
                                >
                                  <Check className="w-4 h-4 mr-2" />
                                  Accept Trade
                                </Button>
                                <Button
                                  onClick={() => handleTradeDecline(request)}
                                  disabled={updateTradeMutation.isPending}
                                  variant="outline"
                                  className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                                >
                                  <X className="w-4 h-4 mr-2" />
                                  Decline
                                </Button>
                              </>
                            )}

                            {canApprove && request.status === 'accepted' && (
                              <>
                                <Button
                                  onClick={() => { setSelectedTradeRequest(request); setReviewTradeDialogOpen(true); }}
                                  className="flex-1 bg-green-600 hover:bg-green-700"
                                >
                                  <Check className="w-4 h-4 mr-2" />
                                  Approve Trade
                                </Button>
                                <Button
                                  onClick={() => { setSelectedTradeRequest(request); setReviewTradeDialogOpen(true); }}
                                  variant="outline"
                                  className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                                >
                                  <X className="w-4 h-4 mr-2" />
                                  Reject Trade
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                <CardContent className="p-12 text-center">
                  <ArrowLeftRight className={`w-12 h-12 mx-auto mb-4 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
                  <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    No trade requests found
                  </h3>
                  <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                    {tradeSearchQuery || tradeStatusFilter !== 'all' 
                      ? 'Try adjusting your filters' 
                      : 'No shift trade requests yet'}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Review Trade Dialog */}
            <Dialog open={reviewTradeDialogOpen} onOpenChange={setReviewTradeDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Review Shift Trade</DialogTitle>
                </DialogHeader>
                {selectedTradeRequest && (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-semibold">Trade Between</Label>
                      <p className="text-sm">
                        {getUserName(selectedTradeRequest.requester_email)} ↔ {selectedTradeRequest.target_email ? getUserName(selectedTradeRequest.target_email) : 'Open'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Reason</Label>
                      <p className="text-sm">{selectedTradeRequest.reason}</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="trade_review_notes">Manager Notes (Optional)</Label>
                      <Textarea
                        id="trade_review_notes"
                        value={tradeReviewNotes}
                        onChange={(e) => setTradeReviewNotes(e.target.value)}
                        placeholder="Add notes about your decision..."
                        rows={3}
                      />
                    </div>
                    <div className="flex gap-3 pt-4">
                      <Button
                        onClick={() => submitTradeReview('approved')}
                        disabled={updateTradeMutation.isPending}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        <Check className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => submitTradeReview('rejected')}
                        disabled={updateTradeMutation.isPending}
                        variant="outline"
                        className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </>
        )}

        {/* Recurring Schedules Tab */}
        {activeTab === "recurring" && canEdit && (
          <RecurringScheduleManager
            users={users}
            locations={locations}
            effectiveLocationId={effectiveLocationId}
            canEdit={canEdit}
            getAvailableRoles={getAvailableRoles}
            getPositionLabel={getPositionLabel}
            isDarkMode={isDarkMode}
          />
        )}

        {/* Availability Tab */}
        {activeTab === "availability" && user && (
          <AvailabilityManager
            user={user}
            isDarkMode={isDarkMode}
          />
        )}
      </div>
    </div>);

}