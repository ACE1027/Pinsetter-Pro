import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Calendar, Plus, Edit, Trash2, CheckCircle2, Clock, AlertCircle, History, Repeat, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useLocation } from "../components/LocationContext";
import { useTheme } from "../components/ThemeContext";
import { useRecurringScheduleProcessor } from "@/components/maintenance/RecurringScheduleProcessor";
import { ExportMenu } from "@/components/ExportMenu";

export default function ScheduledMaintenance() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState(null);
  const [activeTab, setActiveTab] = useState("upcoming");
  const { selectedLocationId } = useLocation();
  const [recurringDialogOpen, setRecurringDialogOpen] = useState(false);
  const [recurringFormData, setRecurringFormData] = useState({
    bowling_alley_id: "",
    name: "",
    maintenance_type: "",
    lane_number: "",
    machine_type: "",
    recurrence_pattern: "monthly",
    assigned_to: "",
    description: "",
    auto_generate_logs: true,
    active: true
  });
  const [formData, setFormData] = useState({
    bowling_alley_id: "",
    lane_number: "",
    machine_type: "",
    maintenance_type: "",
    scheduled_date: "",
    due_date: "",
    description: "",
    status: "scheduled",
    assigned_to: ""
  });

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u.bowling_alley_id) {
        setFormData(prev => ({ ...prev, bowling_alley_id: u.bowling_alley_id }));
      }
    }).catch(() => {});
  }, []);

  const { data: schedules = [], isLoading } = useQuery({
    queryKey: ['scheduledMaintenance'],
    queryFn: () => base44.entities.ScheduledMaintenance.list('-scheduled_date'),
    initialData: [],
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const { data: recurringSchedules = [] } = useQuery({
    queryKey: ['recurringMaintenanceSchedules'],
    queryFn: () => base44.entities.RecurringMaintenanceSchedule.list(),
    initialData: []
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ScheduledMaintenance.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledMaintenance'] });
      resetForm();
      toast.success("Maintenance scheduled successfully");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ScheduledMaintenance.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledMaintenance'] });
      resetForm();
      toast.success("Schedule updated successfully");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ScheduledMaintenance.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledMaintenance'] });
      toast.success("Schedule deleted successfully");
    },
  });

  const createRecurringMutation = useMutation({
    mutationFn: (data) => base44.entities.RecurringMaintenanceSchedule.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringMaintenanceSchedules'] });
      setRecurringDialogOpen(false);
      setRecurringFormData({
        bowling_alley_id: user?.bowling_alley_id || "",
        name: "",
        maintenance_type: "",
        lane_number: "",
        machine_type: "",
        recurrence_pattern: "monthly",
        assigned_to: "",
        description: "",
        auto_generate_logs: true,
        active: true
      });
      toast.success("Recurring schedule created");
    }
  });

  const deleteRecurringMutation = useMutation({
    mutationFn: (id) => base44.entities.RecurringMaintenanceSchedule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurringMaintenanceSchedules'] });
      toast.success("Recurring schedule deleted");
    }
  });

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  const canEdit = isAdmin || isManager;

  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  // Process recurring schedules
  const { processRecurringSchedules } = useRecurringScheduleProcessor(effectiveLocationId);

  const accessibleSchedules = schedules.filter(schedule => {
    if (!user) return false;
    if (isAdmin) return true;
    return schedule.bowling_alley_id === user.bowling_alley_id;
  });

  const upcomingSchedules = accessibleSchedules.filter(s => s.status !== 'completed');
  const completedSchedules = accessibleSchedules.filter(s => s.status === 'completed');

  // Group completed schedules by lane
  const schedulesByLane = completedSchedules.reduce((acc, schedule) => {
    const lane = schedule.lane_number || 'No Lane Specified';
    if (!acc[lane]) {
      acc[lane] = [];
    }
    acc[lane].push(schedule);
    return acc;
  }, {});

  const sortedLanes = Object.keys(schedulesByLane).sort((a, b) => {
    if (a === 'No Lane Specified') return 1;
    if (b === 'No Lane Specified') return -1;
    return parseInt(a) - parseInt(b);
  });

  const resetForm = () => {
    setDialogOpen(false);
    setEditingSchedule(null);
    setFormData({
      bowling_alley_id: user?.bowling_alley_id || "",
      lane_number: "",
      machine_type: "",
      maintenance_type: "",
      scheduled_date: "",
      due_date: "",
      description: "",
      status: "scheduled",
      assigned_to: ""
    });
  };

  const handleEdit = (schedule) => {
    setEditingSchedule(schedule);
    setFormData({
      bowling_alley_id: schedule.bowling_alley_id || "",
      lane_number: schedule.lane_number || "",
      machine_type: schedule.machine_type || "",
      maintenance_type: schedule.maintenance_type || "",
      scheduled_date: schedule.scheduled_date ? schedule.scheduled_date.split('T')[0] : "",
      due_date: schedule.due_date ? schedule.due_date.split('T')[0] : "",
      description: schedule.description || "",
      status: schedule.status || "scheduled",
      assigned_to: schedule.assigned_to || ""
    });
    setDialogOpen(true);
  };

  const handleDelete = (schedule) => {
    if (window.confirm(`Are you sure you want to delete this scheduled maintenance?`)) {
      deleteMutation.mutate(schedule.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const deviceTimestamp = new Date().toISOString();
    
    // Fix timezone issue by setting time to noon local time
    const scheduledDate = formData.scheduled_date 
      ? new Date(formData.scheduled_date + 'T12:00:00').toISOString()
      : formData.scheduled_date;
    
    const dueDate = formData.due_date 
      ? new Date(formData.due_date + 'T12:00:00').toISOString()
      : null;
    
    const dataToSubmit = {
      ...formData,
      scheduled_date: scheduledDate,
      due_date: dueDate
    };
    
    if (editingSchedule) {
      updateMutation.mutate({ id: editingSchedule.id, data: dataToSubmit });
    } else {
      createMutation.mutate({ ...dataToSubmit, device_timestamp: deviceTimestamp });
    }
  };

  const getStatusBadge = (status) => {
    const config = {
      scheduled: { color: "bg-blue-100 text-blue-800", icon: Clock, label: "Scheduled" },
      completed: { color: "bg-green-100 text-green-800", icon: CheckCircle2, label: "Completed" },
      overdue: { color: "bg-red-100 text-red-800", icon: AlertCircle, label: "Overdue" },
    };
    const { color, icon: Icon, label } = config[status] || config.scheduled;
    return (
      <Badge className={color}>
        <Icon className="w-3 h-3 mr-1" />
        {label}
      </Badge>
    );
  };

  const getLocationName = (locationId) => {
    const location = locations.find(l => l.id === locationId);
    return location?.name || 'Unknown Location';
  };

  const locationRecurringSchedules = recurringSchedules.filter(s => 
    s.bowling_alley_id === effectiveLocationId && s.active
  );

  const assignableUsers = allUsers.filter((u) =>
    (u.department === 'mechanic' || u.department === 'manager' || u.role === 'admin') &&
    (u.bowling_alley_id === formData.bowling_alley_id || u.role === 'admin')
  );

  const recurringAssignableUsers = allUsers.filter((u) =>
    (u.department === 'mechanic' || u.department === 'manager' || u.role === 'admin') &&
    (u.bowling_alley_id === recurringFormData.bowling_alley_id || u.role === 'admin')
  );

  const handleRecurringSubmit = (e) => {
    e.preventDefault();
    createRecurringMutation.mutate(recurringFormData);
  };

  const handleDeleteRecurring = (scheduleId) => {
    if (window.confirm('Delete this recurring schedule?')) {
      deleteRecurringMutation.mutate(scheduleId);
    }
  };

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Scheduled Machine Maintenance</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Plan and track upcoming maintenance tasks</p>
          </div>
          {canEdit && (
            <div className="flex flex-wrap gap-2">
              <ExportMenu 
                data={activeTab === 'upcoming' ? upcomingSchedules : completedSchedules}
                columns={[
                  { header: 'Maintenance Type', key: 'maintenance_type' },
                  { header: 'Lane', key: 'lane_number' },
                  { header: 'Machine', key: 'machine_type' },
                  { header: 'Date', key: 'scheduled_date' },
                  { header: 'Status', key: 'status' },
                  { header: 'Assigned To', key: 'assigned_to' },
                  { header: 'Description', key: 'description' }
                ]}
                filename={`scheduled-maintenance-${activeTab}`}
                title={`Scheduled Maintenance - ${activeTab}`}
              />
              <Button
                variant="outline"
                onClick={() => {
                  processRecurringSchedules();
                  toast.success("Recurring schedules processed");
                }}
                className="border-green-600 text-green-600 hover:bg-green-50"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Recurring
              </Button>
              <Dialog open={recurringDialogOpen} onOpenChange={setRecurringDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="border-purple-600 text-purple-600 hover:bg-purple-50">
                    <Repeat className="w-4 h-4 mr-2" />
                    Recurring
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Create Recurring Maintenance Schedule</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleRecurringSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="rec_name">Schedule Name *</Label>
                      <Input
                        id="rec_name"
                        value={recurringFormData.name}
                        onChange={(e) => setRecurringFormData(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="e.g., Monthly Lane Oil Check"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="rec_location">Location *</Label>
                      <Select 
                        value={recurringFormData.bowling_alley_id} 
                        onValueChange={(value) => setRecurringFormData(prev => ({ ...prev, bowling_alley_id: value }))}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select location" />
                        </SelectTrigger>
                        <SelectContent>
                          {locations.filter(l => l.active !== false).map(location => (
                            <SelectItem key={location.id} value={location.id}>
                              {location.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="rec_maintenance_type">Maintenance Type *</Label>
                        <Input
                          id="rec_maintenance_type"
                          value={recurringFormData.maintenance_type}
                          onChange={(e) => setRecurringFormData(prev => ({ ...prev, maintenance_type: e.target.value }))}
                          placeholder="e.g., Oil Change"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rec_pattern">Recurrence *</Label>
                        <Select 
                          value={recurringFormData.recurrence_pattern} 
                          onValueChange={(value) => setRecurringFormData(prev => ({ ...prev, recurrence_pattern: value }))}
                          required
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="quarterly">Quarterly</SelectItem>
                            <SelectItem value="yearly">Yearly</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="rec_lane">Lane Number</Label>
                        <Select
                          value={recurringFormData.lane_number}
                          onValueChange={(value) => setRecurringFormData(prev => ({ ...prev, lane_number: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Optional" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value={null}>N/A</SelectItem>
                            {locations.find(l => l.id === recurringFormData.bowling_alley_id)?.total_lanes > 0 &&
                              Array.from({ length: locations.find(l => l.id === recurringFormData.bowling_alley_id).total_lanes }, (_, i) => (i + 1).toString()).map((lane) => (
                                <SelectItem key={lane} value={lane}>
                                  Lane {lane}
                                </SelectItem>
                              ))
                            }
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rec_machine">Machine Type</Label>
                        <Select
                          value={recurringFormData.machine_type}
                          onValueChange={(value) => setRecurringFormData(prev => ({ ...prev, machine_type: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Optional" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value={null}>None</SelectItem>
                            <SelectItem value="Original A Pinsetter">Original A Pinsetter</SelectItem>
                            <SelectItem value="A-2 Pinsetter">A-2 Pinsetter</SelectItem>
                            <SelectItem value="Jetback Pinsetter">Jetback Pinsetter</SelectItem>
                            <SelectItem value="String Pin Boost XT">String Pin Boost XT</SelectItem>
                            <SelectItem value="GS-X Machine">GS-X Machine</SelectItem>
                            <SelectItem value="Brunswick GSX NXT">Brunswick GSX NXT</SelectItem>
                            <SelectItem value="82-30">82-30</SelectItem>
                            <SelectItem value="82-70 Pinspotter">82-70 Pinspotter</SelectItem>
                            <SelectItem value="82-90 Pinspotter">82-90 Pinspotter</SelectItem>
                            <SelectItem value="90XLI Pinspotter">90XLI Pinspotter</SelectItem>
                            <SelectItem value="Qubica AMF XLI Edge">Qubica AMF XLI Edge</SelectItem>
                            <SelectItem value="EDGE Free Fall Pinspotter">EDGE Free Fall Pinspotter</SelectItem>
                            <SelectItem value="EDGE String Pin Pinspotter">EDGE String Pin Pinspotter</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="rec_assigned">Assign To</Label>
                      <Select
                        value={recurringFormData.assigned_to}
                        onValueChange={(value) => setRecurringFormData(prev => ({ ...prev, assigned_to: value }))}
                        disabled={!recurringFormData.bowling_alley_id}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Unassigned" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>Unassigned</SelectItem>
                          {recurringAssignableUsers.map(u => (
                            <SelectItem key={u.id} value={u.email}>
                              {u.full_name || u.email}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="rec_description">Description</Label>
                      <Textarea
                        id="rec_description"
                        value={recurringFormData.description}
                        onChange={(e) => setRecurringFormData(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Details about the recurring maintenance..."
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button type="button" variant="outline" onClick={() => setRecurringDialogOpen(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createRecurringMutation.isPending} className="flex-1 bg-purple-600 hover:bg-purple-700">
                        Create Schedule
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>

              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" onClick={() => resetForm()}>
                  <Plus className="w-4 h-4 mr-2" />
                  Schedule Maintenance
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingSchedule ? "Edit Scheduled Maintenance" : "Schedule New Maintenance"}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bowling_alley_id">Location *</Label>
                    <Select 
                      value={formData.bowling_alley_id} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, bowling_alley_id: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.filter(l => l.active !== false).map(location => (
                          <SelectItem key={location.id} value={location.id}>
                            {location.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lane_number">Lane Number</Label>
                      <Input
                        id="lane_number"
                        value={formData.lane_number}
                        onChange={(e) => setFormData(prev => ({ ...prev, lane_number: e.target.value }))}
                        placeholder="e.g., 12"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="machine_type">Machine Type</Label>
                      <Select 
                        value={formData.machine_type} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, machine_type: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select machine type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Original A Pinsetter">Original A Pinsetter</SelectItem>
                          <SelectItem value="A-2 Pinsetter">A-2 Pinsetter</SelectItem>
                          <SelectItem value="Jetback Pinsetter">Jetback Pinsetter</SelectItem>
                          <SelectItem value="String Pin Boost XT">String Pin Boost XT</SelectItem>
                          <SelectItem value="GS-X Machine">GS-X Machine</SelectItem>
                          <SelectItem value="Brunswick GSX NXT">Brunswick GSX NXT</SelectItem>
                          <SelectItem value="82-30">82-30</SelectItem>
                          <SelectItem value="82-70 Pinspotter">82-70 Pinspotter</SelectItem>
                          <SelectItem value="82-90 Pinspotter">82-90 Pinspotter</SelectItem>
                          <SelectItem value="90XLI Pinspotter">90XLI Pinspotter</SelectItem>
                          <SelectItem value="Qubica AMF XLI Edge">Qubica AMF XLI Edge</SelectItem>
                          <SelectItem value="EDGE Free Fall Pinspotter">EDGE Free Fall Pinspotter</SelectItem>
                          <SelectItem value="EDGE String Pin Pinspotter">EDGE String Pin Pinspotter</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maintenance_type">Maintenance Type *</Label>
                    <Select 
                      value={formData.maintenance_type} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, maintenance_type: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select maintenance type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Belt Replacement">Belt Replacement</SelectItem>
                        <SelectItem value="Oil Change">Oil Change</SelectItem>
                        <SelectItem value="Pin Replacement">Pin Replacement</SelectItem>
                        <SelectItem value="Cushion Replacement">Cushion Replacement</SelectItem>
                        <SelectItem value="Motor Maintenance">Motor Maintenance</SelectItem>
                        <SelectItem value="Detector Calibration">Detector Calibration</SelectItem>
                        <SelectItem value="Sweep Adjustment">Sweep Adjustment</SelectItem>
                        <SelectItem value="Turret Inspection">Turret Inspection</SelectItem>
                        <SelectItem value="Deck Maintenance">Deck Maintenance</SelectItem>
                        <SelectItem value="Electrical Inspection">Electrical Inspection</SelectItem>
                        <SelectItem value="Full Machine Inspection">Full Machine Inspection</SelectItem>
                        <SelectItem value="Lane Surface Maintenance">Lane Surface Maintenance</SelectItem>
                        <SelectItem value="Ball Return Maintenance">Ball Return Maintenance</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="scheduled_date">Scheduled Date *</Label>
                      <Input
                        id="scheduled_date"
                        type="date"
                        value={formData.scheduled_date}
                        onChange={(e) => setFormData(prev => ({ ...prev, scheduled_date: e.target.value }))}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="due_date">Due Date</Label>
                      <Input
                        id="due_date"
                        type="date"
                        value={formData.due_date || ''}
                        onChange={(e) => setFormData(prev => ({ ...prev, due_date: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="assigned_to">Assign To</Label>
                    <Select
                      value={formData.assigned_to}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, assigned_to: value }))}
                      disabled={!formData.bowling_alley_id}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Unassigned" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>Unassigned</SelectItem>
                        {assignableUsers.map(u => (
                          <SelectItem key={u.id} value={u.email}>
                            {u.full_name || u.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Additional details about the maintenance..."
                      rows={4}
                    />
                  </div>

                  {editingSchedule && (
                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Select 
                        value={formData.status} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="scheduled">Scheduled</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="overdue">Overdue</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createMutation.isPending || updateMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      {editingSchedule ? "Update Schedule" : "Schedule Maintenance"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
            </div>
          )}
        </div>

        {locationRecurringSchedules.length > 0 && (
          <Card className={`shadow-lg mb-6 ${isDarkMode ? 'bg-purple-900/20 border-purple-800' : 'bg-purple-50 border-purple-300'}`}>
            <CardHeader>
              <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-purple-400' : 'text-purple-900'}`}>
                <Repeat className="w-5 h-5" />
                Recurring Schedules
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {locationRecurringSchedules.map(schedule => (
                  <div key={schedule.id} className={`flex justify-between items-start p-3 rounded-lg ${isDarkMode ? 'bg-slate-900' : 'bg-white'} border`}>
                    <div className="flex-1">
                      <p className={`font-medium ${isDarkMode ? 'text-slate-100' : ''}`}>{schedule.name}</p>
                      <p className="text-sm text-slate-500 mt-1">
                        {schedule.maintenance_type} • {schedule.recurrence_pattern}
                        {schedule.lane_number && ` • Lane ${schedule.lane_number}`}
                        {schedule.assigned_to && ` • Assigned to ${schedule.assigned_to}`}
                      </p>
                    </div>
                    {canEdit && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteRecurring(schedule.id)}
                        className="h-8 w-8 text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="upcoming">
              Upcoming ({upcomingSchedules.length})
            </TabsTrigger>
            <TabsTrigger value="history">
              <History className="w-4 h-4 mr-2" />
              History by Lane ({completedSchedules.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
              </div>
            ) : upcomingSchedules.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {upcomingSchedules.map(schedule => (
              <Card key={schedule.id} className="shadow-lg border-slate-200 hover:shadow-xl transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{schedule.maintenance_type}</CardTitle>
                      <p className="text-sm text-slate-600 mt-1">
                        {getLocationName(schedule.bowling_alley_id)}
                        {schedule.lane_number && ` - Lane ${schedule.lane_number}`}
                      </p>
                    </div>
                    {getStatusBadge(schedule.status)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span className="font-medium">
                      {format(new Date(schedule.scheduled_date), "MMMM d, yyyy")}
                    </span>
                  </div>
                  {schedule.machine_type && (
                    <p className="text-sm text-slate-600">
                      <span className="font-medium">Machine:</span> {schedule.machine_type}
                    </p>
                  )}
                  {schedule.description && (
                    <p className="text-sm text-slate-700">{schedule.description}</p>
                  )}
                  {canEdit && (
                    <div className="flex gap-2 pt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(schedule)}
                        className="flex-1"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(schedule)}
                        className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        Delete
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
                ))}
              </div>
            ) : (
              <Card className="shadow-lg border-slate-200">
                <CardContent className="p-12 text-center">
                  <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No Upcoming Maintenance</h3>
                  <p className="text-slate-600">
                    {canEdit ? "Schedule your first maintenance task to get started" : "No maintenance tasks have been scheduled yet"}
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="history">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
              </div>
            ) : completedSchedules.length > 0 ? (
              <div className="space-y-6">
                {sortedLanes.map(lane => (
                  <Card key={lane} className="shadow-lg border-slate-200">
                    <CardHeader className="bg-slate-50 border-b">
                      <CardTitle className="text-xl">
                        {lane === 'No Lane Specified' ? 'General Maintenance' : `Lane ${lane}`}
                      </CardTitle>
                      <p className="text-sm text-slate-600">
                        {schedulesByLane[lane].length} completed maintenance {schedulesByLane[lane].length === 1 ? 'task' : 'tasks'}
                      </p>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {schedulesByLane[lane]
                          .sort((a, b) => new Date(b.scheduled_date) - new Date(a.scheduled_date))
                          .map(schedule => (
                            <div key={schedule.id} className="flex items-start gap-4 p-4 bg-green-50 rounded-lg border border-green-200">
                              <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                              <div className="flex-1">
                                <h4 className="font-semibold text-slate-900">{schedule.maintenance_type}</h4>
                                {schedule.machine_type && (
                                  <p className="text-sm text-slate-600 mt-1">
                                    <span className="font-medium">Machine:</span> {schedule.machine_type}
                                  </p>
                                )}
                                {schedule.description && (
                                  <p className="text-sm text-slate-700 mt-1">{schedule.description}</p>
                                )}
                                <div className="flex items-center gap-2 mt-2">
                                  <Calendar className="w-3 h-3 text-slate-400" />
                                  <span className="text-xs text-slate-500">
                                    {format(new Date(schedule.scheduled_date), "MMM d, yyyy")}
                                  </span>
                                  {schedule.updated_date && (
                                    <span className="text-xs text-slate-400">
                                      • Completed {format(new Date(schedule.updated_date), "MMM d, yyyy")}
                                    </span>
                                  )}
                                </div>
                              </div>
                              {canEdit && (
                                <div className="flex gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEdit(schedule)}
                                    className="h-8 w-8"
                                  >
                                    <Edit className="w-3 h-3" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDelete(schedule)}
                                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </div>
                              )}
                            </div>
                          ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="shadow-lg border-slate-200">
                <CardContent className="p-12 text-center">
                  <History className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No Maintenance History</h3>
                  <p className="text-slate-600">Complete maintenance tasks to build your history</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}