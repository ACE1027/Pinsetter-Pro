import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Send, Users, Mail } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "@/components/ThemeContext";

export default function SendUpdateNotification() {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [subject, setSubject] = useState("Pinsetter Pro Update");
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.role !== 'admin') {
        toast.error("Access denied - Admins only");
        navigate(-1);
      }
    }).catch(() => {});
  }, [navigate]);

  const { data: users = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const managementUsers = users.filter(u => 
    u.department === 'manager' || u.role === 'admin'
  );

  const handleSendNotifications = async () => {
    if (!subject.trim() || !message.trim()) {
      toast.error("Please provide both subject and message");
      return;
    }

    setIsSending(true);

    try {
      const emailPromises = managementUsers.map(recipient => 
        base44.integrations.Core.SendEmail({
          from_name: "Pinsetter Pro Updates",
          to: recipient.email,
          subject: subject,
          body: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #2563eb;">Program Update</h2>
              <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                ${message.split('\n').map(line => `<p style="margin: 10px 0;">${line}</p>`).join('')}
              </div>
              <p style="color: #64748b; font-size: 14px; margin-top: 20px;">
                This is an automated notification from Pinsetter Pro.
              </p>
            </div>
          `
        })
      );

      await Promise.all(emailPromises);

      await Promise.all(
        managementUsers.map(recipient =>
          base44.entities.Notification.create({
            user_email: recipient.email,
            type: 'system_update',
            title: subject,
            message: message,
            priority: 'high'
          })
        )
      );

      toast.success(`Notification sent to ${managementUsers.length} managers`);
      setSubject("Pinsetter Pro Update");
      setMessage("");
    } catch (error) {
      toast.error("Failed to send notifications: " + error.message);
    } finally {
      setIsSending(false);
    }
  };

  if (!user || user.role !== 'admin') {
    return null;
  }

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              Send Program Update
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Notify all managers and admins about program updates
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-300' : ''}>Compose Notification</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Update title..."
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe the update, new features, changes, or important information..."
                    rows={12}
                    className={isDarkMode ? 'bg-slate-800 border-slate-700' : ''}
                  />
                  <p className="text-xs text-slate-500">
                    This message will be sent via email and in-app notification
                  </p>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => navigate(-1)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSendNotifications}
                    disabled={isSending || !subject.trim() || !message.trim()}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {isSending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send to {managementUsers.length} Managers
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`text-sm ${isDarkMode ? 'text-slate-300' : ''}`}>Recipients</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-4">
                  <Users className="w-5 h-5 text-blue-500" />
                  <span className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {managementUsers.length}
                  </span>
                  <span className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    managers
                  </span>
                </div>
                <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-blue-50'}`}>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    Notification will be sent to all users with:
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Badge className="bg-blue-100 text-blue-800">Admin Role</Badge>
                    <Badge className="bg-purple-100 text-purple-800">Manager Department</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
              <CardHeader>
                <CardTitle className={`text-sm ${isDarkMode ? 'text-slate-300' : ''}`}>Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`p-3 rounded-lg border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span className={`text-sm font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-900'}`}>
                      {subject || "Subject"}
                    </span>
                  </div>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'} whitespace-pre-wrap`}>
                    {message || "Your message will appear here..."}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}