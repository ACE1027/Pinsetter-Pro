import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useOfflineSync } from "@/components/offline/OfflineManager";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger } from
"@/components/ui/dialog";
import { ArrowLeft, Save, User, Calendar, Plus, Trash2, Wrench, Building2, CheckCircle2, Edit, Tag } from "lucide-react";
import AttachmentUploader from "@/components/attachments/AttachmentUploader";
import AttachmentGallery from "@/components/attachments/AttachmentGallery";
import { format } from "date-fns";
import StatusBadge from "../components/service/StatusBadge";
import PriorityBadge from "../components/service/PriorityBadge";
import { toast } from "sonner";
import { useTheme } from "../components/ThemeContext";
import MobileServiceCallDetail from "../components/mobile/MobileServiceCallDetail";
import { playSound, SOUND_TYPES } from "@/components/sounds/SoundManager";

const BALL_CALL_LOCATIONS = [
{ value: "infront_pit_cushion", label: "Infront of Pit Cushion" },
{ value: "caught_side_cushion", label: "Caught on side of Cushion" },
{ value: "spinning_ball_wheel", label: "Spinning on Ball Wheel" },
{ value: "stuck_sbe", label: "Stuck on SBE" },
{ value: "bottom_corner_lift_rods", label: "Bottom corner of Lift Rods" },
{ value: "yoyo_lift_rods", label: "Yo-Yo on Lift Rods" },
{ value: "top_lift_rods", label: "Top of Lift Rods" },
{ value: "at_y_switch", label: "At the Y - Switch" },
{ value: "behind_ball_stop", label: "Behind Ball Stop" },
{ value: "in_accelerator", label: "In accelerator(Belt Off)" },
{ value: "pin_caught_with_ball", label: "Pin Caught With Ball" },
{ value: "pin_subway_power_lift", label: "Pin in Subway or Power Lift" },
{ value: "ball_in_pinwheel", label: "Ball in Pinwheel" },
{ value: "ghost_ball", label: "Ghost Ball" },
{ value: "other", label: "Other" }];


const ONE_EIGHTY_ISSUES = [
{ value: "elevator_pin_guide_jam", label: "Elevator Pin Guide Jam" },
{ value: "turn_pan_jam", label: "Turn Pan Jam" },
{ value: "pin_head_first", label: "Pin Head First" },
{ value: "pin_gate_locked", label: "Pin Gate Locked" },
{ value: "failed_to_index", label: "Failed To Index" },
{ value: "failed_to_index_after_5pin", label: "Failed To Index After 5-Pin" },
{ value: "turret_wire_jam", label: "Turret Wire Jam" },
{ value: "jam_on_top_of_deck", label: "Jam On Top Of Deck" },
{ value: "log_jam_pit_pinwheel", label: "Log Jam In Pit Or Pin Wheel" },
{ value: "other", label: "Other" }];


const DECK_JAMS_BLACKOUTS = [
{ value: "blackout_switch", label: "Blackout On/off Switch" },
{ value: "jam_in_deck_chute", label: "Jam In Deck Chute" },
{ value: "pins_in_top_of_deck", label: "Pins In Top Of Deck" },
{ value: "moving_deck_cable_off", label: "Moving Deck Cable off" },
{ value: "other", label: "Other" }];


const CON_CYCLES = [
{ value: "failed_to_trigger", label: "Failed To Trigger" },
{ value: "90_180_270_stops", label: "90/180//270 Stops" },
{ value: "banana_tree", label: "Banana Tree" },
{ value: "out_of_range", label: "Out of Range" },
{ value: "other", label: "Other" }];


const MISCELLANEOUS = [
{ value: "deadwood", label: "Deadwood" },
{ value: "other", label: "Other" }];


const PIN_NUMBERS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];

export default function ServiceCallDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const urlParams = new URLSearchParams(window.location.search);
  const callId = urlParams.get('id');

  const [notes, setNotes] = useState("");
  const [completionNotes, setCompletionNotes] = useState("");
  const [addPartDialogOpen, setAddPartDialogOpen] = useState(false);
  const [editDescriptionOpen, setEditDescriptionOpen] = useState(false);
  const { isOnline, queueUpdate } = useOfflineSync();
  const [descriptionFormData, setDescriptionFormData] = useState({
    description_category: "",
    ball_call_location: "",
    one_eighty_issue: "",
    deck_jam_issue: "",
    con_cycle_issue: "",
    respot_pins: [],
    misc_issue: "",
    additional_description: ""
  });
  const [partFormData, setPartFormData] = useState({
    part_id: "",
    quantity_used: 1,
    notes: ""
  });

  const positionHierarchy = [
  { value: "general_manager", label: "General Manager", level: 1 },
  { value: "service_manager", label: "Service Manager", level: 2 },
  { value: "assistant_manager", label: "Assistant Manager", level: 3 },
  { value: "senior_mechanic", label: "Senior Mechanic", level: 4 },
  { value: "lead_mechanic", label: "Lead Mechanic", level: 5 },
  { value: "mechanic", label: "Mechanic", level: 6 },
  { value: "mechanic_apprentice", label: "Mechanic Apprentice", level: 7 }];


  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const { data: call, isLoading } = useQuery({
    queryKey: ['serviceCall', callId],
    queryFn: async () => {
      const foundCall = await base44.entities.ServiceCall.get(callId);

      if (foundCall && user) {
        const isAdmin = user.role === 'admin';
        const isFromUserLocation = foundCall.bowling_alley_id === user.bowling_alley_id;

        if (!isAdmin && !isFromUserLocation) {
          toast.error("You don't have permission to view this service call");
          navigate(createPageUrl("ServiceCalls"));
          return null;
        }
      }

      return foundCall;
    },
    enabled: !!callId && !!user
  });

  const { data: bowlingAlley, isLoading: isLoadingBowlingAlley } = useQuery({
    queryKey: ['bowlingAlley', call?.bowling_alley_id],
    queryFn: () => base44.entities.BowlingAlley.get(call.bowling_alley_id),
    enabled: !!call?.bowling_alley_id
  });

  const displayDate = call?.device_timestamp || call?.created_date;
  const locationName = bowlingAlley?.name || "Unknown Location";

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: async () => {
      return await base44.entities.User.list();
    }
  });

  const mechanics = allUsers.filter((u) => u.department === 'mechanic' || u.department === 'manager' || u.department === 'front_desk' || u.role === 'admin');

  const { data: usedParts = [] } = useQuery({
    queryKey: ['usedParts', callId],
    queryFn: async () => {
      const parts = await base44.entities.UsedPart.list();
      return parts.filter((p) => p.service_call_id === callId);
    },
    enabled: !!callId
  });

  const { data: allParts = [] } = useQuery({
    queryKey: ['parts'],
    queryFn: () => base44.entities.Part.list()
  });

  const locationParts = call?.bowling_alley_id ?
  allParts.filter((p) => p.bowling_alley_id === call.bowling_alley_id) :
  allParts;

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => {
      if (!isOnline) {
        queueUpdate('update_service_call', data, id);
        return Promise.resolve({ id, ...data });
      }
      return base44.entities.ServiceCall.update(id, data);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['serviceCall', callId] });
      await queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      toast.success(isOnline ? "Service call updated" : "Update queued for sync");
    }
  });

  const addPartMutation = useMutation({
    mutationFn: async (data) => {
      await base44.entities.UsedPart.create(data);

      const part = locationParts.find((p) => p.id === data.part_id);
      if (part) {
        await base44.entities.Part.update(part.id, {
          quantity_in_stock: Math.max(0, part.quantity_in_stock - data.quantity_used)
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['usedParts', callId] });
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      setAddPartDialogOpen(false);
      setPartFormData({ part_id: "", quantity_used: 1, notes: "" });
      toast.success("Part added to service call");
    }
  });

  const deletePartMutation = useMutation({
    mutationFn: async (usedPart) => {
      await base44.entities.UsedPart.delete(usedPart.id);

      const part = locationParts.find((p) => p.id === usedPart.part_id);
      if (part) {
        await base44.entities.Part.update(part.id, {
          quantity_in_stock: part.quantity_in_stock + usedPart.quantity_used
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['usedParts', callId] });
      queryClient.invalidateQueries({ queryKey: ['parts'] });
      toast.success("Part removed from service call");
    }
  });

  const deleteServiceCallMutation = useMutation({
    mutationFn: (id) => base44.entities.ServiceCall.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['serviceCalls'] });
      toast.success("Service call deleted");
      navigate(createPageUrl("ServiceCalls"));
    }
  });

  const handleDeleteServiceCall = () => {
    if (!canDelete) {
      toast.error("You don't have permission to delete service calls");
      return;
    }

    if (window.confirm(`Are you sure you want to delete this service call? This action cannot be undone.`)) {
      deleteServiceCallMutation.mutate(callId);
    }
  };

  const canEdit = user && call && (
  user.department === 'manager' ||
  user.role === 'admin' ||
  call.assigned_to === user.email);


  // Check if user can delete (Lead Mechanic or higher)
  const userPositionLevel = user?.position ? positionHierarchy.find((p) => p.value === user.position)?.level : 999;
  const canDelete = user && (user.role === 'admin' || user.department === 'manager' || userPositionLevel <= 5);

  const handleStatusChange = async (newStatus, notes = '') => {
    if (!canEdit) {
      toast.error("You don't have permission to update this call");
      return;
    }

    const updateData = { status: newStatus };
    if (newStatus === 'completed') {
      updateData.completed_date = new Date().toISOString();
      if (notes || completionNotes) {
        updateData.completion_notes = notes || completionNotes;
      }
      
      // Play completion sound
      try {
        const currentUser = await base44.auth.me();
        playSound(SOUND_TYPES.SERVICE_CALL_COMPLETED, currentUser.sound_preferences);
      } catch (error) {
        playSound(SOUND_TYPES.SERVICE_CALL_COMPLETED, { service_call_completed: true });
      }
    }

    if (!isOnline) {
      queueUpdate('update_service_call', updateData, callId);
      toast.success("Update queued - will sync when online");
      return;
    }

    updateMutation.mutate({ id: callId, data: updateData });
  };

  const handleAssignmentChange = (newAssignee) => {
    if (!user || user.department !== 'mechanic' && user.department !== 'manager' && user.department !== 'front_desk' && user.role !== 'admin') {
      toast.error("Only mechanics, managers, and front desk can assign work");
      return;
    }
    updateMutation.mutate({ id: callId, data: { assigned_to: newAssignee } });
  };

  const handleAddNotes = (noteText = notes) => {
    if (!noteText.trim()) return;
    const existingNotes = call.notes || "";
    const timestamp = format(new Date(), "MMM d, yyyy h:mm a");
    const newNote = `[${timestamp} - ${user?.display_name || user?.full_name || user?.email}]\n${noteText}\n\n`;
    
    if (!isOnline) {
      queueUpdate('update_service_call', { notes: newNote + existingNotes }, callId);
      toast.success("Note queued - will sync when online");
      setNotes("");
      return;
    }
    
    updateMutation.mutate({
      id: callId,
      data: { notes: newNote + existingNotes }
    });
    setNotes("");
  };

  const handleAddPart = (e) => {
    e.preventDefault();
    if (!partFormData.part_id) {
      toast.error("Please select a part");
      return;
    }

    const part = locationParts.find((p) => p.id === partFormData.part_id);
    if (part && part.quantity_in_stock < partFormData.quantity_used) {
      toast.error("Not enough parts in stock");
      return;
    }

    addPartMutation.mutate({
      ...partFormData,
      service_call_id: callId
    });
  };

  const handleDeletePart = (usedPart) => {
    if (!canEdit) {
      toast.error("You don't have permission to remove parts");
      return;
    }
    deletePartMutation.mutate(usedPart);
  };

  const getPartDetails = (partId) => {
    const part = locationParts.find((p) => p.id === partId);
    return part;
  };

  // Get attachments from call entity
  const attachments = call?.attachments || [];

  const handleEditDescription = () => {
    const currentDesc = call.description || "";
    const lines = currentDesc.split('\n');

    let category = "";
    let ballCall = "";
    let oneEighty = "";
    let deckJam = "";
    let conCycle = "";
    let respotPins = [];
    let misc = "";
    let additionalText = "";

    lines.forEach((line) => {
      if (line.startsWith("Ball Calls - ")) {
        category = "ball_calls";
        const detail = line.substring("Ball Calls - ".length);
        const foundOption = BALL_CALL_LOCATIONS.find((opt) => opt.label === detail);
        ballCall = foundOption ? foundOption.value : "";
      } else if (line.startsWith("180's - ")) {
        category = "180s";
        const detail = line.substring("180's - ".length);
        const foundOption = ONE_EIGHTY_ISSUES.find((opt) => opt.label === detail);
        oneEighty = foundOption ? foundOption.value : "";
      } else if (line.startsWith("Deck Jams/Black Outs - ")) {
        category = "deck_jams";
        const detail = line.substring("Deck Jams/Black Outs - ".length);
        const foundOption = DECK_JAMS_BLACKOUTS.find((opt) => opt.label === detail);
        deckJam = foundOption ? foundOption.value : "";
      } else if (line.startsWith("Con. Cycles - ")) {
        category = "con_cycles";
        const detail = line.substring("Con. Cycles - ".length);
        const foundOption = CON_CYCLES.find((opt) => opt.label === detail);
        conCycle = foundOption ? foundOption.value : "";
      } else if (line.startsWith("Re-Spots - Pins ")) {
        category = "respots";
        const pinsStr = line.substring("Re-Spots - Pins ".length);
        respotPins = pinsStr.split(", ");
      } else if (line.startsWith("Miscellaneous - ")) {
        category = "miscellaneous";
        const detail = line.substring("Miscellaneous - ".length);
        const foundOption = MISCELLANEOUS.find((opt) => opt.label === detail);
        misc = foundOption ? foundOption.value : "";
      } else if (line.trim() && !line.match(/^(Ball Calls|180's|Deck Jams\/Black Outs|Con\. Cycles|Re-Spots|Miscellaneous)\s*-/)) {
        additionalText += (additionalText ? "\n" : "") + line;
      }
    });

    setDescriptionFormData({
      description_category: category,
      ball_call_location: ballCall,
      one_eighty_issue: oneEighty,
      deck_jam_issue: deckJam,
      con_cycle_issue: conCycle,
      respot_pins: respotPins,
      misc_issue: misc,
      additional_description: additionalText
    });

    setEditDescriptionOpen(true);
  };

  const handleDescriptionChange = (field, value) => {
    setDescriptionFormData((prev) => {
      const newData = { ...prev, [field]: value };

      if (field === 'description_category') {
        newData.ball_call_location = "";
        newData.one_eighty_issue = "";
        newData.deck_jam_issue = "";
        newData.con_cycle_issue = "";
        newData.respot_pins = [];
        newData.misc_issue = "";
      }

      return newData;
    });
  };

  const handleRespotPinToggle = (pin) => {
    setDescriptionFormData((prev) => {
      const pins = [...prev.respot_pins];
      const index = pins.indexOf(pin);
      if (index > -1) {
        pins.splice(index, 1);
      } else {
        pins.push(pin);
        pins.sort((a, b) => parseInt(a) - parseInt(b));
      }
      return { ...prev, respot_pins: pins };
    });
  };

  const handleSaveDescription = () => {
    let description = "";

    if (descriptionFormData.description_category === "ball_calls" && descriptionFormData.ball_call_location) {
      const ballLocationLabel = BALL_CALL_LOCATIONS.find((l) => l.value === descriptionFormData.ball_call_location)?.label || "";
      description = `Ball Calls - ${ballLocationLabel}`;
    } else if (descriptionFormData.description_category === "180s" && descriptionFormData.one_eighty_issue) {
      const issueLabel = ONE_EIGHTY_ISSUES.find((i) => i.value === descriptionFormData.one_eighty_issue)?.label || "";
      description = `180's - ${issueLabel}`;
    } else if (descriptionFormData.description_category === "deck_jams" && descriptionFormData.deck_jam_issue) {
      const issueLabel = DECK_JAMS_BLACKOUTS.find((i) => i.value === descriptionFormData.deck_jam_issue)?.label || "";
      description = `Deck Jams/Black Outs - ${issueLabel}`;
    } else if (descriptionFormData.description_category === "con_cycles" && descriptionFormData.con_cycle_issue) {
      const issueLabel = CON_CYCLES.find((i) => i.value === descriptionFormData.con_cycle_issue)?.label || "";
      description = `Con. Cycles - ${issueLabel}`;
    } else if (descriptionFormData.description_category === "respots" && descriptionFormData.respot_pins.length > 0) {
      description = `Re-Spots - Pins ${descriptionFormData.respot_pins.join(", ")}`;
    } else if (descriptionFormData.description_category === "miscellaneous" && descriptionFormData.misc_issue) {
      const issueLabel = MISCELLANEOUS.find((i) => i.value === descriptionFormData.misc_issue)?.label || "";
      description = `Miscellaneous - ${issueLabel}`;
    }

    if (descriptionFormData.additional_description) {
      description = description ? `${description}\n\n${descriptionFormData.additional_description}` : descriptionFormData.additional_description;
    }

    updateMutation.mutate({
      id: callId,
      data: { description }
    });

    setEditDescriptionOpen(false);
  };

  // Mobile view
  if (isMobile && call && bowlingAlley) {
    return (
      <MobileServiceCallDetail
        call={call}
        bowlingAlley={bowlingAlley}
        user={user}
        allUsers={allUsers}
        mechanics={mechanics || []}
        usedParts={usedParts}
        allParts={allParts}
        canEdit={canEdit}
        canDelete={canDelete}
        isOffline={!isOnline}
        onStatusChange={handleStatusChange}
        onAssignmentChange={handleAssignmentChange}
        onAddNote={handleAddNotes}
        onAddPart={handleAddPart}
        onDeletePart={handleDeletePart}
        onDeleteCall={handleDeleteServiceCall}
        onBack={() => navigate(createPageUrl("ServiceCalls"))}
      />
    );
  }

  // Desktop view
  return (
    <div className={`min-h-screen p-6 lg:p-8 ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("ServiceCalls"))}>

            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Service Call Detail</h1>
        </div>

        {isLoading || isLoadingBowlingAlley ?
        <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
          </div> :
        !call ?
        <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-12 text-center">
              <Wrench className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>Service Call Not Found</h3>
              <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>The service call you're looking for doesn't exist.</p>
            </CardContent>
          </Card> :

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Service Call Details */}
              <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className={`text-2xl mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{call.title}</CardTitle>
                      <div className="flex flex-wrap gap-2">
                        <StatusBadge status={call.status} showIcon />
                        <PriorityBadge priority={call.priority} showIcon />
                        {call.category && (
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${isDarkMode ? 'bg-blue-900 text-blue-300' : 'bg-blue-100 text-blue-800'}`}>
                            <Tag className="w-3 h-3" />
                            {call.category.replace(/_/g, ' ')}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label className="text-slate-500 text-sm">Location</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <Building2 className="w-4 h-4 text-slate-400" />
                          <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{locationName}</p>
                        </div>
                      </div>
                      <div>
                        <Label className="text-slate-500 text-sm">Lane Number</Label>
                        <p className={`mt-1 text-lg font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{call.lane_number}</p>
                      </div>
                      <div>
                        <Label className="text-slate-500 text-sm">Reported</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <p className={`text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{format(new Date(displayDate), "MMM d, yyyy 'at' h:mm a")}</p>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <Label className="text-slate-500 text-sm">Reported By</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <User className="w-4 h-4 text-slate-400" />
                          <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                            {(() => {
                              const creator = allUsers?.find(u => u.email === call.created_by);
                              return creator?.display_name || creator?.full_name || call.created_by;
                            })()}
                          </p>
                        </div>
                      </div>
                      <div>
                        <Label className="text-slate-500 text-sm">Assigned To</Label>
                        <p className={`mt-1 font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{call.assigned_to || 'Unassigned'}</p>
                      </div>
                      {call.completed_date &&
                    <div>
                          <Label className="text-slate-500 text-sm">Completed</Label>
                          <div className="flex items-center gap-2 mt-1">
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                            <p className={`text-sm ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{format(new Date(call.completed_date), "MMM d, yyyy 'at' h:mm a")}</p>
                          </div>
                        </div>
                    }
                    </div>
                  </div>

                  <div className={`mt-6 pt-6 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                    <div className="flex justify-between items-start mb-2">
                      <Label className="text-slate-500">Description</Label>
                      {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleEditDescription}>

                          <Edit className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                    }
                    </div>
                    <div>
                      {call.description ?
                    <div className={`mt-1 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                          {call.description.split('\n').map((line, index) => {
                        if (line.match(/^(Ball Calls|180's|Deck Jams\/Black Outs|Con\. Cycles|Re-Spots|Miscellaneous)\s*-/)) {
                          const [category, detail] = line.split(' - ');
                          return (
                            <div key={index} className="mb-2">
                                  <span className="inline-block px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm font-semibold mr-2">
                                    {category}
                                  </span>
                                  <span>{detail}</span>
                                </div>);

                        }
                        return line ? <p key={index} className="mb-1">{line}</p> : <br key={index} />;
                      })}
                        </div> :

                    <p className="mt-1 text-slate-500">No description provided</p>
                    }

                      {/* Attachments Gallery */}
                      <AttachmentGallery attachments={attachments} isDarkMode={isDarkMode} />
                    </div>

                    {call.completion_notes &&
                  <div className="mt-4">
                        <Label className="text-slate-500">Completion Notes</Label>
                        <p className="mt-1 text-slate-900 bg-green-50 p-3 rounded-lg">{call.completion_notes}</p>
                      </div>
                  }
                  </div>
                </CardContent>
              </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Work Notes</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
                <div className="space-y-3">
                    <Textarea
                    placeholder="Add work notes..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3} />

                    <Button onClick={handleAddNotes} disabled={!notes.trim()} className="w-full">
                      <Save className="w-4 h-4 mr-2" />
                      Add Note
                    </Button>
                  </div>
                }
                
                {call.notes ?
                <div className={`rounded-lg p-4 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
                    <pre className={`whitespace-pre-wrap text-sm font-sans ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                      {call.notes}
                    </pre>
                  </div> :

                <p className={`text-center py-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>No work notes yet</p>
                }
              </CardContent>
            </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader className={`border-b flex flex-row items-center justify-between ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Parts Used</CardTitle>
                {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
                <Dialog open={addPartDialogOpen} onOpenChange={setAddPartDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Part
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Part to Service Call</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddPart} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="part">Select Part *</Label>
                          <Select
                          value={partFormData.part_id}
                          onValueChange={(value) => setPartFormData((prev) => ({ ...prev, part_id: value }))}>

                            <SelectTrigger>
                              <SelectValue placeholder="Choose a part" />
                            </SelectTrigger>
                            <SelectContent>
                              {locationParts.filter((p) => p.quantity_in_stock > 0).map((part) =>
                            <SelectItem key={part.id} value={part.id}>
                                  {part.name} ({part.part_number}) - Stock: {part.quantity_in_stock}
                                </SelectItem>
                            )}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="quantity">Quantity Used *</Label>
                          <Input
                          id="quantity"
                          type="number"
                          min="1"
                          value={partFormData.quantity_used}
                          onChange={(e) => setPartFormData((prev) => ({ ...prev, quantity_used: parseInt(e.target.value) }))} />

                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="part_notes">Notes</Label>
                          <Textarea
                          id="part_notes"
                          placeholder="Additional notes about this part..."
                          value={partFormData.notes}
                          onChange={(e) => setPartFormData((prev) => ({ ...prev, notes: e.target.value }))}
                          rows={3} />

                        </div>

                        <div className="flex gap-3 pt-4">
                          <Button
                          type="button"
                          variant="outline"
                          onClick={() => setAddPartDialogOpen(false)}
                          className="flex-1">

                            Cancel
                          </Button>
                          <Button
                          type="submit"
                          disabled={addPartMutation.isPending}
                          className="flex-1 bg-blue-600 hover:bg-blue-700">

                            {addPartMutation.isPending ? "Adding..." : "Add Part"}
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                }
              </CardHeader>
              <CardContent className="p-6">
                {usedParts.length > 0 ?
                <div className="space-y-2">
                    {usedParts.map((usedPart) => {
                    const part = getPartDetails(usedPart.part_id);
                    return (
                      <div key={usedPart.id} className={`flex justify-between items-start p-3 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
                          <div className="flex-1">
                            <p className={`font-medium ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                              {part ? `${part.name} (${part.part_number})` : 'Unknown Part'}
                            </p>
                            {usedPart.notes && <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{usedPart.notes}</p>}
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>×{usedPart.quantity_used}</span>
                            {canEdit && call.status !== 'completed' && call.status !== 'cancelled' &&
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeletePart(usedPart)}
                            className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50">

                                <Trash2 className="w-4 h-4" />
                              </Button>
                          }
                          </div>
                        </div>);

                  })}
                  </div> :

                <p className={`text-center py-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>No parts used yet</p>
                }
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Status Management AND Assignment */}
          <div className="space-y-6">
            {/* Delete Service Call - Only for Lead Mechanic and above */}
            {canDelete &&
            <Card className="shadow-lg border-red-200 bg-red-50">
                <CardHeader className="border-b border-red-200">
                  <CardTitle className="text-red-900">Delete Service Call</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <p className="text-sm text-red-800 mb-4">
                    Permanently delete this service call. This action cannot be undone.
                  </p>
                  <Button
                  onClick={handleDeleteServiceCall}
                  disabled={deleteServiceCallMutation.isPending}
                  className="w-full bg-red-600 hover:bg-red-700 text-white">

                    <Trash2 className="w-4 h-4 mr-2" />
                    {deleteServiceCallMutation.isPending ? "Deleting..." : "Delete Service Call"}
                  </Button>
                </CardContent>
              </Card>
            }

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Status Management</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <div className="space-y-2">
                  <Label className={isDarkMode ? 'text-slate-300' : ''}>Update Status</Label>
                  <Select
                    value={call.status}
                    onValueChange={handleStatusChange}
                    disabled={!canEdit}>

                    <SelectTrigger className={`h-12 text-base capitalize ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`}>
                      <SelectValue placeholder="Select status">
                        {call.status?.replace(/_/g, ' ')}
                      </SelectValue>
                    </SelectTrigger>
                    <SelectContent position="popper" className={`z-50 ${isDarkMode ? 'bg-slate-800 border-slate-700' : ''}`}>
                      <SelectItem value="open" className="text-base py-3">Open</SelectItem>
                      <SelectItem value="in_progress" className="text-base py-3">In Progress</SelectItem>
                      <SelectItem value="waiting_for_parts" className="text-base py-3">Waiting for Parts</SelectItem>
                      <SelectItem value="completed" className="text-base py-3">Completed</SelectItem>
                      <SelectItem value="cancelled" className="text-base py-3">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {call.status !== 'completed' && call.status !== 'cancelled' && canEdit &&
                <div className="space-y-2">
                    <Label className={isDarkMode ? 'text-slate-300' : ''}>Completion Notes</Label>
                    <Textarea
                    placeholder="Add notes before completing..."
                    value={completionNotes}
                    onChange={(e) => setCompletionNotes(e.target.value)}
                    rows={3}
                    className={`text-base ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`} />

                  </div>
                }

                {!canEdit &&
                <p className={`text-xs mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    Only assigned mechanics and managers can update status
                  </p>
                }
              </CardContent>
            </Card>

            {/* Assignment Card */}
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Assignment</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-2">
                  <Label className={isDarkMode ? 'text-slate-300' : ''}>Assigned Mechanic</Label>
                  <Select
                    value={call.assigned_to || ""}
                    onValueChange={handleAssignmentChange}
                    disabled={!user || user.department !== 'mechanic' && user.department !== 'manager' && user.department !== 'front_desk' && user.role !== 'admin'}>

                    <SelectTrigger>
                      <SelectValue placeholder="Unassigned" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Unassigned</SelectItem>
                      {mechanics.map((mechanic) =>
                      <SelectItem key={mechanic.id} value={mechanic.email}>
                          {mechanic.display_name || mechanic.full_name || mechanic.email}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    Mechanics, managers, and front desk can reassign work
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        }

        {/* Edit Description Dialog */}
        <Dialog open={editDescriptionOpen} onOpenChange={setEditDescriptionOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Description Category</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="description_category">Description Category</Label>
                <Select
                  value={descriptionFormData.description_category}
                  onValueChange={(value) => handleDescriptionChange('description_category', value)}>

                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>None</SelectItem>
                    <SelectItem value="ball_calls">Ball Calls</SelectItem>
                    <SelectItem value="180s">180's</SelectItem>
                    <SelectItem value="deck_jams">Deck Jams/Black Outs</SelectItem>
                    <SelectItem value="con_cycles">Con. Cycles</SelectItem>
                    <SelectItem value="respots">Re-Spots</SelectItem>
                    <SelectItem value="miscellaneous">Miscellaneous</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Ball Calls */}
              {descriptionFormData.description_category === 'ball_calls' &&
              <div className="space-y-2 pl-4 border-l-2 border-blue-300 bg-blue-50 p-4 rounded-r-lg">
                  <Label htmlFor="ball_call_location">Ball Call Location *</Label>
                  <Select
                  value={descriptionFormData.ball_call_location}
                  onValueChange={(value) => handleDescriptionChange('ball_call_location', value)}>

                    <SelectTrigger>
                      <SelectValue placeholder="Select ball call location" />
                    </SelectTrigger>
                    <SelectContent>
                      {BALL_CALL_LOCATIONS.map((location) =>
                    <SelectItem key={location.value} value={location.value}>
                          {location.label}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
              }

              {/* 180's */}
              {descriptionFormData.description_category === '180s' &&
              <div className="space-y-2 pl-4 border-l-2 border-purple-300 bg-purple-50 p-4 rounded-r-lg">
                  <Label htmlFor="one_eighty_issue">180's Issue *</Label>
                  <Select
                  value={descriptionFormData.one_eighty_issue}
                  onValueChange={(value) => handleDescriptionChange('one_eighty_issue', value)}>

                    <SelectTrigger>
                      <SelectValue placeholder="Select 180's issue" />
                    </SelectTrigger>
                    <SelectContent>
                      {ONE_EIGHTY_ISSUES.map((issue) =>
                    <SelectItem key={issue.value} value={issue.value}>
                          {issue.label}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
              }

              {/* Deck Jams/Black Outs */}
              {descriptionFormData.description_category === 'deck_jams' &&
              <div className="space-y-2 pl-4 border-l-2 border-orange-300 bg-orange-50 p-4 rounded-r-lg">
                  <Label htmlFor="deck_jam_issue">Deck Jams/Black Outs Issue *</Label>
                  <Select
                  value={descriptionFormData.deck_jam_issue}
                  onValueChange={(value) => handleDescriptionChange('deck_jam_issue', value)}>

                    <SelectTrigger>
                      <SelectValue placeholder="Select deck jam/blackout issue" />
                    </SelectTrigger>
                    <SelectContent>
                      {DECK_JAMS_BLACKOUTS.map((issue) =>
                    <SelectItem key={issue.value} value={issue.value}>
                          {issue.label}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
              }

              {/* Con. Cycles */}
              {descriptionFormData.description_category === 'con_cycles' &&
              <div className="space-y-2 pl-4 border-l-2 border-green-300 bg-green-50 p-4 rounded-r-lg">
                  <Label htmlFor="con_cycle_issue">Con. Cycles Issue *</Label>
                  <Select
                  value={descriptionFormData.con_cycle_issue}
                  onValueChange={(value) => handleDescriptionChange('con_cycle_issue', value)}>

                    <SelectTrigger>
                      <SelectValue placeholder="Select con. cycle issue" />
                    </SelectTrigger>
                    <SelectContent>
                      {CON_CYCLES.map((issue) =>
                    <SelectItem key={issue.value} value={issue.value}>
                          {issue.label}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
              }

              {/* Re-Spots */}
              {descriptionFormData.description_category === 'respots' &&
              <div className="space-y-2 pl-4 border-l-2 border-teal-300 bg-teal-50 p-4 rounded-r-lg">
                  <Label>Select Pins to Re-spot *</Label>
                  <div className="grid grid-cols-5 gap-3 p-4 bg-white rounded-lg">
                    {PIN_NUMBERS.map((pin) =>
                  <div key={pin} className="flex items-center space-x-2">
                        <Checkbox
                      id={`respot-pin-${pin}`}
                      checked={descriptionFormData.respot_pins.includes(pin)}
                      onCheckedChange={() => handleRespotPinToggle(pin)} />

                        <Label
                      htmlFor={`respot-pin-${pin}`}
                      className="text-sm font-medium cursor-pointer">

                          Pin {pin}
                        </Label>
                      </div>
                  )}
                  </div>
                  {descriptionFormData.respot_pins.length > 0 &&
                <p className="text-sm text-teal-800">
                      Selected: {descriptionFormData.respot_pins.join(", ")}
                    </p>
                }
                </div>
              }

              {/* Miscellaneous */}
              {descriptionFormData.description_category === 'miscellaneous' &&
              <div className="space-y-2 pl-4 border-l-2 border-amber-300 bg-amber-50 p-4 rounded-r-lg">
                  <Label htmlFor="misc_issue">Miscellaneous Issue *</Label>
                  <Select
                  value={descriptionFormData.misc_issue}
                  onValueChange={(value) => handleDescriptionChange('misc_issue', value)}>

                    <SelectTrigger>
                      <SelectValue placeholder="Select miscellaneous issue" />
                    </SelectTrigger>
                    <SelectContent>
                      {MISCELLANEOUS.map((issue) =>
                    <SelectItem key={issue.value} value={issue.value}>
                          {issue.label}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
              }

              <div className="space-y-2">
                <Label htmlFor="additional_description">Additional Details</Label>
                <Textarea
                  id="additional_description"
                  placeholder="Provide additional information about the issue..."
                  value={descriptionFormData.additional_description}
                  onChange={(e) => handleDescriptionChange('additional_description', e.target.value)}
                  rows={5} />

              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditDescriptionOpen(false)}
                  className="flex-1">

                  Cancel
                </Button>
                <Button
                  onClick={handleSaveDescription}
                  disabled={updateMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700">

                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>);

}