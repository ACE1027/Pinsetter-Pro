import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useTheme } from "../components/ThemeContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  History,
  Search,
  Calendar,
  Filter,
  Download,
  Clock,
  CheckCircle2,
  XCircle,
  Hash,
  FileText,
  FileSpreadsheet,
  File
} from "lucide-react";
import ServiceCallCard from "../components/service/ServiceCallCard";
import { useLocation } from "../components/LocationContext";
import { format } from "date-fns";
import { toast } from "sonner";

const ISSUE_TYPES = [
{ value: "all", label: "All Types" },
{ value: "dead_wood", label: "Dead Wood" },
{ value: "ball_return", label: "Ball Return" },
{ value: "180_stop", label: "180 Stop" },
{ value: "out_of_range", label: "Out of Range" },
{ value: "re_spot", label: "Re-Spot" },
{ value: "add", label: "Add" },
{ value: "full_rack", label: "Full Rack" },
{ value: "90_stop", label: "90 Stop" },
{ value: "270_stop", label: "270 Stop" },
{ value: "banana_tree", label: "Banana Tree" },
{ value: "continuous_cycle", label: "Continuous Cycle" },
{ value: "black_out", label: "Black Out" },
{ value: "ball_damage", label: "Ball Damage" },
{ value: "other", label: "Other" }];


export default function ServiceCallHistory() {
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [issueTypeFilter, setIssueTypeFilter] = useState("all");
  const [laneFilter, setLaneFilter] = useState("all");
  const [dateRangeFilter, setDateRangeFilter] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const { selectedLocationId } = useLocation();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allCalls = [], isLoading } = useQuery({
    queryKey: ['serviceCallsHistory'],
    queryFn: () => base44.entities.ServiceCall.list('-completed_date'),
    initialData: []
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: []
  });

  const isAdmin = user && user.role === 'admin';

  // Determine which location to show - regular users ONLY see their assigned location
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' ?
  selectedLocationId :
  user?.bowling_alley_id;

  // Filter calls - strict location-based access control
  const accessibleCalls = allCalls.filter((call) => {
    if (!user) return false;

    // Only show completed or cancelled calls
    if (call.status !== 'completed' && call.status !== 'cancelled') return false;

    // Admins can view all if "All Locations" selected
    if (isAdmin && selectedLocationId === 'all') {
      return true;
    }

    // All other users see only their location's calls
    if (effectiveLocationId && call.bowling_alley_id === effectiveLocationId) {
      return true;
    }

    return false;
  });

  // Get unique lane numbers from accessible calls for filter dropdown
  const uniqueLanes = [...new Set(accessibleCalls.
  map((call) => call.lane_number).
  filter((lane) => lane)
  )].sort((a, b) => {
    const aNum = parseInt(a);
    const bNum = parseInt(b);
    if (!isNaN(aNum) && !isNaN(bNum)) {
      return aNum - bNum;
    }
    return a.localeCompare(b);
  });

  // Apply date range filter
  const dateFilteredCalls = accessibleCalls.filter((call) => {
    if (dateRangeFilter === 'all') return true;

    const callDate = new Date(call.completed_date || call.created_date);
    const now = new Date();

    if (dateRangeFilter === 'today') {
      return callDate.toDateString() === now.toDateString();
    } else if (dateRangeFilter === 'week') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      return callDate >= weekAgo;
    } else if (dateRangeFilter === 'month') {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      return callDate >= monthAgo;
    } else if (dateRangeFilter === 'custom' && startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999); // Include the entire end date
      return callDate >= start && callDate <= end;
    }

    return true;
  });

  // Apply all filters
  const filteredCalls = dateFilteredCalls.filter((call) => {
    // Status filter
    const matchesStatus = statusFilter === 'all' || call.status === statusFilter;

    // Issue type filter (check if title contains the issue type)
    const matchesIssueType = issueTypeFilter === 'all' || (() => {
      const issueType = ISSUE_TYPES.find((t) => t.value === issueTypeFilter);
      if (!issueType) return false;
      return call.title?.toLowerCase().includes(issueType.label.toLowerCase());
    })();

    // Lane filter
    const matchesLane = laneFilter === 'all' || call.lane_number === laneFilter;

    // Search filter (search in title, description, lane, notes)
    const matchesSearch = !searchQuery || (() => {
      const query = searchQuery.toLowerCase();
      return (
        call.title?.toLowerCase().includes(query) ||
        call.description?.toLowerCase().includes(query) ||
        call.lane_number?.toLowerCase().includes(query) ||
        call.notes?.toLowerCase().includes(query) ||
        call.completion_notes?.toLowerCase().includes(query));

    })();

    return matchesStatus && matchesIssueType && matchesLane && matchesSearch;
  });

  const statusCounts = {
    all: accessibleCalls.length,
    completed: accessibleCalls.filter((c) => c.status === 'completed').length,
    cancelled: accessibleCalls.filter((c) => c.status === 'cancelled').length
  };

  const getLocationName = (locationId) => {
    const location = locations.find((l) => l.id === locationId);
    return location?.name || 'Unknown Location';
  };

  const prepareExportData = () => {
    return filteredCalls.map(call => ({
      ...call,
      location_name: getLocationName(call.bowling_alley_id)
    }));
  };

  const handleExportCSV = () => {
    if (filteredCalls.length === 0) {
      toast.error('No records to export');
      return;
    }

    const headers = ['Date Completed', 'Location', 'Lane', 'Title', 'Status', 'Priority', 'Assigned To', 'Description', 'Completion Notes'];
    const rows = filteredCalls.map((call) => [
      call.completed_date ? format(new Date(call.completed_date), 'yyyy-MM-dd HH:mm') : 'N/A',
      getLocationName(call.bowling_alley_id),
      call.lane_number || '',
      call.title || '',
      call.status || '',
      call.priority || '',
      call.assigned_to || '',
      (call.description || '').replace(/\n/g, ' '),
      (call.completion_notes || '').replace(/\n/g, ' ')
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.map((cell) => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `service-call-history-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('CSV exported successfully');
  };

  const handleExportTSV = () => {
    if (filteredCalls.length === 0) {
      toast.error('No records to export');
      return;
    }

    const headers = ['Date Completed', 'Location', 'Lane', 'Title', 'Status', 'Priority', 'Assigned To', 'Description', 'Completion Notes'];
    const rows = filteredCalls.map((call) => [
      call.completed_date ? format(new Date(call.completed_date), 'yyyy-MM-dd HH:mm') : 'N/A',
      getLocationName(call.bowling_alley_id),
      call.lane_number || '',
      call.title || '',
      call.status || '',
      call.priority || '',
      call.assigned_to || '',
      (call.description || '').replace(/\t/g, ' ').replace(/\n/g, ' '),
      (call.completion_notes || '').replace(/\t/g, ' ').replace(/\n/g, ' ')
    ]);

    const tsvContent = [headers.join('\t'), ...rows.map((row) => row.join('\t'))].join('\n');
    const blob = new Blob([tsvContent], { type: 'text/tab-separated-values;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `service-call-history-${format(new Date(), 'yyyy-MM-dd')}.tsv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('TSV exported successfully');
  };

  const handleExportHTML = () => {
    if (filteredCalls.length === 0) {
      toast.error('No records to export');
      return;
    }

    const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Service Call History</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    h1 { color: #2563eb; }
    table { border-collapse: collapse; width: 100%; margin-top: 20px; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background-color: #2563eb; color: white; }
    tr:nth-child(even) { background-color: #f9fafb; }
    .meta { color: #64748b; margin: 10px 0; }
  </style>
</head>
<body>
  <h1>Service Call History</h1>
  <div class="meta">Generated: ${new Date().toLocaleString()}</div>
  <div class="meta">Total Records: ${filteredCalls.length}</div>
  <table>
    <thead>
      <tr>
        <th>Date</th>
        <th>Title</th>
        <th>Status</th>
        <th>Priority</th>
        <th>Lane</th>
        <th>Location</th>
      </tr>
    </thead>
    <tbody>
      ${filteredCalls.map(call => `
      <tr>
        <td>${call.completed_date ? format(new Date(call.completed_date), 'yyyy-MM-dd HH:mm') : 'N/A'}</td>
        <td>${call.title || ''}</td>
        <td>${call.status || ''}</td>
        <td>${call.priority || ''}</td>
        <td>${call.lane_number || ''}</td>
        <td>${getLocationName(call.bowling_alley_id)}</td>
      </tr>`).join('')}
    </tbody>
  </table>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `service-call-history-${format(new Date(), 'yyyy-MM-dd')}.html`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('HTML exported successfully');
  };

  const handleExport = async (exportFormat) => {
    if (filteredCalls.length === 0) {
      toast.error('No records to export');
      return;
    }

    if (exportFormat === 'csv') {
      handleExportCSV();
      return;
    }
    if (exportFormat === 'tsv') {
      handleExportTSV();
      return;
    }
    if (exportFormat === 'html') {
      handleExportHTML();
      return;
    }

    try {
      toast.info(`Generating ${exportFormat.toUpperCase()} file...`);
      const exportData = prepareExportData();
      const filename = `service-call-history-${format(new Date(), 'yyyy-MM-dd')}`;
      
      const response = await base44.functions.invoke('exportServiceHistory', {
        calls: exportData,
        format: exportFormat,
        filename
      });

      const blob = new Blob([response.data], { 
        type: exportFormat === 'pdf' ? 'application/pdf' : 
              exportFormat === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' :
              exportFormat === 'ods' ? 'application/vnd.oasis.opendocument.spreadsheet' :
              'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      });
      
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `${filename}.${exportFormat}`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success(`${exportFormat.toUpperCase()} exported successfully`);
    } catch (error) {
      toast.error(`Failed to export ${exportFormat.toUpperCase()}`);
      console.error(error);
    }
  };

  return (
    <div className={`min-h-screen ${theme.bg}`}>
      <div className="p-6 lg:p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h1 className={`text-3xl font-bold flex items-center gap-3 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                <History className="w-8 h-8 text-blue-600" />
                Service Call History
              </h1>
              <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>View all completed and cancelled service requests</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>Export Format</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleExport('csv')}>
                  <FileText className="w-4 h-4 mr-2" />
                  CSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('tsv')}>
                  <FileText className="w-4 h-4 mr-2" />
                  TSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('html')}>
                  <File className="w-4 h-4 mr-2" />
                  HTML
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleExport('pdf')}>
                  <FileText className="w-4 h-4 mr-2" />
                  PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('xlsx')}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('ods')}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  OpenDocument (.ods)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('docx')}>
                  <FileText className="w-4 h-4 mr-2" />
                  Word (.docx)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <Card className={`bg-gradient-to-br ${isDarkMode ? 'from-blue-950 to-blue-900 border-blue-800' : 'from-blue-50 to-blue-100 border-blue-200'}`}>
              <CardContent className="bg-indigo-400 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-700 font-medium">Total Records</p>
                    <p className="text-3xl font-bold text-blue-900 mt-1">{statusCounts.all}</p>
                  </div>
                  <History className="w-12 h-12 text-blue-600 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className={`bg-gradient-to-br ${isDarkMode ? 'from-green-950 to-green-900 border-green-800' : 'from-green-50 to-green-100 border-green-200'}`}>
              <CardContent className="bg-green-500 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-700 font-medium">Completed</p>
                    <p className="text-3xl font-bold text-green-900 mt-1">{statusCounts.completed}</p>
                  </div>
                  <CheckCircle2 className="w-12 h-12 text-green-600 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className={`bg-gradient-to-br ${isDarkMode ? 'from-slate-900 to-slate-800 border-slate-700' : 'from-slate-50 to-slate-100 border-slate-200'}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-700 font-medium">Cancelled</p>
                    <p className="text-3xl font-bold text-slate-900 mt-1">{statusCounts.cancelled}</p>
                  </div>
                  <XCircle className="w-12 h-12 text-slate-600 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className={`shadow-sm p-4 mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <div className="space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search by keyword in titles, descriptions, notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : ''}`} />

              </div>

              {/* Status Tabs */}
              <div>
                <Label className="text-xs text-slate-600 mb-2 block">Status</Label>
                <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
                    <TabsTrigger value="completed">Completed ({statusCounts.completed})</TabsTrigger>
                    <TabsTrigger value="cancelled">Cancelled ({statusCounts.cancelled})</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>

              {/* Date Range, Issue Type, Lane, and Results */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Date Range */}
                <div className="space-y-2">
                  <Label className="text-xs text-slate-600 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    Date Range
                  </Label>
                  <Select value={dateRangeFilter} onValueChange={setDateRangeFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select date range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Time</SelectItem>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">Last 7 Days</SelectItem>
                      <SelectItem value="month">Last 30 Days</SelectItem>
                      <SelectItem value="custom">Custom Range</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Issue Type */}
                <div className="space-y-2">
                  <Label className="text-xs text-slate-600 flex items-center gap-1">
                    <Filter className="w-3 h-3" />
                    Issue Type
                  </Label>
                  <Select value={issueTypeFilter} onValueChange={setIssueTypeFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select issue type" />
                    </SelectTrigger>
                    <SelectContent>
                      {ISSUE_TYPES.map((type) =>
                      <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {/* Lane Number */}
                <div className="space-y-2">
                  <Label className="text-xs text-slate-600 flex items-center gap-1">
                    <Hash className="w-3 h-3" />
                    Lane Number
                  </Label>
                  <Select value={laneFilter} onValueChange={setLaneFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All lanes" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Lanes</SelectItem>
                      {uniqueLanes.map((lane) =>
                      <SelectItem key={lane} value={lane}>
                          Lane {lane}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {/* Results Count */}
                <div className="space-y-2">
                  <Label className="text-xs text-slate-600 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Results
                  </Label>
                  <div className="h-10 flex items-center px-3 bg-slate-50 border border-slate-200 rounded-md">
                    <span className="text-sm font-medium text-slate-700">
                      {filteredCalls.length} record{filteredCalls.length !== 1 ? 's' : ''} found
                    </span>
                  </div>
                </div>
              </div>

              {/* Custom Date Range */}
              {dateRangeFilter === 'custom' &&
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="space-y-2">
                    <Label htmlFor="start_date" className="text-sm text-blue-900">Start Date</Label>
                    <Input
                    id="start_date"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="bg-white" />

                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end_date" className="text-sm text-blue-900">End Date</Label>
                    <Input
                    id="end_date"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="bg-white" />

                  </div>
                </div>
              }

              {/* Active Filters Summary */}
              {(searchQuery || statusFilter !== 'all' || issueTypeFilter !== 'all' || laneFilter !== 'all' || dateRangeFilter !== 'all') &&
              <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-200">
                  <span className="text-xs text-slate-600 font-medium">Active Filters:</span>
                  {statusFilter !== 'all' &&
                <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                      Status: {statusFilter}
                    </span>
                }
                  {issueTypeFilter !== 'all' &&
                <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">
                      Type: {ISSUE_TYPES.find((t) => t.value === issueTypeFilter)?.label}
                    </span>
                }
                  {laneFilter !== 'all' &&
                <span className="text-xs bg-teal-100 text-teal-800 px-2 py-1 rounded-full">
                      Lane: {laneFilter}
                    </span>
                }
                  {dateRangeFilter !== 'all' &&
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                      Date: {dateRangeFilter === 'custom' ? `${startDate} to ${endDate}` : dateRangeFilter}
                    </span>
                }
                  {searchQuery &&
                <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full">
                      Search: "{searchQuery}"
                    </span>
                }
                  <button
                  onClick={() => {
                    setSearchQuery("");
                    setStatusFilter("all");
                    setIssueTypeFilter("all");
                    setLaneFilter("all");
                    setDateRangeFilter("all");
                    setStartDate("");
                    setEndDate("");
                  }}
                  className="text-xs text-red-600 hover:text-red-700 underline">

                    Clear all
                  </button>
                </div>
              }
            </div>
          </Card>

          {/* Service Calls Grid */}
          {isLoading ?
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {Array(6).fill(0).map((_, i) =>
            <div key={i} className={`h-48 rounded-lg animate-pulse ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`} />
            )}
            </div> :
          filteredCalls.length > 0 ?
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filteredCalls.map((call) =>
            <ServiceCallCard key={call.id} call={call} />
            )}
            </div> :

          <div className={`rounded-lg border-2 border-dashed p-12 text-center ${isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-300'}`}>
              <History className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>No history records found</h3>
              <p className={`mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {searchQuery || statusFilter !== 'all' || issueTypeFilter !== 'all' || laneFilter !== 'all' || dateRangeFilter !== 'all' ?
              "Try adjusting your filters or search criteria" :
              "Completed and cancelled service calls will appear here"}
              </p>
            </div>
          }
        </div>
      </div>
    </div>);

}