import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, X } from "lucide-react";
import ServiceCallCard from "../components/service/ServiceCallCard";
import { useLocation } from "../components/LocationContext";
import { useNotifications, NotificationPrompt } from "../components/NotificationManager";
import { useTheme } from "@/components/ThemeContext";
import { Badge } from "@/components/ui/badge";

export default function ServiceCalls() {
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [machineTypeFilter, setMachineTypeFilter] = useState("all");
  const [sortBy, setSortBy] = useState("-created_date");
  const { selectedLocationId } = useLocation();
  const { sendNotification } = useNotifications();
  const [lastCallCount, setLastCallCount] = useState(0);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allCalls = [], isLoading } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list('-created_date'),
    initialData: [],
  });

  const isAdmin = user && user.role === 'admin';

  // Determine which location to show - regular users ONLY see their assigned location
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  // Filter calls - strict location-based access control
  const accessibleCalls = allCalls.filter(call => {
    if (!user) return false;
    
    // Admins can view all if "All Locations" selected
    if (isAdmin && selectedLocationId === 'all') {
      return true;
    }
    
    // All other users (including admins with specific location selected) see only their location's calls
    if (effectiveLocationId && call.bowling_alley_id === effectiveLocationId) {
      return true;
    }
    
    return false;
  });

  // Get unique machine types from accessible calls
  const uniqueMachineTypes = [...new Set(accessibleCalls.map(call => call.machine_type).filter(Boolean))].sort();

  // Apply filters
  const filteredCalls = accessibleCalls.filter(call => {
    const matchesStatus = statusFilter === 'all' || call.status === statusFilter;
    const matchesMachineType = machineTypeFilter === 'all' || call.machine_type === machineTypeFilter;
    const matchesSearch = !searchQuery || 
      call.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      call.lane_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      call.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      call.machine_type?.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesMachineType && matchesSearch;
  });

  // Apply sorting
  const sortedCalls = [...filteredCalls].sort((a, b) => {
    const isDescending = sortBy.startsWith('-');
    const field = isDescending ? sortBy.slice(1) : sortBy;
    
    let aVal = a[field];
    let bVal = b[field];
    
    if (field === 'priority') {
      const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
      aVal = priorityOrder[aVal] || 0;
      bVal = priorityOrder[bVal] || 0;
    }
    
    if (aVal < bVal) return isDescending ? 1 : -1;
    if (aVal > bVal) return isDescending ? -1 : 1;
    return 0;
  });

  // Monitor for new urgent service calls
  useEffect(() => {
    const urgentCalls = accessibleCalls.filter(c => c.priority === 'urgent' && c.status !== 'completed' && c.status !== 'cancelled');
    
    if (lastCallCount > 0 && urgentCalls.length > lastCallCount) {
      const newCalls = urgentCalls.slice(0, urgentCalls.length - lastCallCount);
      newCalls.forEach(call => {
        sendNotification('🚨 Urgent Service Call', {
          body: `Lane ${call.lane_number}: ${call.title}`,
          tag: `urgent-call-${call.id}`,
          data: { url: createPageUrl('ServiceCallDetail') + '?id=' + call.id },
        });
      });
    }
    
    setLastCallCount(urgentCalls.length);
  }, [accessibleCalls, sendNotification]);

  const statusCounts = {
    all: accessibleCalls.length,
    open: accessibleCalls.filter(c => c.status === 'open').length,
    in_progress: accessibleCalls.filter(c => c.status === 'in_progress').length,
    waiting_for_parts: accessibleCalls.filter(c => c.status === 'waiting_for_parts').length,
    completed: accessibleCalls.filter(c => c.status === 'completed').length,
    cancelled: accessibleCalls.filter(c => c.status === 'cancelled').length,
  };

  const clearFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setMachineTypeFilter("all");
  };

  const activeFilterCount = (searchQuery ? 1 : 0) + (statusFilter !== 'all' ? 1 : 0) + (machineTypeFilter !== 'all' ? 1 : 0);

  return (
    <div className={`min-h-full ${theme.bg}`}>
      <div className="p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-4 w-full">
          <NotificationPrompt />
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h1 className={`text-3xl font-bold ${theme.text}`}>Service Calls</h1>
              <p className={`mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>Manage and track all service requests</p>
            </div>
            <Link to={createPageUrl("CreateServiceCall")}>
              <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                New Service Call
              </Button>
            </Link>
          </div>

          {/* Filters */}
          <div className={`rounded-lg shadow-sm border p-3 mb-4 backdrop-blur-sm ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
            <div className="flex flex-col gap-3 sm:gap-4">
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search by title, lane, machine type, or description..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`pl-10 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-white border-slate-300'}`}
                  />
                </div>
                <Select value={machineTypeFilter} onValueChange={setMachineTypeFilter}>
                  <SelectTrigger className={`w-full sm:w-56 h-10 text-sm ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'text-black'}`}>
                    <SelectValue placeholder="All Machine Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Machine Types</SelectItem>
                    {uniqueMachineTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className={`w-full sm:w-48 h-10 text-sm ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'text-black'}`}>
                    <SelectValue placeholder="Sort by..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="-created_date">Newest First</SelectItem>
                    <SelectItem value="created_date">Oldest First</SelectItem>
                    <SelectItem value="-priority">Priority: High to Low</SelectItem>
                    <SelectItem value="priority">Priority: Low to High</SelectItem>
                    <SelectItem value="lane_number">Lane: Low to High</SelectItem>
                    <SelectItem value="-lane_number">Lane: High to Low</SelectItem>
                    <SelectItem value="status">Status</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Active filters display */}
              {activeFilterCount > 0 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Active filters:</span>
                  {machineTypeFilter !== 'all' && (
                    <Badge variant="secondary" className="gap-1">
                      {machineTypeFilter}
                      <button onClick={() => setMachineTypeFilter('all')} className="ml-1">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  )}
                  {statusFilter !== 'all' && (
                    <Badge variant="secondary" className="gap-1">
                      {statusFilter.replace(/_/g, ' ')}
                      <button onClick={() => setStatusFilter('all')} className="ml-1">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  )}
                  {searchQuery && (
                    <Badge variant="secondary" className="gap-1">
                      Search: "{searchQuery}"
                      <button onClick={() => setSearchQuery('')} className="ml-1">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  )}
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-xs h-6">
                    Clear all
                  </Button>
                </div>
              )}

              <div className="overflow-x-auto w-full -mx-3 px-3 sm:mx-0 sm:px-0 max-w-full">
                <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-full">
                  <TabsList className="inline-flex h-9 items-center justify-start gap-1 p-1 bg-slate-100 dark:bg-slate-800 w-max min-w-full lg:grid lg:grid-cols-6 lg:w-full max-w-full">
                  <TabsTrigger value="all" className="text-xs sm:text-sm whitespace-nowrap">All ({statusCounts.all})</TabsTrigger>
                  <TabsTrigger value="open" className="text-xs sm:text-sm whitespace-nowrap">Open ({statusCounts.open})</TabsTrigger>
                  <TabsTrigger value="in_progress" className="text-xs sm:text-sm whitespace-nowrap">Progress ({statusCounts.in_progress})</TabsTrigger>
                  <TabsTrigger value="waiting_for_parts" className="text-xs sm:text-sm whitespace-nowrap">Waiting ({statusCounts.waiting_for_parts})</TabsTrigger>
                  <TabsTrigger value="completed" className="text-xs sm:text-sm whitespace-nowrap">Done ({statusCounts.completed})</TabsTrigger>
                  <TabsTrigger value="cancelled" className="text-xs sm:text-sm whitespace-nowrap">Cancelled ({statusCounts.cancelled})</TabsTrigger>
                  </TabsList>
                  </Tabs>
                  </div>
                  </div>
          </div>

          {/* Service Calls Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className={`h-48 rounded-lg animate-pulse ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`} />
              ))}
            </div>
            ) : sortedCalls.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {sortedCalls.map(call => (
                <ServiceCallCard key={call.id} call={call} />
              ))}
            </div>
          ) : (
            <div className={`rounded-lg border-2 border-dashed p-12 text-center ${isDarkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-300'}`}>
              <h3 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-black'}`}>No service calls found</h3>
              <p className={`mb-4 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                {searchQuery || statusFilter !== 'all' || machineTypeFilter !== 'all'
                  ? "Try adjusting your filters" 
                  : "Create your first service call to get started"}
              </p>
              {activeFilterCount > 0 && (
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}