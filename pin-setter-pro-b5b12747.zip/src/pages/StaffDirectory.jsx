import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Mail, Phone, MapPin, User } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "@/components/LocationContext";

export default function StaffDirectory() {
  const navigate = useNavigate();
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  const accessibleUsers = allUsers.filter(u => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && u.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const filteredUsers = accessibleUsers.filter(u => {
    const matchesDepartment = departmentFilter === 'all' || u.department === departmentFilter;
    const matchesSearch = !searchQuery || 
      u.display_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.position?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDepartment && matchesSearch;
  });

  const getLocationName = (locationId) => {
    return locations.find(l => l.id === locationId)?.name || "Unknown";
  };

  const departmentCounts = {
    all: accessibleUsers.length,
    mechanic: accessibleUsers.filter(u => u.department === 'mechanic').length,
    manager: accessibleUsers.filter(u => u.department === 'manager').length,
    front_desk: accessibleUsers.filter(u => u.department === 'front_desk').length,
  };

  const positionColors = {
    general_manager: "bg-purple-100 text-purple-800",
    service_manager: "bg-blue-100 text-blue-800",
    assistant_manager: "bg-cyan-100 text-cyan-800",
    senior_mechanic: "bg-green-100 text-green-800",
    lead_mechanic: "bg-teal-100 text-teal-800",
    mechanic: "bg-slate-100 text-slate-800",
    mechanic_apprentice: "bg-amber-100 text-amber-800",
    front_desk_supervisor: "bg-indigo-100 text-indigo-800",
    front_desk_staff: "bg-pink-100 text-pink-800",
  };

  return (
    <div className={`min-h-screen overflow-x-hidden p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto w-full">
        <div className="mb-6">
          <h1 className={`text-3xl font-bold ${theme.text}`}>Staff Directory</h1>
          <p className={`mt-1 ${theme.textSecondary}`}>Find and contact team members</p>
        </div>

        <Card className={`mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardContent className="p-4">
            <div className="flex flex-col gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search by name, email, or position..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Tabs value={departmentFilter} onValueChange={setDepartmentFilter}>
                <TabsList className="grid grid-cols-4 w-full">
                  <TabsTrigger value="all">All ({departmentCounts.all})</TabsTrigger>
                  <TabsTrigger value="mechanic">Mechanics ({departmentCounts.mechanic})</TabsTrigger>
                  <TabsTrigger value="manager">Managers ({departmentCounts.manager})</TabsTrigger>
                  <TabsTrigger value="front_desk">Front Desk ({departmentCounts.front_desk})</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredUsers.map(employee => (
            <Card 
              key={employee.id} 
              className={`cursor-pointer hover:shadow-lg transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
              onClick={() => navigate(createPageUrl("EmployeeProfile") + `?email=${employee.email}`)}
            >
              <CardHeader>
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-semibold">
                    {(employee.display_name || employee.full_name)?.charAt(0) || employee.email?.charAt(0) || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <CardTitle className={`text-base truncate ${theme.text}`}>
                      {employee.display_name || employee.full_name || employee.email}
                    </CardTitle>
                    {employee.position && (
                      <Badge className={`mt-1 text-xs ${positionColors[employee.position] || 'bg-slate-100 text-slate-800'}`}>
                        {employee.position.replace(/_/g, ' ')}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {employee.email && (
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span className={`truncate ${theme.textSecondary}`}>{employee.email}</span>
                  </div>
                )}
                {employee.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span className={theme.textSecondary}>{employee.phone}</span>
                  </div>
                )}
                {isAdmin && employee.bowling_alley_id && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    <span className={`truncate ${theme.textTertiary}`}>{getLocationName(employee.bowling_alley_id)}</span>
                  </div>
                )}
                <Button 
                  size="sm" 
                  className="w-full mt-3 bg-blue-600 hover:bg-blue-700"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(createPageUrl("EmployeeProfile") + `?email=${employee.email}`);
                  }}
                >
                  View Profile
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredUsers.length === 0 && (
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardContent className="p-12 text-center">
              <User className={`w-12 h-12 mx-auto mb-2 ${isDarkMode ? 'text-slate-600' : 'text-slate-400'}`} />
              <p className={theme.textSecondary}>No staff members found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}