import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "@/components/ThemeContext";
import { useLocation } from "@/components/LocationContext";
import { toast } from "sonner";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarPlus, Save, FileText, Users, Plus, QrCode, Calendar, List, Search, Filter, SortAsc } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import TaskQRCodeDisplay from "@/components/tasks/TaskQRCodeDisplay";
import TaskCalendarView from "@/components/tasks/TaskCalendarView";
import TaskBulkActions from "@/components/tasks/TaskBulkActions";

export default function TaskScheduling() {
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("schedule");

  const [formData, setFormData] = useState({
    task_title: "",
    description: "",
    assigned_to: "",
    scheduled_date: "",
    due_date: "",
    priority: "medium",
    category: "",
    lane_number: "",
    machine_type: "",
    requires_signature: false,
    notes: "",
  });

  const [templateData, setTemplateData] = useState({
    template_name: "",
    description: "",
    task_type: "scheduled_maintenance",
    department: "general",
    category: "",
    estimated_duration: 30,
    requires_signature: false,
    requires_photos: false,
    template_data: {
      default_assignee: "",
      checklist: [],
    },
  });

  const [editingTemplate, setEditingTemplate] = useState(null);
  const [checklistItem, setChecklistItem] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("all");

  const [qrTaskToShow, setQrTaskToShow] = useState(null);
  const [qrDialogOpen, setQrDialogOpen] = useState(false);
  
  const [viewMode, setViewMode] = useState("list");
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [assigneeFilter, setAssigneeFilter] = useState("all");
  const [sortBy, setSortBy] = useState("-scheduled_date");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: scheduledTasks = [] } = useQuery({
    queryKey: ['scheduledTasks', selectedLocationId],
    queryFn: () => {
      if (selectedLocationId) {
        return base44.entities.ScheduledTask.filter({ bowling_alley_id: selectedLocationId }, '-scheduled_date');
      }
      return base44.entities.ScheduledTask.list('-scheduled_date');
    },
    enabled: !!user,
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['taskTemplates'],
    queryFn: () => base44.entities.TaskTemplate.list(),
    initialData: [],
  });

  const createTaskMutation = useMutation({
    mutationFn: (data) => base44.entities.ScheduledTask.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledTasks'] });
      toast.success("Task scheduled successfully");
      setDialogOpen(false);
      resetForm();
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ScheduledTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledTasks'] });
      toast.success("Task updated successfully");
    },
  });

  const deleteTasksMutation = useMutation({
    mutationFn: async (taskIds) => {
      await Promise.all(taskIds.map(id => base44.entities.ScheduledTask.delete(id)));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduledTasks'] });
      toast.success("Tasks deleted successfully");
      setSelectedTasks([]);
    },
  });

  const createTemplateMutation = useMutation({
    mutationFn: (data) => base44.entities.TaskTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['taskTemplates'] });
      toast.success("Template created successfully");
      setTemplateDialogOpen(false);
      resetTemplateForm();
    },
  });

  const updateTemplateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TaskTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['taskTemplates'] });
      toast.success("Template updated successfully");
      setTemplateDialogOpen(false);
      setEditingTemplate(null);
      resetTemplateForm();
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: (id) => base44.entities.TaskTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['taskTemplates'] });
      toast.success("Template deleted successfully");
    },
  });

  const resetForm = () => {
    setFormData({
      task_title: "",
      description: "",
      assigned_to: "",
      scheduled_date: "",
      due_date: "",
      priority: "medium",
      category: "",
      lane_number: "",
      machine_type: "",
      requires_signature: false,
      notes: "",
    });
  };

  const resetTemplateForm = () => {
    setTemplateData({
      template_name: "",
      description: "",
      task_type: "scheduled_maintenance",
      department: "general",
      category: "",
      estimated_duration: 30,
      requires_signature: false,
      requires_photos: false,
      template_data: {
        default_assignee: "",
        checklist: [],
      },
    });
    setEditingTemplate(null);
    setChecklistItem("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const taskData = {
      ...formData,
      bowling_alley_id: selectedLocationId || user?.bowling_alley_id,
      qr_code: `TASK-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    createTaskMutation.mutate(taskData);
  };

  const handleTemplateSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...templateData,
      bowling_alley_id: selectedLocationId || user?.bowling_alley_id,
    };
    if (editingTemplate) {
      updateTemplateMutation.mutate({ id: editingTemplate.id, data });
    } else {
      createTemplateMutation.mutate(data);
    }
  };

  const handleUseTemplate = (template) => {
    setFormData({
      ...formData,
      task_title: template.template_name,
      description: template.description || "",
      category: template.category || "",
      requires_signature: template.requires_signature || false,
      assigned_to: template.template_data?.default_assignee || "",
    });
    setDialogOpen(true);
  };

  const handleEditTemplate = (template) => {
    setEditingTemplate(template);
    setTemplateData({
      template_name: template.template_name,
      description: template.description || "",
      task_type: template.task_type || "scheduled_maintenance",
      department: template.department || "general",
      category: template.category || "",
      estimated_duration: template.estimated_duration || 30,
      requires_signature: template.requires_signature || false,
      requires_photos: template.requires_photos || false,
      template_data: template.template_data || { default_assignee: "", checklist: [] },
    });
    setTemplateDialogOpen(true);
  };

  const handleAddChecklistItem = () => {
    if (!checklistItem.trim()) return;
    setTemplateData({
      ...templateData,
      template_data: {
        ...templateData.template_data,
        checklist: [...(templateData.template_data.checklist || []), checklistItem],
      },
    });
    setChecklistItem("");
  };

  const handleRemoveChecklistItem = (index) => {
    setTemplateData({
      ...templateData,
      template_data: {
        ...templateData.template_data,
        checklist: templateData.template_data.checklist.filter((_, i) => i !== index),
      },
    });
  };

  const allAssignableUsers = users.filter(u => 
    u.department === 'mechanic' || 
    u.department === 'manager' || 
    u.department === 'front_counter' ||
    u.department === 'snack_bar' ||
    u.department === 'maintenance_crew'
  );

  const filteredTemplates = templates.filter(t => 
    selectedDepartment === 'all' || t.department === selectedDepartment || t.department === 'general'
  );

  // Filter and sort tasks
  const filteredAndSortedTasks = React.useMemo(() => {
    let filtered = scheduledTasks.filter(task => {
      const matchesSearch = !searchQuery || 
        task.task_title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.assigned_to?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
      const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;
      const matchesAssignee = assigneeFilter === 'all' || task.assigned_to === assigneeFilter;
      
      return matchesSearch && matchesStatus && matchesPriority && matchesAssignee;
    });

    // Sort
    const isDescending = sortBy.startsWith('-');
    const field = isDescending ? sortBy.slice(1) : sortBy;
    
    filtered.sort((a, b) => {
      let aVal = a[field];
      let bVal = b[field];
      
      if (field === 'priority') {
        const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        aVal = priorityOrder[aVal] || 0;
        bVal = priorityOrder[bVal] || 0;
      } else if (field === 'scheduled_date' || field === 'due_date') {
        aVal = new Date(aVal || 0).getTime();
        bVal = new Date(bVal || 0).getTime();
      }
      
      if (aVal < bVal) return isDescending ? 1 : -1;
      if (aVal > bVal) return isDescending ? -1 : 1;
      return 0;
    });

    return filtered;
  }, [scheduledTasks, searchQuery, statusFilter, priorityFilter, assigneeFilter, sortBy]);

  const handleTaskDrop = async (task, newDate) => {
    const newScheduledDate = new Date(newDate);
    newScheduledDate.setHours(new Date(task.scheduled_date).getHours());
    newScheduledDate.setMinutes(new Date(task.scheduled_date).getMinutes());
    
    await updateTaskMutation.mutateAsync({
      id: task.id,
      data: { scheduled_date: newScheduledDate.toISOString() }
    });
  };

  const handleBulkUpdate = async (updates) => {
    await Promise.all(
      selectedTasks.map(taskId => {
        const task = scheduledTasks.find(t => t.id === taskId);
        return updateTaskMutation.mutateAsync({ id: taskId, data: updates });
      })
    );
    setSelectedTasks([]);
  };

  const handleBulkDelete = () => {
    deleteTasksMutation.mutate(selectedTasks);
  };

  const toggleTaskSelection = (taskId) => {
    setSelectedTasks(prev => 
      prev.includes(taskId) ? prev.filter(id => id !== taskId) : [...prev, taskId]
    );
  };

  if (!user || (user.department !== 'manager' && user.role !== 'admin')) {
    return (
      <div className={`min-h-screen ${theme.bg} p-6`}>
        <Card>
          <CardContent className="p-12 text-center">
            <p className={theme.text}>Access restricted to managers and administrators.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme.bg} p-4 sm:p-6 lg:p-8`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${theme.text}`}>Task Scheduling</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Schedule tasks and manage templates
            </p>
          </div>
          <div className="flex gap-3">
            <Dialog open={templateDialogOpen} onOpenChange={(open) => {
              setTemplateDialogOpen(open);
              if (!open) {
                setEditingTemplate(null);
                resetTemplateForm();
              }
            }}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  Create Template
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingTemplate ? 'Edit' : 'Create'} Task Template</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleTemplateSubmit} className="space-y-4">
                  <div>
                    <Label>Template Name *</Label>
                    <Input
                      value={templateData.template_name}
                      onChange={(e) => setTemplateData({...templateData, template_name: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={templateData.description}
                      onChange={(e) => setTemplateData({...templateData, description: e.target.value})}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label>Department</Label>
                    <Select value={templateData.department} onValueChange={(v) => setTemplateData({...templateData, department: v})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General (All Departments)</SelectItem>
                        <SelectItem value="mechanic">Mechanic</SelectItem>
                        <SelectItem value="manager">Management</SelectItem>
                        <SelectItem value="front_counter">Front Counter</SelectItem>
                        <SelectItem value="snack_bar">Snack Bar</SelectItem>
                        <SelectItem value="maintenance_crew">Maintenance Crew</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Category</Label>
                    <Select value={templateData.category} onValueChange={(v) => setTemplateData({...templateData, category: v})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pinsetter">Pinsetter</SelectItem>
                        <SelectItem value="lane">Lane</SelectItem>
                        <SelectItem value="ball_return">Ball Return</SelectItem>
                        <SelectItem value="electrical">Electrical</SelectItem>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="safety">Safety</SelectItem>
                        <SelectItem value="building">Building</SelectItem>
                        <SelectItem value="front_of_house">Front of House</SelectItem>
                        <SelectItem value="food_service">Food Service</SelectItem>
                        <SelectItem value="cleaning">Cleaning</SelectItem>
                        <SelectItem value="administrative">Administrative</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Estimated Duration (minutes)</Label>
                    <Input
                      type="number"
                      value={templateData.estimated_duration}
                      onChange={(e) => setTemplateData({...templateData, estimated_duration: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="req-sig"
                      checked={templateData.requires_signature}
                      onCheckedChange={(c) => setTemplateData({...templateData, requires_signature: c})}
                    />
                    <Label htmlFor="req-sig">Requires Signature</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="req-photos"
                      checked={templateData.requires_photos}
                      onCheckedChange={(c) => setTemplateData({...templateData, requires_photos: c})}
                    />
                    <Label htmlFor="req-photos">Requires Photos</Label>
                  </div>
                  <div>
                    <Label>Default Assignee (Optional)</Label>
                    <Select 
                      value={templateData.template_data?.default_assignee || ""} 
                      onValueChange={(v) => setTemplateData({
                        ...templateData, 
                        template_data: { ...templateData.template_data, default_assignee: v }
                      })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select default assignee" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>None</SelectItem>
                        {allAssignableUsers.map(u => (
                          <SelectItem key={u.id} value={u.email}>
                            {u.full_name || u.email} {u.department && `(${u.department.replace(/_/g, ' ')})`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Checklist Items</Label>
                    <div className="flex gap-2 mb-2">
                      <Input
                        placeholder="Add checklist item..."
                        value={checklistItem}
                        onChange={(e) => setChecklistItem(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddChecklistItem())}
                      />
                      <Button type="button" size="sm" onClick={handleAddChecklistItem}>
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    {templateData.template_data?.checklist?.length > 0 && (
                      <div className="space-y-2 mt-2">
                        {templateData.template_data.checklist.map((item, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                            <span className="text-sm">{item}</span>
                            <Button 
                              type="button" 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => handleRemoveChecklistItem(index)}
                            >
                              ×
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={() => setTemplateDialogOpen(false)} className="flex-1">
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      <Save className="w-4 h-4 mr-2" />
                      {editingTemplate ? 'Update' : 'Create'} Template
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <CalendarPlus className="w-4 h-4 mr-2" />
                  Schedule Task
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Schedule New Task</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  {filteredTemplates.length > 0 && (
                    <div>
                      <Label>Use Template (Optional)</Label>
                      <Select onValueChange={(id) => {
                        const template = templates.find(t => t.id === id);
                        if (template) handleUseTemplate(template);
                      }}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a template to auto-fill" />
                        </SelectTrigger>
                        <SelectContent>
                          {filteredTemplates.map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.template_name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div>
                    <Label>Task Title *</Label>
                    <Input
                      value={formData.task_title}
                      onChange={(e) => setFormData({...formData, task_title: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label>Assign To *</Label>
                    <Select value={formData.assigned_to} onValueChange={(v) => setFormData({...formData, assigned_to: v})} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent>
                        {allAssignableUsers.map(u => (
                          <SelectItem key={u.id} value={u.email}>
                            {u.full_name || u.email} {u.department && `(${u.department.replace(/_/g, ' ')})`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Scheduled Date *</Label>
                      <Input
                        type="datetime-local"
                        value={formData.scheduled_date}
                        onChange={(e) => setFormData({...formData, scheduled_date: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <Label>Due Date</Label>
                      <Input
                        type="datetime-local"
                        value={formData.due_date}
                        onChange={(e) => setFormData({...formData, due_date: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Priority</Label>
                      <Select value={formData.priority} onValueChange={(v) => setFormData({...formData, priority: v})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Category</Label>
                      <Select value={formData.category} onValueChange={(v) => setFormData({...formData, category: v})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pinsetter">Pinsetter</SelectItem>
                          <SelectItem value="lane">Lane</SelectItem>
                          <SelectItem value="ball_return">Ball Return</SelectItem>
                          <SelectItem value="electrical">Electrical</SelectItem>
                          <SelectItem value="general">General</SelectItem>
                          <SelectItem value="safety">Safety</SelectItem>
                          <SelectItem value="building">Building</SelectItem>
                          <SelectItem value="front_of_house">Front of House</SelectItem>
                          <SelectItem value="food_service">Food Service</SelectItem>
                          <SelectItem value="cleaning">Cleaning</SelectItem>
                          <SelectItem value="administrative">Administrative</SelectItem>
                          </SelectContent>
                          </Select>
                          </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="signature"
                      checked={formData.requires_signature}
                      onCheckedChange={(c) => setFormData({...formData, requires_signature: c})}
                    />
                    <Label htmlFor="signature">Requires Signature Upon Completion</Label>
                  </div>
                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} className="flex-1">
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      <CalendarPlus className="w-4 h-4 mr-2" />
                      Schedule Task
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="schedule">Scheduled Tasks</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="schedule" className="mt-6 space-y-4">
            {/* Filters and View Toggle */}
            <div className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'} border rounded-lg p-4 space-y-4`}>
              <div className="flex flex-wrap gap-4 items-end">
                <div className="flex-1 min-w-[200px]">
                  <Label>Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Search tasks..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Priority</Label>
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Assignee</Label>
                  <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Assignees</SelectItem>
                      {allAssignableUsers.map(u => (
                        <SelectItem key={u.id} value={u.email}>{u.full_name || u.email}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Sort By</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-[160px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="-scheduled_date">Newest First</SelectItem>
                      <SelectItem value="scheduled_date">Oldest First</SelectItem>
                      <SelectItem value="-priority">Priority: High to Low</SelectItem>
                      <SelectItem value="priority">Priority: Low to High</SelectItem>
                      <SelectItem value="task_title">Title A-Z</SelectItem>
                      <SelectItem value="-task_title">Title Z-A</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'calendar' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('calendar')}
                  >
                    <Calendar className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {(searchQuery || statusFilter !== 'all' || priorityFilter !== 'all' || assigneeFilter !== 'all') && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-500">Showing {filteredAndSortedTasks.length} of {scheduledTasks.length} tasks</span>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={() => {
                      setSearchQuery("");
                      setStatusFilter("all");
                      setPriorityFilter("all");
                      setAssigneeFilter("all");
                    }}
                  >
                    Clear filters
                  </Button>
                </div>
              )}
            </div>

            {/* Calendar or List View */}
            {viewMode === 'calendar' ? (
              <TaskCalendarView
                tasks={filteredAndSortedTasks}
                onTaskClick={(task) => {
                  setQrTaskToShow(task);
                  setQrDialogOpen(true);
                }}
                onDateClick={(date) => {
                  setFormData({...formData, scheduled_date: format(date, "yyyy-MM-dd'T'HH:mm")});
                  setDialogOpen(true);
                }}
                onTaskDrop={handleTaskDrop}
                isDarkMode={isDarkMode}
              />
            ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAndSortedTasks.map(task => (
                <Card key={task.id} className={`${isDarkMode ? 'bg-slate-900 border-slate-800' : ''} ${selectedTasks.includes(task.id) ? 'ring-2 ring-blue-500' : ''}`}>
                  <CardHeader>
                    <div className="flex items-start gap-2">
                      <Checkbox
                        checked={selectedTasks.includes(task.id)}
                        onCheckedChange={() => toggleTaskSelection(task.id)}
                        onClick={(e) => e.stopPropagation()}
                      />
                      <CardTitle className="text-base flex-1">{task.task_title}</CardTitle>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <Badge>{task.priority}</Badge>
                      <Badge variant="outline">{task.status}</Badge>
                      {task.requires_signature && <Badge variant="secondary">Signature Required</Badge>}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-slate-600 mb-2">{task.description}</p>
                    <p className="text-xs text-slate-500">Assigned: {task.assigned_to}</p>
                    <p className="text-xs text-slate-500">Scheduled: {new Date(task.scheduled_date).toLocaleString()}</p>
                    {task.qr_code && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          setQrTaskToShow(task);
                          setQrDialogOpen(true);
                        }}
                      >
                        <QrCode className="w-4 h-4 mr-2" />
                        View QR Code
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
              {filteredAndSortedTasks.length === 0 && scheduledTasks.length > 0 && (
                <Card className="col-span-full">
                  <CardContent className="p-12 text-center">
                    <Filter className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-600">No tasks match your filters</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => {
                        setSearchQuery("");
                        setStatusFilter("all");
                        setPriorityFilter("all");
                        setAssigneeFilter("all");
                      }}
                    >
                      Clear filters
                    </Button>
                  </CardContent>
                </Card>
              )}
              {scheduledTasks.length === 0 && (
                <Card className="col-span-full">
                  <CardContent className="p-12 text-center">
                    <CalendarPlus className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-600">No scheduled tasks yet</p>
                  </CardContent>
                </Card>
              )}
            </div>
            )}
          </TabsContent>

          <TabsContent value="templates" className="mt-6">
            <div className="mb-4">
              <Label>Filter by Department</Label>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="max-w-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                  <SelectItem value="mechanic">Mechanic</SelectItem>
                  <SelectItem value="manager">Management</SelectItem>
                  <SelectItem value="front_counter">Front Counter</SelectItem>
                  <SelectItem value="snack_bar">Snack Bar</SelectItem>
                  <SelectItem value="maintenance_crew">Maintenance Crew</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTemplates.map(template => (
                <Card key={template.id} className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
                  <CardHeader>
                    <CardTitle className="text-base">{template.template_name}</CardTitle>
                    <div className="flex gap-2 flex-wrap mt-2">
                      {template.department && (
                        <Badge variant="default">
                          {template.department === 'general' ? 'All Departments' : template.department.replace(/_/g, ' ')}
                        </Badge>
                      )}
                      {template.category && <Badge variant="outline">{template.category}</Badge>}
                      {template.template_data?.default_assignee && (
                        <Badge variant="secondary" className="text-xs">
                          <Users className="w-3 h-3 mr-1" />
                          Default assignee
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-600 mb-3">{template.description}</p>
                    <div className="flex gap-2 flex-wrap mb-3">
                      {template.requires_signature && <Badge variant="outline" className="text-xs">Signature</Badge>}
                      {template.requires_photos && <Badge variant="outline" className="text-xs">Photos</Badge>}
                      {template.estimated_duration && <Badge variant="outline" className="text-xs">{template.estimated_duration}min</Badge>}
                      {template.template_data?.checklist?.length > 0 && (
                        <Badge variant="outline" className="text-xs">{template.template_data.checklist.length} items</Badge>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleUseTemplate(template)} className="flex-1">
                        <Plus className="w-4 h-4 mr-2" />
                        Use
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleEditTemplate(template)}>
                        Edit
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => {
                          if (confirm('Delete this template?')) {
                            deleteTemplateMutation.mutate(template.id);
                          }
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {filteredTemplates.length === 0 && (
                <Card className="col-span-full">
                  <CardContent className="p-12 text-center">
                    <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-600">No templates created yet</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <TaskQRCodeDisplay 
          task={qrTaskToShow}
          open={qrDialogOpen}
          onOpenChange={setQrDialogOpen}
        />

        <TaskBulkActions
          selectedTasks={selectedTasks}
          onBulkUpdate={handleBulkUpdate}
          onBulkDelete={handleBulkDelete}
          onClearSelection={() => setSelectedTasks([])}
          users={allAssignableUsers}
          isDarkMode={isDarkMode}
        />
      </div>
    </div>
  );
}