import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "../components/LocationContext";
import { useTheme } from "@/components/ThemeContext";
import { User, Award, Clock, TrendingUp, AlertTriangle, Target, ChevronDown, ChevronUp } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { ExportMenu } from "@/components/ExportMenu";

export default function TechnicianPerformance() {
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [dateRange, setDateRange] = useState('30');
  const [selectedTechnician, setSelectedTechnician] = useState('all');
  const [sortBy, setSortBy] = useState('completed');
  const [sortOrder, setSortOrder] = useState('desc');
  const { selectedLocationId } = useLocation();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: serviceCalls = [] } = useQuery({
    queryKey: ['serviceCalls'],
    queryFn: () => base44.entities.ServiceCall.list(),
    initialData: []
  });

  const { data: repairLogs = [] } = useQuery({
    queryKey: ['repairLogs'],
    queryFn: () => base44.entities.MachineRepairLog.list(),
    initialData: []
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  // Filter calls by location
  const filteredCalls = serviceCalls.filter((call) => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    return call.bowling_alley_id === effectiveLocationId;
  });

  const filteredLogs = repairLogs.filter((log) => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    return log.bowling_alley_id === effectiveLocationId;
  });

  // Filter by date range
  const daysAgo = parseInt(dateRange);
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysAgo);

  const recentCalls = filteredCalls.filter((call) =>
    new Date(call.created_date) >= cutoffDate
  );

  const recentLogs = filteredLogs.filter((log) =>
    new Date(log.created_date) >= cutoffDate
  );

  // Get all technicians (mechanics and managers)
  const technicians = allUsers.filter(u => 
    (u.department === 'mechanic' || u.department === 'manager') &&
    (isAdmin && selectedLocationId === 'all' || u.bowling_alley_id === effectiveLocationId)
  );

  // Calculate performance metrics for each technician
  const technicianMetrics = technicians.map(tech => {
    // Service Call metrics
    const assignedCalls = recentCalls.filter(c => c.assigned_to === tech.email);
    const completedCalls = assignedCalls.filter(c => c.status === 'completed' && c.completed_date);
    
    // Calculate average resolution time
    const avgResolutionHours = completedCalls.length > 0 ?
      completedCalls.reduce((sum, call) => {
        const created = new Date(call.created_date);
        const completed = new Date(call.completed_date);
        const hours = (completed - created) / (1000 * 60 * 60);
        return sum + hours;
      }, 0) / completedCalls.length : 0;

    // Resolution time by issue type
    const resolutionByIssueType = completedCalls.reduce((acc, call) => {
      const issueType = call.title.split(' - ')[0] || 'Other';
      if (!acc[issueType]) {
        acc[issueType] = { totalHours: 0, count: 0 };
      }
      const created = new Date(call.created_date);
      const completed = new Date(call.completed_date);
      const hours = (completed - created) / (1000 * 60 * 60);
      acc[issueType].totalHours += hours;
      acc[issueType].count += 1;
      return acc;
    }, {});

    const avgResolutionByType = Object.entries(resolutionByIssueType)
      .map(([issue, data]) => ({
        issue,
        avgHours: data.totalHours / data.count,
        count: data.count
      }))
      .sort((a, b) => b.count - a.count);

    // Repeat issues - issues that occurred on the same lane within 7 days after being marked completed
    const repeatIssues = completedCalls.filter(call => {
      const completedDate = new Date(call.completed_date);
      const sevenDaysLater = new Date(completedDate.getTime() + 7 * 24 * 60 * 60 * 1000);
      
      // Check if there's another call on the same lane with similar issue within 7 days
      return recentCalls.some(otherCall => 
        otherCall.id !== call.id &&
        otherCall.lane_number === call.lane_number &&
        new Date(otherCall.created_date) > completedDate &&
        new Date(otherCall.created_date) <= sevenDaysLater &&
        otherCall.title.split(' - ')[0] === call.title.split(' - ')[0]
      );
    });

    // Repair logs by this technician
    const techLogs = recentLogs.filter(log => log.created_by === tech.email);

    // Calculate average time spent from repair logs
    const logsWithTime = techLogs.filter(log => log.time_spent);
    const avgTimeSpent = logsWithTime.length > 0 ?
      logsWithTime.reduce((sum, log) => sum + log.time_spent, 0) / logsWithTime.length : 0;

    return {
      id: tech.id,
      name: tech.display_name || tech.full_name || tech.email,
      email: tech.email,
      department: tech.department,
      assigned: assignedCalls.length,
      completed: completedCalls.length,
      inProgress: assignedCalls.filter(c => c.status === 'in_progress').length,
      open: assignedCalls.filter(c => c.status === 'open').length,
      completionRate: assignedCalls.length > 0 
        ? ((completedCalls.length / assignedCalls.length) * 100).toFixed(1)
        : 0,
      avgResolutionHours: avgResolutionHours,
      avgResolutionByType,
      repeatIssues: repeatIssues.length,
      repeatRate: completedCalls.length > 0 
        ? ((repeatIssues.length / completedCalls.length) * 100).toFixed(1)
        : 0,
      repairLogsCount: techLogs.length,
      avgTimeSpentMinutes: avgTimeSpent,
      urgentCallsResolved: completedCalls.filter(c => c.priority === 'urgent').length
    };
  }).filter(m => m.assigned > 0 || m.repairLogsCount > 0);

  // Sort technicians
  const sortedTechnicians = [...technicianMetrics].sort((a, b) => {
    let aVal = a[sortBy];
    let bVal = b[sortBy];
    
    if (sortBy === 'completionRate' || sortBy === 'repeatRate') {
      aVal = parseFloat(aVal);
      bVal = parseFloat(bVal);
    }
    
    return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
  });

  // Filter by selected technician
  const displayedTechnicians = selectedTechnician === 'all' 
    ? sortedTechnicians 
    : sortedTechnicians.filter(t => t.email === selectedTechnician);

  // Aggregate data for charts
  const topPerformers = sortedTechnicians.slice(0, 5);
  
  // Comparison chart data
  const comparisonData = displayedTechnicians.map(tech => ({
    name: tech.name.split(' ')[0],
    completed: tech.completed,
    avgResolution: parseFloat(tech.avgResolutionHours.toFixed(1)),
    repeatRate: parseFloat(tech.repeatRate)
  }));

  const handleSort = (column) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  const getSortIcon = (column) => {
    if (sortBy !== column) return null;
    return sortOrder === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />;
  };

  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold flex items-center gap-3 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              <Award className="w-8 h-8 text-blue-600" />
              Technician Performance
            </h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Track repair efficiency, resolution times, and quality metrics
            </p>
          </div>
          <div className="flex gap-3">
            <Select value={selectedTechnician} onValueChange={setSelectedTechnician}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Technicians" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Technicians</SelectItem>
                {technicians.map(tech => (
                  <SelectItem key={tech.id} value={tech.email}>
                    {tech.display_name || tech.full_name || tech.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 Days</SelectItem>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 90 Days</SelectItem>
                <SelectItem value="365">Last Year</SelectItem>
              </SelectContent>
            </Select>
            <ExportMenu 
              data={displayedTechnicians}
              columns={[
                { header: 'Name', key: 'name' },
                { header: 'Email', key: 'email' },
                { header: 'Assigned', key: 'assigned' },
                { header: 'Completed', key: 'completed' },
                { header: 'Completion Rate (%)', key: 'completionRate' },
                { header: 'Avg Resolution (h)', key: 'avgResolutionHours' },
                { header: 'Repeat Rate (%)', key: 'repeatRate' },
                { header: 'Urgent Resolved', key: 'urgentCallsResolved' }
              ]}
              filename={`technician-performance-${dateRange}days`}
              title={`Technician Performance (Last ${dateRange} Days)`}
            />
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Active Technicians</p>
                  <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {technicianMetrics.length}
                  </p>
                </div>
                <User className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Total Completed</p>
                  <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {technicianMetrics.reduce((sum, t) => sum + t.completed, 0)}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Avg Resolution</p>
                  <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {technicianMetrics.length > 0 
                      ? (technicianMetrics.reduce((sum, t) => sum + t.avgResolutionHours, 0) / technicianMetrics.length).toFixed(1)
                      : 0}h
                  </p>
                </div>
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Repeat Issues</p>
                  <p className={`text-2xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {technicianMetrics.reduce((sum, t) => sum + t.repeatIssues, 0)}
                  </p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid grid-cols-2 lg:grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="detailed">Detailed Metrics</TabsTrigger>
            <TabsTrigger value="comparison">Comparison</TabsTrigger>
            <TabsTrigger value="quality">Quality</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Performance Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                        <TableHead className="font-semibold">Technician</TableHead>
                        <TableHead 
                          className="font-semibold cursor-pointer hover:bg-slate-100"
                          onClick={() => handleSort('completed')}
                        >
                          <div className="flex items-center gap-1">
                            Completed {getSortIcon('completed')}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="font-semibold cursor-pointer hover:bg-slate-100"
                          onClick={() => handleSort('avgResolutionHours')}
                        >
                          <div className="flex items-center gap-1">
                            Avg Time {getSortIcon('avgResolutionHours')}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="font-semibold cursor-pointer hover:bg-slate-100"
                          onClick={() => handleSort('completionRate')}
                        >
                          <div className="flex items-center gap-1">
                            Completion Rate {getSortIcon('completionRate')}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="font-semibold cursor-pointer hover:bg-slate-100"
                          onClick={() => handleSort('repeatRate')}
                        >
                          <div className="flex items-center gap-1">
                            Repeat Rate {getSortIcon('repeatRate')}
                          </div>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {displayedTechnicians.map((tech) => (
                        <TableRow key={tech.email}>
                          <TableCell className="font-medium">
                            <div>
                              <p className={isDarkMode ? 'text-slate-100' : ''}>{tech.name}</p>
                              <p className="text-xs text-slate-500">{tech.department}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">
                              {tech.completed}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <span className="font-semibold text-blue-600">
                              {tech.avgResolutionHours.toFixed(1)}h
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-slate-200 rounded-full h-2 max-w-[100px]">
                                <div 
                                  className="bg-green-600 h-2 rounded-full"
                                  style={{ width: `${tech.completionRate}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium">{tech.completionRate}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={
                              parseFloat(tech.repeatRate) < 10 
                                ? 'bg-green-100 text-green-800' 
                                : parseFloat(tech.repeatRate) < 20 
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-red-100 text-red-800'
                            }>
                              {tech.repeatRate}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {displayedTechnicians.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No performance data available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Detailed Metrics Tab */}
          <TabsContent value="detailed" className="space-y-6">
            {displayedTechnicians.map((tech) => (
              <Card key={tech.email} className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardHeader>
                  <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : ''}`}>
                    <User className="w-5 h-5 text-blue-600" />
                    {tech.name}
                  </CardTitle>
                  <p className="text-sm text-slate-500">{tech.email}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-xs font-medium text-blue-900 mb-1">Assigned</p>
                      <p className="text-2xl font-bold text-blue-700">{tech.assigned}</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <p className="text-xs font-medium text-green-900 mb-1">Completed</p>
                      <p className="text-2xl font-bold text-green-700">{tech.completed}</p>
                    </div>
                    <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                      <p className="text-xs font-medium text-orange-900 mb-1">In Progress</p>
                      <p className="text-2xl font-bold text-orange-700">{tech.inProgress}</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                      <p className="text-xs font-medium text-slate-900 mb-1">Open</p>
                      <p className="text-2xl font-bold text-slate-700">{tech.open}</p>
                    </div>
                  </div>

                  {tech.avgResolutionByType.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">Average Resolution Time by Issue Type</h4>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={tech.avgResolutionByType}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="issue" angle={-45} textAnchor="end" height={100} />
                          <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                          <Tooltip />
                          <Bar dataKey="avgHours" fill="#3b82f6" name="Avg Hours" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-slate-600 mb-1">Urgent Calls Resolved</p>
                      <p className="text-xl font-bold text-red-600">{tech.urgentCallsResolved}</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-slate-600 mb-1">Repair Logs</p>
                      <p className="text-xl font-bold text-purple-600">{tech.repairLogsCount}</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-slate-600 mb-1">Avg Time Spent</p>
                      <p className="text-xl font-bold text-blue-600">{tech.avgTimeSpentMinutes.toFixed(0)} min</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {displayedTechnicians.length === 0 && (
              <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
                <CardContent className="p-12 text-center">
                  <Target className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500">No detailed metrics available</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Comparison Tab */}
          <TabsContent value="comparison" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Completed Calls Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={comparisonData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="completed" fill="#10b981" name="Completed" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={isDarkMode ? 'text-slate-100' : ''}>Resolution Time vs Repeat Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={comparisonData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="avgResolution" stroke="#3b82f6" strokeWidth={2} name="Avg Resolution (h)" />
                    <Line yAxisId="right" type="monotone" dataKey="repeatRate" stroke="#f59e0b" strokeWidth={2} name="Repeat Rate (%)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Quality Tab */}
          <TabsContent value="quality" className="space-y-6">
            <Card className={`shadow-lg ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'border-slate-200'}`}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${isDarkMode ? 'text-slate-100' : ''}`}>
                  <Target className="w-5 h-5 text-blue-600" />
                  Repeat Issue Analysis
                </CardTitle>
                <p className="text-sm text-slate-500 mt-1">
                  Issues that recurred on the same lane within 7 days
                </p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className={isDarkMode ? 'border-slate-700' : 'bg-slate-50'}>
                        <TableHead className="font-semibold">Technician</TableHead>
                        <TableHead className="font-semibold">Total Completed</TableHead>
                        <TableHead className="font-semibold">Repeat Issues</TableHead>
                        <TableHead className="font-semibold">Repeat Rate</TableHead>
                        <TableHead className="font-semibold">Quality Score</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {displayedTechnicians.map((tech) => {
                        const qualityScore = Math.max(0, 100 - parseFloat(tech.repeatRate));
                        return (
                          <TableRow key={tech.email}>
                            <TableCell className="font-medium">
                              <div>
                                <p className={isDarkMode ? 'text-slate-100' : ''}>{tech.name}</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="bg-blue-50">
                                {tech.completed}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge className={
                                tech.repeatIssues === 0 
                                  ? 'bg-green-100 text-green-800'
                                  : tech.repeatIssues < 3
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-red-100 text-red-800'
                              }>
                                {tech.repeatIssues}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <span className={
                                parseFloat(tech.repeatRate) < 10 
                                  ? 'text-green-600 font-semibold'
                                  : parseFloat(tech.repeatRate) < 20
                                  ? 'text-yellow-600 font-semibold'
                                  : 'text-red-600 font-semibold'
                              }>
                                {tech.repeatRate}%
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div className="flex-1 bg-slate-200 rounded-full h-2 max-w-[100px]">
                                  <div 
                                    className={`h-2 rounded-full ${
                                      qualityScore >= 90 ? 'bg-green-600' :
                                      qualityScore >= 80 ? 'bg-yellow-600' :
                                      'bg-red-600'
                                    }`}
                                    style={{ width: `${qualityScore}%` }}
                                  />
                                </div>
                                <span className="text-sm font-medium">{qualityScore.toFixed(0)}</span>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>

                {displayedTechnicians.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No quality data available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}