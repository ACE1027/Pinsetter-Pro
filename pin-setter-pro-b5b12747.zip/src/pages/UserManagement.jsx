import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Users, Search, Shield, AlertCircle, UserPlus } from "lucide-react";
import UserCard from "../components/users/UserCard";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "../components/LocationContext";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useTheme } from "@/components/ThemeContext";
import AdvancedPermissionEditor from "@/components/permissions/AdvancedPermissionEditor";
import PermissionPresets from "@/components/permissions/PermissionPresets";

const positionHierarchy = [
  { value: "general_manager", label: "General Manager", level: 1 },
  { value: "service_manager", label: "Service Manager", level: 2 },
  { value: "assistant_manager", label: "Assistant Manager", level: 3 },
  { value: "senior_mechanic", label: "Senior Mechanic", level: 4 },
  { value: "lead_mechanic", label: "Lead Mechanic", level: 5 },
  { value: "mechanic", label: "Mechanic", level: 6 },
  { value: "mechanic_apprentice", label: "Mechanic Apprentice", level: 7 },
  { value: "front_desk_supervisor", label: "Front Desk Supervisor", level: 8 },
  { value: "front_desk_staff", label: "Front Desk Staff", level: 9 },
];

const defaultPermissions = {
  can_create_service_calls: true,
  can_edit_service_calls: true,
  can_complete_service_calls: true,
  can_assign_work: false,
  can_manage_inventory: false,
  can_view_all_locations: false,
  can_manage_users: false,
  can_manage_locations: false,
};

export default function UserManagement() {
  const queryClient = useQueryClient();
  const { theme, isDarkMode } = useTheme();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("active");
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [permissionTab, setPermissionTab] = useState("presets");
  const { selectedLocationId } = useLocation();
  const [formData, setFormData] = useState({
    display_name: "",
    phone: "",
    department: "",
    position: "",
    roles: [],
    bowling_alley_id: "",
    bowling_alley_ids: [],
    hire_date: "",
    active: true,
    permissions: { ...defaultPermissions },
    custom_permissions: [],
    role_id: "",
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allUsers = [], isLoading } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const { data: systemRoles = [] } = useQuery({
    queryKey: ['systemRoles'],
    queryFn: () => base44.entities.Role.list(),
    initialData: [],
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.User.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allUsers'] });
      setEditDialogOpen(false);
      setEditingUser(null);
      toast.success("User updated successfully");
    },
  });

  const isAdmin = user && user.role === 'admin';
  const isManager = user && user.department === 'manager';
  
  // Check if user is lead mechanic or higher (level 5 or lower in hierarchy)
  const userPositionLevel = user?.position ? positionHierarchy.find(p => p.value === user.position)?.level : 999;
  const isLeadOrHigher = userPositionLevel <= 5;
  
  // All users can view, but only certain roles can manage
  const canManage = isAdmin || isManager || isLeadOrHigher;
  const canView = true; // All users can view their location's staff

  // Determine which location's users to show - regular users can't access this page anyway
  // Managers see ONLY their location, admins can switch
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  // Filter users - strict location-based access
  const users = isAdmin 
    ? (selectedLocationId === 'all'
        ? allUsers  // Admin viewing all
        : allUsers.filter(u => u.bowling_alley_id === effectiveLocationId))  // Admin viewing specific location
    : allUsers.filter(u => u.bowling_alley_id === user?.bowling_alley_id);  // Managers see only their location

  const filteredUsers = users.filter(u => {
    const matchesDepartment = departmentFilter === 'all' || u.department === departmentFilter;
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'active' && u.active !== false) ||
      (statusFilter === 'inactive' && u.active === false);
    
    // Enhanced search - include location name, position, and department
    const matchesSearch = !searchQuery || (() => {
      const query = searchQuery.toLowerCase();
      
      // Get location name for this user
      const userLocation = locations.find(l => l.id === u.bowling_alley_id);
      const locationName = userLocation?.name?.toLowerCase() || '';
      
      // Get position label
      const positionLabel = positionHierarchy.find(p => p.value === u.position)?.label?.toLowerCase() || '';
      const positionValue = u.position?.toLowerCase().replace(/_/g, ' ') || '';
      
      // Get department
      const department = u.department?.toLowerCase().replace(/_/g, ' ') || '';
      
      return (
        u.full_name?.toLowerCase().includes(query) ||
        u.email?.toLowerCase().includes(query) ||
        u.phone?.includes(query) ||
        locationName.includes(query) ||
        positionLabel.includes(query) ||
        positionValue.includes(query) ||
        department.includes(query)
      );
    })();
    
    return matchesDepartment && matchesSearch && matchesStatus;
  });

  const handleEdit = (userToEdit) => {
    setEditingUser(userToEdit);
    setFormData({
      display_name: userToEdit.display_name || "",
      phone: userToEdit.phone || "",
      department: userToEdit.department || "",
      position: userToEdit.position || "",
      roles: userToEdit.roles || [],
      bowling_alley_id: userToEdit.bowling_alley_id || "",
      bowling_alley_ids: userToEdit.bowling_alley_ids || [],
      hire_date: userToEdit.hire_date || "",
      active: userToEdit.active !== false,
      permissions: userToEdit.permissions || { ...defaultPermissions },
      custom_permissions: userToEdit.custom_permissions || [],
      role_id: userToEdit.role_id || "",
    });
    setEditDialogOpen(true);
  };

  // This handleToggleActive is for the UserCard, allowing direct activation/deactivation without opening the dialog
  const handleToggleActive = (userToToggle) => {
    if (userToToggle.id === user?.id) {
      toast.error("You cannot deactivate your own account");
      return;
    }
    
    const newStatus = !userToToggle.active || userToToggle.active === false;
    updateUserMutation.mutate({
      id: userToToggle.id,
      data: { active: newStatus }
    });
  };

  // This handleToggleActiveStatusInDialog is for the Edit User Dialog itself, updating formData locally
  const handleToggleActiveStatusInDialog = () => {
    if (editingUser.id === user?.id) {
      toast.error("You cannot deactivate your own account");
      return;
    }
    
    const newStatus = !formData.active;
    setFormData(prev => ({ ...prev, active: newStatus }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateUserMutation.mutate({
      id: editingUser.id,
      data: formData
    });
  };

  const handleChange = (field, value) => {
    setFormData(prev => {
      const newState = { ...prev };

      if (field === 'bowling_alley_id') {
        newState[field] = value === "" ? null : value;
      } else {
        newState[field] = value;
      }
      
      return newState;
    });
  };

  const handlePermissionChange = (permission, value) => {
    setFormData(prev => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [permission]: value
      }
    }));
  };

  const departmentCounts = {
    all: users.length,
    manager: users.filter(u => u.department === 'manager').length,
    mechanic: users.filter(u => u.department === 'mechanic').length,
    front_desk: users.filter(u => u.department === 'front_desk').length,
  };

  const activeCount = users.filter(u => u.active !== false).length;
  const inactiveCount = users.filter(u => u.active === false).length;

  // Filter locations for managers - only show their assigned location
  const visibleLocations = isAdmin 
    ? locations 
    : locations.filter(l => l.id === user?.bowling_alley_id);

  const selectedLocation = locations.find(l => l.id === effectiveLocationId);

  // Determine if the current user can manage the user being edited in the dialog
  const canManageUser = isAdmin || (user?.bowling_alley_id === editingUser?.bowling_alley_id);


  return (
    <div className={`min-h-screen p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>User Management</h1>
            <p className={`mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              {isAdmin 
                ? (selectedLocation ? `${selectedLocation.name} - Manage staff` : 'Manage staff, roles, and permissions')
                : `Manage staff at your location`}
            </p>
          </div>
          <div className="flex gap-3 items-center">
            {isAdmin && (
              <Alert className="bg-blue-50 border-blue-200 max-w-md">
                <AlertCircle className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-900 text-sm">
                  Admin access: Full control over users and permissions
                </AlertDescription>
              </Alert>
            )}
            {!canManage && (
              <Alert className="bg-slate-100 border-slate-300 max-w-md">
                <AlertCircle className="h-4 w-4 text-slate-600" />
                <AlertDescription className="text-slate-700 text-sm">
                  View-only access: You can view staff at your location
                </AlertDescription>
              </Alert>
            )}
            {canManage && (
              <Link to={createPageUrl("InviteUser")}>
                <Button className="bg-green-600 hover:bg-green-700 shadow-lg">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Invite User
                </Button>
              </Link>
            )}
          </div>
        </div>

        {/* Organizational Hierarchy */}
        <Card className="mb-6 bg-gradient-to-br from-blue-50 to-slate-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Users className="w-5 h-5" />
              Organizational Hierarchy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {positionHierarchy.map((pos, idx) => (
                <div key={pos.value} className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-semibold">
                    {pos.level}
                  </div>
                  <span className="text-sm text-slate-700">{pos.label}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by name, email, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Tabs value={departmentFilter} onValueChange={setDepartmentFilter} className="w-full lg:w-auto">
              <TabsList className="grid grid-cols-4 w-full lg:w-auto">
                <TabsTrigger value="all">All ({departmentCounts.all})</TabsTrigger>
                <TabsTrigger value="manager">Managers ({departmentCounts.manager})</TabsTrigger>
                <TabsTrigger value="mechanic">Mechanics ({departmentCounts.mechanic})</TabsTrigger>
                <TabsTrigger value="front_desk">Front Desk ({departmentCounts.front_desk})</TabsTrigger>
              </TabsList>
            </Tabs>
            <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-full lg:w-auto">
              <TabsList className="grid grid-cols-3 w-full lg:w-auto">
                <TabsTrigger value="active">Active ({activeCount})</TabsTrigger>
                <TabsTrigger value="inactive">Inactive ({inactiveCount})</TabsTrigger>
                <TabsTrigger value="all">All</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Users Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="h-48 bg-white rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredUsers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredUsers.map(u => (
              <UserCard 
                key={u.id} 
                user={u} 
                onEdit={canManage ? handleEdit : undefined}
                onToggleActive={canManage ? handleToggleActive : undefined}
                locations={locations}
                currentUser={user}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg border-2 border-dashed border-slate-300 p-12 text-center">
            <Users className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No users found</h3>
            <p className="text-slate-600">Try adjusting your filters</p>
          </div>
        )}

        {/* Edit User Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                Edit User
                {editingUser?.role === 'admin' && (
                  <Badge className="bg-red-100 text-red-800 border-red-300">Admin</Badge>
                )}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="display_name">Display Name</Label>
                <Input
                  id="display_name"
                  value={formData.display_name}
                  onChange={(e) => handleChange('display_name', e.target.value)}
                  placeholder="Enter display name"
                />
                <p className="text-xs text-slate-500">This name will be shown throughout the app</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bowling_alley_id">Primary Location</Label>
                <Select 
                  value={formData.bowling_alley_id || ""} 
                  onValueChange={(value) => handleChange('bowling_alley_id', value)}
                  disabled={!isAdmin && user?.position !== 'general_manager'}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select primary location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>No location assigned</SelectItem>
                    {visibleLocations.filter(l => l.active !== false).map(location => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!isAdmin && user?.position !== 'general_manager' && (
                  <p className="text-xs text-slate-500">
                    Only general managers and admins can change locations
                  </p>
                )}
                {(isAdmin || user?.position === 'general_manager') && (
                  <p className="text-xs text-slate-500">
                    This location will be auto-selected when the user logs in
                  </p>
                )}
              </div>

              {(isAdmin || user?.department === 'manager') && (
                <div className="space-y-2">
                  <Label>Additional Locations</Label>
                  <div className="border border-slate-200 rounded-lg p-4 max-h-64 overflow-y-auto">
                    <div className="space-y-2">
                      {visibleLocations.filter(l => l.active !== false).map(location => (
                        <div key={location.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`location-${location.id}`}
                            checked={formData.bowling_alley_ids?.includes(location.id) || false}
                            onCheckedChange={(checked) => {
                              setFormData(prev => ({
                                ...prev,
                                bowling_alley_ids: checked
                                  ? [...(prev.bowling_alley_ids || []), location.id]
                                  : (prev.bowling_alley_ids || []).filter(id => id !== location.id)
                              }));
                            }}
                          />
                          <Label htmlFor={`location-${location.id}`} className="text-sm cursor-pointer flex-1">
                            {location.name}
                            {location.id === formData.bowling_alley_id && (
                              <Badge variant="outline" className="ml-2 text-xs">Primary</Badge>
                            )}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-slate-500">
                    Select all locations this employee can work at. They will be able to view and manage service calls, inventory, and other data from these locations.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="position">Primary Position</Label>
                  <Select value={formData.position} onValueChange={(value) => handleChange('position', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select primary position" />
                    </SelectTrigger>
                    <SelectContent>
                      {positionHierarchy.map(pos => (
                        <SelectItem key={pos.value} value={pos.value}>
                          {pos.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Select value={formData.department} onValueChange={(value) => handleChange('department', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="mechanic">Mechanic</SelectItem>
                      <SelectItem value="front_desk">Front Desk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Role Selection */}
              <div className="space-y-2">
                <Label htmlFor="role_id">Permission Role</Label>
                <Select value={formData.role_id || ""} onValueChange={(value) => handleChange('role_id', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role (determines permissions)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>No role assigned</SelectItem>
                    {systemRoles.filter(r => r.active !== false).map(role => (
                      <SelectItem key={role.id} value={role.id}>
                        <div className="flex items-center gap-2">
                          <Shield className="w-3 h-3" />
                          {role.name}
                          {role.is_system_role && (
                            <Badge variant="outline" className="text-xs">System</Badge>
                          )}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  {formData.role_id 
                    ? `This role grants ${systemRoles.find(r => r.id === formData.role_id)?.permission_keys?.length || 0} permissions`
                    : "Assign a role to grant permissions to this user"}
                </p>
              </div>

              <div className="space-y-2">
                <Label>Additional Roles</Label>
                <div className="border border-slate-200 rounded-lg p-4 max-h-48 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-3">
                    {positionHierarchy.map(pos => (
                      <div key={pos.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={`role-${pos.value}`}
                          checked={formData.roles?.includes(pos.value) || false}
                          onCheckedChange={(checked) => {
                            setFormData(prev => ({
                              ...prev,
                              roles: checked
                                ? [...(prev.roles || []), pos.value]
                                : (prev.roles || []).filter(r => r !== pos.value)
                            }));
                          }}
                        />
                        <Label htmlFor={`role-${pos.value}`} className="text-sm cursor-pointer">
                          {pos.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Select all roles this user can work in when scheduled
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="(555) 123-4567"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hire_date">Hire Date</Label>
                  <Input
                    id="hire_date"
                    type="date"
                    value={formData.hire_date}
                    onChange={(e) => handleChange('hire_date', e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="active">Account Status</Label>
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${formData.active ? 'bg-green-500' : 'bg-red-500'}`} />
                      <span className="font-medium">{formData.active ? 'Active' : 'Inactive'}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      {formData.active ? 'User can access the system' : 'User cannot access the system'}
                    </p>
                  </div>
                  {editingUser?.id !== user?.id && canManageUser && (
                    <Button
                      type="button"
                      variant={formData.active ? "destructive" : "default"}
                      onClick={handleToggleActiveStatusInDialog}
                      size="sm"
                    >
                      {formData.active ? 'Deactivate Account' : 'Activate Account'}
                    </Button>
                  )}
                </div>
                {editingUser?.id === user?.id && (
                  <p className="text-xs text-slate-500">You cannot deactivate your own account</p>
                )}
              </div>

              {/* Permissions Section - Only for admins */}
              {isAdmin && (
                <Accordion type="single" collapsible className="w-full" defaultValue="permissions">
                  <AccordionItem value="permissions" className="border border-slate-200 rounded-lg px-4">
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-blue-600" />
                        <span className="font-semibold">Permissions & Access Control</span>
                        <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                          {(formData.custom_permissions || []).length} permissions
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pt-4">
                      <Tabs value={permissionTab} onValueChange={setPermissionTab}>
                        <TabsList className="grid w-full grid-cols-3 mb-4">
                          <TabsTrigger value="presets">Quick Presets</TabsTrigger>
                          <TabsTrigger value="custom">Custom Permissions</TabsTrigger>
                          <TabsTrigger value="legacy">Legacy Settings</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="presets">
                          <Alert className="mb-4 bg-blue-50 border-blue-200">
                            <Shield className="h-4 w-4 text-blue-600" />
                            <AlertDescription className="text-blue-900 text-sm">
                              Apply a preset to the user's assigned role, or select a role above to use pre-configured permissions.
                            </AlertDescription>
                          </Alert>
                          <PermissionPresets
                            currentPermissions={formData.custom_permissions || []}
                            onApplyPreset={(permissions) => 
                              setFormData(prev => ({ ...prev, custom_permissions: permissions }))
                            }
                          />
                        </TabsContent>
                        
                        <TabsContent value="custom">
                          <Alert className="mb-4 bg-amber-50 border-amber-200">
                            <AlertCircle className="h-4 w-4 text-amber-600" />
                            <AlertDescription className="text-amber-900 text-sm">
                              Custom permissions are added on top of the role's permissions. Use this to grant additional specific permissions to this user.
                            </AlertDescription>
                          </Alert>
                          {formData.role_id && (
                            <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                              <p className="text-sm text-blue-900">
                                <strong>Current Role:</strong> {systemRoles.find(r => r.id === formData.role_id)?.name}
                                <span className="ml-2 text-blue-700">
                                  ({systemRoles.find(r => r.id === formData.role_id)?.permission_keys?.length || 0} base permissions)
                                </span>
                              </p>
                            </div>
                          )}
                          <AdvancedPermissionEditor
                            permissions={formData.custom_permissions || []}
                            onChange={(permissions) => 
                              setFormData(prev => ({ ...prev, custom_permissions: permissions }))
                            }
                          />
                        </TabsContent>
                        
                        <TabsContent value="legacy">
                          <Alert className="mb-4 bg-amber-50 border-amber-200">
                            <AlertCircle className="h-4 w-4 text-amber-600" />
                            <AlertDescription className="text-amber-900 text-sm">
                              Legacy permission toggles. Consider using the new permission system above for better control.
                            </AlertDescription>
                          </Alert>
                      <div className="space-y-4">
                        <div className="space-y-3">
                          <h4 className="text-sm font-semibold text-slate-700">Service Call Permissions</h4>
                          <div className="space-y-2 pl-4">
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_create_service_calls"
                                checked={formData.permissions?.can_create_service_calls || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_create_service_calls', checked)}
                              />
                              <Label htmlFor="can_create_service_calls" className="text-sm cursor-pointer">
                                Can create new service calls
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_edit_service_calls"
                                checked={formData.permissions?.can_edit_service_calls || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_edit_service_calls', checked)}
                              />
                              <Label htmlFor="can_edit_service_calls" className="text-sm cursor-pointer">
                                Can edit service calls
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_complete_service_calls"
                                checked={formData.permissions?.can_complete_service_calls || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_complete_service_calls', checked)}
                              />
                              <Label htmlFor="can_complete_service_calls" className="text-sm cursor-pointer">
                                Can mark service calls as completed
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_assign_work"
                                checked={formData.permissions?.can_assign_work || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_assign_work', checked)}
                              />
                              <Label htmlFor="can_assign_work" className="text-sm cursor-pointer">
                                Can assign work to other users
                              </Label>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className="text-sm font-semibold text-slate-700">Inventory Permissions</h4>
                          <div className="space-y-2 pl-4">
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_manage_inventory"
                                checked={formData.permissions?.can_manage_inventory || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_manage_inventory', checked)}
                              />
                              <Label htmlFor="can_manage_inventory" className="text-sm cursor-pointer">
                                Can add, edit, and delete parts in inventory
                              </Label>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className="text-sm font-semibold text-slate-700">Administrative Permissions</h4>
                          <div className="space-y-2 pl-4">
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_view_all_locations"
                                checked={formData.permissions?.can_view_all_locations || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_view_all_locations', checked)}
                              />
                              <Label htmlFor="can_view_all_locations" className="text-sm cursor-pointer">
                                Can view data from all locations
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_manage_users"
                                checked={formData.permissions?.can_manage_users || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_manage_users', checked)}
                              />
                              <Label htmlFor="can_manage_users" className="text-sm cursor-pointer">
                                Can manage user accounts
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="can_manage_locations"
                                checked={formData.permissions?.can_manage_locations || false}
                                onCheckedChange={(checked) => handlePermissionChange('can_manage_locations', checked)}
                              />
                              <Label htmlFor="can_manage_locations" className="text-sm cursor-pointer">
                                Can manage bowling alley locations
                              </Label>
                            </div>
                          </div>
                        </div>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}

              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-600">
                  <strong>Email:</strong> {editingUser?.email}
                </p>
                <p className="text-sm text-slate-500 mt-2">
                  Note: Email addresses cannot be changed. Users must be invited with the correct email.
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setEditDialogOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateUserMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}