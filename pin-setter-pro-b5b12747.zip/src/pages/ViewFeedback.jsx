import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star, MessageSquare, Search, Filter } from "lucide-react";
import { useTheme } from "@/components/ThemeContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "@/components/LocationContext";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ViewFeedback() {
  const { theme, isDarkMode } = useTheme();
  const { selectedLocationId } = useLocation();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const [responseText, setResponseText] = useState("");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: allFeedback = [] } = useQuery({
    queryKey: ['customerFeedback'],
    queryFn: () => base44.entities.CustomerFeedback.list('-created_date'),
    initialData: [],
    refetchInterval: 30000,
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.BowlingAlley.list(),
    initialData: [],
  });

  const isAdmin = user && user.role === 'admin';
  const effectiveLocationId = isAdmin && selectedLocationId && selectedLocationId !== 'all' 
    ? selectedLocationId 
    : user?.bowling_alley_id;

  const accessibleFeedback = allFeedback.filter(fb => {
    if (!user) return false;
    if (isAdmin && selectedLocationId === 'all') return true;
    if (effectiveLocationId && fb.bowling_alley_id === effectiveLocationId) return true;
    return false;
  });

  const filteredFeedback = accessibleFeedback.filter(fb => {
    const matchesStatus = statusFilter === 'all' || fb.status === statusFilter;
    const matchesSearch = !searchQuery || 
      fb.customer_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fb.feedback_text?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const respondMutation = useMutation({
    mutationFn: ({ id, response }) => base44.entities.CustomerFeedback.update(id, {
      response,
      responded_by: user.email,
      responded_date: new Date().toISOString(),
      status: 'responded'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customerFeedback'] });
      setSelectedFeedback(null);
      setResponseText("");
      toast.success("Response sent successfully");
    }
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.CustomerFeedback.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customerFeedback'] });
      toast.success("Status updated");
    }
  });

  const getLocationName = (locationId) => {
    return locations.find(l => l.id === locationId)?.name || "Unknown";
  };

  const statusCounts = {
    all: accessibleFeedback.length,
    new: accessibleFeedback.filter(f => f.status === 'new').length,
    reviewed: accessibleFeedback.filter(f => f.status === 'reviewed').length,
    responded: accessibleFeedback.filter(f => f.status === 'responded').length,
    resolved: accessibleFeedback.filter(f => f.status === 'resolved').length,
  };

  const averageRating = accessibleFeedback.length > 0 
    ? (accessibleFeedback.reduce((sum, f) => sum + f.rating, 0) / accessibleFeedback.length).toFixed(1)
    : 0;

  return (
    <div className={`min-h-screen p-4 sm:p-6 lg:p-8 ${theme.bg}`}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className={`text-3xl font-bold ${theme.text}`}>Customer Feedback</h1>
          <p className={`mt-1 ${theme.textSecondary}`}>View and respond to customer feedback</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">Total Feedback</CardTitle>
            </CardHeader>
            <CardContent>
              <span className={`text-3xl font-bold ${theme.text}`}>{accessibleFeedback.length}</span>
            </CardContent>
          </Card>

          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">Average Rating</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold ${theme.text}`}>{averageRating}</span>
                <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className={isDarkMode ? 'bg-slate-900 border-slate-800' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-500">Needs Response</CardTitle>
            </CardHeader>
            <CardContent>
              <span className={`text-3xl font-bold ${statusCounts.new > 0 ? 'text-red-600' : theme.text}`}>
                {statusCounts.new}
              </span>
            </CardContent>
          </Card>
        </div>

        <Card className={`mb-6 ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search feedback..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Tabs value={statusFilter} onValueChange={setStatusFilter} className="mt-4">
              <TabsList className="w-full grid grid-cols-5">
                <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
                <TabsTrigger value="new">New ({statusCounts.new})</TabsTrigger>
                <TabsTrigger value="reviewed">Reviewed ({statusCounts.reviewed})</TabsTrigger>
                <TabsTrigger value="responded">Responded ({statusCounts.responded})</TabsTrigger>
                <TabsTrigger value="resolved">Resolved ({statusCounts.resolved})</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {filteredFeedback.map(feedback => (
            <Card 
              key={feedback.id} 
              className={`cursor-pointer hover:shadow-lg transition-all ${isDarkMode ? 'bg-slate-900 border-slate-800' : ''}`}
              onClick={() => setSelectedFeedback(feedback)}
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className={`font-semibold ${theme.text}`}>{feedback.customer_name}</h3>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-4 h-4 ${i < feedback.rating ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'}`}
                          />
                        ))}
                      </div>
                      <Badge className={
                        feedback.status === 'new' ? 'bg-red-100 text-red-800' :
                        feedback.status === 'reviewed' ? 'bg-blue-100 text-blue-800' :
                        feedback.status === 'responded' ? 'bg-green-100 text-green-800' :
                        'bg-slate-100 text-slate-800'
                      }>
                        {feedback.status}
                      </Badge>
                    </div>
                    <p className={`text-sm ${theme.textTertiary} mb-2`}>
                      {feedback.feedback_type} • {format(new Date(feedback.created_date), 'MMM d, yyyy')}
                    </p>
                    {isAdmin && (
                      <p className="text-xs text-slate-500 mb-2">{getLocationName(feedback.bowling_alley_id)}</p>
                    )}
                    <p className={theme.textSecondary}>{feedback.feedback_text}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Dialog open={!!selectedFeedback} onOpenChange={(open) => !open && setSelectedFeedback(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Feedback Details</DialogTitle>
            </DialogHeader>
            {selectedFeedback && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Customer Information</h3>
                  <p><strong>Name:</strong> {selectedFeedback.customer_name}</p>
                  {selectedFeedback.customer_email && <p><strong>Email:</strong> {selectedFeedback.customer_email}</p>}
                  {selectedFeedback.customer_phone && <p><strong>Phone:</strong> {selectedFeedback.customer_phone}</p>}
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Feedback</h3>
                  <div className="flex items-center gap-2 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-5 h-5 ${i < selectedFeedback.rating ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'}`}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-slate-500 mb-2">Category: {selectedFeedback.feedback_type}</p>
                  <p>{selectedFeedback.feedback_text}</p>
                </div>

                {selectedFeedback.response && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Your Response</h3>
                    <p>{selectedFeedback.response}</p>
                    <p className="text-xs text-slate-500 mt-2">
                      Responded by {selectedFeedback.responded_by} on {format(new Date(selectedFeedback.responded_date), 'MMM d, yyyy')}
                    </p>
                  </div>
                )}

                {!selectedFeedback.response && (
                  <div className="space-y-3">
                    <Label>Send Response</Label>
                    <Textarea
                      rows={4}
                      placeholder="Type your response..."
                      value={responseText}
                      onChange={(e) => setResponseText(e.target.value)}
                    />
                    <Button 
                      onClick={() => respondMutation.mutate({ id: selectedFeedback.id, response: responseText })}
                      disabled={!responseText || respondMutation.isPending}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Send Response
                    </Button>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    onClick={() => updateStatusMutation.mutate({ id: selectedFeedback.id, status: 'reviewed' })}
                    disabled={selectedFeedback.status === 'reviewed'}
                  >
                    Mark as Reviewed
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => updateStatusMutation.mutate({ id: selectedFeedback.id, status: 'resolved' })}
                    disabled={selectedFeedback.status === 'resolved'}
                  >
                    Mark as Resolved
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}