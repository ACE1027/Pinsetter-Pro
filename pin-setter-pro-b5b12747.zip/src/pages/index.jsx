import Layout from "./Layout.jsx";

import A2CallSheet from "./A2CallSheet";

import AdminDashboard from "./AdminDashboard";

import Analytics from "./Analytics";

import BuildingMaintenance from "./BuildingMaintenance";

import CompleteProfile from "./CompleteProfile";

import CreateServiceCall from "./CreateServiceCall";

import CustomerFeedback from "./CustomerFeedback";

import Dashboard from "./Dashboard";

import DashboardSettings from "./DashboardSettings";

import Discussion from "./Discussion";

import EmployeeDashboard from "./EmployeeDashboard";

import EmployeeProfile from "./EmployeeProfile";

import GSXCallSheet from "./GSXCallSheet";

import HelpResources from "./HelpResources";

import Home from "./Home";

import InitializePermissions from "./InitializePermissions";

import InviteUser from "./InviteUser";

import JetbackCallSheet from "./JetbackCallSheet";

import Locations from "./Locations";

import MachineCallSheet from "./MachineCallSheet";

import MachineDetail from "./MachineDetail";

import MachineInventory from "./MachineInventory";

import MachineRepairLog from "./MachineRepairLog";

import ManagerDashboard from "./ManagerDashboard";

import MechanicsDashboard from "./MechanicsDashboard";

import MobileMechanicHub from "./MobileMechanicHub";

import MyTasks from "./MyTasks";

import OnboardingDetail from "./OnboardingDetail";

import OriginalACallSheet from "./OriginalACallSheet";

import PartsInventory from "./PartsInventory";

import PerformanceReview from "./PerformanceReview";

import PreventativeMaintenance from "./PreventativeMaintenance";

import Profile from "./Profile";

import RoleManagement from "./RoleManagement";

import Schedule from "./Schedule";

import ScheduledMaintenance from "./ScheduledMaintenance";

import SendUpdateNotification from "./SendUpdateNotification";

import ServiceCallDetail from "./ServiceCallDetail";

import ServiceCallHistory from "./ServiceCallHistory";

import ServiceCalls from "./ServiceCalls";

import StaffDirectory from "./StaffDirectory";

import StringPinCallSheet from "./StringPinCallSheet";

import TaskScheduling from "./TaskScheduling";

import TechnicianPerformance from "./TechnicianPerformance";

import UserManagement from "./UserManagement";

import ViewFeedback from "./ViewFeedback";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    A2CallSheet: A2CallSheet,
    
    AdminDashboard: AdminDashboard,
    
    Analytics: Analytics,
    
    BuildingMaintenance: BuildingMaintenance,
    
    CompleteProfile: CompleteProfile,
    
    CreateServiceCall: CreateServiceCall,
    
    CustomerFeedback: CustomerFeedback,
    
    Dashboard: Dashboard,
    
    DashboardSettings: DashboardSettings,
    
    Discussion: Discussion,
    
    EmployeeDashboard: EmployeeDashboard,
    
    EmployeeProfile: EmployeeProfile,
    
    GSXCallSheet: GSXCallSheet,
    
    HelpResources: HelpResources,
    
    Home: Home,
    
    InitializePermissions: InitializePermissions,
    
    InviteUser: InviteUser,
    
    JetbackCallSheet: JetbackCallSheet,
    
    Locations: Locations,
    
    MachineCallSheet: MachineCallSheet,
    
    MachineDetail: MachineDetail,
    
    MachineInventory: MachineInventory,
    
    MachineRepairLog: MachineRepairLog,
    
    ManagerDashboard: ManagerDashboard,
    
    MechanicsDashboard: MechanicsDashboard,
    
    MobileMechanicHub: MobileMechanicHub,
    
    MyTasks: MyTasks,
    
    OnboardingDetail: OnboardingDetail,
    
    OriginalACallSheet: OriginalACallSheet,
    
    PartsInventory: PartsInventory,
    
    PerformanceReview: PerformanceReview,
    
    PreventativeMaintenance: PreventativeMaintenance,
    
    Profile: Profile,
    
    RoleManagement: RoleManagement,
    
    Schedule: Schedule,
    
    ScheduledMaintenance: ScheduledMaintenance,
    
    SendUpdateNotification: SendUpdateNotification,
    
    ServiceCallDetail: ServiceCallDetail,
    
    ServiceCallHistory: ServiceCallHistory,
    
    ServiceCalls: ServiceCalls,
    
    StaffDirectory: StaffDirectory,
    
    StringPinCallSheet: StringPinCallSheet,
    
    TaskScheduling: TaskScheduling,
    
    TechnicianPerformance: TechnicianPerformance,
    
    UserManagement: UserManagement,
    
    ViewFeedback: ViewFeedback,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<A2CallSheet />} />
                
                
                <Route path="/A2CallSheet" element={<A2CallSheet />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/BuildingMaintenance" element={<BuildingMaintenance />} />
                
                <Route path="/CompleteProfile" element={<CompleteProfile />} />
                
                <Route path="/CreateServiceCall" element={<CreateServiceCall />} />
                
                <Route path="/CustomerFeedback" element={<CustomerFeedback />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/DashboardSettings" element={<DashboardSettings />} />
                
                <Route path="/Discussion" element={<Discussion />} />
                
                <Route path="/EmployeeDashboard" element={<EmployeeDashboard />} />
                
                <Route path="/EmployeeProfile" element={<EmployeeProfile />} />
                
                <Route path="/GSXCallSheet" element={<GSXCallSheet />} />
                
                <Route path="/HelpResources" element={<HelpResources />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/InitializePermissions" element={<InitializePermissions />} />
                
                <Route path="/InviteUser" element={<InviteUser />} />
                
                <Route path="/JetbackCallSheet" element={<JetbackCallSheet />} />
                
                <Route path="/Locations" element={<Locations />} />
                
                <Route path="/MachineCallSheet" element={<MachineCallSheet />} />
                
                <Route path="/MachineDetail" element={<MachineDetail />} />
                
                <Route path="/MachineInventory" element={<MachineInventory />} />
                
                <Route path="/MachineRepairLog" element={<MachineRepairLog />} />
                
                <Route path="/ManagerDashboard" element={<ManagerDashboard />} />
                
                <Route path="/MechanicsDashboard" element={<MechanicsDashboard />} />
                
                <Route path="/MobileMechanicHub" element={<MobileMechanicHub />} />
                
                <Route path="/MyTasks" element={<MyTasks />} />
                
                <Route path="/OnboardingDetail" element={<OnboardingDetail />} />
                
                <Route path="/OriginalACallSheet" element={<OriginalACallSheet />} />
                
                <Route path="/PartsInventory" element={<PartsInventory />} />
                
                <Route path="/PerformanceReview" element={<PerformanceReview />} />
                
                <Route path="/PreventativeMaintenance" element={<PreventativeMaintenance />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/RoleManagement" element={<RoleManagement />} />
                
                <Route path="/Schedule" element={<Schedule />} />
                
                <Route path="/ScheduledMaintenance" element={<ScheduledMaintenance />} />
                
                <Route path="/SendUpdateNotification" element={<SendUpdateNotification />} />
                
                <Route path="/ServiceCallDetail" element={<ServiceCallDetail />} />
                
                <Route path="/ServiceCallHistory" element={<ServiceCallHistory />} />
                
                <Route path="/ServiceCalls" element={<ServiceCalls />} />
                
                <Route path="/StaffDirectory" element={<StaffDirectory />} />
                
                <Route path="/StringPinCallSheet" element={<StringPinCallSheet />} />
                
                <Route path="/TaskScheduling" element={<TaskScheduling />} />
                
                <Route path="/TechnicianPerformance" element={<TechnicianPerformance />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/ViewFeedback" element={<ViewFeedback />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}